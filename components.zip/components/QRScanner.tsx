import React, { useEffect, useCallback, useState } from 'react';
import { StyleSheet, View, Text, Button, TouchableOpacity } from 'react-native';
import {
	Camera,
	useCameraDevice,
	useCodeScanner,
	useCameraPermission,
	Code,
} from 'react-native-vision-camera';
import { useIsFocused } from '@react-navigation/native';
import { useIsForeground } from '@global/utils/useIsForeground';
import { TestEntity } from '@app/faastflex/DataAccess/TestAccess/TestEntity';
import { SafeAreaView } from 'react-native-safe-area-context';

interface QRScannerProps {
	scannerTitle?: string;
	onCodeScanned: (value: string) => void;
	onScannerCancelled: () => void;
	cancelButtonText: string;
}

const QRScanner: React.FC<QRScannerProps> = (props: QRScannerProps) => {
	const device = useCameraDevice('back');
	const { hasPermission, requestPermission } = useCameraPermission();
	const isFocused = useIsFocused();
	const isForeground = useIsForeground();
	const isActive = isFocused && isForeground;
	const [torchOn, setTorchOn] = useState<boolean>(false);

	useEffect(() => {
		if (!hasPermission) {
			requestPermission();
		}
	}, [hasPermission, requestPermission]);

	const onCodeScanned = useCallback(
		(codes: Code[]) => {
			const value = codes[0]?.value;
			if (value == null) return;
			console.log(`Scanned code: ${value}`);
			props.onCodeScanned(value);
		},
		[props.onCodeScanned],
	);

	const codeScanner = useCodeScanner({
		codeTypes: ['qr', 'ean-13'],
		onCodeScanned: onCodeScanned,
	});

	const toggleTorch = () => {
		setTorchOn(current => !current);
	};

	if (!hasPermission) {
		return (
			<View style={styles.container}>
				<Text style={styles.text}>Camera permission not granted</Text>
			</View>
		);
	}

	if (device == null) {
		return (
			<View style={styles.container}>
				<Text style={styles.text}>No camera device found</Text>
			</View>
		);
	}

	return (
		<View style={styles.container}>
			<SafeAreaView>
				<View
					style={[
						styles.topContainer,
						{
							height: 100,
							backgroundColor: '#000',
							alignItems: 'center',
						},
					]}>
					<Text style={styles.text}>{props.scannerTitle}</Text>
				</View>
			</SafeAreaView>
			<TouchableOpacity style={styles.torchButton} onPress={toggleTorch}>
				<Text style={styles.torchText}>Torch: {torchOn ? 'ON' : 'OFF'}</Text>
			</TouchableOpacity>

			<View style={{ marginVertical: 20 }}>
				<Camera
					style={styles.camera}
					device={device}
					isActive={isActive}
					codeScanner={codeScanner}
					enableZoomGesture={true}
					torch={torchOn ? 'on' : 'off'}
				/>
			</View>
			<View
				style={[
					styles.bottomContainer,
					{ backgroundColor: torchOn ? 'white' : 'black' },
				]}>
				<TouchableOpacity
					style={styles.cancelButton}
					onPress={props.onScannerCancelled}>
					<Text style={styles.torchText}>{props.cancelButtonText}</Text>
				</TouchableOpacity>
			</View>
		</View>
	);
};

const styles = StyleSheet.create({
	container: {
		flex: 1,
		backgroundColor: '#000',
		alignItems: 'center',
		justifyContent: 'flex-start',
	},
	topContainer: {
		justifyContent: 'center',
		alignItems: 'center',
		marginBottom: 20,
	},
	camera: {
		width: 300,
		height: 400,
	},
	bottomContainer: {
		position: 'absolute',
		bottom: 40,
		width: '100%',
		justifyContent: 'center',
		alignItems: 'center',
	},
	text: {
		color: 'white',
		fontSize: 18,
	},
	buttonsRow: {
		flexDirection: 'row',
		justifyContent: 'space-around',
		width: '100%',
		paddingHorizontal: 20,
	},
	torchButton: {
		backgroundColor: '#444',
		padding: 10,
		borderRadius: 5,
		marginRight: 10,
		justifyContent: 'center',
	},
	cancelButton: {
		backgroundColor: '#1792E5',
		padding: 10,
		borderRadius: 5,
		marginRight: 10,
		justifyContent: 'center',
	},
	torchText: {
		color: 'white',
		fontSize: 16,
	},
});

export default QRScanner;
