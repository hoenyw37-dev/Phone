import { commonColors, commonSizes } from '@styles/base';
import React from 'react';
import { StyleSheet, Text, TouchableOpacity, View } from 'react-native';

const RadioButton = ({ option, isSelected, onOptionChange }: any) => {
	return (
		<TouchableOpacity
			onPress={() => onOptionChange(option.id)}
			style={styles.wrapper}>
			<View style={[styles.radio, isSelected && styles.radioSelected]}>
				{isSelected ? <View style={styles.radioBG} /> : null}
			</View>
			<Text style={styles.radioText}>{option.text}</Text>
		</TouchableOpacity>
	);
};
const RadioButtonGroup = ({
	options,
	value,
	onChange,
	disabled = false,
}: any) => {
	return (
		<View style={styles.container}>
			{options &&
				options.map((option: any, index: any) => (
					<TouchableOpacity
						key={index}
						onPress={disabled ? undefined : () => onChange(option.value)}
						style={[styles.radioButton, disabled && styles.disabledRadioButton]}
						disabled={disabled}>
						<View style={styles.wrapper}>
							<View style={[styles.radio, disabled && styles.disabledRadio]}>
								{value === option.value ? (
									<View
										style={[styles.radioBG, disabled && styles.disabledRadioBG]}
									/>
								) : null}
							</View>
							<Text style={[styles.radioText, disabled && styles.disabledText]}>
								{option.label}
							</Text>
						</View>
					</TouchableOpacity>
				))}
		</View>
	);
};

export { RadioButton };
export { RadioButtonGroup };

const styles = StyleSheet.create({
	container: {
		flexDirection: 'row',
		alignItems: 'center',
		marginBottom: 10,
	},
	radioButton: {
		flexDirection: 'row',
		alignItems: 'center',
		marginRight: 20, // Add some space between radio buttons
	},
	wrapper: {
		flexDirection: 'row',
		alignItems: 'center',
	},
	radio: {
		height: commonSizes.textSizeL,
		width: commonSizes.textSizeL,
		borderRadius: commonSizes.textSizeL,
		borderWidth: commonSizes.lineThickness,
		borderColor: commonColors.lineColor,
		alignItems: 'center',
		justifyContent: 'center',
	},
	radioSelected: {
		borderColor: commonColors.backgroundColor_Blue,
	},
	radioBG: {
		width: commonSizes.textSizeS,
		height: commonSizes.textSizeS,
		borderRadius: commonSizes.textSizeS,
		backgroundColor: commonColors.backgroundColor_Blue,
	},
	radioText: {
		fontSize: commonSizes.textSizeM,
		color: 'black',
		marginLeft: commonSizes.widthM_Pixel,
	},
	disabledRadioButton: {
		opacity: 0.5,
	},
	disabledRadio: {
		borderColor: commonColors.lineColor,
		backgroundColor: '#f5f5f5',
	},
	disabledRadioBG: {
		backgroundColor: '#ccc',
	},
	disabledText: {
		color: '#999',
	},
});

export default RadioButton;
