import React from 'react';
import { View, Text, Modal, TouchableOpacity, StyleSheet } from 'react-native';
import DoubleButtonFooter from './doubleButtonFooter';
import { commonColors, commonSizes } from '@styles/base';

type ConfirmationModalProps = {
	visible: boolean;
	onClose: () => void;
	onProceed: () => void;
	title: string;
	description: string;
	leftButtonText: string;
	rightButtonText: string;
};

export default function ConfirmationModal(props: ConfirmationModalProps) {
	const {
		visible,
		onClose,
		onProceed,
		title,
		description,
		leftButtonText,
		rightButtonText,
	} = props;
	return (
		<Modal
			transparent
			animationType='fade'
			visible={visible}
			onRequestClose={onClose}>
			<TouchableOpacity
				style={styles.overlay}
				activeOpacity={1}
				onPress={onClose}>
				<View style={styles.popupContainer}>
					<Text style={styles.title}>{title}</Text>
					<Text style={styles.message}>{description}</Text>
					<DoubleButtonFooter
						leftButtonText={leftButtonText}
						rightButtonText={rightButtonText}
						onLeftButtonPress={onClose}
						onRightButtonPress={onProceed}
						//leftButtonStyle={styles.leftButton}
						//leftButtonTextStyle={styles.leftButtonText}
						//rightButtonStyle={styles.rightButton}
						//rightButtonTextStyle={styles.rightButtonText}
						//containerStyle={styles.container}
					/>
				</View>
			</TouchableOpacity>
		</Modal>
	);
}

const styles = StyleSheet.create({
	overlay: {
		flex: 1,
		backgroundColor: commonColors.backgroundColor_TransparentGrey,
		justifyContent: 'center',
		alignItems: 'center',
	},
	popupContainer: {
		width: '80%',
		paddingHorizontal: commonSizes.paddingXL_Percent,
		paddingTop: commonSizes.paddingXL_Percent,
		backgroundColor: commonColors.backgroundColor_White,
		borderRadius: commonSizes.cornerRadius,
		shadowColor: commonColors.textColor_Black,
		shadowOffset: { width: 0, height: 2 },
		shadowOpacity: 0.8,
		shadowRadius: 2,
		elevation: 5,
	},
	title: {
		fontSize: commonSizes.textSizeL,
		fontWeight: '800',
		color: commonColors.textColor_Black,
	},
	message: {
		fontSize: commonSizes.textSizeM,
		color: commonColors.textColor_Black,
		marginTop: '5%',
		marginBottom: '5%',
	},
});
