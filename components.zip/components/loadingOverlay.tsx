import React from 'react';
import { ActivityIndicator, StyleSheet, Text, View } from 'react-native';
import { useLoading } from '../global/GlobalContext/LoadingContext.tsx';

export const LoadingOverlay = () => {
	const { isLoading, loadingMessage } = useLoading();

	if (!isLoading) return null;

	return (
		<View style={styles.container}>
			<View style={styles.loadingBox}>
				<ActivityIndicator size='large' color='#ffffff' />
				<Text style={styles.text}>{loadingMessage}</Text>
			</View>
		</View>
	);
};

const styles = StyleSheet.create({
	container: {
		position: 'absolute',
		top: 0,
		left: 0,
		right: 0,
		bottom: 0,
		justifyContent: 'center',
		alignItems: 'center',
		backgroundColor: 'rgba(0, 0, 0, 0.7)',
		zIndex: 999,
	},
	loadingBox: {
		padding: 20,
		backgroundColor: 'rgba(50, 50, 50, 0.8)',
		borderRadius: 10,
		alignItems: 'center',
		justifyContent: 'center',
	},
	text: {
		color: 'white',
		marginTop: 10,
		fontSize: 16,
	},
});
