import React from 'react';
import { View, ActivityIndicator, StyleSheet } from 'react-native';

const CustomActivityIndicator = () => (
	<View style={styles.overlay}>
		<ActivityIndicator size='large' color='#0096FF' />
	</View>
);

const styles = StyleSheet.create({
	overlay: {
		...StyleSheet.absoluteFillObject, // Covers the entire screen
		justifyContent: 'center',
		alignItems: 'center',
		backgroundColor: 'rgba(0, 0, 0, 0.5)', // Semi-transparent overlay
		zIndex: 999, // Ensures it appears above other content
	},
});

export { CustomActivityIndicator };
