import React, { ReactNode } from 'react';
import {
	Modal,
	View,
	Text,
	StyleSheet,
	StyleProp,
	TextStyle,
} from 'react-native';
import DoubleButtonFooter from './doubleButtonFooter';
import { commonColors, commonSizes } from '@styles/base';

type CommonModalUIProps = {
	modalVisible: boolean;
	closeModal: () => void;
	leftButtonText: string;
	rightButtonText: string;
	onLeftButtonPress: () => void;
	onRightButtonPress: () => void;
	titleText: string;
	titleTextExtraStyle?: StyleProp<TextStyle>;
	children: ReactNode;
};

const CommonModalUI = (props: CommonModalUIProps) => {
	return (
		<Modal
			animationType='fade'
			transparent={true}
			visible={props.modalVisible}
			onRequestClose={props.closeModal}>
			<View style={CommonModalUIStyles.modalContainer}>
				<View style={CommonModalUIStyles.modalContent}>
					<View>
						<Text
							style={[
								CommonModalUIStyles.titleText,
								props.titleTextExtraStyle,
							]}>
							{props.titleText}
						</Text>
					</View>
					{/* <View style={CommonModalUIStyles.horizontalLine} /> */}
					{props.children}
					<DoubleButtonFooter
						leftButtonText={props.leftButtonText}
						rightButtonText={props.rightButtonText}
						onLeftButtonPress={props.onLeftButtonPress}
						onRightButtonPress={props.onRightButtonPress}
					/>
				</View>
			</View>
		</Modal>
	);
};

const CommonModalUIStyles = StyleSheet.create({
	modalContainer: {
		flex: 1,
		justifyContent: 'center',
		alignItems: 'center',
		backgroundColor: commonColors.backgroundColor_TransparentGrey,
	},
	modalContent: {
		width: '80%',
		paddingHorizontal: commonSizes.paddingXL_Percent,
		paddingTop: commonSizes.paddingXL_Percent,
		backgroundColor: commonColors.backgroundColor_White,
		borderRadius: commonSizes.cornerRadius,
		shadowColor: commonColors.textColor_Black,
		shadowOffset: { width: 0, height: 2 },
		shadowOpacity: 0.8,
		shadowRadius: 2,
		elevation: 5,
	},
	titleText: {
		fontSize: commonSizes.textSizeXL,
		fontWeight: '500',
		color: commonColors.textColor_Black,
		// marginTop: '3%',
	},
});

export default CommonModalUI;
