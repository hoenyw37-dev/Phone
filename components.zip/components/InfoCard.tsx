import { commonColors, commonSizes } from '@styles/base';
import React, { View, Text, StyleSheet } from 'react-native';

interface InfoCardProps {
	heading?: string;
	description: string;
}

export default function InfoCard({ heading, description }: InfoCardProps) {
	return (
		<View
			style={[
				styles.box,
				heading ? styles.withHeading : styles.withoutHeading,
			]}>
			{heading && <Text style={styles.heading}>{heading}</Text>}
			<Text style={styles.description}>{description}</Text>
		</View>
	);
}

const styles = StyleSheet.create({
	box: {
		backgroundColor: commonColors.backgroundColor_White,
		justifyContent: 'space-between',
	},
	withHeading: {
		padding: commonSizes.paddingXL_Percent,
	},
	withoutHeading: {
		padding: commonSizes.paddingS_Percent,
		paddingLeft: commonSizes.widthL_Pixel,
	},
	heading: {
		fontSize: commonSizes.textSizeM,
		fontWeight: '900',
		color: commonColors.textColor_Black,
	},
	description: {
		fontSize: commonSizes.textSizeS,
		fontWeight: '400',
		color: commonColors.textColor_Black,
		marginTop: commonSizes.heightXS_Pixel,
	},
});
