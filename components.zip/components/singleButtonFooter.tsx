import React, { useEffect, useState } from 'react';
import { View, StyleSheet, Dimensions, Text, Pressable } from 'react-native';
import { SingleFooterProps } from './../types/footerProps';
import { getFontSize } from '@global/dynamicFont';
import { commonColors, commonSizes } from '@styles/base';

export default function SingleButtonFooter(props: SingleFooterProps) {
	const {
		buttonText,
		onButtonPress,
		buttonDisabled = false,
		buttonStyle,
		buttonTextStyle,
		containerStyle,
	} = props;
	const [fontSizes, setFontSizes] = useState({
		buttonTextSize: getFontSize(17),
		// Add other font sizes as needed
	});
	useEffect(() => {
		const handleDimensionsChange = () => {
			setFontSizes({
				buttonTextSize: getFontSize(17),
				// Update other font sizes as needed
			});
		};

		const subscription = Dimensions.addEventListener(
			'change',
			handleDimensionsChange,
		);

		return () => {
			subscription?.remove();
		};
	}, []);
	return (
		<View style={[containerStyle]}>
			{/* <View style={styles.horizontalLine} /> */}
			<View style={styles.buttonRow}>
				<Pressable
					style={[styles.button, buttonStyle]}
					onPress={onButtonPress}
					disabled={buttonDisabled}>
					<Text
						style={[
							styles.buttonText,
							{ fontSize: fontSizes.buttonTextSize },
							buttonTextStyle,
						]}>
						{buttonText}
					</Text>
				</Pressable>
			</View>
		</View>
	);
}

const styles = StyleSheet.create({
	horizontalLine: {
		height: 1,
		backgroundColor: commonColors.lineColor,
	},
	buttonRow: {
		marginTop: commonSizes.heightS_Pixel,
		marginBottom: commonSizes.heightS_Pixel,
	},
	button: {
		borderColor: commonColors.textColor_Blue,
		borderWidth: commonSizes.lineThickness,
		alignItems: 'center',
		justifyContent: 'center',
		height: commonSizes.heightXL_Pixel,
		borderRadius: commonSizes.cornerRadius,
		// shadowColor: commonColors.shadowColor,
		// shadowOffset: {width: 0, height: 2},
		// shadowOpacity: 0.1,
		// shadowRadius: 4,
		// elevation: 2,
	},
	buttonText: {
		color: commonColors.textColor_Blue,
		fontWeight: 'bold',
		textAlign: 'center',
	},
});
