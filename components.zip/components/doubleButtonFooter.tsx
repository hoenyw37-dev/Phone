import React, { useEffect, useState } from 'react';
import {
	View,
	StyleSheet,
	Dimensions,
	Pressable,
	Text,
	SafeAreaView,
} from 'react-native';
import { DoubleFooterProps } from './../types/footerProps';
import { getFontSize } from '@global/dynamicFont';
import { commonColors, commonSizes } from '@styles/base';

export default function DoubleButtonFooter(props: DoubleFooterProps) {
	const {
		leftButtonText,
		rightButtonText,
		onLeftButtonPress,
		onRightButtonPress,
		leftButtonDisabled = false,
		rightButtonDisabled = false,
		leftButtonStyle,
		leftButtonTextStyle,
		rightButtonStyle,
		rightButtonTextStyle,
		containerStyle,
	} = props;

	const enabledButtonOpacity = 1;
	const disabledButtonOpacity = 0.4;

	const [fontSizes, setFontSizes] = useState({
		buttonTextSize: getFontSize(17),
		// Add other font sizes as needed
	});
	useEffect(() => {
		const handleDimensionsChange = () => {
			setFontSizes({
				buttonTextSize: getFontSize(17),
				// Update other font sizes as needed
			});
		};

		const subscription = Dimensions.addEventListener(
			'change',
			handleDimensionsChange,
		);

		return () => {
			subscription?.remove();
		};
	}, []);
	return (
		<View style={[containerStyle]}>
			{/* <View style={styles.horizontalLine} /> */}
			<View style={styles.buttonRow}>
				<Pressable
					style={[
						styles.button,
						styles.buttonLeft,
						{
							opacity: leftButtonDisabled
								? disabledButtonOpacity
								: enabledButtonOpacity,
						},
						leftButtonStyle,
					]}
					onPress={onLeftButtonPress}
					disabled={leftButtonDisabled}>
					<Text
						style={[
							styles.buttonLeftText,
							{ fontSize: fontSizes.buttonTextSize },
							leftButtonTextStyle,
						]}>
						{leftButtonText}
					</Text>
				</Pressable>
				<Pressable
					style={[
						styles.button,
						styles.buttonRight,
						{
							opacity: rightButtonDisabled
								? disabledButtonOpacity
								: enabledButtonOpacity,
						},
						rightButtonStyle,
					]}
					onPress={onRightButtonPress}
					disabled={rightButtonDisabled}>
					<Text
						style={[
							styles.buttonRightText,
							{ fontSize: fontSizes.buttonTextSize },
							rightButtonTextStyle,
						]}>
						{rightButtonText}
					</Text>
				</Pressable>
			</View>
		</View>
	);
}

const styles = StyleSheet.create({
	horizontalLine: {
		height: 1,
		backgroundColor: commonColors.lineColor,
	},
	buttonRow: {
		flexDirection: 'row',
		justifyContent: 'space-between',
		width: '100%',
		marginTop: commonSizes.heightS_Pixel,
		marginBottom: commonSizes.heightS_Pixel,
	},
	button: {
		width: '48%',
		borderWidth: commonSizes.lineThickness,
		alignItems: 'center',
		justifyContent: 'center',
		height: commonSizes.heightXL_Pixel,
		borderRadius: commonSizes.cornerRadius,
		shadowColor: commonColors.shadowColor,
		shadowOffset: { width: 0, height: 2 },
		shadowOpacity: 0.1,
		shadowRadius: 4,
		elevation: 2,
	},
	buttonLeft: {
		backgroundColor: commonColors.backgroundColor_White,
		borderColor: commonColors.textColor_Blue,
	},
	buttonRight: {
		backgroundColor: commonColors.textColor_Blue,
		borderColor: commonColors.textColor_Blue,
	},
	buttonLeftText: {
		color: commonColors.textColor_Blue,
		fontWeight: 'bold',
		textAlign: 'center',
	},
	buttonRightText: {
		color: commonColors.backgroundColor_White,
		fontWeight: 'bold',
		textAlign: 'center',
	},
});
