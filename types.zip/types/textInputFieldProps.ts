import { Control } from 'react-hook-form';

export type TextInputFieldProps = {
	name: string;
	control: Control<any>;
	placeholder: string;
	title?: string;
	isRequired?: Boolean;
	errorMessage?: string;
	maxChar?: number;
};
