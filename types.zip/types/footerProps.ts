export type DoubleFooterProps = {
	leftButtonText: string;
	rightButtonText: string;
	onLeftButtonPress: () => void;
	onRightButtonPress: () => void;
	// Optional props for additional customization
	leftButtonDisabled?: boolean;
	rightButtonDisabled?: boolean;
	leftButtonStyle?: object;
	leftButtonTextStyle?: object;
	rightButtonStyle?: object;
	rightButtonTextStyle?: object;
	containerStyle?: object;
	dividerLine?: boolean;
};

export type SingleFooterProps = {
	buttonText: string;
	onButtonPress: () => void;
	// Optional props for additional customization
	buttonDisabled?: boolean;
	buttonStyle?: object;
	buttonTextStyle?: object;
	containerStyle?: object;
};
