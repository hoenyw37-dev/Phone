import 'intl-pluralrules';
import i18n from 'i18next';
import { initReactI18next } from 'react-i18next';
import en from './locales/en.json';
import es from './locales/es.json';
import fr from './locales/fr.json';
import de from './locales/de.json';
import it from './locales/it.json';
import ko from './locales/ko.json';
import pl from './locales/pl.json';
import zh from './locales/zh.json';

i18n.use(initReactI18next).init({
	resources: {
		en: { translation: en },
		es: { translation: es },
		fr: { translation: fr },
		de: { translation: de },
		it: { translation: it },
		ko: { translation: ko },
		pl: { translation: pl },
		zh: { translation: zh },
	},
	lng: 'en', // default language
	fallbackLng: 'en',
	interpolation: {
		escapeValue: false,
	},
});

export default i18n;
