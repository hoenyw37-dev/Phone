import {
	Configuration,
	Country,
	DeviceStatus,
	DeviceType,
	RelayEnabled,
} from '../faastflexCommands/commandEnum';

export interface FaastFlexDeviceStatus {
	DeviceStatus: DeviceStatus;
	Channels: number;
	Country: Country;
	LEDStatus: string[];
	DeviceConfiguration: Configuration;
	RelayEnabled: RelayEnabled;
	DeviceType: DeviceType;
}
