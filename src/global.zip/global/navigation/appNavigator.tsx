import React from 'react';
import {
	View,
	ActivityIndicator,
	StyleSheet,
	Text,
	ImageBackground,
} from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { useTranslation } from 'react-i18next';
import { useAuth } from '@base/auth/authContext';

import ProjectHome from '@base/projects/screens/projectHome';
import ProjectList from '@base/projects/screens/projectList';
import AddProject from '@base/projects/screens/addProject';
import EditProject from '@base/projects/screens/editProject';
import { Powerstrike } from '@powerstrike/powerstrike';
import AboutUs from '@base/about/screens/aboutUs';
import ContactUs from '@base/about/screens/contactUs';
import LanguageSelector from '@base/projects/screens/languageSelector';
import LicenseAgreementModal from '@base/eula/screens/LicenseAgreementModal';
import TermsAndConditions from '@base/eula/screens/TermsAndConditions';
import LoginScreen from '@base/auth/loginScreen';
import Toast from 'react-native-toast-message';
import { FaastflexNavigation } from '@faastflex/navigation/faastflexNavigation';

const Stack = createNativeStackNavigator();

const AppNavigator = () => {
	const { t } = useTranslation();
	const { isLoading } = useAuth();

	if (isLoading) {
		return (
			<ImageBackground
				style={styles.backgroudImageContainer}
				source={require('@assets/images/WelcomeScreenImage.png')}>
				<View style={styles.container}>
					<ActivityIndicator size='large' color='#0078d4' />
					<Text style={styles.text}>Authenticating...</Text>
				</View>
			</ImageBackground>
		);
	}

	return (
		<NavigationContainer>
			<Stack.Navigator
				initialRouteName='LicenseAgreementModal'
				screenOptions={{
					headerStyle: {
						backgroundColor: '#101010',
					},
					headerTintColor: 'white',
				}}>
				{/* <Stack.Screen
                                name="AppIndex"
                                component={AppIndex}
                                options={{
                                    headerShown: false,
                                }}
                            /> */}
				<Stack.Screen
					name='ProjectList'
					component={ProjectList}
					options={{
						headerShown: false,
					}}
				/>
				<Stack.Screen
					name='LoginScreen'
					component={LoginScreen}
					options={{
						headerShown: false,
						headerBackVisible: false,
					}}
				/>
				<Stack.Screen
					name='ProjectHome'
					component={ProjectHome}
					options={{
						headerShown: false,
					}}
				/>
				<Stack.Screen
					name='AddProject'
					component={AddProject}
					options={{ title: 'New Project', headerShown: false }}
				/>
				<Stack.Screen
					name='EditProject'
					component={EditProject}
					options={{ title: 'Edit Project', headerShown: false }}
				/>
				{Powerstrike()}
				{FaastflexNavigation()}
				<Stack.Screen
					name='AboutUs'
					component={AboutUs}
					options={{ title: 'About Us', headerShown: false }}
				/>
				<Stack.Screen
					name='ContactUs'
					component={ContactUs}
					options={{ title: 'Contact Us', headerShown: false }}
				/>
				<Stack.Screen
					name='LanguageSelector'
					component={LanguageSelector}
					options={{ headerShown: false }}
				/>
				<Stack.Screen
					name='LicenseAgreementModal'
					component={LicenseAgreementModal}
					options={{
						headerShown: false,
					}}
				/>
				<Stack.Screen
					name='TermsAndConditions'
					component={TermsAndConditions}
					options={{ title: 'Terms And Conditions', headerShown: false }}
				/>
			</Stack.Navigator>
			<Toast />
		</NavigationContainer>
	);
};

export default AppNavigator;

const styles = StyleSheet.create({
	container: {
		flex: 1,
		justifyContent: 'center',
		alignItems: 'center',
	},
	text: {
		marginTop: 15,
		fontSize: 16,
		color: '#333',
		fontWeight: '600',
	},
	backgroudImageContainer: {
		flex: 1,
		resizeMode: 'cover',
	},
});
