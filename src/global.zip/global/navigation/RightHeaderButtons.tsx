import React from 'react';
import { Text, View, TouchableOpacity, Button, Dimensions } from 'react-native';
import {
	Menu,
	MenuOptions,
	MenuOption,
	MenuTrigger,
	renderers,
} from 'react-native-popup-menu';

import SearchIconWhite from '@assets/images/SearchIconWhite.svg';
import AddIconWhite from '@assets/images/AddIconWhite.svg';
import TripleDotIconWhite from '@assets/images/TripleDotIconWhite.svg';
import { commonColors, commonSizes, commonStyles } from '@styles/base';

const { width, height } = Dimensions.get('window');
const iconWidth =
	width > 600 ? commonSizes.iconWidthS_Pixel : commonSizes.iconWidthM_Pixel;
const iconHeight =
	height > 1000 ? commonSizes.iconHeightS_Pixel : commonSizes.iconHeightM_Pixel;

export default function HeaderRight({ buttons }) {
	//console.log('buttons', buttons);
	return (
		<View
			style={{
				flexDirection: 'row',
				alignItems: 'center',
			}}>
			{buttons.map((button, index: number) => {
				if (button.type === 'addIcon') {
					return (
						<TouchableOpacity
							key={index}
							onPress={button.onPress}
							style={{ marginRight: commonSizes.widthXXL_Pixel }}>
							<AddIconWhite width={iconWidth} height={iconHeight} />
						</TouchableOpacity>
					);
				} else if (button.type === 'menu') {
					return (
						<Menu key={index} renderer={renderers.Popover}>
							<MenuTrigger>
								{/*<Text style={{color:'white'}}>icon 2</Text>*/}
								<View style={commonStyles.boxClickableMenu}>
									<TripleDotIconWhite width={iconWidth} height={iconHeight} />
								</View>
							</MenuTrigger>
							<MenuOptions>
								{button.options.map((option, optIndex) => (
									<MenuOption key={optIndex} onSelect={option.onSelect}>
										<View style={commonStyles.boxMenuPopUp}>
											<Text
												style={{
													padding: commonSizes.widthS_Pixel,
													color: commonColors.textColor_Black,
													fontSize: commonSizes.textSizeS,
												}}>
												{option.label}
											</Text>
										</View>
									</MenuOption>
								))}
							</MenuOptions>
						</Menu>
					);
				} else if (button.type === 'searchIcon') {
					return (
						<TouchableOpacity
							key={index}
							onPress={button.onPress}
							style={{ marginRight: 20 }}>
							<SearchIconWhite
								width={commonSizes.iconWidthM_Pixel}
								height={commonSizes.iconHeightM_Pixel}
							/>
						</TouchableOpacity>
					);
				} else if (button.type === 'textButton') {
					return (
						<TouchableOpacity
							key={index}
							onPress={button.onPress}
							style={{ marginRight: 20 }}>
							<Text style={{ color: commonColors.textColor_White }}>
								{button.text}
							</Text>
						</TouchableOpacity>
					);
				}
				return null;
			})}
		</View>
	);
}
