import { useState, useRef, useCallback } from 'react';

/**
 * A custom hook that keeps a state and ref in sync
 * @param initialValue - The initial value for both state and ref
 * @returns A tuple containing [currentState, updateFunction, ref]
 */
function useSyncedState<T>(initialValue: T) {
	const [state, setState] = useState<T>(initialValue);
	const ref = useRef<T>(initialValue);

	const updateState = useCallback((updates: T | Partial<T>) => {
		let updatedState: T;

		if (updates === null) {
			updatedState = updates as T;
		} else if (updates === undefined) {
			updatedState = ref.current;
		} else if (typeof updates === 'object' && typeof ref.current === 'object') {
			if (ref.current === null) {
				updatedState = updates as T;
			} else {
				updatedState = { ...ref.current, ...updates } as T;
			}
		} else {
			updatedState = updates as T;
		}

		ref.current = updatedState;
		setState(updatedState);

		return updatedState;
	}, []);

	return [state, updateState, ref] as const;
}

export default useSyncedState;
