export interface BaseDataModel {
	id: number;
	user: string;
	lastModifiedDate: string;
	isUpdated: boolean;
}
export enum TransactionType {
	Save = 'Save',
	Update = 'Update',
	Delete = 'Delete',
	Get = 'Get',
	GetAll = 'GetAll',
}

export enum DatabaseOperation {
	Save = 'Save',
	Update = 'Update',
	Delete = 'Delete',
	Get = 'Get',
	GetAll = 'GetAll',
}
