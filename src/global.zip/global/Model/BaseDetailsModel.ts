import { BaseDataModel } from './BaseDataModel.ts';

export interface BaseDetailsModel extends BaseDataModel {
	// Additional base properties for detail models
}
