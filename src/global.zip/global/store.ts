import { configureStore, createAsyncThunk } from '@reduxjs/toolkit';
import projectsReducer from '../app/base/projects/redux/projectsSlice';
import panelsReducer from '../app/powerstrike/features/panels/redux/panelsSlice';
import templatesReducer from '../app/powerstrike/features/switches/redux/templatesSlice';
import devicessReducer from '@ff_redux/deviceRedux/devicesSlice';
import testsReducer from '@ff_redux/testRedux/testsSlice';
import testHistoryReducer from '@ff_redux/testHistoryRedux/testHistorySlice';
import deviceParameterReducer from '@ff_redux/deviceParameterRedux/deviceParameterSlice';
import eventLogReducer from '@ff_redux/eventLogRedux/eventLogSlice';

export const store = configureStore({
	reducer: {
		projects: projectsReducer,
		panels: panelsReducer,
		templates: templatesReducer,
		devices: devicessReducer,
		tests: testsReducer,
		testHistory: testHistoryReducer,
		deviceParameter: deviceParameterReducer,
		eventLog: eventLogReducer,
	},
	middleware: getDefaultMiddleware =>
		getDefaultMiddleware({
			serializableCheck: false,
		}),
});

export type AppStore = typeof store;
// Infer the `RootState` and `AppDispatch` types from the store itself
export type RootState = ReturnType<typeof store.getState>;
// Inferred type
export type AppDispatch = typeof store.dispatch;

export const createAppAsyncThunk = createAsyncThunk.withTypes<{
	state: RootState;
	dispatch: AppDispatch;
}>();
