type Listener = (...args: any[]) => void;

class EventHandler {
	private events: Record<string, Listener[]> = {};

	subscribe(event: string, callback: Listener): () => void {
		if (!this.events[event]) {
			this.events[event] = [];
		}
		this.events[event].push(callback);

		return () => {
			this.events[event] = this.events[event].filter(cb => cb !== callback);
		};
	}

	publish(event: string, ...args: any[]): void {
		if (this.events[event]) {
			this.events[event].forEach(callback => callback(...args));
		}
	}
}

export const eventHandler = new EventHandler();
