import React, { createContext, useState, useContext, ReactNode } from 'react';

interface LoadingContextType {
	showLoadingIndicator: (message?: string) => void;
	hideLoadingIndicator: () => void;
	isLoading: boolean;
	loadingMessage: string;
}

const LoadingContext = createContext<LoadingContextType | undefined>(undefined);

export const LoadingProvider = ({ children }: { children: ReactNode }) => {
	const [isLoading, setIsLoading] = useState(false);
	const [loadingMessage, setLoadingMessage] = useState('');

	const showLoadingIndicator = (message: string = '') => {
		setLoadingMessage(message);
		setIsLoading(true);
	};

	const hideLoadingIndicator = () => {
		setIsLoading(false);
		setLoadingMessage('');
	};

	return (
		<LoadingContext.Provider
			value={{
				isLoading,
				loadingMessage,
				showLoadingIndicator: showLoadingIndicator,
				hideLoadingIndicator,
			}}>
			{children}
		</LoadingContext.Provider>
	);
};

export const useLoading = (): LoadingContextType => {
	const context = useContext(LoadingContext);
	if (context === undefined) {
		throw new Error('useLoading must be used within a LoadingProvider');
	}
	return context;
};
