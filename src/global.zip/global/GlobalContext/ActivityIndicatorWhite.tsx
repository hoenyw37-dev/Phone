import React from 'react';
import { Modal, View, ActivityIndicator, Text, StyleSheet } from 'react-native';

interface ActivityIndicatorWhiteProps {
	visible: boolean;
	message?: string;
	indicatorColor?: string;
	indicatorSize?: 'small' | 'large';
	onRequestClose?: () => void;
}

const ActivityIndicatorWhite: React.FC<ActivityIndicatorWhiteProps> = ({
	visible,
	message = 'Please wait, connecting...',
	indicatorColor = '#0000ff',
	indicatorSize = 'large',
	onRequestClose,
}) => {
	return (
		<Modal
			visible={visible}
			transparent={true}
			animationType='fade'
			onRequestClose={onRequestClose}>
			<View style={styles.overlay}>
				<View style={styles.container}>
					<ActivityIndicator size={indicatorSize} color={indicatorColor} />
					<Text style={styles.message}>{message}</Text>
				</View>
			</View>
		</Modal>
	);
};

const styles = StyleSheet.create({
	overlay: {
		flex: 1,
		backgroundColor: 'rgba(0,0,0,0.4)',
		justifyContent: 'center',
		alignItems: 'center',
	},
	container: {
		backgroundColor: '#fff',
		padding: 30,
		borderRadius: 10,
		alignItems: 'center',
	},
	message: {
		marginTop: 15,
		fontSize: 16,
	},
});

export default ActivityIndicatorWhite;
