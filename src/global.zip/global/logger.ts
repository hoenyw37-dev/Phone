import {
	logger,
	mapConsoleTransport,
	fileAsyncTransport,
} from 'react-native-logs';
import RNFS from 'react-native-fs';

//set to true/false to enable/disable file logging
var fileLogging: boolean = true;

const config = {
	transport: fileLogging
		? [mapConsoleTransport, fileAsyncTransport]
		: [mapConsoleTransport],
	transports: {},
	levels: {
		debug: 0,
		info: 1,
		warn: 2,
		error: 3,
	},
	transportOptions: {
		FS: RNFS,
		fileName: `smartconfig-logs_{date-today}.log`,
		filePath: RNFS.DocumentDirectoryPath,
		mapLevels: {
			debug: 'log',
			info: 'info',
			warn: 'warn',
			err: 'error',
		},
	},
};
const log = logger.createLogger(config);

const debug = (message: any) => {
	log.debug(message.toString());
};

const info = (message: any) => {
	log.info(message.toString());
};

const warn = (message: any) => {
	log.warn(message.toString());
};

const error = (message: any) => {
	log.error(message.toString());
};

export default {
	debug,
	info,
	warn,
	error,
	fileLogging,
};

//to use the logger, import this "log" object use "log.debug('message')", "log.info('message')", "log.warn('message')", "log.error('message')"
//directory path for logs: Android: /data/user/0/com.smartconfigx/files
