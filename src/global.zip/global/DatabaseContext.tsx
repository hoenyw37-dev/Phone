import React, {
	useState,
	useEffect,
	useContext,
	createContext,
	useCallback,
} from 'react';
import { View } from 'react-native';
import { DataSource } from 'typeorm/browser';
//import { createTables } from './createTables';
import { ProjectEntity } from '../app/base/projects/dataAccess/projectEntity';
import { PanelEntity } from '../app/powerstrike/features/panels/dataAccess/panelEntity';
import { TemplateEntity } from '../app/powerstrike/features/switches/dataAccess/templateEntity';
import { DeviceEntity } from '@ff_dataAccess/deviceAccess/deviceEntity';
import { TestHistoryEntity } from '@ff_dataAccess/testHistoryAccess/testHistoryEntity';
import { TestEntity } from '@ff_dataAccess/testAccess/testEntity';
import { EventLogEntity } from '@ff_dataAccess/logsAccess/logEntity';
import { DeviceParameterEntity } from '@ff_dataAccess/deviceParametersDataAccess/deviceParameterEntity';

type DatabaseContextType = {
	dataSource: DataSource;
};

const DatabaseContext = createContext<DatabaseContextType | undefined>(
	undefined,
);
export const useDatabase = (): DatabaseContextType => {
	const context = useContext(DatabaseContext);
	if (context === undefined) {
		throw new Error('useDatabase must be used within a DatabaseProvider');
	}
	return context;
};

export const DatabaseProvider = ({ children }: any) => {
	const [dataSource, setDataSource] = useState<DataSource | null>(null);

	const getDataSource = useCallback(async () => {
		const AppDataSource = new DataSource({
			type: 'react-native',
			database: 'test',
			location: 'default',
			logging: ['error', 'query', 'schema'],
			synchronize: true,
			entities: [
				ProjectEntity,
				PanelEntity,
				TemplateEntity,
				DeviceEntity,
				TestEntity,
				TestHistoryEntity,
				EventLogEntity,
				DeviceParameterEntity,
			],
		});
		AppDataSource.initialize()
			.then(() => {
				setDataSource(AppDataSource);
				console.log('Data Source has been initialized!');
			})
			.catch(err => {
				console.error('Error during Data Source initialization', err);
			});
	}, []);

	useEffect(() => {
		console.log('DatabaseContext!!!!!!!!!!!!!!');
		if (!dataSource) {
			getDataSource();
		}
	}, [getDataSource, dataSource]);

	if (!dataSource) {
		return (
			<View
				style={{
					flex: 1,
					justifyContent: 'center',
					alignItems: 'center',
				}}></View>
		);
	}

	return (
		<DatabaseContext.Provider value={{ dataSource }}>
			{children}
		</DatabaseContext.Provider>
	);
};

/* Context Provider for SQLite
import React, { useState, useEffect, useContext, createContext, ReactNode } from "react";
import SQLite from 'react-native-sqlite-storage';
import { View, Text, ActivityIndicator } from "react-native";
import { createTables } from './createTables';

type DatabaseContextType = {
    db: SQLite.SQLiteDatabase;
};

const DatabaseContext = createContext<DatabaseContextType | undefined>(undefined);
export const useDatabase = (): DatabaseContextType => {
    const context = useContext(DatabaseContext);
    if (context === undefined) {
        throw new Error('useDatabase must be used within a DatabaseProvider');
    }
    return context;
};

export const DatabaseProvider = ({ children }) => {

    const [db, setDb] = useState<SQLite.SQLiteDatabase | null>(null);

    const getDatabase = async () => {
        try {
            const dbInstance = await SQLite.openDatabase(
                { name: 'appInfo.db', location: 'default' },
                () => {
                    console.log('Database opened successfully');
                    setDb(dbInstance); // Set the DB once it's initialized
                },
                (error) => {
                    console.error('Error opening database:', error);
                }
            );
            //console.log(dbInstance);
            await createTables(dbInstance);
        } catch (error) {
            console.error('Error initializing database:', error);
        }
    }

    useEffect(() => {
        getDatabase();
    }, [])

    if (!db) {
        return (
            <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
                <Text>Loading Database...</Text>
            </View>
        );
    }

    return (
        <DatabaseContext.Provider value={{ db }}>
            { children }
        </DatabaseContext.Provider>
    )
}*/
