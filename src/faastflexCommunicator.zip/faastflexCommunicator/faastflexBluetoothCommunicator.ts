import {
	AlarmFaultStatus,
	AlarmLevel,
	AlarmMode,
	Channel,
	Configuration,
	Country,
	DeviceAuthenticated,
	DeviceOrientation,
	DeviceStatus,
	DeviceType,
	ErrorCode,
	ExternalInputAction,
	ExternalInputMode,
	ExternalInputNormalState,
	FanPWMPercCorrection,
	FanSpeedLevel,
	getAlarmFaultStatusDescription,
	getDeviceOrientationDescription,
	getDeviceTypeDescription,
	getModelTypeDescription,
	LatchedMode,
	PasswordValid,
	PreAlarmLevel,
	RelayAlert,
	RelayEnabled,
} from '../faastflexCommands/commandEnum';
import { FaastFlexDeviceStatus } from '../faastflexCommandModel/faastflexResponseParserModel';

import { useBLE } from '../bleCommunicator/bleContext';
import { FaastFlexDeviceStatusLowerFirmware } from '../faastflexCommands/command_ffDeviceStatus';
import { FaastFlexDeviceStatus22 } from '../faastflexCommands/command_ffDeviceStatus22';
import {
	startManualPairing,
	startManualPairingAnswer,
} from '../faastflexCommands/command_bleManualPairing';
import { FaastFlexDeviceMode } from '../faastflexCommands/command_getDeviceMode';
import { FaastFlexDeviceType } from '../faastflexCommands/command_getDeviceType';
import { FaastFlexSerialNumber } from '../faastflexCommands/command_getSerialNumber';
import { FaastFlexProductionDate } from '../faastflexCommands/command_getProductionDate';
import { FaastFlexFirmwareVersion } from '../faastflexCommands/command_getFirmwareVersion';
import { FaastFlexModelType } from '../faastflexCommands/command_getModelType';
import { FaastFlexSelfTestChina } from '../faastflexCommands/command_selftestForChina';
import { FaastFlexSilenceDeviceBuzzerChina } from '../faastflexCommands/command_SilenceDeviceBuzzerChina';
import { FaastFlexDisableDevice } from '../faastflexCommands/command_DisableFaastFlexDevice';
import { parse, format as dateFormat } from 'date-fns';
import { enGB, is } from 'date-fns/locale';
import { FaastFlexLEDStatus } from '../faastflexCommands/comand_getLEDStatus';
import { FaastFlexChannelsAndSensorsParameters } from '../faastflexCommands/command_getChannelsAndSensorsParams';
import { FaastFlexGetDeviceConfiguration } from '../faastflexCommands/command_getDeviceConfiguration';
import { FaastFlexDeviceMeasures } from '../faastflexCommands/command_getDeviceMeasures';
import { FaastFlexDeviceOrientation } from '../faastflexCommands/command_getDeviceOrientation';
import { FaastFlexGetDeviceRelayEnabled } from '../faastflexCommands/command_getDeviceRelayEnabled';
import { FaastFlexGeneralParameters } from '../faastflexCommands/command_getGeneralParameters';
import { FaastFlexGetPowerVoltage } from '../faastflexCommands/command_getPowerVoltage';
import { FaastFlexGPIParameters } from '../faastflexCommands/command_GPIParameters';
import { DeviceGPIParams } from '../faastflexCommands/common_objects';
import {
	IEventLogData,
	FaastFlexLogs,
	getLogEventTypeDescription,
	LogEventType,
	getLogEventIdDescription,
	getLogEventZoneDescription,
} from '../faastflexCommands/command_log';
import { FaastFlexResetDevice } from '../faastflexCommands/command_resetDevice';
import { FaastFlexSelfTestEurope } from '../faastflexCommands/command_selftestEurope';
import { FaastFlexSendPasswordToDevice } from '../faastflexCommands/command_sendFaastflexDevicePassword';
import { FaastFlexSetAlarmDelay } from '../faastflexCommands/command_setAlarmDelay';
import { FaastFlexSetAlarmLatched } from '../faastflexCommands/command_setAlarmLatched';
import { FaastFlexSetAlarmMode } from '../faastflexCommands/command_setAlarmMode';
import { FaastFlexSetBlowerSpeed } from '../faastflexCommands/command_setBlowerSpeed';
import { FaastFlexSetBlowerSpeedCorrection } from '../faastflexCommands/command_setBlowerSpeedCorrection';
import { FaastFlexSetChannelAlarmLevel } from '../faastflexCommands/command_setChannelAlarmLevel';
import { FaastFlexSetChannelPreAlarmLevel } from '../faastflexCommands/command_setChannelPreAlarmLevel';
import { FaastFlexSetDatetimeofDevice } from '../faastflexCommands/command_setDatetimeofDevice';
import { FaastFlexSetExternalInput } from '../faastflexCommands/command_setExternalInput';
import { FaastFlexSetExternalTriggredClosed } from '../faastflexCommands/command_setExternalTriggredClosed';
import { FaastFlexSetExternalTriggredUnbalanced } from '../faastflexCommands/command_setExternalTriggredUnbalanced';
import { FaastFlexSetExternalUnbalancedNormalState } from '../faastflexCommands/command_setExternalUnbalancedNormalState';
import { FaastFlexSetFaultLatched } from '../faastflexCommands/command_setFaultLatched';
import { FaastFlexSetFlowFaultDelay } from '../faastflexCommands/command_setFlowFaultDelay';
import { FaastFlexSetFlowFaultThreshold } from '../faastflexCommands/command_setFlowFaultThreshold';
import { FaastFlexSetLowPowerFaultSetRelay } from '../faastflexCommands/command_setLowPowerFaultSetRelay';
import { FaastFlexSetNormalizedCommand } from '../faastflexCommands/command_setNormalizedCommand';
import { FaastFlexSetPreAlarmDelay } from '../faastflexCommands/command_setPreAlarmDelay';
import { FaastFlexSetPreAlarmLatched } from '../faastflexCommands/command_setPreAlarmLatched';
import { FaastFlexSetTempFaultSetRelay } from '../faastflexCommands/command_setTempFaultSetRelay';
import { FaastFlexSetSetTrendlogDisabled } from '../faastflexCommands/command_setTrendlogDisabled';
import { FaastFlexSetExternalTriggredOpen } from '../faastflexCommands/command_setExternalTriggredOpen';
import {
	DeviceGeneralParams,
	DeviceChannelAndSensorParams,
	DeviceMeasures,
} from '../faastflexCommands/common_objects';
import { EventLogModel } from '@ff_model/eventLogModel';
import { FaastFlexGetBlowerSpeed } from '../faastflexCommands/command_getBlowerSpeed';
import { FaastFlexGetBlowerSpeedCorrection } from '../faastflexCommands/command_getBlowerSpeedCorrection';
import { FaastFlexSoundPairing } from '../faastflexCommands/command_bleSoundPairing';
import { FaastFlexCheckAuthenticated } from '../faastflexCommands/command_checkAuthenticated';
import { AppConstants } from '@global/GlobalConstants/globalConstants';
import { FaastFlexIntelligentDeviceStatus } from '../faastflexCommands/command_getFFIDeviceStatus';
import { FaastFlexIntelligentDeviceMeasures } from '../faastflexCommands/command_getFFIDeviceMeasures';
import { FaastFlexIntelligentChannelsAndSensorsParameters } from '../faastflexCommands/command_getFFIChannelsAndSensorsParams';
import { FaastFlexIntelligentGeneralParameters } from '../faastflexCommands/command_getFFIGeneralParameters';
import { FaastFlexIntelligentLogs } from '../faastflexCommands/command_ffILog';
import { FaastFlexIntelligentSetSensorAddress } from '../faastflexCommands/command_setFFISensorAddress';
import { FaastFlexIntelligentGetSensorAddress } from '../faastflexCommands/command_getFFISensorAddress';
import { FaastFlexIntelligentSetSetTrendlogPeriod } from '../faastflexCommands/command_setFFITrendlogDisabled';
import { FaastFlexIntelligentGetActiveFaults } from '../faastflexCommands/command_getFFIActiveFaults';
import { FaastFlexSetAUXFaultLatched } from '../faastflexCommands/command_setAuxFaultLatched';

const { SendPacketWithByteReceived } = useBLE();

const mMsgSend: Uint8Array = new Uint8Array(16);
const mMsgRecv: Uint8Array = new Uint8Array(518);
let mByteToSend: number = 0;
let mByteToReceive: number = 0;
const resetTempData = (): void => {
	mMsgSend.fill(0); // Clear the mMsgSend array by filling it with 0
	mMsgRecv.fill(0); // Clear the mMsgRecv array by filling it with 0

	mByteToSend = 0; // Reset mByteToSend to 0
	mByteToReceive = 0; // Reset mByteToReceive to 0
};

class FaastFlexCommunicator {
	private static instance: FaastFlexCommunicator;

	private constructor() {}

	public static getInstance(): FaastFlexCommunicator {
		if (!FaastFlexCommunicator.instance) {
			FaastFlexCommunicator.instance = new FaastFlexCommunicator();
		}
		return FaastFlexCommunicator.instance;
	}

	//#region Commands
	public async checkAuthenticated(
		uniqueIdentifier: string,
	): Promise<{ isValid: DeviceAuthenticated; error: ErrorCode }> {
		let error: ErrorCode = ErrorCode.eERR_UNKNOWN;
		let isValid: DeviceAuthenticated = DeviceAuthenticated.eUnknown;
		console.log('uniqueIdentifier:', uniqueIdentifier);
		resetTempData();
		const { errorCode, byteToSend, byteToReceive } =
			FaastFlexCheckAuthenticated.amIAuthenticated(
				{ msg: mMsgSend },
				uniqueIdentifier.charCodeAt(0),
				uniqueIdentifier.charCodeAt(1),
				uniqueIdentifier.charCodeAt(2),
				uniqueIdentifier.charCodeAt(3),
				uniqueIdentifier.charCodeAt(4),
				uniqueIdentifier.charCodeAt(5),
				uniqueIdentifier.charCodeAt(6),
				uniqueIdentifier.charCodeAt(7),
				uniqueIdentifier.charCodeAt(8),
				uniqueIdentifier.charCodeAt(9),
				uniqueIdentifier.charCodeAt(10),
				uniqueIdentifier.charCodeAt(11),
			);
		mByteToSend = byteToSend;
		mByteToReceive = byteToReceive;
		if (errorCode === ErrorCode.eOK) {
			const response = await SendPacketWithByteReceived(
				mMsgSend,
				byteToReceive,
			);
			const eRetData = FaastFlexCheckAuthenticated.amIAuthenticatedAnswer(
				{ msg: response },
				byteToReceive,
				byteToReceive,
				isValid,
			);
			if (eRetData.retErrorCode === ErrorCode.eOK) {
				error = eRetData.retErrorCode;
				isValid = eRetData.retDeviceAuthenticated;
			}
		}
		return { isValid, error };
	}
	public async getDeviceStatusData(): Promise<{
		deviceStatus: FaastFlexDeviceStatus;
		error: ErrorCode;
	}> {
		let deviceData: FaastFlexDeviceStatus = {
			DeviceStatus: DeviceStatus.UNKNOWN,
			Channels: 0,
			Country: Country.Unknown,
			LEDStatus: [],
			DeviceConfiguration: Configuration.Unknown,
			RelayEnabled: RelayEnabled.Unknown,
			DeviceType: DeviceType.eUnknown,
		};
		let error: ErrorCode = ErrorCode.eERR_UNKNOWN;

		// Call equivalent of resetTempData()
		resetTempData();
		let ledStatus: string[] = [];

		const { errorCode, byteToSend, byteToReceive } =
			FaastFlexDeviceStatusLowerFirmware.getFaastFlexDeviceStatus({
				msg: mMsgSend,
			});
		mByteToSend = byteToSend;
		mByteToReceive = byteToReceive;
		if (errorCode === ErrorCode.eOK) {
			const response = await SendPacketWithByteReceived(
				mMsgSend,
				byteToReceive,
			);

			const eRetData =
				FaastFlexDeviceStatusLowerFirmware.getFaastFlexDeviceStatusAnswer(
					response,
					byteToReceive,
					byteToReceive,
				);
			if (eRetData.errorCode === ErrorCode.eOK) {
				error = eRetData.errorCode;
				deviceData.DeviceStatus = eRetData.deviceStatus;
				if (eRetData.numberOfChannel === Channel.Channel1)
					deviceData.Channels = 1;
				else if (eRetData.numberOfChannel === Channel.Channel2)
					deviceData.Channels = 2;
				else if (eRetData.numberOfChannel === Channel.Unknown)
					deviceData.Channels = 0;
				deviceData.Country = eRetData.country;
				ledStatus.push(getAlarmFaultStatusDescription(eRetData.alarmfault1));
				ledStatus.push(getAlarmFaultStatusDescription(eRetData.alarmfault2));
				ledStatus.push(getAlarmFaultStatusDescription(eRetData.actionfault1));
				ledStatus.push(getAlarmFaultStatusDescription(eRetData.actionfault2));
				ledStatus.push(getAlarmFaultStatusDescription(eRetData.fault));
				deviceData.LEDStatus = ledStatus || [];
				deviceData.DeviceConfiguration = eRetData.deviceConfiguration;
				deviceData.RelayEnabled = eRetData.relayEnabled;
				deviceData.DeviceType = DeviceType.eStandAlone;
			}
		}
		return { deviceStatus: deviceData, error };
	}

	public async getDeviceStatusData22(): Promise<{
		deviceStatus: FaastFlexDeviceStatus;
		error: ErrorCode;
	}> {
		let deviceData: FaastFlexDeviceStatus = {
			DeviceStatus: DeviceStatus.UNKNOWN,
			Channels: 0,
			Country: Country.Unknown,
			LEDStatus: [],
			DeviceConfiguration: Configuration.Unknown,
			RelayEnabled: RelayEnabled.Unknown,
			DeviceType: DeviceType.eUnknown,
		};
		let error: ErrorCode = ErrorCode.eERR_UNKNOWN;

		// Call equivalent of resetTempData()
		resetTempData();
		let ledStatus: string[] = [];

		const { errorCode, byteToSend, byteToReceive } =
			FaastFlexDeviceStatus22.getFaastFlexDeviceStatus22({
				msg: mMsgSend,
			});
		mByteToSend = byteToSend;
		mByteToReceive = byteToReceive;
		if (errorCode === ErrorCode.eOK) {
			const response = await SendPacketWithByteReceived(
				mMsgSend,
				byteToReceive,
			);

			const eRetData = FaastFlexDeviceStatus22.getFaastFlexDeviceStatusAnswer22(
				response,
				byteToReceive,
				byteToReceive,
			);

			if (eRetData.errorCode === ErrorCode.eOK) {
				error = eRetData.errorCode;
				deviceData.DeviceStatus = eRetData.deviceStatus;
				if (eRetData.numberOfChannel === Channel.Channel1)
					deviceData.Channels = 1;
				else if (eRetData.numberOfChannel === Channel.Channel2)
					deviceData.Channels = 2;
				else if (eRetData.numberOfChannel === Channel.Unknown)
					deviceData.Channels = 0;
				deviceData.Country = eRetData.country;
				ledStatus.push(getAlarmFaultStatusDescription(eRetData.alarmfault1));
				ledStatus.push(getAlarmFaultStatusDescription(eRetData.alarmfault2));
				ledStatus.push(getAlarmFaultStatusDescription(eRetData.actionfault1));
				ledStatus.push(getAlarmFaultStatusDescription(eRetData.actionfault2));
				ledStatus.push(getAlarmFaultStatusDescription(eRetData.fault));
				ledStatus.push(getAlarmFaultStatusDescription(eRetData.alert));
				deviceData.LEDStatus = ledStatus || [];
				deviceData.DeviceConfiguration = eRetData.deviceConfiguration;
				deviceData.RelayEnabled = eRetData.relayEnabled;
				deviceData.DeviceType = DeviceType.eStandAlone;
			}
		}
		return { deviceStatus: deviceData, error };
	}

	public async getFFIDeviceStatusData(): Promise<{
		deviceStatus: FaastFlexDeviceStatus;
		error: ErrorCode;
	}> {
		let deviceData: FaastFlexDeviceStatus = {
			DeviceStatus: DeviceStatus.UNKNOWN,
			Channels: 0,
			Country: Country.Unknown,
			LEDStatus: [],
			DeviceConfiguration: Configuration.Unknown,
			RelayEnabled: RelayEnabled.Unknown,
			DeviceType: DeviceType.eUnknown,
		};
		let error: ErrorCode = ErrorCode.eERR_UNKNOWN;

		// Call equivalent of resetTempData()
		resetTempData();
		let ledStatus: string[] = [];

		const { errorCode, byteToSend, byteToReceive } =
			FaastFlexIntelligentDeviceStatus.getFaastFlexIntelligentDeviceStatus({
				msg: mMsgSend,
			});
		mByteToSend = byteToSend;
		mByteToReceive = byteToReceive;
		if (errorCode === ErrorCode.eOK) {
			const response = await SendPacketWithByteReceived(
				mMsgSend,
				byteToReceive,
			);

			const eRetData =
				FaastFlexIntelligentDeviceStatus.getFaastFlexIntelligentDeviceStatusAnswer(
					response,
					byteToReceive,
					byteToReceive,
				);

			if (eRetData.errorCode === ErrorCode.eOK) {
				error = eRetData.errorCode;
				deviceData.DeviceStatus = eRetData.deviceStatus;
				if (eRetData.numberOfChannel === Channel.Channel1)
					deviceData.Channels = 1;
				else if (eRetData.numberOfChannel === Channel.Channel2)
					deviceData.Channels = 2;
				else if (eRetData.numberOfChannel === Channel.Unknown)
					deviceData.Channels = 0;
				deviceData.Country = eRetData.country;
				ledStatus.push(getAlarmFaultStatusDescription(eRetData.alarmfault1));
				ledStatus.push(getAlarmFaultStatusDescription(eRetData.alarmfault2));
				ledStatus.push(
					getAlarmFaultStatusDescription(AlarmFaultStatus.Unknown),
				);
				ledStatus.push(
					getAlarmFaultStatusDescription(AlarmFaultStatus.Unknown),
				);
				ledStatus.push(getAlarmFaultStatusDescription(eRetData.fault));
				ledStatus.push(getAlarmFaultStatusDescription(eRetData.alert));
				deviceData.LEDStatus = ledStatus || [];
				deviceData.DeviceConfiguration = eRetData.deviceConfiguration;
				deviceData.RelayEnabled = eRetData.relayEnabled;
				deviceData.DeviceType = eRetData.deviceType;
			}
		}
		return { deviceStatus: deviceData, error };
	}

	public async StarManualConnection(
		uniqueIdentifier: string,
	): Promise<{ passcode: string; error: ErrorCode }> {
		console.log(
			'----------> StarManualConnection called with uniqueIdentifier:',
		);
		let error: ErrorCode = ErrorCode.eERR_UNKNOWN;
		let passcode: string = '';
		console.log('uniqueIdentifier:', uniqueIdentifier);
		resetTempData();
		const { errorCode, byteToSend, byteToReceive } = startManualPairing(
			{ msg: mMsgSend },
			uniqueIdentifier.charCodeAt(0),
			uniqueIdentifier.charCodeAt(1),
			uniqueIdentifier.charCodeAt(2),
			uniqueIdentifier.charCodeAt(3),
			uniqueIdentifier.charCodeAt(4),
			uniqueIdentifier.charCodeAt(5),
			uniqueIdentifier.charCodeAt(6),
			uniqueIdentifier.charCodeAt(7),
			uniqueIdentifier.charCodeAt(8),
			uniqueIdentifier.charCodeAt(9),
			uniqueIdentifier.charCodeAt(10),
			uniqueIdentifier.charCodeAt(11),
		);
		mByteToSend = byteToSend;
		mByteToReceive = byteToReceive;
		console.log('mp: ErrorCode:', errorCode);
		console.log('mp: ByteToSend:', byteToSend);
		console.log('mp: ByteToReceive:', byteToReceive);
		console.log('mp: msg:', mMsgSend);
		if (errorCode === ErrorCode.eOK) {
			const response = await SendPacketWithByteReceived(
				mMsgSend,
				byteToReceive,
			);
			console.log('mp: Response:', response);
			const { retErrorCode, num1, num2, num3, num4, num5, num6 } =
				startManualPairingAnswer(
					{ msg: response },
					byteToReceive,
					byteToReceive,
				);
			console.log('mp: retErrorCode:', retErrorCode);
			console.log('mp: num1:', num1);
			console.log('mp: num2:', num2);
			console.log('mp: num3:', num3);
			console.log('mp: num4:', num4);
			console.log('mp: num5:', num5);
			console.log('mp: num6:', num6);

			if (retErrorCode === ErrorCode.eOK) {
				error = retErrorCode;
				passcode = `${num1}${num2}${num3}${num4}${num5}${num6}`;
			} else if (retErrorCode === ErrorCode.eGCL_NOT_ALLOWED_FOR_COVER_CLOSED) {
				passcode = AppConstants.NOT_ALLOWED_FOR_COVER_CLOSED;
			}
		}
		return { passcode, error };
	}

	public async GetDeviceMode(): Promise<{
		deviceMode: DeviceStatus;
		error: ErrorCode;
	}> {
		console.log('----------> GetDeviceMode called:');
		let error: ErrorCode = ErrorCode.eERR_UNKNOWN;
		let deviceMode: DeviceStatus = DeviceStatus.UNKNOWN;
		resetTempData();
		const { errorCode, byteToSend, byteToReceive } =
			FaastFlexDeviceMode.getDeviceStatus({ msg: mMsgSend });
		mByteToSend = byteToSend;
		mByteToReceive = byteToReceive;
		if (errorCode === ErrorCode.eOK) {
			const response = await SendPacketWithByteReceived(
				mMsgSend,
				byteToReceive,
			);
			const { retErrorCode, retDeviceStatus } =
				FaastFlexDeviceMode.getDeviceStatusAnswer(
					{ msg: response },
					byteToReceive,
					byteToReceive,
				);

			if (retErrorCode === ErrorCode.eOK) {
				error = retErrorCode;
				deviceMode = retDeviceStatus;
			}
		}
		return { deviceMode, error };
	}

	public async GetDeviceType(): Promise<{
		deviceType: string;
		error: ErrorCode;
	}> {
		console.log('----------> GetDeviceType called:');
		let error: ErrorCode = ErrorCode.eERR_UNKNOWN;
		let deviceType: string = '';
		resetTempData();
		const { errorCode, byteToSend, byteToReceive } =
			FaastFlexDeviceType.GetDeviceType({ msg: mMsgSend });
		mByteToSend = byteToSend;
		mByteToReceive = byteToReceive;
		if (errorCode === ErrorCode.eOK) {
			const response = await SendPacketWithByteReceived(
				mMsgSend,
				byteToReceive,
			);
			console.log('dm: Response:', response);
			const { retErrorCode, retDeviceType } =
				FaastFlexDeviceType.GetDeviceTypeAnswer(
					{ msg: response },
					byteToReceive,
					byteToReceive,
				);
			console.log('mp: retErrorCode:', retErrorCode);

			if (retErrorCode === ErrorCode.eOK) {
				error = retErrorCode;
				deviceType = getDeviceTypeDescription(retDeviceType);
			} else if (retErrorCode === ErrorCode.eGCL_NOT_PAIRED_ERROR) {
				deviceType = getDeviceTypeDescription(DeviceType.eStandAlone);
			}
		}
		return { deviceType, error };
	}

	public async GetSerialNumber(): Promise<{
		serialNumber: string;
		error: ErrorCode;
	}> {
		console.log('----------> GetSerialNumber called:');
		let error: ErrorCode = ErrorCode.eERR_UNKNOWN;
		let serialNumber: string = '';
		resetTempData();
		const { errorCode, byteToSend, byteToReceive } =
			FaastFlexSerialNumber.GetSerialNumberEEPROM({ msg: mMsgSend });
		mByteToSend = byteToSend;
		mByteToReceive = byteToReceive;
		if (errorCode === ErrorCode.eOK) {
			const response = await SendPacketWithByteReceived(
				mMsgSend,
				byteToReceive,
			);
			console.log('dm: Response:', response);
			const { retErrorCode, retNumber } =
				FaastFlexSerialNumber.GetSerialNumberEEPROMAnswer(
					{ msg: response },
					byteToReceive,
					byteToReceive,
				);
			console.log('mp: retErrorCode:', retErrorCode);

			if (retErrorCode === ErrorCode.eOK) {
				error = retErrorCode;
				serialNumber = retNumber;
			}
		}
		return { serialNumber, error };
	}

	public async GetProductionDate(): Promise<{
		productionDate: string;
		error: ErrorCode;
	}> {
		console.log('----------> GetProductionDate called:');
		let error: ErrorCode = ErrorCode.eERR_UNKNOWN;
		let productionDate: string = '';
		resetTempData();
		const { errorCode, byteToSend, byteToReceive } =
			FaastFlexProductionDate.GetProductionDate({ msg: mMsgSend });
		mByteToSend = byteToSend;
		mByteToReceive = byteToReceive;
		if (errorCode === ErrorCode.eOK) {
			const response = await SendPacketWithByteReceived(
				mMsgSend,
				byteToReceive,
			);
			console.log('dm: Response:', response);
			const retValue = FaastFlexProductionDate.GetProductionDateAnswer(
				{ msg: response },
				byteToReceive,
				byteToReceive,
			);

			if (retValue.errorCode === ErrorCode.eOK) {
				error = retValue.errorCode;
				productionDate = `${retValue.MANIF_DD}-${retValue.MANIF_MM}-${retValue.MANIF_YY}  ${retValue.MANIF_HH}:${retValue.MANIF_MI}:${retValue.MANIF_SS}`;
			} else {
				productionDate = 'Unknown';
				error = retValue.errorCode;
			}
		}
		return { productionDate, error };
	}
	public async GetFirmwareVersion(): Promise<{
		firmwareVersion: string;
		error: ErrorCode;
	}> {
		console.log('----------> GetFirmwareVersion called:');
		let error: ErrorCode = ErrorCode.eERR_UNKNOWN;
		let firmwareVersion: string = '';
		resetTempData();
		const { errorCode, byteToSend, byteToReceive } =
			FaastFlexFirmwareVersion.GetFirmwareVersion({ msg: mMsgSend });
		mByteToSend = byteToSend;
		mByteToReceive = byteToReceive;
		if (errorCode === ErrorCode.eOK) {
			const response = await SendPacketWithByteReceived(
				mMsgSend,
				byteToReceive,
			);
			console.log('dm: Response:', response);
			const retValue = FaastFlexFirmwareVersion.GetFirmwareVersionAnswer(
				{ msg: response },
				byteToReceive,
				byteToReceive,
			);
			error = retValue.errorCode;
			if (retValue.errorCode === ErrorCode.eOK) {
				firmwareVersion = `${retValue.currentVersionRelease}.${retValue.currentVersionMajor}.${retValue.currentVersionMinor}.${retValue.currentVersionBuild}`;
			}
		}
		return { firmwareVersion, error };
	}
	public async GetModelType(): Promise<{
		modelType: string;
		error: ErrorCode;
	}> {
		console.log('----------> GetModelType called:');
		let error: ErrorCode = ErrorCode.eERR_UNKNOWN;
		let modelType: string = '';
		resetTempData();
		const { errorCode, byteToSend, byteToReceive } =
			FaastFlexModelType.GetModelTypeEEPROM({ msg: mMsgSend });
		mByteToSend = byteToSend;
		mByteToReceive = byteToReceive;
		if (errorCode === ErrorCode.eOK) {
			const response = await SendPacketWithByteReceived(
				mMsgSend,
				byteToReceive,
			);
			console.log('dm: Response:', response);
			const retValue = FaastFlexModelType.GetModelTypeEEPROMAnswer(
				{ msg: response },
				byteToReceive,
				byteToReceive,
			);
			error = retValue.retErrorCode;
			if (retValue.retErrorCode === ErrorCode.eOK) {
				modelType = getModelTypeDescription(retValue.retModelType);
			}
		}
		return { modelType, error };
	}

	public async StartSelfTestForChina(): Promise<{
		isStarted: boolean;
		error: ErrorCode;
	}> {
		console.log('----------> StartSelfTestForChina called:');
		let error: ErrorCode = ErrorCode.eERR_UNKNOWN;
		resetTempData();
		const { errorCode, byteToSend, byteToReceive } =
			FaastFlexSelfTestChina.StartSelfTestChina({ msg: mMsgSend });
		mByteToSend = byteToSend;
		mByteToReceive = byteToReceive;
		if (errorCode === ErrorCode.eOK) {
			const response = await SendPacketWithByteReceived(
				mMsgSend,
				byteToReceive,
			);
			console.log('dm: Response:', response);
			const retValue = FaastFlexSelfTestChina.StartSelfTestChinaAnswer(
				{ msg: response },
				byteToReceive,
				byteToReceive,
			);
			error = retValue.retErrorCode;
			if (retValue.retErrorCode === ErrorCode.eOK) {
				return { isStarted: true, error };
			}
		}
		return { isStarted: false, error };
	}
	public async SilenceDeviceBuzzerChina(): Promise<{
		isStarted: boolean;
		error: ErrorCode;
	}> {
		console.log('----------> StartSelfTestForChina called:');
		let error: ErrorCode = ErrorCode.eERR_UNKNOWN;
		resetTempData();
		const { errorCode, byteToSend, byteToReceive } =
			FaastFlexSilenceDeviceBuzzerChina.SilenceBuzzerChina({
				msg: mMsgSend,
			});
		mByteToSend = byteToSend;
		mByteToReceive = byteToReceive;
		if (errorCode === ErrorCode.eOK) {
			const response = await SendPacketWithByteReceived(
				mMsgSend,
				byteToReceive,
			);
			console.log('dm: Response:', response);
			const retValue =
				FaastFlexSilenceDeviceBuzzerChina.SilenceBuzzerChinaAnswer(
					{ msg: response },
					byteToReceive,
					byteToReceive,
				);
			error = retValue.retErrorCode;
			if (retValue.retErrorCode === ErrorCode.eOK) {
				return { isStarted: true, error };
			}
		}
		return { isStarted: false, error };
	}
	public async DisableFAASTFlexDevice(): Promise<{
		isDisabled: boolean;
		error: ErrorCode;
	}> {
		console.log('----------> StartSelfTestForChina called:');
		let error: ErrorCode = ErrorCode.eERR_UNKNOWN;
		resetTempData();
		const { errorCode, byteToSend, byteToReceive } =
			FaastFlexDisableDevice.DisableDevice({ msg: mMsgSend });
		mByteToSend = byteToSend;
		mByteToReceive = byteToReceive;
		if (errorCode === ErrorCode.eOK) {
			const response = await SendPacketWithByteReceived(
				mMsgSend,
				byteToReceive,
			);
			console.log('dm: Response:', response);
			const retValue = FaastFlexDisableDevice.DisableDeviceAnswer(
				{ msg: response },
				byteToReceive,
				byteToReceive,
			);
			error = retValue.retErrorCode;
			if (retValue.retErrorCode === ErrorCode.eOK) {
				return { isDisabled: true, error };
			}
		}
		return { isDisabled: false, error };
	}
	public async ResetDevice(): Promise<{
		isReset: boolean;
		error: ErrorCode;
	}> {
		console.log('----------> StartSelfTestForChina called:');
		let error: ErrorCode = ErrorCode.eERR_UNKNOWN;
		resetTempData();
		const { errorCode, byteToSend, byteToReceive } =
			FaastFlexResetDevice.ResetFaultsAndAlarms({ msg: mMsgSend });
		mByteToSend = byteToSend;
		mByteToReceive = byteToReceive;
		if (errorCode === ErrorCode.eOK) {
			const response = await SendPacketWithByteReceived(
				mMsgSend,
				byteToReceive,
			);
			console.log('dm: Response:', response);
			const retValue = FaastFlexResetDevice.ResetFaultsAndAlarmsAnswer(
				{ msg: response },
				byteToReceive,
				byteToReceive,
			);
			error = retValue.retErrorCode;
			if (retValue.retErrorCode === ErrorCode.eOK) {
				return { isReset: true, error };
			}
		}
		return { isReset: false, error };
	}
	public async GetRecentlogs(
		logIndexLSB: number,
		logIndexMSB: number,
	): Promise<{ eventLog: EventLogModel; error: ErrorCode }> {
		let error: ErrorCode = ErrorCode.eERR_UNKNOWN;
		let eventLog: EventLogModel = new EventLogModel();

		resetTempData();
		const { errorCode, byteToSend, byteToReceive } = FaastFlexLogs.GetLogEntry(
			{ msg: mMsgSend },
			logIndexLSB,
			logIndexMSB,
		);
		mByteToSend = byteToSend;
		mByteToReceive = byteToReceive;
		if (errorCode === ErrorCode.eOK) {
			const response = await SendPacketWithByteReceived(
				mMsgSend,
				byteToReceive,
			);
			console.log('dm: Response:', response);
			const retValue = FaastFlexLogs.GetLogEntryAnswer(
				{ msg: response },
				byteToReceive,
				byteToReceive,
			);
			error = retValue.retErrorCode;
			if (retValue.retErrorCode === ErrorCode.eOK) {
				eventLog.logId = retValue.logEntryId;
				const strMonth = retValue.month.toString().padStart(2, '0');
				const strDay = retValue.day.toString().padStart(2, '0');
				try {
					// const format = retValue.year.toString() + strMonth + strDay;
					// const dt = parse(format, 'yyMMdd', new Date(), { locale: enGB });
					const fullYear =
						retValue.year < 100 ? 2000 + retValue.year : retValue.year;
					const dateTime = new Date(
						fullYear,
						retValue.month - 1,
						retValue.day,
						retValue.hour,
						retValue.minute,
						retValue.second,
					);
					eventLog.eventDateTime = dateTime.toLocaleDateString();
					eventLog.eventDate = dateFormat(dateTime, 'dd MMMM yyyy');
					eventLog.eventTime = dateFormat(dateTime, 'hh:mm:ss');
				} catch (e) {
					console.error('Error formatting date:', e);
				}
				eventLog.eventType = retValue.eventType;
				eventLog.eventTypeStr = getLogEventTypeDescription(retValue.eventType);
				if (retValue.eventType === LogEventType.eUnknown) {
					eventLog.eventBarColor = '#B9261C';
					eventLog.statusIcon = 'Alarm.png';
				} else if (retValue.eventType === LogEventType.eAlarm) {
					eventLog.eventBarColor = '#F58D4C';
					eventLog.statusIcon = 'Service.png';
				} else {
					eventLog.eventBarColor = '#FFD153';
					eventLog.statusIcon = 'DisabledStatus.png';
				}
				eventLog.logChannel = retValue.eventZone;
				eventLog.eventName = retValue.logEventId;
				eventLog.eventDescription = getLogEventIdDescription(
					retValue.logEventId,
				);
				eventLog.addtionalInfo =
					'Temp Ch1 = ' +
					retValue.temperatureChannel1 +
					', Temp Ch2 = ' +
					retValue.temperatureChannel2 +
					', Flow Ch1 = ' +
					retValue.flowChannel1 +
					', Flow Ch2 = ' +
					retValue.flowChannel2 +
					', LogZone = ' +
					getLogEventZoneDescription(retValue.eventZone) +
					', RPM = ' +
					retValue.blowerRPM;
				eventLog.eventIdInfo =
					'Event Id = ' +
					Number(retValue.logEventId) +
					', Log Seq Id = ' +
					retValue.logEntryId;
				eventLog.ch1Flow = retValue.flowChannel1;
				eventLog.ch2Flow = retValue.flowChannel2;
				eventLog.ch1Temperature = retValue.temperatureChannel1;
				eventLog.ch2Temperature = retValue.temperatureChannel2;
				eventLog.ch1Sensor = retValue.sensorChannel1;
				eventLog.ch2Sensor = retValue.sensorChannel2;
				eventLog.blowerRPM = retValue.blowerRPM;
			}
		}
		return { eventLog, error };
	}
	public async GetDeviceOrientation(): Promise<{
		deviceOrientation: string;
		error: ErrorCode;
	}> {
		console.log('----------> GetModelType called:');
		let error: ErrorCode = ErrorCode.eERR_UNKNOWN;
		let deviceOrientation: string = getDeviceOrientationDescription(
			DeviceOrientation.eUnknown,
		);
		resetTempData();
		const { errorCode, byteToSend, byteToReceive } =
			FaastFlexDeviceOrientation.GetDeviceOrientationEEPROM({
				msg: mMsgSend,
			});
		mByteToSend = byteToSend;
		mByteToReceive = byteToReceive;
		if (errorCode === ErrorCode.eOK) {
			const response = await SendPacketWithByteReceived(
				mMsgSend,
				byteToReceive,
			);
			console.log('dm: Response:', response);
			const retValue =
				FaastFlexDeviceOrientation.GetDeviceOrientationEEPROMAnswer(
					{ msg: response },
					byteToReceive,
					byteToReceive,
				);
			error = retValue.retErrorCode;
			if (retValue.retErrorCode === ErrorCode.eOK) {
				deviceOrientation = getDeviceOrientationDescription(
					retValue.orientation,
				);
			}
		}
		return { deviceOrientation, error };
	}
	public async SendFaastflexDevicePassword(
		passCodeChar: string,
	): Promise<{ passwordValid: PasswordValid; error: ErrorCode }> {
		console.log('----------> GetModelType called:');
		let error: ErrorCode = ErrorCode.eERR_UNKNOWN;
		let passwordValid: PasswordValid = PasswordValid.eUnknown;
		// Extract each character from the password string and convert to PasswordValid type
		const pass1: PasswordValid = parseInt(
			passCodeChar.charAt(0),
			10,
		) as unknown as PasswordValid;
		const pass2: PasswordValid = parseInt(
			passCodeChar.charAt(1),
			10,
		) as unknown as PasswordValid;
		const pass3: PasswordValid = parseInt(
			passCodeChar.charAt(2),
			10,
		) as unknown as PasswordValid;
		const pass4: PasswordValid = parseInt(
			passCodeChar.charAt(3),
			10,
		) as unknown as PasswordValid;
		const pass5: PasswordValid = parseInt(
			passCodeChar.charAt(4),
			10,
		) as unknown as PasswordValid;
		const pass6: PasswordValid = parseInt(
			passCodeChar.charAt(5),
			10,
		) as unknown as PasswordValid;
		resetTempData();
		const { errorCode, byteToSend, byteToReceive } =
			FaastFlexSendPasswordToDevice.SendFAASTPassword(
				{ msg: mMsgSend },
				pass1,
				pass2,
				pass3,
				pass4,
				pass5,
				pass6,
			);
		mByteToSend = byteToSend;
		mByteToReceive = byteToReceive;
		if (errorCode === ErrorCode.eOK) {
			const response = await SendPacketWithByteReceived(
				mMsgSend,
				byteToReceive,
			);
			console.log('dm: Response:', response);
			const retValue = FaastFlexSendPasswordToDevice.SendFAASTPasswordAnswer(
				{ msg: response },
				byteToReceive,
				byteToReceive,
			);
			error = retValue.retErrorCode;
			if (retValue.retErrorCode === ErrorCode.eOK) {
				passwordValid = PasswordValid.eValid;
			} else if (retValue.retErrorCode === ErrorCode.GCL_PASSWORD_DELAYED) {
				passwordValid = PasswordValid.ePasswordDelay;
			} else {
				passwordValid = PasswordValid.eInvalid;
			}
		}
		return { passwordValid, error };
	}
	public async ChangeDevicePassword(
		password: string,
	): Promise<{ isChanged: boolean; error: ErrorCode }> {
		console.log('----------> GetModelType called:');
		let error: ErrorCode = ErrorCode.eERR_UNKNOWN;
		let isChanged: boolean = false;
		// Extract each character from the password string and convert to PasswordValid type
		const pass1: PasswordValid = parseInt(
			password.charAt(0),
			10,
		) as unknown as PasswordValid;
		const pass2: PasswordValid = parseInt(
			password.charAt(1),
			10,
		) as unknown as PasswordValid;
		const pass3: PasswordValid = parseInt(
			password.charAt(2),
			10,
		) as unknown as PasswordValid;
		const pass4: PasswordValid = parseInt(
			password.charAt(3),
			10,
		) as unknown as PasswordValid;
		const pass5: PasswordValid = parseInt(
			password.charAt(4),
			10,
		) as unknown as PasswordValid;
		const pass6: PasswordValid = parseInt(
			password.charAt(5),
			10,
		) as unknown as PasswordValid;
		resetTempData();
		const { errorCode, byteToSend, byteToReceive } =
			FaastFlexSendPasswordToDevice.ChangePassword(
				{ msg: mMsgSend },
				pass1,
				pass2,
				pass3,
				pass4,
				pass5,
				pass6,
			);
		mByteToSend = byteToSend;
		mByteToReceive = byteToReceive;
		if (errorCode === ErrorCode.eOK) {
			const response = await SendPacketWithByteReceived(
				mMsgSend,
				byteToReceive,
			);
			console.log('dm: Response:', response);
			const retValue = FaastFlexSendPasswordToDevice.ChangePasswordAnswer(
				{ msg: response },
				byteToReceive,
				byteToReceive,
			);
			error = retValue.retErrorCode;
			if (retValue.retErrorCode === ErrorCode.eOK) {
				isChanged = true;
			} else {
				isChanged = false;
			}
		}
		return { isChanged, error };
	}
	public async StartSelftestEurope(
		nextCmd: number,
	): Promise<{ isTestCommandSent: boolean; error: ErrorCode }> {
		console.log('----------> GetModelType called:');
		let error: ErrorCode = ErrorCode.eERR_UNKNOWN;
		let isTestCommandSent: boolean = false;

		resetTempData();
		const { errorCode, byteToSend, byteToReceive } =
			FaastFlexSelfTestEurope.StartSelfTestEurope({ msg: mMsgSend }, nextCmd);
		mByteToSend = byteToSend;
		mByteToReceive = byteToReceive;
		if (errorCode === ErrorCode.eOK) {
			const response = await SendPacketWithByteReceived(
				mMsgSend,
				byteToReceive,
			);
			console.log('dm: Response:', response);
			const retValue = FaastFlexSelfTestEurope.StartSelfTestEuropeAnswer(
				{ msg: response },
				byteToReceive,
				byteToReceive,
			);
			error = retValue.retErrorCode;
			if (retValue.retErrorCode === ErrorCode.eOK) {
				isTestCommandSent = true;
			}
		}
		return { isTestCommandSent, error };
	}
	public async GetLEDStatus(): Promise<{
		ledStatus: string[];
		error: ErrorCode;
	}> {
		let error: ErrorCode = ErrorCode.eERR_UNKNOWN;
		let led: string[] = [];
		resetTempData();
		const { errorCode, byteToSend, byteToReceive } =
			FaastFlexLEDStatus.GetHMILed({ msg: mMsgSend });
		mByteToSend = byteToSend;
		mByteToReceive = byteToReceive;
		if (errorCode === ErrorCode.eOK) {
			const response = await SendPacketWithByteReceived(
				mMsgSend,
				byteToReceive,
			);
			console.log('dm: Response:', response);
			const retValue = FaastFlexLEDStatus.GetHMILedAnswer(
				{ msg: response },
				byteToReceive,
				byteToReceive,
			);
			error = retValue.errorCode;
			if (error === ErrorCode.eOK) {
				led.push(getAlarmFaultStatusDescription(retValue.AlarmStatus1));
				led.push(getAlarmFaultStatusDescription(retValue.preAlarmFault1));
				led.push(getAlarmFaultStatusDescription(retValue.AlarmStatus2));
				led.push(getAlarmFaultStatusDescription(retValue.preAlarmFault2));
				led.push(getAlarmFaultStatusDescription(retValue.FaultStatus));
			}
		}
		return { ledStatus: led, error };
	}
	public async GetDeviceGPIParams(): Promise<{
		gpiParams: DeviceGPIParams;
		error: ErrorCode;
	}> {
		console.log('----------> GetModelType called:');
		let error: ErrorCode = ErrorCode.eERR_UNKNOWN;
		let deviceGPIParams: DeviceGPIParams = {
			GPIExternalInput: ExternalInputMode.eUnknown,
			SupervisedExternalTriggerOnClosed: ExternalInputAction.eUnknown,
			SupervisedExternalTriggerOnOpen: ExternalInputAction.eUnknown,
			UnSupervisedEventTriggered: ExternalInputAction.eUnknown,
			UnSupervisedNormalState: ExternalInputNormalState.eUnknown,
		};

		resetTempData();
		const { errorCode, byteToSend, byteToReceive } =
			FaastFlexGPIParameters.GetGPIParams({ msg: mMsgSend });
		mByteToSend = byteToSend;
		mByteToReceive = byteToReceive;
		if (errorCode === ErrorCode.eOK) {
			const response = await SendPacketWithByteReceived(
				mMsgSend,
				byteToReceive,
			);
			console.log('dm: Response:', response);
			const retValue = FaastFlexGPIParameters.GetGPIParamsAnswer(
				{ msg: response },
				byteToReceive,
				byteToReceive,
			);
			error = retValue.retErrorCode;
			if (retValue.retErrorCode === ErrorCode.eOK) {
				deviceGPIParams.GPIExternalInput = retValue._externalInput;
				deviceGPIParams.SupervisedExternalTriggerOnClosed =
					retValue._supervisedTriggerOnClosed;
				deviceGPIParams.SupervisedExternalTriggerOnOpen =
					retValue._supervisedTriggerOnOpen;
				deviceGPIParams.UnSupervisedEventTriggered =
					retValue._unSupervisedEventTriggered;
				deviceGPIParams.UnSupervisedNormalState =
					retValue._unSupervisedNormalState;
			}
		}
		return { gpiParams: deviceGPIParams, error };
	}
	public async GetDeviceGeneralParams(): Promise<{
		generalParams: DeviceGeneralParams;
		error: ErrorCode;
	}> {
		let error: ErrorCode = ErrorCode.eERR_UNKNOWN;

		let generalParams: DeviceGeneralParams = {
			DeviceOrientation: DeviceOrientation.eUnknown,
			TempRelay: RelayAlert.eUnknown,
			LowPowerRelay: RelayAlert.eUnknown,
			BlowerSpeedLevel: FanSpeedLevel.eUnknown,
			BlowerSpeedCorrection: FanPWMPercCorrection.eUnknown,
			DeviceDateTime: new Date(),
			Trendlog: 0,
		};

		resetTempData();
		const { errorCode, byteToSend, byteToReceive } =
			FaastFlexGeneralParameters.GetGeneralParams({ msg: mMsgSend });
		mByteToSend = byteToSend;
		mByteToReceive = byteToReceive;
		if (errorCode === ErrorCode.eOK) {
			const response = await SendPacketWithByteReceived(
				mMsgSend,
				byteToReceive,
			);
			console.log('dm: Response:', response);
			const retValue = FaastFlexGeneralParameters.GetGeneralParamsAnswer(
				{ msg: response },
				byteToReceive,
				byteToReceive,
			);
			error = retValue.errorCode;
			if (error === ErrorCode.eOK) {
				generalParams.DeviceOrientation = retValue.deviceOrientation;
				generalParams.TempRelay = retValue.tempRelay;
				generalParams.LowPowerRelay = retValue.lowPowerRelay;
				generalParams.BlowerSpeedLevel = retValue.blowerSpeedLevel;
				generalParams.BlowerSpeedCorrection = retValue.blowerSpeedCorrection;
				generalParams.Trendlog = retValue.trendlog;
				try {
					const format = retValue.year > 0 ? retValue.year.toString() : '00';
					const dt = parse(format, 'yy', new Date(), {
						locale: enGB,
					});
					generalParams.DeviceDateTime = new Date(
						dt.getFullYear(),
						retValue.month - 1,
						retValue.day,
						retValue.hour,
						retValue.minute,
						retValue.second,
					);
				} catch (e) {
					console.error('Error formatting date:', e);
				}
			}
		}
		return { generalParams, error };
	}
	public async GetDeviceChannelsAndSensorsParams(): Promise<{
		channelAndSensorParams: DeviceChannelAndSensorParams;
		error: ErrorCode;
	}> {
		let error: ErrorCode = ErrorCode.eERR_UNKNOWN;

		let params: DeviceChannelAndSensorParams =
			new DeviceChannelAndSensorParams();
		resetTempData();
		const { errorCode, byteToSend, byteToReceive } =
			FaastFlexChannelsAndSensorsParameters.GetChannelsAndSensorParams({
				msg: mMsgSend,
			});
		mByteToSend = byteToSend;
		mByteToReceive = byteToReceive;
		if (errorCode === ErrorCode.eOK) {
			const response = await SendPacketWithByteReceived(
				mMsgSend,
				byteToReceive,
			);
			console.log('dm: Response:', response);
			const retValue =
				FaastFlexChannelsAndSensorsParameters.GetChannelsAndSensorParamsAnswer(
					{ msg: response },
					byteToReceive,
					byteToReceive,
				);
			error = retValue.errorCode;
			if (error === ErrorCode.eOK) {
				params.actionDelay = retValue.preAlarmDelay.toString();
				params.alarmDelay = retValue.alarmDelay.toString();
				params.flowFaultDelay = retValue.flowFaultDelay.toString();
				params.alarmLatched = retValue.alarmLatched;
				params.preAlarmLatched = retValue.preAlarmLatched;
				params.faultLatched = retValue.faultLatched;
				params.alarmMode = retValue.alarmMode;

				params.ch1AlarmLevel = retValue.ch1AlarmLevel;
				params.ch1FlowFaultThreshold = retValue.ch1Flowthreshold;
				params.ch1PreAlarmLevel = retValue.ch1PreAlarmLevel;
				params.ch1RefAirflow = retValue.ch1RefAirflow;

				params.ch2AlarmLevel = retValue.ch2AlarmLevel;
				params.ch2FlowFaultThreshold = retValue.ch2Flowthreshold;
				params.ch2PreAlarmLevel = retValue.ch2PreAlarmLevel;
				params.ch2RefAirflow = retValue.ch2RefAirflow;
			}
		}
		return { channelAndSensorParams: params, error };
	}
	public async GetPowerVoltage(): Promise<{
		powerVoltage: string;
		error: ErrorCode;
	}> {
		console.log('----------> GetPowerVoltage called:');
		let error: ErrorCode = ErrorCode.eERR_UNKNOWN;
		let voltage: string = '';
		resetTempData();
		const { errorCode, byteToSend, byteToReceive } =
			FaastFlexGetPowerVoltage.GetPowerVoltageEEPROM({ msg: mMsgSend });
		mByteToSend = byteToSend;
		mByteToReceive = byteToReceive;
		if (errorCode === ErrorCode.eOK) {
			const response = await SendPacketWithByteReceived(
				mMsgSend,
				byteToReceive,
			);
			console.log('dm: Response:', response);
			const result = FaastFlexGetPowerVoltage.GetPowerVoltageAnswer(
				{ msg: response },
				byteToReceive,
				byteToReceive,
			);

			if (result.errorCode === ErrorCode.eOK) {
				error = result.errorCode;
				voltage = result.powerLSB.toString() + '-' + result.powerMSB.toString();
			}
		}
		return { powerVoltage: voltage, error };
	}
	public async GetDeviceConfiguration(
		deviceType: DeviceType = DeviceType.eStandAlone,
	): Promise<{ devconfig: Configuration; error: ErrorCode }> {
		console.log('----------> GetDeviceMode called:');
		let error: ErrorCode = ErrorCode.eERR_UNKNOWN;
		let config: Configuration = Configuration.Unknown;
		resetTempData();
		const { errorCode, byteToSend, byteToReceive } =
			FaastFlexGetDeviceConfiguration.GetRealConf({ msg: mMsgSend });
		mByteToSend = byteToSend;
		mByteToReceive = byteToReceive;
		console.log('dm: ErrorCode:', errorCode);
		console.log('dm: ByteToSend:', byteToSend);
		console.log('dm: ByteToReceive:', byteToReceive);
		console.log('dm: msg:', mMsgSend);
		if (errorCode === ErrorCode.eOK) {
			const response = await SendPacketWithByteReceived(
				mMsgSend,
				byteToReceive,
			);
			console.log('dm: Response:', response);
			const value = FaastFlexGetDeviceConfiguration.GetRealConfAnswer(
				{ msg: response },
				byteToReceive,
				byteToReceive,
				deviceType,
			);

			if (value.retErrorCode === ErrorCode.eOK) {
				error = value.retErrorCode;
				config = value.realConf;
			}
		}
		return { devconfig: config, error };
	}

	public async GetDeviceRelayEnabled(): Promise<{
		relayEnabled: RelayEnabled;
		error: ErrorCode;
	}> {
		console.log('----------> GetDeviceMode called:');
		let error: ErrorCode = ErrorCode.eERR_UNKNOWN;
		let relay: RelayEnabled = RelayEnabled.Unknown;
		resetTempData();
		const { errorCode, byteToSend, byteToReceive } =
			FaastFlexGetDeviceRelayEnabled.GetRelayEnabled({ msg: mMsgSend });
		mByteToSend = byteToSend;
		mByteToReceive = byteToReceive;
		console.log('dm: ErrorCode:', errorCode);
		console.log('dm: ByteToSend:', byteToSend);
		console.log('dm: ByteToReceive:', byteToReceive);
		console.log('rl: msg:', mMsgSend);
		if (errorCode === ErrorCode.eOK) {
			const response = await SendPacketWithByteReceived(
				mMsgSend,
				byteToReceive,
			);
			console.log('rl: Response:', response);
			const value = FaastFlexGetDeviceRelayEnabled.GetRelayEnabledAnswer(
				{ msg: response },
				byteToReceive,
				byteToReceive,
			);
			if (value.retErrorCode === ErrorCode.eOK) {
				error = value.retErrorCode;
				relay = value.relayEnabled;
			}
		}
		return { relayEnabled: relay, error };
	}

	//#region Device detils page
	public async GetDeviceViewMeasures(): Promise<{
		devMeasures: DeviceMeasures;
		error: ErrorCode;
	}> {
		console.log('----------> GetDeviceViewMeasures called:');
		let error: ErrorCode = ErrorCode.eERR_UNKNOWN;

		let devMeasures: DeviceMeasures = new DeviceMeasures();
		resetTempData();
		const { errorCode, byteToSend, byteToReceive } =
			FaastFlexDeviceMeasures.GetViewMeasures({ msg: mMsgSend });
		mByteToSend = byteToSend;
		mByteToReceive = byteToReceive;
		if (errorCode === ErrorCode.eOK) {
			const response = await SendPacketWithByteReceived(
				mMsgSend,
				byteToReceive,
			);
			console.log('dm: Response:', response);
			const result = FaastFlexDeviceMeasures.GetViewMeasuresAnswer(
				{ msg: response },
				byteToReceive,
				byteToReceive,
			);
			console.log('mp: retErrorCode:', result.errorCode);

			if (result.errorCode === ErrorCode.eOK) {
				devMeasures.RPM = result.measures.RPM;
				devMeasures.CH1Flow = result.measures.CH1Flow;
				devMeasures.CH2Flow = result.measures.CH2Flow;
				devMeasures.CH1MinFlow = result.measures.CH1MinFlow;
				devMeasures.CH2MinFlow = result.measures.CH2MinFlow;
				devMeasures.CH1RefFlow = result.measures.CH1RefFlow;
				devMeasures.CH2RefFlow = result.measures.CH2RefFlow;
				devMeasures.CH1MaxFlow = result.measures.CH1MaxFlow;
				devMeasures.CH2MaxFlow = result.measures.CH2MaxFlow;
				devMeasures.CH1Temperature = result.measures.CH1Temperature;
				devMeasures.CH2Temperature = result.measures.CH2Temperature;
				devMeasures.CH1SmokeLevel = result.measures.CH1SmokeLevel;
				devMeasures.CH2SmokeLevel = result.measures.CH2SmokeLevel;
				devMeasures.CH1AlarmLevel = result.measures.CH1AlarmLevel;
				devMeasures.CH2AlarmLevel = result.measures.CH2AlarmLevel;
				devMeasures.CH1PreAlarmLevel = result.measures.CH1PreAlarmLevel;
				devMeasures.CH2PreAlarmLevel = result.measures.CH2PreAlarmLevel;
				error = result.errorCode;
			}
		}
		return { devMeasures, error };
	}
	//#endregion

	//#region  SaveGeneralParametersToDevice
	public async SetDatetimeofDevice(
		year: number = 0,
		month: number = 0,
		day: number = 0,
		hour: number = 0,
		minute: number = 0,
		second: number = 0,
	): Promise<{ isUpdated: boolean; error: ErrorCode }> {
		console.log('----------> GetModelType called:');
		let error: ErrorCode = ErrorCode.eERR_UNKNOWN;
		let isUpdated: boolean = false;
		resetTempData();
		const { errorCode, byteToSend, byteToReceive } =
			FaastFlexSetDatetimeofDevice.SetRealTimeClock(
				{ msg: mMsgSend },
				year,
				month,
				day,
				hour,
				minute,
				second,
			);
		mByteToSend = byteToSend;
		mByteToReceive = byteToReceive;
		if (errorCode === ErrorCode.eOK) {
			const response = await SendPacketWithByteReceived(
				mMsgSend,
				byteToReceive,
			);
			console.log('dm: Response:', response);
			const retValue = FaastFlexSetDatetimeofDevice.SetRealTimeClockAnswer(
				{ msg: response },
				byteToReceive,
				byteToReceive,
			);
			error = retValue.retErrorCode;
			if (retValue.retErrorCode === ErrorCode.eOK) {
				isUpdated = true;
			} else {
				isUpdated = false;
			}
		}
		return { isUpdated, error };
	}

	public async SetTrendlogDisabled(
		trendLog: number,
	): Promise<{ isUpdated: boolean; error: ErrorCode }> {
		let error: ErrorCode = ErrorCode.eERR_UNKNOWN;
		let isUpdated: boolean = false;

		resetTempData();
		const { errorCode, byteToSend, byteToReceive } =
			FaastFlexSetSetTrendlogDisabled.SetTrendLogIntervalEEPROM(
				{ msg: mMsgSend },
				trendLog,
			);
		mByteToSend = byteToSend;
		mByteToReceive = byteToReceive;
		if (errorCode === ErrorCode.eOK) {
			const response = await SendPacketWithByteReceived(
				mMsgSend,
				byteToReceive,
			);
			console.log('dm: Response:', response);
			const retValue =
				FaastFlexSetSetTrendlogDisabled.SetTrendLogIntervalEEPROMAnswer(
					{ msg: response },
					byteToReceive,
					byteToReceive,
				);
			error = retValue.retErrorCode;
			if (retValue.retErrorCode === ErrorCode.eOK) {
				isUpdated = true;
			} else {
				isUpdated = false;
			}
		}
		return { isUpdated, error };
	}

	public async SetTempFaultSetRelay(
		tempFaultRelay: RelayAlert,
	): Promise<{ isUpdated: boolean; error: ErrorCode }> {
		let error: ErrorCode = ErrorCode.eERR_UNKNOWN;
		let isUpdated: boolean = false;

		resetTempData();
		const { errorCode, byteToSend, byteToReceive } =
			FaastFlexSetTempFaultSetRelay.SetRelayForTemperatureAlertEEPROM(
				{ msg: mMsgSend },
				tempFaultRelay,
			);
		mByteToSend = byteToSend;
		mByteToReceive = byteToReceive;
		if (errorCode === ErrorCode.eOK) {
			const response = await SendPacketWithByteReceived(
				mMsgSend,
				byteToReceive,
			);
			console.log('dm: Response:', response);
			const retValue =
				FaastFlexSetTempFaultSetRelay.SetRelayForTemperatureAlertEEPROMAnswer(
					{ msg: response },
					byteToReceive,
					byteToReceive,
				);
			error = retValue.retErrorCode;
			if (retValue.retErrorCode === ErrorCode.eOK) {
				isUpdated = true;
			} else {
				isUpdated = false;
			}
		}
		return { isUpdated, error };
	}

	public async SetLowPowerFaultSetRelay(
		lowpowerFaultRelay: RelayAlert,
	): Promise<{ isUpdated: boolean; error: ErrorCode }> {
		let error: ErrorCode = ErrorCode.eERR_UNKNOWN;
		let isUpdated: boolean = false;

		resetTempData();
		const { errorCode, byteToSend, byteToReceive } =
			FaastFlexSetLowPowerFaultSetRelay.SetRelayForLowPowerAlertEEPROM(
				{ msg: mMsgSend },
				lowpowerFaultRelay,
			);
		mByteToSend = byteToSend;
		mByteToReceive = byteToReceive;
		if (errorCode === ErrorCode.eOK) {
			const response = await SendPacketWithByteReceived(
				mMsgSend,
				byteToReceive,
			);
			console.log('dm: Response:', response);
			const retValue =
				FaastFlexSetLowPowerFaultSetRelay.SetRelayForLowPowerAlertEEPROMAnswer(
					{ msg: response },
					byteToReceive,
					byteToReceive,
				);
			error = retValue.retErrorCode;
			if (retValue.retErrorCode === ErrorCode.eOK) {
				isUpdated = true;
			} else {
				isUpdated = false;
			}
		}
		return { isUpdated, error };
	}

	public async SetExternalInput(
		externalInput: ExternalInputMode,
	): Promise<{ isUpdated: boolean; error: ErrorCode }> {
		let error: ErrorCode = ErrorCode.eERR_UNKNOWN;
		let isUpdated: boolean = false;

		resetTempData();
		const { errorCode, byteToSend, byteToReceive } =
			FaastFlexSetExternalInput.SetExtInputMode(
				{ msg: mMsgSend },
				externalInput,
			);
		mByteToSend = byteToSend;
		mByteToReceive = byteToReceive;
		if (errorCode === ErrorCode.eOK) {
			const response = await SendPacketWithByteReceived(
				mMsgSend,
				byteToReceive,
			);
			console.log('dm: Response:', response);
			const retValue = FaastFlexSetExternalInput.SetExtInputModeAnswer(
				{ msg: response },
				byteToReceive,
				byteToReceive,
			);
			error = retValue.retErrorCode;
			if (retValue.retErrorCode === ErrorCode.eOK) {
				isUpdated = true;
			} else {
				isUpdated = false;
			}
		}
		return { isUpdated, error };
	}

	public async SetExternalTriggredOpen(
		externalInputAction: ExternalInputAction,
	): Promise<{ isUpdated: boolean; error: ErrorCode }> {
		let error: ErrorCode = ErrorCode.eERR_UNKNOWN;
		let isUpdated: boolean = false;

		resetTempData();
		const { errorCode, byteToSend, byteToReceive } =
			FaastFlexSetExternalTriggredOpen.SetExtInputBalancedActionOnOpenEEPROM(
				{ msg: mMsgSend },
				externalInputAction,
			);
		mByteToSend = byteToSend;
		mByteToReceive = byteToReceive;
		if (errorCode === ErrorCode.eOK) {
			const response = await SendPacketWithByteReceived(
				mMsgSend,
				byteToReceive,
			);
			console.log('dm: Response:', response);
			const retValue =
				FaastFlexSetExternalTriggredOpen.SetExtInputBalancedActionOnOpenEEPROMAnswer(
					{ msg: response },
					byteToReceive,
					byteToReceive,
				);
			error = retValue.retErrorCode;
			if (retValue.retErrorCode === ErrorCode.eOK) {
				isUpdated = true;
			} else {
				isUpdated = false;
			}
		}
		return { isUpdated, error };
	}

	public async SetExternalTriggredClosed(
		externalInputAction: ExternalInputAction,
	): Promise<{ isUpdated: boolean; error: ErrorCode }> {
		let error: ErrorCode = ErrorCode.eERR_UNKNOWN;
		let isUpdated: boolean = false;

		resetTempData();
		const { errorCode, byteToSend, byteToReceive } =
			FaastFlexSetExternalTriggredClosed.SetExternalInputBalancedActionOnShortEEPROM(
				{ msg: mMsgSend },
				externalInputAction,
			);
		mByteToSend = byteToSend;
		mByteToReceive = byteToReceive;
		if (errorCode === ErrorCode.eOK) {
			const response = await SendPacketWithByteReceived(
				mMsgSend,
				byteToReceive,
			);
			console.log('dm: Response:', response);
			const retValue =
				FaastFlexSetExternalTriggredClosed.SetExternalInputBalancedActionOnShortEEPROMAnswer(
					{ msg: response },
					byteToReceive,
					byteToReceive,
				);
			error = retValue.retErrorCode;
			if (retValue.retErrorCode === ErrorCode.eOK) {
				isUpdated = true;
			} else {
				isUpdated = false;
			}
		}
		return { isUpdated, error };
	}

	public async SetExternalUnbalancedNormalState(
		extInputNormal: ExternalInputNormalState,
	): Promise<{ isUpdated: boolean; error: ErrorCode }> {
		let error: ErrorCode = ErrorCode.eERR_UNKNOWN;
		let isUpdated: boolean = false;

		resetTempData();
		const { errorCode, byteToSend, byteToReceive } =
			FaastFlexSetExternalUnbalancedNormalState.SetExtInputUnbalancedNormalStateEEPROM(
				{ msg: mMsgSend },
				extInputNormal,
			);
		mByteToSend = byteToSend;
		mByteToReceive = byteToReceive;
		if (errorCode === ErrorCode.eOK) {
			const response = await SendPacketWithByteReceived(
				mMsgSend,
				byteToReceive,
			);
			console.log('dm: Response:', response);
			const retValue =
				FaastFlexSetExternalUnbalancedNormalState.SetExtInputUnbalancedNormalStateEEPROMAnswer(
					{ msg: response },
					byteToReceive,
					byteToReceive,
				);
			error = retValue.retErrorCode;
			if (retValue.retErrorCode === ErrorCode.eOK) {
				isUpdated = true;
			} else {
				isUpdated = false;
			}
		}
		return { isUpdated, error };
	}

	public async SetExternalTriggredUnbalanced(
		extInputAction: ExternalInputAction,
	): Promise<{ isUpdated: boolean; error: ErrorCode }> {
		let error: ErrorCode = ErrorCode.eERR_UNKNOWN;
		let isUpdated: boolean = false;

		resetTempData();
		const { errorCode, byteToSend, byteToReceive } =
			FaastFlexSetExternalTriggredUnbalanced.SetExtInputUnbalancedActionOnChangeEEPROM(
				{ msg: mMsgSend },
				extInputAction,
			);
		mByteToSend = byteToSend;
		mByteToReceive = byteToReceive;
		if (errorCode === ErrorCode.eOK) {
			const response = await SendPacketWithByteReceived(
				mMsgSend,
				byteToReceive,
			);
			console.log('dm: Response:', response);
			const retValue =
				FaastFlexSetExternalTriggredUnbalanced.SetExtInputUnbalancedActionOnChangeEEPROMAnswer(
					{ msg: response },
					byteToReceive,
					byteToReceive,
				);
			error = retValue.retErrorCode;
			if (retValue.retErrorCode === ErrorCode.eOK) {
				isUpdated = true;
			} else {
				isUpdated = false;
			}
		}
		return { isUpdated, error };
	}

	public async GetBlowerSpeed(): Promise<{
		fanSpeedLevel: FanSpeedLevel;
		error: ErrorCode;
	}> {
		console.log('----------> GetBlowerSpeed called:');
		let error: ErrorCode = ErrorCode.eERR_UNKNOWN;
		let fanSpeedLevel: FanSpeedLevel = FanSpeedLevel.eUnknown;

		resetTempData();
		// You need to import this from a module like "../faastflexCommands/command_getBlowerSpeed"
		const { errorCode, byteToSend, byteToReceive } =
			FaastFlexGetBlowerSpeed.GetFanSpeedLevelEEPROM({ msg: mMsgSend });
		mByteToSend = byteToSend;
		mByteToReceive = byteToReceive;

		if (errorCode === ErrorCode.eOK) {
			const response = await SendPacketWithByteReceived(
				mMsgSend,
				byteToReceive,
			);
			console.log('GetBlowerSpeed response:', response);

			const retValue = FaastFlexGetBlowerSpeed.GetFanSpeedLevelEEPROMAnswer(
				{ msg: response },
				byteToReceive,
				byteToReceive,
			);

			error = retValue.retErrorCode;
			if (retValue.retErrorCode === ErrorCode.eOK) {
				fanSpeedLevel = retValue.fanSpeedLevel;
			}
		}

		return { fanSpeedLevel, error };
	}

	public async SetBlowerSpeed(
		fanSpeed: FanSpeedLevel,
	): Promise<{ isUpdated: boolean; error: ErrorCode }> {
		let error: ErrorCode = ErrorCode.eERR_UNKNOWN;
		let isUpdated: boolean = false;

		resetTempData();
		const { errorCode, byteToSend, byteToReceive } =
			FaastFlexSetBlowerSpeed.SetFanSpeedEEPROM({ msg: mMsgSend }, fanSpeed);
		mByteToSend = byteToSend;
		mByteToReceive = byteToReceive;
		if (errorCode === ErrorCode.eOK) {
			const response = await SendPacketWithByteReceived(
				mMsgSend,
				byteToReceive,
			);
			console.log('dm: Response:', response);
			const retValue = FaastFlexSetBlowerSpeed.SetFanSpeedEEPROMAnswer(
				{ msg: response },
				byteToReceive,
				byteToReceive,
			);
			error = retValue.retErrorCode;
			if (retValue.retErrorCode === ErrorCode.eOK) {
				isUpdated = true;
			} else {
				isUpdated = false;
			}
		}
		return { isUpdated, error };
	}
	//#endregion

	//#region SaveChannelsAndSensorsParametersToDevice
	public async SetPreAlarmDelay(
		inputParam: number,
	): Promise<{ isUpdated: boolean; error: ErrorCode }> {
		let error: ErrorCode = ErrorCode.eERR_UNKNOWN;
		let isUpdated: boolean = false;

		resetTempData();
		const { errorCode, byteToSend, byteToReceive } =
			FaastFlexSetPreAlarmDelay.SetPreAlarmDelayEEPROM(
				{ msg: mMsgSend },
				inputParam,
			);
		mByteToSend = byteToSend;
		mByteToReceive = byteToReceive;
		if (errorCode === ErrorCode.eOK) {
			const response = await SendPacketWithByteReceived(
				mMsgSend,
				byteToReceive,
			);
			console.log('dm: Response:', response);
			const retValue = FaastFlexSetPreAlarmDelay.SetPreAlarmDelayEEPROMAnswer(
				{ msg: response },
				byteToReceive,
				byteToReceive,
			);
			error = retValue.retErrorCode;
			if (retValue.retErrorCode === ErrorCode.eOK) {
				isUpdated = true;
			} else {
				isUpdated = false;
			}
		}
		return { isUpdated, error };
	}

	public async SetAlarmDelay(
		inputParam: number,
	): Promise<{ isUpdated: boolean; error: ErrorCode }> {
		let error: ErrorCode = ErrorCode.eERR_UNKNOWN;
		let isUpdated: boolean = false;

		resetTempData();
		const { errorCode, byteToSend, byteToReceive } =
			FaastFlexSetAlarmDelay.SetAlarmDelayEEPROM({ msg: mMsgSend }, inputParam);
		mByteToSend = byteToSend;
		mByteToReceive = byteToReceive;
		if (errorCode === ErrorCode.eOK) {
			const response = await SendPacketWithByteReceived(
				mMsgSend,
				byteToReceive,
			);
			console.log('dm: Response:', response);
			const retValue = FaastFlexSetAlarmDelay.SetAlarmDelayEEPROMAnswer(
				{ msg: response },
				byteToReceive,
				byteToReceive,
			);
			error = retValue.retErrorCode;
			if (retValue.retErrorCode === ErrorCode.eOK) {
				isUpdated = true;
			} else {
				isUpdated = false;
			}
		}
		return { isUpdated, error };
	}

	public async SetFlowFaultDelay(
		inputParam: number,
	): Promise<{ isUpdated: boolean; error: ErrorCode }> {
		let error: ErrorCode = ErrorCode.eERR_UNKNOWN;
		let isUpdated: boolean = false;

		resetTempData();
		const { errorCode, byteToSend, byteToReceive } =
			FaastFlexSetFlowFaultDelay.SetFlowFaultDelayEEPROM(
				{ msg: mMsgSend },
				inputParam,
			);
		mByteToSend = byteToSend;
		mByteToReceive = byteToReceive;
		if (errorCode === ErrorCode.eOK) {
			const response = await SendPacketWithByteReceived(
				mMsgSend,
				byteToReceive,
			);
			console.log('dm: Response:', response);
			const retValue = FaastFlexSetFlowFaultDelay.SetFlowFaultDelayEEPROMAnswer(
				{ msg: response },
				byteToReceive,
				byteToReceive,
			);
			error = retValue.retErrorCode;
			if (retValue.retErrorCode === ErrorCode.eOK) {
				isUpdated = true;
			} else {
				isUpdated = false;
			}
		}
		return { isUpdated, error };
	}

	public async SetAlarmLatched(
		inputParam: LatchedMode,
	): Promise<{ isUpdated: boolean; error: ErrorCode }> {
		let error: ErrorCode = ErrorCode.eERR_UNKNOWN;
		let isUpdated: boolean = false;

		resetTempData();
		const { errorCode, byteToSend, byteToReceive } =
			FaastFlexSetAlarmLatched.SetBothAlarmLatchedEEPROM(
				{ msg: mMsgSend },
				inputParam,
			);
		mByteToSend = byteToSend;
		mByteToReceive = byteToReceive;
		if (errorCode === ErrorCode.eOK) {
			const response = await SendPacketWithByteReceived(
				mMsgSend,
				byteToReceive,
			);
			console.log('dm: Response:', response);
			const retValue = FaastFlexSetAlarmLatched.SetBothAlarmLatchedEEPROMAnswer(
				{ msg: response },
				byteToReceive,
				byteToReceive,
			);
			error = retValue.retErrorCode;
			if (retValue.retErrorCode === ErrorCode.eOK) {
				isUpdated = true;
			} else {
				isUpdated = false;
			}
		}
		return { isUpdated, error };
	}

	public async SetPreAlarmLatched(
		inputParam: LatchedMode,
	): Promise<{ isUpdated: boolean; error: ErrorCode }> {
		let error: ErrorCode = ErrorCode.eERR_UNKNOWN;
		let isUpdated: boolean = false;

		resetTempData();
		const { errorCode, byteToSend, byteToReceive } =
			FaastFlexSetPreAlarmLatched.SetBothPreAlarmLatchedEEPROM(
				{ msg: mMsgSend },
				inputParam,
			);
		mByteToSend = byteToSend;
		mByteToReceive = byteToReceive;
		if (errorCode === ErrorCode.eOK) {
			const response = await SendPacketWithByteReceived(
				mMsgSend,
				byteToReceive,
			);
			console.log('dm: Response:', response);
			const retValue =
				FaastFlexSetPreAlarmLatched.SetBothPreAlarmLatchedEEPROMAnswer(
					{ msg: response },
					byteToReceive,
					byteToReceive,
				);
			error = retValue.retErrorCode;
			if (retValue.retErrorCode === ErrorCode.eOK) {
				isUpdated = true;
			} else {
				isUpdated = false;
			}
		}
		return { isUpdated, error };
	}

	public async SetFaultLatched(
		inputParam: LatchedMode,
	): Promise<{ isUpdated: boolean; error: ErrorCode }> {
		let error: ErrorCode = ErrorCode.eERR_UNKNOWN;
		let isUpdated: boolean = false;

		resetTempData();
		const { errorCode, byteToSend, byteToReceive } =
			FaastFlexSetFaultLatched.SetBothFaultLatchedEEPROM(
				{ msg: mMsgSend },
				inputParam,
			);
		mByteToSend = byteToSend;
		mByteToReceive = byteToReceive;
		if (errorCode === ErrorCode.eOK) {
			const response = await SendPacketWithByteReceived(
				mMsgSend,
				byteToReceive,
			);
			console.log('dm: Response:', response);
			const retValue = FaastFlexSetFaultLatched.SetBothFaultLatchedEEPROMAnswer(
				{ msg: response },
				byteToReceive,
				byteToReceive,
			);
			error = retValue.retErrorCode;
			if (retValue.retErrorCode === ErrorCode.eOK) {
				isUpdated = true;
			} else {
				isUpdated = false;
			}
		}
		return { isUpdated, error };
	}

	public async SetAlarmMode(
		inputParam: AlarmMode,
	): Promise<{ isUpdated: boolean; error: ErrorCode }> {
		let error: ErrorCode = ErrorCode.eERR_UNKNOWN;
		let isUpdated: boolean = false;

		resetTempData();
		const { errorCode, byteToSend, byteToReceive } =
			FaastFlexSetAlarmMode.SetAlarmModeEEPROM({ msg: mMsgSend }, inputParam);
		mByteToSend = byteToSend;
		mByteToReceive = byteToReceive;
		if (errorCode === ErrorCode.eOK) {
			const response = await SendPacketWithByteReceived(
				mMsgSend,
				byteToReceive,
			);
			console.log('dm: Response:', response);
			const retValue = FaastFlexSetAlarmMode.SetAlarmModeEEPROMAnswer(
				{ msg: response },
				byteToReceive,
				byteToReceive,
			);
			error = retValue.retErrorCode;
			if (retValue.retErrorCode === ErrorCode.eOK) {
				isUpdated = true;
			} else {
				isUpdated = false;
			}
		}
		return { isUpdated, error };
	}

	public async SetChannelAlarmLevel(
		_channel: Channel,
		inputParam: AlarmLevel,
	): Promise<{ isUpdated: boolean; error: ErrorCode }> {
		let error: ErrorCode = ErrorCode.eERR_UNKNOWN;
		let isUpdated: boolean = false;

		resetTempData();
		const { errorCode, byteToSend, byteToReceive } =
			FaastFlexSetChannelAlarmLevel.SetAlarmLevelEEPROM(
				{ msg: mMsgSend },
				_channel,
				inputParam,
			);
		mByteToSend = byteToSend;
		mByteToReceive = byteToReceive;
		if (errorCode === ErrorCode.eOK) {
			const response = await SendPacketWithByteReceived(
				mMsgSend,
				byteToReceive,
			);
			console.log('dm: Response:', response);
			const retValue = FaastFlexSetChannelAlarmLevel.SetAlarmLevelEEPROMAnswer(
				{ msg: response },
				byteToReceive,
				byteToReceive,
			);
			error = retValue.retErrorCode;
			if (retValue.retErrorCode === ErrorCode.eOK) {
				isUpdated = true;
			} else {
				isUpdated = false;
			}
		}
		return { isUpdated, error };
	}
	public async SetChannelPreAlarmLevel(
		_channel: Channel,
		inputParam: PreAlarmLevel,
	): Promise<{ isUpdated: boolean; error: ErrorCode }> {
		let error: ErrorCode = ErrorCode.eERR_UNKNOWN;
		let isUpdated: boolean = false;

		resetTempData();
		const { errorCode, byteToSend, byteToReceive } =
			FaastFlexSetChannelPreAlarmLevel.SetPreAlarmLevelEEPROM(
				{ msg: mMsgSend },
				_channel,
				inputParam,
			);
		mByteToSend = byteToSend;
		mByteToReceive = byteToReceive;
		if (errorCode === ErrorCode.eOK) {
			const response = await SendPacketWithByteReceived(
				mMsgSend,
				byteToReceive,
			);
			console.log('dm: Response:', response);
			const retValue =
				FaastFlexSetChannelPreAlarmLevel.SetPreAlarmLevelEEPROMAnswer(
					{ msg: response },
					byteToReceive,
					byteToReceive,
				);
			error = retValue.retErrorCode;
			if (retValue.retErrorCode === ErrorCode.eOK) {
				isUpdated = true;
			} else {
				isUpdated = false;
			}
		}
		return { isUpdated, error };
	}
	public async SetFlowFaultThreshold(
		_channel: Channel,
		inputParam: number,
	): Promise<{ isUpdated: boolean; error: ErrorCode }> {
		let error: ErrorCode = ErrorCode.eERR_UNKNOWN;
		let isUpdated: boolean = false;

		resetTempData();
		const { errorCode, byteToSend, byteToReceive } =
			FaastFlexSetFlowFaultThreshold.SetFlowFaultThresholdEEPROM(
				{ msg: mMsgSend },
				_channel,
				inputParam,
			);
		mByteToSend = byteToSend;
		mByteToReceive = byteToReceive;
		if (errorCode === ErrorCode.eOK) {
			const response = await SendPacketWithByteReceived(
				mMsgSend,
				byteToReceive,
			);
			console.log('dm: Response:', response);
			const retValue =
				FaastFlexSetFlowFaultThreshold.SetFlowFaultThresholdEEPROMAnswer(
					{ msg: response },
					byteToReceive,
					byteToReceive,
				);
			error = retValue.retErrorCode;
			if (retValue.retErrorCode === ErrorCode.eOK) {
				isUpdated = true;
			} else {
				isUpdated = false;
			}
		}
		return { isUpdated, error };
	}
	//#endregion

	//#region Aspirator Spare part change

	public async GetBlowerSpeedCorrection(): Promise<{
		fanCorrectionValue: FanPWMPercCorrection;
		error: ErrorCode;
	}> {
		console.log('----------> GetBlowerSpeed called:');
		let error: ErrorCode = ErrorCode.eERR_UNKNOWN;
		let fanCorrection: FanPWMPercCorrection = FanPWMPercCorrection.eUnknown;

		resetTempData();
		// You need to import this from a module like "../faastflexCommands/command_getBlowerSpeed"
		const { errorCode, byteToSend, byteToReceive } =
			FaastFlexGetBlowerSpeedCorrection.GetFanCorrectionEEPROM({
				msg: mMsgSend,
			});
		mByteToSend = byteToSend;
		mByteToReceive = byteToReceive;

		if (errorCode === ErrorCode.eOK) {
			const response = await SendPacketWithByteReceived(
				mMsgSend,
				byteToReceive,
			);
			console.log('GetBlowerSpeed response:', response);

			const retValue =
				FaastFlexGetBlowerSpeedCorrection.GetFanCorrectionEEPROMAnswer(
					{ msg: response },
					byteToReceive,
					byteToReceive,
				);

			error = retValue.retErrorCode;
			if (retValue.retErrorCode === ErrorCode.eOK) {
				fanCorrection = retValue.fanCorrection;
			}
		}

		return { fanCorrectionValue: fanCorrection, error };
	}

	public async SetBlowerSpeedCorrection(
		fancorrection: FanPWMPercCorrection,
	): Promise<{ isUpdated: boolean; error: ErrorCode }> {
		let error: ErrorCode = ErrorCode.eERR_UNKNOWN;
		let isUpdated: boolean = false;

		resetTempData();
		const { errorCode, byteToSend, byteToReceive } =
			FaastFlexSetBlowerSpeedCorrection.SetFanCorrectionEEPROM(
				{ msg: mMsgSend },
				fancorrection,
			);
		mByteToSend = byteToSend;
		mByteToReceive = byteToReceive;
		if (errorCode === ErrorCode.eOK) {
			const response = await SendPacketWithByteReceived(
				mMsgSend,
				byteToReceive,
			);
			console.log('dm: Response:', response);
			const retValue =
				FaastFlexSetBlowerSpeedCorrection.SetFanCorrectionEEPROMAnswer(
					{ msg: response },
					byteToReceive,
					byteToReceive,
				);
			error = retValue.retErrorCode;
			if (retValue.retErrorCode === ErrorCode.eOK) {
				isUpdated = true;
			} else {
				isUpdated = false;
			}
		}
		return { isUpdated, error };
	}
	//#endregion

	//#region Normalize Device
	public async SetNormalizedCommand(): Promise<{
		isReset: boolean;
		error: ErrorCode;
	}> {
		console.log('----------> StartSelfTestForChina called:');
		let error: ErrorCode = ErrorCode.eERR_UNKNOWN;
		resetTempData();
		const { errorCode, byteToSend, byteToReceive } =
			FaastFlexSetNormalizedCommand.StartNormalize({ msg: mMsgSend });
		mByteToSend = byteToSend;
		mByteToReceive = byteToReceive;
		if (errorCode === ErrorCode.eOK) {
			const response = await SendPacketWithByteReceived(
				mMsgSend,
				byteToReceive,
			);
			console.log('dm: Response:', response);
			const retValue = FaastFlexSetNormalizedCommand.StartNormalizeAnswer(
				{ msg: response },
				byteToReceive,
				byteToReceive,
			);
			error = retValue.retErrorCode;
			if (retValue.retErrorCode === ErrorCode.eOK) {
				return { isReset: true, error };
			}
		}
		return { isReset: false, error };
	}
	//#endregion

	//#region Sound Pairing
	public async SoundPairingSequence(
		uniqueIdentifier: string,
	): Promise<{ isStarted: boolean; error: ErrorCode }> {
		let error: ErrorCode = ErrorCode.eERR_UNKNOWN;
		let isStarted: boolean = false;
		console.log('uniqueIdentifier:', uniqueIdentifier);
		resetTempData();
		const { errorCode, byteToSend, byteToReceive } =
			FaastFlexSoundPairing.startSoundPairing(
				{ msg: mMsgSend },
				uniqueIdentifier.charCodeAt(0),
				uniqueIdentifier.charCodeAt(1),
				uniqueIdentifier.charCodeAt(2),
				uniqueIdentifier.charCodeAt(3),
				uniqueIdentifier.charCodeAt(4),
				uniqueIdentifier.charCodeAt(5),
				uniqueIdentifier.charCodeAt(6),
				uniqueIdentifier.charCodeAt(7),
				uniqueIdentifier.charCodeAt(8),
				uniqueIdentifier.charCodeAt(9),
				uniqueIdentifier.charCodeAt(10),
				uniqueIdentifier.charCodeAt(11),
			);
		mByteToSend = byteToSend;
		mByteToReceive = byteToReceive;
		console.log('mp: ErrorCode:', errorCode);
		console.log('mp: ByteToSend:', byteToSend);
		console.log('mp: ByteToReceive:', byteToReceive);
		console.log('mp: msg:', mMsgSend);
		if (errorCode === ErrorCode.eOK) {
			const response = await SendPacketWithByteReceived(
				mMsgSend,
				byteToReceive,
			);
			console.log('mp: Response:', response);
			const returnVal = FaastFlexSoundPairing.starSoundPairingAnswer(
				{ msg: response },
				byteToReceive,
				byteToReceive,
			);

			if (returnVal === ErrorCode.eOK) {
				error = returnVal;
				isStarted = true;
			}
		}
		return { isStarted, error };
	}

	// Add this method to the FaastFlexCommunicator class
	public async StartDecodedPwdDigits(
		p1: number,
		p2: number,
		p3: number,
		p4: number,
		p5: number,
		p6: number,
	): Promise<{ isAuthenticated: DeviceAuthenticated; error: ErrorCode }> {
		console.log('----------> StartDecodedPwdDigits called');
		let error: ErrorCode = ErrorCode.eERR_UNKNOWN;
		let deviceAuthenticated: DeviceAuthenticated = DeviceAuthenticated.eUnknown;

		resetTempData();

		// You'll need to import this from a module or create it
		const { errorCode, byteToSend, byteToReceive } =
			FaastFlexSoundPairing.SoundPairingPassword(
				{ msg: mMsgSend },
				p1,
				p2,
				p3,
				p4,
				p5,
				p6,
			);

		mByteToSend = byteToSend;
		mByteToReceive = byteToReceive;

		if (errorCode === ErrorCode.eOK) {
			const response = await SendPacketWithByteReceived(
				mMsgSend,
				byteToReceive,
			);
			console.log('StartDecodedPwdDigits response:', response);

			// You'll need to import this from a module or create it
			const retValue = FaastFlexSoundPairing.SendDecodedPwdDigitsAnswer(
				{ msg: response },
				byteToReceive,
				byteToReceive,
			);
			error = retValue.retErrorCode;
			if (retValue.retErrorCode === ErrorCode.eOK) {
				deviceAuthenticated = DeviceAuthenticated.eAuthenticated;
			} else {
				deviceAuthenticated = DeviceAuthenticated.eNotAuthenticated;
			}
		}

		return { isAuthenticated: deviceAuthenticated, error };
	}
	//#endregion

	//#region Intelligent Device Commands

	public async GetFFIDeviceViewMeasures(): Promise<{
		devMeasures: DeviceMeasures;
		error: ErrorCode;
	}> {
		console.log('----------> Get FFI DeviceViewMeasures called:');
		let error: ErrorCode = ErrorCode.eERR_UNKNOWN;

		let devMeasures: DeviceMeasures = new DeviceMeasures();
		resetTempData();
		const { errorCode, byteToSend, byteToReceive } =
			FaastFlexIntelligentDeviceMeasures.GetFaastFlexIntelligentViewMeasures({
				msg: mMsgSend,
			});
		mByteToSend = byteToSend;
		mByteToReceive = byteToReceive;
		if (errorCode === ErrorCode.eOK) {
			const response = await SendPacketWithByteReceived(
				mMsgSend,
				byteToReceive,
			);
			console.log('dm: Response:', response);
			const result =
				FaastFlexIntelligentDeviceMeasures.GetFaastFlexIntelligentViewMeasuresAnswer(
					{ msg: response },
					byteToReceive,
					byteToReceive,
				);
			console.log('mp: retErrorCode:', result.errorCode);

			if (result.errorCode === ErrorCode.eOK) {
				devMeasures.RPM = result.measures.RPM;
				devMeasures.CH1Flow = result.measures.CH1Flow;
				devMeasures.CH2Flow = result.measures.CH2Flow;
				devMeasures.CH1MinFlow = result.measures.CH1MinFlow;
				devMeasures.CH2MinFlow = result.measures.CH2MinFlow;
				devMeasures.CH1RefFlow = result.measures.CH1RefFlow;
				devMeasures.CH2RefFlow = result.measures.CH2RefFlow;
				devMeasures.CH1MaxFlow = result.measures.CH1MaxFlow;
				devMeasures.CH2MaxFlow = result.measures.CH2MaxFlow;
				devMeasures.CH1Temperature = result.measures.CH1Temperature;
				devMeasures.CH2Temperature = result.measures.CH2Temperature;
				error = result.errorCode;
			}
		}
		return { devMeasures, error };
	}

	public async GetFFIRecentlogs(
		logIndexLSB: number,
		logIndexMSB: number,
	): Promise<{ eventLog: EventLogModel; error: ErrorCode }> {
		let error: ErrorCode = ErrorCode.eERR_UNKNOWN;
		let eventLog: EventLogModel = new EventLogModel();

		resetTempData();
		const { errorCode, byteToSend, byteToReceive } =
			FaastFlexIntelligentLogs.GetFFILogEntry(
				{ msg: mMsgSend },
				logIndexLSB,
				logIndexMSB,
			);
		mByteToSend = byteToSend;
		mByteToReceive = byteToReceive;
		if (errorCode === ErrorCode.eOK) {
			const response = await SendPacketWithByteReceived(
				mMsgSend,
				byteToReceive,
			);
			console.log('dm: Response:', response);
			const retValue = FaastFlexIntelligentLogs.GetFFILogEntryAnswer(
				{ msg: response },
				byteToReceive,
				byteToReceive,
			);
			error = retValue.retErrorCode;
			if (retValue.retErrorCode === ErrorCode.eOK) {
				eventLog.logId = retValue.logEntryId;
				const strMonth = retValue.month.toString().padStart(2, '0');
				const strDay = retValue.day.toString().padStart(2, '0');
				try {
					// const format = retValue.year.toString() + strMonth + strDay;
					// const dt = parse(format, 'yyMMdd', new Date(), { locale: enGB });
					const fullYear =
						retValue.year < 100 ? 2000 + retValue.year : retValue.year;
					const dateTime = new Date(
						fullYear,
						retValue.month - 1,
						retValue.day,
						retValue.hour,
						retValue.minute,
						retValue.second,
					);
					eventLog.eventDateTime = dateTime.toLocaleDateString();
					eventLog.eventDate = dateFormat(dateTime, 'dd MMMM yyyy');
					eventLog.eventTime = dateFormat(dateTime, 'hh:mm:ss');
				} catch (e) {
					console.error('Error formatting date:', e);
				}
				eventLog.eventType = retValue.eventType;
				eventLog.eventTypeStr = getLogEventTypeDescription(retValue.eventType);
				if (retValue.eventType === LogEventType.eUnknown) {
					eventLog.eventBarColor = '#B9261C';
					eventLog.statusIcon = 'Alarm.png';
				} else if (retValue.eventType === LogEventType.eAlarm) {
					eventLog.eventBarColor = '#F58D4C';
					eventLog.statusIcon = 'Service.png';
				} else {
					eventLog.eventBarColor = '#FFD153';
					eventLog.statusIcon = 'DisabledStatus.png';
				}
				eventLog.logChannel = retValue.eventZone;
				eventLog.eventName = retValue.logEventId;
				eventLog.eventDescription = getLogEventIdDescription(
					retValue.logEventId,
				);
				eventLog.addtionalInfo =
					'Temp Ch1 = ' +
					retValue.temperatureChannel1 +
					', Temp Ch2 = ' +
					retValue.temperatureChannel2 +
					', Flow Ch1 = ' +
					retValue.flowChannel1 +
					', Flow Ch2 = ' +
					retValue.flowChannel2 +
					', LogZone = ' +
					getLogEventZoneDescription(retValue.eventZone) +
					', RPM = ' +
					retValue.blowerRPM;
				eventLog.eventIdInfo =
					'Event Id = ' +
					Number(retValue.logEventId) +
					', Log Seq Id = ' +
					retValue.logEntryId;
				eventLog.ch1Flow = retValue.flowChannel1;
				eventLog.ch2Flow = retValue.flowChannel2;
				eventLog.ch1Temperature = retValue.temperatureChannel1;
				eventLog.ch2Temperature = retValue.temperatureChannel2;
				eventLog.blowerRPM = retValue.blowerRPM;
			}
		}
		return { eventLog, error };
	}

	public async GetFFIDeviceChannelsAndSensorsParams(): Promise<{
		channelAndSensorParams: DeviceChannelAndSensorParams;
		error: ErrorCode;
	}> {
		let error: ErrorCode = ErrorCode.eERR_UNKNOWN;

		let params: DeviceChannelAndSensorParams =
			new DeviceChannelAndSensorParams();
		resetTempData();
		const { errorCode, byteToSend, byteToReceive } =
			FaastFlexIntelligentChannelsAndSensorsParameters.GetFFIntelligentChannelsAndSensorParams(
				{ msg: mMsgSend },
			);
		mByteToSend = byteToSend;
		mByteToReceive = byteToReceive;
		if (errorCode === ErrorCode.eOK) {
			const response = await SendPacketWithByteReceived(
				mMsgSend,
				byteToReceive,
			);
			console.log('dm: Response:', response);
			const retValue =
				FaastFlexIntelligentChannelsAndSensorsParameters.GetFFIntelligentChannelsAndSensorParamsAnswer(
					{ msg: response },
					byteToReceive,
					byteToReceive,
				);
			error = retValue.errorCode;
			if (error === ErrorCode.eOK) {
				params.flowFaultDelay = retValue.flowFaultDelay.toString();
				params.alarmLatched = retValue.ch1LatchAlarmRelay;
				params.alarm2Latched = retValue.ch2LatchAlarmRelay;
				params.generalFaultLatched = retValue.generalFaultRelay;
				params.auxFaultLatched = retValue.auxFaultRelay;
				params.alarmMode = retValue.alarmMode;

				params.ch1FlowFaultThreshold =
					retValue.flowthreshold === 128 ? 15 : retValue.flowthreshold;
				params.ch1RefAirflow = retValue.ch1RefAirflow;

				params.ch2RefAirflow = retValue.ch2RefAirflow;
			}
		}
		return { channelAndSensorParams: params, error };
	}
	public async GetFFIDeviceGeneralParams(): Promise<{
		generalParams: DeviceGeneralParams;
		error: ErrorCode;
	}> {
		let error: ErrorCode = ErrorCode.eERR_UNKNOWN;

		let generalParams: DeviceGeneralParams = {
			DeviceOrientation: DeviceOrientation.eUnknown,
			TempRelay: RelayAlert.eUnknown,
			LowPowerRelay: RelayAlert.eUnknown,
			BlowerSpeedLevel: FanSpeedLevel.eUnknown,
			BlowerSpeedCorrection: FanPWMPercCorrection.eUnknown,
			DeviceDateTime: new Date(),
			Trendlog: 0,
		};

		resetTempData();
		const { errorCode, byteToSend, byteToReceive } =
			FaastFlexIntelligentGeneralParameters.GetFFIGeneralParams({
				msg: mMsgSend,
			});
		mByteToSend = byteToSend;
		mByteToReceive = byteToReceive;
		if (errorCode === ErrorCode.eOK) {
			const response = await SendPacketWithByteReceived(
				mMsgSend,
				byteToReceive,
			);
			console.log('dm: Response:', response);
			const retValue =
				FaastFlexIntelligentGeneralParameters.GetFFIGeneralParamsAnswer(
					{ msg: response },
					byteToReceive,
					byteToReceive,
				);
			error = retValue.errorCode;
			if (error === ErrorCode.eOK) {
				generalParams.DeviceOrientation = retValue.deviceOrientation;
				generalParams.TempRelay = retValue.tempRelay;
				generalParams.BlowerSpeedLevel = retValue.blowerSpeedLevel;
				generalParams.BlowerSpeedCorrection = retValue.blowerSpeedCorrection;
				generalParams.Trendlog = retValue.trendlog;
				try {
					const format = retValue.year > 0 ? retValue.year.toString() : '00';
					const dt = parse(format, 'yy', new Date(), {
						locale: enGB,
					});
					generalParams.DeviceDateTime = new Date(
						dt.getFullYear(),
						retValue.month - 1,
						retValue.day,
						retValue.hour,
						retValue.minute,
						retValue.second,
					);
				} catch (e) {
					console.error('Error formatting date:', e);
				}
			}
		}
		return { generalParams, error };
	}

	public async GetFFISensorAddress(
		_channel: Channel,
	): Promise<{ address: number; error: ErrorCode }> {
		let error: ErrorCode = ErrorCode.eERR_UNKNOWN;
		let address: number = -1;

		resetTempData();
		const { errorCode, byteToSend, byteToReceive } =
			FaastFlexIntelligentGetSensorAddress.GetIntelligentSetSensorAddress(
				{ msg: mMsgSend },
				_channel,
			);
		mByteToSend = byteToSend;
		mByteToReceive = byteToReceive;
		if (errorCode === ErrorCode.eOK) {
			const response = await SendPacketWithByteReceived(
				mMsgSend,
				byteToReceive,
			);
			console.log('dm: Response:', response);
			const retValue =
				FaastFlexIntelligentGetSensorAddress.GetIntelligentSetSensorAddressAnswer(
					{ msg: response },
					byteToReceive,
					byteToReceive,
				);
			error = retValue.retErrorCode;
			if (retValue.retErrorCode === ErrorCode.eOK) {
				address = retValue.address;
			}
		}
		return { address, error };
	}

	public async SetFFISensorAddress(
		_channel: Channel,
		sensorAddress: number,
	): Promise<{ isUpdated: boolean; error: ErrorCode }> {
		let error: ErrorCode = ErrorCode.eERR_UNKNOWN;
		let isUpdated: boolean = false;

		resetTempData();
		const { errorCode, byteToSend, byteToReceive } =
			FaastFlexIntelligentSetSensorAddress.SetIntelligentSetSensorAddress(
				{ msg: mMsgSend },
				_channel,
				sensorAddress,
			);
		mByteToSend = byteToSend;
		mByteToReceive = byteToReceive;
		if (errorCode === ErrorCode.eOK) {
			const response = await SendPacketWithByteReceived(
				mMsgSend,
				byteToReceive,
			);
			console.log('dm: Response:', response);
			const retValue =
				FaastFlexIntelligentSetSensorAddress.SetIntelligentSetSensorAddressAnswer(
					{ msg: response },
					byteToReceive,
					byteToReceive,
				);
			error = retValue.retErrorCode;
			if (retValue.retErrorCode === ErrorCode.eOK) {
				isUpdated = true;
			} else {
				isUpdated = false;
			}
		}
		return { isUpdated, error };
	}

	public async SetFFITrendlogDisabled(
		trendLogLSB: number,
		trendLogMSB: number,
	): Promise<{ isUpdated: boolean; error: ErrorCode }> {
		let error: ErrorCode = ErrorCode.eERR_UNKNOWN;
		let isUpdated: boolean = false;

		resetTempData();
		const { errorCode, byteToSend, byteToReceive } =
			FaastFlexIntelligentSetSetTrendlogPeriod.SetFFITrendLogPeriod(
				{ msg: mMsgSend },
				trendLogLSB,
				trendLogMSB,
			);
		mByteToSend = byteToSend;
		mByteToReceive = byteToReceive;
		if (errorCode === ErrorCode.eOK) {
			const response = await SendPacketWithByteReceived(
				mMsgSend,
				byteToReceive,
			);
			console.log('dm: Response:', response);
			const retValue =
				FaastFlexSetSetTrendlogDisabled.SetTrendLogIntervalEEPROMAnswer(
					{ msg: response },
					byteToReceive,
					byteToReceive,
				);
			error = retValue.retErrorCode;
			if (retValue.retErrorCode === ErrorCode.eOK) {
				isUpdated = true;
			} else {
				isUpdated = false;
			}
		}
		return { isUpdated, error };
	}

	public async SetFFIFlowFaultThreshold(
		inputParam: number,
	): Promise<{ isUpdated: boolean; error: ErrorCode }> {
		let error: ErrorCode = ErrorCode.eERR_UNKNOWN;
		let isUpdated: boolean = false;

		resetTempData();
		const { errorCode, byteToSend, byteToReceive } =
			FaastFlexSetFlowFaultThreshold.SetFFIntelligentFlowFaultThresholdEEPROM(
				{ msg: mMsgSend },
				inputParam,
			);
		mByteToSend = byteToSend;
		mByteToReceive = byteToReceive;
		if (errorCode === ErrorCode.eOK) {
			const response = await SendPacketWithByteReceived(
				mMsgSend,
				byteToReceive,
			);
			console.log('dm: Response:', response);
			const retValue =
				FaastFlexSetFlowFaultThreshold.SetFFIntelligentFlowFaultThresholdEEPROMAnswer(
					{ msg: response },
					byteToReceive,
					byteToReceive,
				);
			error = retValue.retErrorCode;
			if (retValue.retErrorCode === ErrorCode.eOK) {
				isUpdated = true;
			} else {
				isUpdated = false;
			}
		}
		return { isUpdated, error };
	}

	public async FFI_SetAlarmLatched(
		inputParam: LatchedMode,
		_channel: Channel,
	): Promise<{ isUpdated: boolean; error: ErrorCode }> {
		let error: ErrorCode = ErrorCode.eERR_UNKNOWN;
		let isUpdated: boolean = false;

		resetTempData();
		const { errorCode, byteToSend, byteToReceive } =
			FaastFlexSetAlarmLatched.FFI_SetSingleChannelAlarmLatchedEEPROM(
				{ msg: mMsgSend },
				inputParam,
				_channel,
			);
		mByteToSend = byteToSend;
		mByteToReceive = byteToReceive;
		if (errorCode === ErrorCode.eOK) {
			const response = await SendPacketWithByteReceived(
				mMsgSend,
				byteToReceive,
			);
			console.log('dm: Response:', response);
			const retValue =
				FaastFlexSetAlarmLatched.FFI_SetSingleChannelAlarmLatchedEEPROMAnswer(
					{ msg: response },
					byteToReceive,
					byteToReceive,
				);
			error = retValue.retErrorCode;
			if (retValue.retErrorCode === ErrorCode.eOK) {
				isUpdated = true;
			} else {
				isUpdated = false;
			}
		}
		return { isUpdated, error };
	}
	public async FFI_SetGeneralFaultLatched(
		inputParam: LatchedMode,
	): Promise<{ isUpdated: boolean; error: ErrorCode }> {
		let error: ErrorCode = ErrorCode.eERR_UNKNOWN;
		let isUpdated: boolean = false;

		resetTempData();
		const { errorCode, byteToSend, byteToReceive } =
			FaastFlexSetFaultLatched.FFI_SetBothFaultLatched(
				{ msg: mMsgSend },
				inputParam,
			);
		mByteToSend = byteToSend;
		mByteToReceive = byteToReceive;
		if (errorCode === ErrorCode.eOK) {
			const response = await SendPacketWithByteReceived(
				mMsgSend,
				byteToReceive,
			);
			const retValue = FaastFlexSetFaultLatched.FFI_SetBothFaultLatchedAnswer(
				{ msg: response },
				byteToReceive,
				byteToReceive,
			);
			error = retValue.retErrorCode;
			if (retValue.retErrorCode === ErrorCode.eOK) {
				isUpdated = true;
			} else {
				isUpdated = false;
			}
		}
		return { isUpdated, error };
	}

	public async FFI_SetAuxFaultLatched(
		inputParam: LatchedMode,
	): Promise<{ isUpdated: boolean; error: ErrorCode }> {
		let error: ErrorCode = ErrorCode.eERR_UNKNOWN;
		let isUpdated: boolean = false;

		resetTempData();
		const { errorCode, byteToSend, byteToReceive } =
			FaastFlexSetAUXFaultLatched.FFI_SetBothAuxFaultLatched(
				{ msg: mMsgSend },
				inputParam,
			);
		mByteToSend = byteToSend;
		mByteToReceive = byteToReceive;
		if (errorCode === ErrorCode.eOK) {
			const response = await SendPacketWithByteReceived(
				mMsgSend,
				byteToReceive,
			);
			const retValue =
				FaastFlexSetAUXFaultLatched.FFI_SetBothAuxFaultLatchedAnswer(
					{ msg: response },
					byteToReceive,
					byteToReceive,
				);
			error = retValue.retErrorCode;
			if (retValue.retErrorCode === ErrorCode.eOK) {
				isUpdated = true;
			} else {
				isUpdated = false;
			}
		}
		return { isUpdated, error };
	}

	public async FFI_SetAlarmMode(
		inputParam: AlarmMode,
	): Promise<{ isUpdated: boolean; error: ErrorCode }> {
		let error: ErrorCode = ErrorCode.eERR_UNKNOWN;
		let isUpdated: boolean = false;

		resetTempData();
		const { errorCode, byteToSend, byteToReceive } =
			FaastFlexSetAlarmMode.FFI_SetAlarmMode({ msg: mMsgSend }, inputParam);
		mByteToSend = byteToSend;
		mByteToReceive = byteToReceive;
		if (errorCode === ErrorCode.eOK) {
			const response = await SendPacketWithByteReceived(
				mMsgSend,
				byteToReceive,
			);
			console.log('dm: Response:', response);
			const retValue = FaastFlexSetAlarmMode.FFI_SetAlarmModeAnswer(
				{ msg: response },
				byteToReceive,
				byteToReceive,
			);
			error = retValue.retErrorCode;
			if (retValue.retErrorCode === ErrorCode.eOK) {
				isUpdated = true;
			} else {
				isUpdated = false;
			}
		}
		return { isUpdated, error };
	}

	public async GetFFIActiveFaults(): Promise<{
		ch1SensoorComnFault: boolean;
		ch2SensoorComnFault: boolean;
		moduleASDFault: boolean;
		error: ErrorCode;
	}> {
		let error: ErrorCode = ErrorCode.eERR_UNKNOWN;
		let ch1SensoorComnFault: boolean = false;
		let ch2SensoorComnFault: boolean = false;
		let moduleASDFault: boolean = false;

		resetTempData();
		const { errorCode, byteToSend, byteToReceive } =
			FaastFlexIntelligentGetActiveFaults.FFI_GetActiveFaults({
				msg: mMsgSend,
			});
		mByteToSend = byteToSend;
		mByteToReceive = byteToReceive;
		if (errorCode === ErrorCode.eOK) {
			const response = await SendPacketWithByteReceived(
				mMsgSend,
				byteToReceive,
			);
			console.log('dm: Response:', response);
			const retValue =
				FaastFlexIntelligentGetActiveFaults.FFI_GetActiveFaultsAnswer(
					{ msg: response },
					byteToReceive,
					byteToReceive,
				);
			error = retValue.errorCode;
			if (retValue.errorCode === ErrorCode.eOK) {
				if (
					retValue.faultMask1 !== null &&
					retValue.faultMask1 &&
					retValue.faultMask1.length > 0 &&
					retValue.faultMask1.length === 8
				) {
					ch1SensoorComnFault = retValue.faultMask1[4] === 1;
					moduleASDFault = retValue.faultMask1[6] === 1;
				}
				if (
					retValue.faultMask2 !== null &&
					retValue.faultMask2 &&
					retValue.faultMask2.length > 0 &&
					retValue.faultMask2.length === 8
				) {
					ch2SensoorComnFault = retValue.faultMask2[2] === 1;
				}
			}
		}
		return {
			ch1SensoorComnFault,
			ch2SensoorComnFault,
			moduleASDFault,
			error,
		};
	}

	//#endregion
}
export default FaastFlexCommunicator.getInstance();
