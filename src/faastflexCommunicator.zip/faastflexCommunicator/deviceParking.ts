import { BluetoothDevice } from '../../src/bleCommunicator/bleService';

class DeviceParking {
	private static instance: DeviceParking;
	private parkedDevices: Map<string, BluetoothDevice>;

	private constructor() {
		this.parkedDevices = new Map<string, BluetoothDevice>();
	}

	public static getInstance(): DeviceParking {
		if (!DeviceParking.instance) {
			DeviceParking.instance = new DeviceParking();
		}
		return DeviceParking.instance;
	}

	public parkDevice(deviceName: string, device: BluetoothDevice): void {
		this.parkedDevices.set(deviceName, device);
	}

	public getParkedDevice(deviceName: string): BluetoothDevice | null {
		return this.parkedDevices.get(deviceName) ?? null;
	}

	public removeParkedDevice(deviceName: string): boolean {
		return this.parkedDevices.delete(deviceName);
	}
}

// Export a singleton instance
export default DeviceParking.getInstance();
