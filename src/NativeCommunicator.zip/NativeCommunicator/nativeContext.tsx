import React, { createContext, useContext, useState, useEffect } from 'react';
import NativeService from '../NativeCommunicator/nativeService.ts';
import { BleErrorCode } from '@global/GlobalConstants/globalConstants';
import { PermissionStatus } from 'react-native';
interface NativeContextType {
	getNativeEventEmitter: () => Promise<any>;
	EnableBluetooth: () => Promise<void>;
	GetPermission: () => Promise<void>;
	CheckBluetoothTurnedOn: () => Promise<boolean>;
	turnOnBluetooth: () => Promise<void>;
	requestBluetoothPermissions: () => Promise<PermissionStatus>;
}

const NativeContext = createContext<NativeContextType | undefined>(undefined);
const Turned_Off = 'TurnedOff';
const Scan_Completed = 'ScanCompleted';
const Not_Responding = 'NotResponding';
const BLUETOOTH_TIMEOUT = 'BLUETOOTH_TIMEOUT';
const BLUETOOTH_NOT_ENABLED = 'BLUETOOTH_NOT_ENABLED';
const BLUETOOTH_NOT_SUPPORTED = 'BLUETOOTH_NOT_SUPPORTED';

export const NativeProvider: React.FC<{ children: React.ReactNode }> = ({
	children,
}) => {
	const nativeEventEmitter = NativeService.getEventEmitter();

	useEffect(() => {
		setupEventListeners();
	}, []);

	const setupEventListeners = () => {
		cleanup();
		// Set up event listeners for the native module events
	};

	const getNativeEventEmitter = async () => {
		return NativeService.getEventEmitter();
	};
	// Request Bluetooth permissions
	const EnableBluetooth = async (): Promise<void> => {
		const status = await NativeService.EnableNativeBluetoothScanAndConnect();
		return status;
	};

	// Request Bluetooth permissions
	const GetPermission = async (): Promise<void> => {
		const status = await NativeService.GetPermission();
		return status;
	};

	const CheckBluetoothTurnedOn = async (): Promise<boolean> => {
		const status = await NativeService.CheckBluetoothTurnedOn();
		return status;
	};

	const turnOnBluetooth = async (): Promise<void> => {
		await NativeService.turnOnBluetooth();
	};

	// Request Bluetooth permissions
	async function requestBluetoothPermissions(): Promise<PermissionStatus> {
		try {
			const permissionStatus =
				await NativeService.requestBluetoothPermissions();
			return permissionStatus;
		} catch (error) {
			console.error('Error requesting Bluetooth permissions:', error);
			return 'denied' as PermissionStatus;
		}
	}
	/**
	 * Clean up event listeners
	 */
	const cleanup = () => {};

	return (
		<NativeContext.Provider
			value={{
				getNativeEventEmitter,
				EnableBluetooth,
				GetPermission,
				CheckBluetoothTurnedOn,
				turnOnBluetooth,
				requestBluetoothPermissions,
			}}>
			{children}
		</NativeContext.Provider>
	);
};

export const useNative = (): NativeContextType => {
	const context = useContext(NativeContext);
	if (!context) {
		throw new Error('useNative must be used within a NativeProvider');
	}
	return context;
};
