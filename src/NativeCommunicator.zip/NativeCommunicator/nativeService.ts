import {
	NativeModules,
	NativeEventEmitter,
	Platform,
	PermissionStatus,
} from 'react-native';

const { NativeCommunicator } = NativeModules;

class NativeService {
	private static instance: NativeService;
	private nativeEventEmitter: NativeEventEmitter;

	private constructor() {
		this.nativeEventEmitter = new NativeEventEmitter(NativeCommunicator);
	}

	public static getInstance(): NativeService {
		if (!NativeService.instance) {
			NativeService.instance = new NativeService();
		}
		return NativeService.instance;
	}

	/**
	 * Check and request Bluetooth permissions for Android API 31+
	 * @returns Permission status
	 */
	public async EnableNativeBluetoothScanAndConnect(): Promise<void> {
		NativeCommunicator.permitBluetoothScanAndConnect();
		return;
	}

	public async CheckBluetoothTurnedOn(): Promise<boolean> {
		return (await NativeCommunicator.isBluetoothTurnedOn()) as boolean;
	}
	public async turnOnBluetooth(): Promise<void> {
		const isTurnedOn = await NativeCommunicator.requestBluetoothOn();
		console.log('isTurnedOn ', isTurnedOn);
		return;
	}
	public async GetPermission(): Promise<void> {
		NativeCommunicator.getPermission();
		return;
	}

	public getEventEmitter(): NativeEventEmitter {
		return this.nativeEventEmitter;
	}

	public async requestBluetoothPermissions(): Promise<PermissionStatus> {
		if (Platform.OS === 'android') {
			try {
				// Check if the native module has the permission checking method
				const hasPermission =
					(await NativeCommunicator.checkBluetoothPermissions()) as boolean;
				if (!hasPermission) {
					// Use the native implementation if available
					const status =
						await NativeCommunicator.checkBluetoothPermissionsStatus();
					return status;
				}
			} catch (error) {
				console.error('Error requesting Bluetooth permissions:', error);
				return 'denied' as PermissionStatus;
			}
		}

		// Default return for older Android versions or when native implementation is not available
		return 'denied' as PermissionStatus;
	}
}

export default NativeService.getInstance();
