import {
	AnswerLength,
	ErrorCode,
	GclCmd,
	AnswerByteParamIndex,
	ModelType,
} from '../faastflexCommands/commandEnum';
import { ResponseParser } from '../faastflexCommands/command';
import { commonCommand } from '../faastflexCommands/CommonCommand';

interface FirmwareVersionResult {
	errorCode: ErrorCode;
	currentVersionRelease: number;
	currentVersionMajor: number;
	currentVersionMinor: number;
	currentVersionBuild: number;
}

export class FaastFlexModelType {
	public static GetModelTypeEEPROM(param: { msg: Uint8Array }): {
		errorCode: ErrorCode;
		byteToSend: number;
		byteToReceive: number;
	} {
		const { errorCode, byteToSend, byteToReceive } =
			commonCommand.cmdNoParamAnsData(
				param,
				GclCmd.SW_CMD_GET_MODEL_TYPE,
				AnswerLength.eThree,
			);

		return { errorCode, byteToSend, byteToReceive };
	}
	public static GetModelTypeEEPROMAnswer(
		param: { msg: Uint8Array },
		byteToBeReceived: number,
		byteReceived: number,
	): { retErrorCode: ErrorCode; retModelType: ModelType } {
		const { retErrorCode, retModelType } = this.ParseByteEnumAnswer(
			param.msg,
			byteToBeReceived,
			byteReceived,
			ModelType.eUnknown,
			ModelType,
		);
		return { retErrorCode, retModelType };
	}
	private static ParseByteEnumAnswer<RES_ENum extends number>(
		msg: Uint8Array,
		byteToBeReceived: number,
		byteReceived: number,
		defaultValue: RES_ENum,
		enumType: any,
	): { retErrorCode: ErrorCode; retModelType: RES_ENum } {
		let type: RES_ENum = defaultValue;
		let eRet: ErrorCode = ErrorCode.eOK;
		if (3 !== byteToBeReceived) {
			eRet = ErrorCode.eERR_ANS_INVALID_SIZE;
		}
		if (ErrorCode.eOK === eRet) {
			eRet = ResponseParser.checkAnswerMsgValidity(
				msg,
				byteToBeReceived,
				byteReceived,
			);
		}
		if (ErrorCode.eOK === eRet) {
			const { result, errorCode } = ResponseParser.getMsgAnswerParToEnum(
				msg,
				AnswerByteParamIndex.eParam_One,
				defaultValue,
				enumType,
			);
			type = result;
			eRet = errorCode;
		}
		return { retErrorCode: eRet, retModelType: type };
	}
}
