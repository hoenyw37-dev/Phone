import {
	AnswerLength,
	ErrorCode,
	FfIGclCmd,
	GclCmd,
} from '../faastflexCommands/commandEnum';
import {
	MessageHeaderHandler,
	ResponseParser,
} from '../faastflexCommands/command';
import { commonCommand } from '../faastflexCommands/CommonCommand';
import {
	getEventTypeFromEventId,
	getEventZoneFromEventId,
	LogEventId,
	LogEventType,
	LogEventZone,
} from './command_log';

export interface IEventLogData {
	logId?: number;
	eventDateTime?: Date;
	eventName?: LogEventId;
	eventDescription?: string;
	addtionalInfo?: string;
	eventDate?: string;
	eventTime?: string;
	eventType?: LogEventType;
	eventTypeStr?: string;
	logChannels?: LogEventZone;
	eventBarColor?: string;
	statusIcon?: string;
	eventIdInfo?: string;
	showErrorMessage?: boolean;
	ch1Temperature?: number;
	ch2Temperature?: number;
	ch1Flow?: number;
	ch2Flow?: number;
	ch1Sensor?: number;
	ch2Sensor?: number;
	blowerRPM?: number;
}

export class FaastFlexIntelligentLogs {
	public static GetFFILogEntry(
		param: { msg: Uint8Array },
		logIndexLSB: number,
		logIndexMSB: number,
	): {
		errorCode: ErrorCode;
		byteToSend: number;
		byteToReceive: number;
	} {
		const { errorCode, byteToSend, byteToReceive } =
			commonCommand.cmdNoParamAnsData(
				param,
				FfIGclCmd.FFI_SW_CMD_GET_LOG_LINE_ENTRY,
				AnswerLength.eTwentyTwo,
			);
		if (errorCode === ErrorCode.eOK) {
			const errorSetHeaderpara1 = MessageHeaderHandler.setMsgHeaderPar1(
				param,
				logIndexLSB,
			);
			const errorSetHeaderpara2 = MessageHeaderHandler.setMsgHeaderPar2(
				param,
				logIndexMSB,
			);
			MessageHeaderHandler.setMsgHeaderChecksum(param);
		}
		return { errorCode, byteToSend, byteToReceive };
	}

	public static GetFFILogEntryAnswer(
		param: { msg: Uint8Array },
		byteToBeReceived: number,
		byteReceived: number,
	): {
		retErrorCode: ErrorCode;
		logEntryId: number;
		day: number;
		month: number;
		year: number;
		hour: number;
		minute: number;
		second: number;
		logEventId: LogEventId;
		temperatureChannel1: number;
		temperatureChannel2: number;
		flowChannel1: number;
		flowChannel2: number;
		sensorChannel1: number;
		sensorChannel2: number;
		blowerRPM: number;
		eventType: LogEventType;
		eventZone: LogEventZone;
	} {
		const eventLogData = {
			retErrorCode: ErrorCode.eERR_UNKNOWN,
			logEntryId: 0,
			day: 0,
			month: 0,
			year: 0,
			hour: 0,
			minute: 0,
			second: 0,
			logEventId: LogEventId.LOG_EVENT_NONE,
			temperatureChannel1: 0,
			temperatureChannel2: 0,
			flowChannel1: 0,
			flowChannel2: 0,
			sensorChannel1: 0,
			sensorChannel2: 0,
			blowerRPM: 0,
			eventType: LogEventType.eUnknown,
			eventZone: LogEventZone.eUnknown,
		};
		//TODO: Firmware Bug: Check with hardware team regarding the issue with byteReceived count
		//TODO: MSB and LSB are inter changed check wit the formware team an change it to right one
		eventLogData.retErrorCode = ResponseParser.checkAnswerMsgValidity(
			param.msg,
			byteToBeReceived,
			byteReceived,
		);
		if (eventLogData.retErrorCode === ErrorCode.eOK) {
			eventLogData.logEntryId = (param.msg[2] << 8) | param.msg[1]; //MSB << 8 | LSB
			eventLogData.day = param.msg[3];
			eventLogData.month = param.msg[4];
			eventLogData.year = param.msg[5];
			eventLogData.hour = param.msg[6];
			eventLogData.minute = param.msg[7];
			eventLogData.second = param.msg[8];
			eventLogData.logEventId = (param.msg[10] << 8) | param.msg[9];
			eventLogData.eventType = getEventTypeFromEventId(eventLogData.logEventId);
			eventLogData.eventZone = getEventZoneFromEventId(eventLogData.logEventId);
			if (eventLogData.logEventId !== LogEventId.LOG_EVENT_NONE) {
				eventLogData.temperatureChannel1 = param.msg[11];
				eventLogData.flowChannel1 = ((param.msg[13] << 8) | param.msg[12]) / 10; //MSB << 8 | LSB
				eventLogData.temperatureChannel2 = param.msg[15];
				eventLogData.flowChannel2 = ((param.msg[17] << 8) | param.msg[16]) / 10; //MSB << 8 | LSB
				eventLogData.blowerRPM = (param.msg[20] << 8) | param.msg[19]; //MSB << 8 | LSB
			}
		}
		return eventLogData;
	}
}
