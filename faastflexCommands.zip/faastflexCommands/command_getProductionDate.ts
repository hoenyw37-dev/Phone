import {
	AnswerLength,
	ErrorCode,
	DeviceStatus,
	GclCmd,
	Configuration,
	Country,
	RelayEnabled,
	Channel,
	AlarmFaultStatus,
	AnswerByteParamIndex,
	DeviceType,
} from '../faastflexCommands/commandEnum';
import {
	HEADER_SIZE,
	SW_COMM_CHECKSUM_BASE,
	MessageHeaderHandler,
	CommandDefault,
	ResponseParser,
} from '../faastflexCommands/command';
import { commonCommand } from '../faastflexCommands/CommonCommand';

interface ProductiondateResult {
	errorCode: ErrorCode;
	MANIF_DD: number;
	MANIF_MM: number;
	MANIF_YY: number;
	MANIF_HH: number;
	MANIF_MI: number;
	MANIF_SS: number;
}

export class FaastFlexProductionDate {
	public static GetProductionDate(param: { msg: Uint8Array }): {
		errorCode: ErrorCode;
		byteToSend: number;
		byteToReceive: number;
	} {
		const { errorCode, byteToSend, byteToReceive } =
			commonCommand.cmdNoParamAnsData(
				param,
				GclCmd.SW_CMD_GET_PRODUCTION_DATE,
				AnswerLength.eEight,
			);

		return { errorCode, byteToSend, byteToReceive };
	}
	public static GetProductionDateAnswer(
		param: { msg: Uint8Array },
		byteToBeReceived: number,
		byteReceived: number,
	): ProductiondateResult {
		let retErrorCode: ErrorCode = ErrorCode.eERR_UNKNOWN;
		let msg = param.msg;
		retErrorCode = ResponseParser.checkAnswerMsgValidity(
			param.msg,
			byteToBeReceived,
			byteReceived,
		);
		var result: ProductiondateResult = {
			errorCode: retErrorCode,
			MANIF_DD: retErrorCode === ErrorCode.eOK ? msg[1] : 0,
			MANIF_MM: retErrorCode === ErrorCode.eOK ? msg[2] : 0,
			MANIF_YY: retErrorCode === ErrorCode.eOK ? msg[3] : 0,
			MANIF_HH: retErrorCode === ErrorCode.eOK ? msg[4] : 0,
			MANIF_MI: retErrorCode === ErrorCode.eOK ? msg[5] : 0,
			MANIF_SS: retErrorCode === ErrorCode.eOK ? msg[6] : 0,
		};
		return result;
	}
}
