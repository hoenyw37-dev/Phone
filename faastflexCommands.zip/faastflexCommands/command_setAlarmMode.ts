import {
	AnswerLength,
	ErrorCode,
	DeviceStatus,
	GclCmd,
	Configuration,
	Country,
	RelayEnabled,
	Channel,
	AlarmFaultStatus,
	AnswerByteParamIndex,
	DeviceType,
	PasswordValid,
	GclSubCmdT,
	LatchedMode,
	AlarmMode,
} from '../faastflexCommands/commandEnum';
import {
	HEADER_SIZE,
	SW_COMM_CHECKSUM_BASE,
	MessageHeaderHandler,
	CommandDefault,
	ResponseParser,
} from '../faastflexCommands/command';
import { commonCommand } from '../faastflexCommands/CommonCommand';
import { min } from 'date-fns';

export class FaastFlexSetAlarmMode {
	public static SetAlarmModeEEPROM(
		param: { msg: Uint8Array },
		updateParam: AlarmMode,
	): {
		errorCode: ErrorCode;
		byteToSend: number;
		byteToReceive: number;
	} {
		const { errorCode, byteToSend, byteToReceive } =
			commonCommand.subCmdWriteOneParamAnsAckOnly(
				param,
				GclSubCmdT.SW_CMD_ALARM_MODE,
				updateParam,
			);
		return { errorCode, byteToSend, byteToReceive };
	}
	public static SetAlarmModeEEPROMAnswer(
		param: { msg: Uint8Array },
		byteToBeReceived: number,
		byteReceived: number,
	): { retErrorCode: ErrorCode } {
		let retErrorCode: ErrorCode = ErrorCode.eERR_UNKNOWN;
		retErrorCode = ResponseParser.checkAnswerMsgValidity(
			param.msg,
			byteToBeReceived,
			byteReceived,
		);
		return { retErrorCode };
	}

	public static FFI_SetAlarmMode(
		param: { msg: Uint8Array },
		updateParam: AlarmMode,
	): {
		errorCode: ErrorCode;
		byteToSend: number;
		byteToReceive: number;
	} {
		const { errorCode, byteToSend, byteToReceive } =
			commonCommand.subCmdWriteOneParamAnsAckOnly(
				param,
				GclSubCmdT.FFI_SW_CMD_MODULE_ALARM_MODE,
				updateParam,
			);
		return { errorCode, byteToSend, byteToReceive };
	}
	public static FFI_SetAlarmModeAnswer(
		param: { msg: Uint8Array },
		byteToBeReceived: number,
		byteReceived: number,
	): { retErrorCode: ErrorCode } {
		let retErrorCode: ErrorCode = ErrorCode.eERR_UNKNOWN;
		retErrorCode = ResponseParser.checkAnswerMsgValidity(
			param.msg,
			byteToBeReceived,
			byteReceived,
		);
		return { retErrorCode };
	}
}
