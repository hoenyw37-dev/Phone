import {
	AnswerLength,
	ErrorCode,
	DeviceStatus,
	GclCmd,
	Configuration,
	Country,
	RelayEnabled,
	Channel,
	AlarmFaultStatus,
} from '../faastflexCommands/commandEnum';
import {
	HEADER_SIZE,
	SW_COMM_CHECKSUM_BASE,
	MessageHeaderHandler,
	CommandDefault,
	ResponseParser,
} from '../faastflexCommands/command';
import { commonCommand } from './CommonCommand';

export class FaastFlexDeviceStatus22 {
	/**
	 * Gets the FaastFlex device status
	 * @param msg The message buffer to be modified
	 * @returns errorCode, byteToSend and byteToReceive
	 */
	public static getFaastFlexDeviceStatus22(param: { msg: Uint8Array }): {
		errorCode: ErrorCode;
		byteToSend: number;
		byteToReceive: number;
	} {
		const { errorCode, byteToSend, byteToReceive } =
			commonCommand.cmdNoParamAnsData(
				param,
				GclCmd.SW_CMD_GET_PARAMS1,
				AnswerLength.eTwentyTwo,
			);

		return { errorCode, byteToSend, byteToReceive };
	}

	/**
	 * Parses the device status response message
	 * @param msg The response message buffer
	 * @param byteToBeReceived Expected number of bytes to be received
	 * @param byteReceived Actual number of bytes received
	 * @returns Object containing error code and device status information
	 */
	public static getFaastFlexDeviceStatusAnswer22(
		msg: Uint8Array,
		byteToBeReceived: number,
		byteReceived: number,
	): {
		errorCode: ErrorCode;
		deviceStatus: DeviceStatus;
		numberOfChannel: Channel;
		country: Country;
		alarmfault1: AlarmFaultStatus;
		alarmfault2: AlarmFaultStatus;
		actionfault1: AlarmFaultStatus;
		actionfault2: AlarmFaultStatus;
		fault: AlarmFaultStatus;
		alert: AlarmFaultStatus;
		deviceConfiguration: Configuration;
		relayEnabled: RelayEnabled;
	} {
		// Initialize result with default values
		const result = {
			errorCode: ErrorCode.eERR_UNKNOWN,
			deviceStatus: DeviceStatus.UNKNOWN,
			numberOfChannel: Channel.Unknown,
			country: Country.Unknown,
			alarmfault1: AlarmFaultStatus.Unknown,
			alarmfault2: AlarmFaultStatus.Unknown,
			actionfault1: AlarmFaultStatus.Unknown,
			actionfault2: AlarmFaultStatus.Unknown,
			fault: AlarmFaultStatus.Unknown,
			alert: AlarmFaultStatus.Unknown,
			deviceConfiguration: Configuration.Unknown,
			relayEnabled: RelayEnabled.Unknown,
		};

		// Check message validity
		result.errorCode = ResponseParser.checkAnswerMsgValidity(
			msg,
			byteToBeReceived,
			byteReceived,
		);
		// Store the error code for further processing
		let errorCode: ErrorCode = result.errorCode;
		let noOfChannel: Channel = result.numberOfChannel;
		if (result.errorCode === ErrorCode.eOK) {
			const channelNumber = msg[2];
			const eRet = ResponseParser.byteToEnum<Channel>(
				channelNumber,
				Channel,
				Channel.Unknown,
			);
			result.errorCode = eRet.errorCode;
			result.numberOfChannel = eRet.result;
		}

		if (result.errorCode === ErrorCode.eOK) {
			const deviceStatus = msg[1];
			const eRet = ResponseParser.byteToEnum<DeviceStatus>(
				deviceStatus,
				DeviceStatus,
				DeviceStatus.UNKNOWN,
			);
			result.errorCode = eRet.errorCode;
			result.deviceStatus = eRet.result;
		}

		if (result.errorCode === ErrorCode.eOK) {
			const deviceCountry = msg[3];
			const eRet = ResponseParser.byteToEnum<Country>(
				deviceCountry,
				Country,
				Country.Unknown,
			);
			result.errorCode = eRet.errorCode;
			result.country = eRet.result;
		}

		if (result.errorCode === ErrorCode.eOK) {
			const faultStatus = msg[4];
			const eRet = ResponseParser.byteToEnum<AlarmFaultStatus>(
				faultStatus,
				AlarmFaultStatus,
				AlarmFaultStatus.Unknown,
			);
			result.errorCode = eRet.errorCode;
			result.fault = eRet.result;
		}

		if (result.errorCode === ErrorCode.eOK) {
			const ch1ActionStatus = msg[5];
			const eRet = ResponseParser.byteToEnum<AlarmFaultStatus>(
				ch1ActionStatus,
				AlarmFaultStatus,
				AlarmFaultStatus.Unknown,
			);
			result.errorCode = eRet.errorCode;
			result.actionfault1 = eRet.result;
		}

		if (result.errorCode === ErrorCode.eOK) {
			const ch1AlarmStatus = msg[6];
			const eRet = ResponseParser.byteToEnum<AlarmFaultStatus>(
				ch1AlarmStatus,
				AlarmFaultStatus,
				AlarmFaultStatus.Unknown,
			);
			result.errorCode = eRet.errorCode;
			result.alarmfault1 = eRet.result;
		}

		if (result.errorCode === ErrorCode.eOK) {
			const ch2ActionStatus = msg[7];
			const eRet = ResponseParser.byteToEnum<AlarmFaultStatus>(
				ch2ActionStatus,
				AlarmFaultStatus,
				AlarmFaultStatus.Unknown,
			);
			result.errorCode = eRet.errorCode;
			result.actionfault2 = eRet.result;
		}

		if (result.errorCode === ErrorCode.eOK) {
			const ch2AlarmStatus = msg[8];
			const eRet = ResponseParser.byteToEnum<AlarmFaultStatus>(
				ch2AlarmStatus,
				AlarmFaultStatus,
				AlarmFaultStatus.Unknown,
			);
			result.errorCode = eRet.errorCode;
			result.alarmfault2 = eRet.result;
		}

		if (result.errorCode === ErrorCode.eOK) {
			const alertStatus = msg[9];
			const eRet = ResponseParser.byteToEnum<AlarmFaultStatus>(
				alertStatus,
				AlarmFaultStatus,
				AlarmFaultStatus.Unknown,
			);
			result.errorCode = eRet.errorCode;
			result.alert = eRet.result;
		}

		if (result.errorCode === ErrorCode.eOK) {
			const deviceConfiguration = msg[10];
			const eRet = ResponseParser.byteToEnum<Configuration>(
				deviceConfiguration,
				Configuration,
				Configuration.Unknown,
			);
			result.errorCode = eRet.errorCode;
			result.deviceConfiguration = eRet.result;
		}

		if (result.errorCode === ErrorCode.eOK) {
			const relayEnabled = msg[20];
			const eRet = ResponseParser.byteToEnum<RelayEnabled>(
				relayEnabled,
				RelayEnabled,
				RelayEnabled.Unknown,
			);
			result.errorCode = eRet.errorCode;
			result.relayEnabled = eRet.result;
		}

		return result;
	}
}
