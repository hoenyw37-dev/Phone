import {
	AnswerLength,
	ErrorCode,
	DeviceStatus,
	GclCmd,
	Configuration,
	Country,
	RelayEnabled,
	Channel,
	AlarmFaultStatus,
	FfIGclCmd,
	DeviceType,
} from '../faastflexCommands/commandEnum';
import { ResponseParser } from '../faastflexCommands/command';
import { commonCommand } from './CommonCommand';

export class FaastFlexIntelligentDeviceStatus {
	/**
	 * Gets the FaastFlex device status
	 * @param msg The message buffer to be modified
	 * @returns errorCode, byteToSend and byteToReceive
	 */
	public static getFaastFlexIntelligentDeviceStatus(param: {
		msg: Uint8Array;
	}): { errorCode: ErrorCode; byteToSend: number; byteToReceive: number } {
		const { errorCode, byteToSend, byteToReceive } =
			commonCommand.cmdNoParamAnsData(
				param,
				FfIGclCmd.FFI_SW_CMD_GET_DIAGNOSTIC_PARAMS,
				AnswerLength.eTwenty,
			);

		return { errorCode, byteToSend, byteToReceive };
	}

	/**
	 * Parses the device status response message
	 * @param msg The response message buffer
	 * @param byteToBeReceived Expected number of bytes to be received
	 * @param byteReceived Actual number of bytes received
	 * @returns Object containing error code and device status information
	 */
	public static getFaastFlexIntelligentDeviceStatusAnswer(
		msg: Uint8Array,
		byteToBeReceived: number,
		byteReceived: number,
	): {
		errorCode: ErrorCode;
		deviceStatus: DeviceStatus;
		numberOfChannel: Channel;
		country: Country;
		alarmfault1: AlarmFaultStatus;
		alarmfault2: AlarmFaultStatus;
		fault: AlarmFaultStatus;
		alert: AlarmFaultStatus;
		deviceConfiguration: Configuration;
		relayEnabled: RelayEnabled;
		deviceType: DeviceType;
	} {
		// Initialize result with default values
		const result = {
			errorCode: ErrorCode.eERR_UNKNOWN,
			deviceStatus: DeviceStatus.UNKNOWN,
			numberOfChannel: Channel.Unknown,
			country: Country.Unknown,
			alarmfault1: AlarmFaultStatus.Unknown,
			alarmfault2: AlarmFaultStatus.Unknown,
			fault: AlarmFaultStatus.Unknown,
			alert: AlarmFaultStatus.Unknown,
			deviceConfiguration: Configuration.Unknown,
			relayEnabled: RelayEnabled.Unknown,
			deviceType: DeviceType.eUnknown,
		};

		// Check message validity
		result.errorCode = ResponseParser.checkAnswerMsgValidity(
			msg,
			byteToBeReceived,
			byteReceived,
		);
		// Store the error code for further processing
		let errorCode: ErrorCode = result.errorCode;
		let noOfChannel: Channel = result.numberOfChannel;
		if (result.errorCode === ErrorCode.eOK) {
			const channelNumber = msg[2];
			const eRet1 = ResponseParser.byteToEnum<Channel>(
				channelNumber,
				Channel,
				Channel.Unknown,
			);
			result.errorCode = eRet1.errorCode;
			result.numberOfChannel = eRet1.result;
		}

		if (result.errorCode === ErrorCode.eOK) {
			const deviceStatus = msg[1];
			const eRet2 = ResponseParser.byteToEnum<DeviceStatus>(
				deviceStatus,
				DeviceStatus,
				DeviceStatus.UNKNOWN,
			);
			result.errorCode = eRet2.errorCode;
			result.deviceStatus = eRet2.result;
		}

		if (result.errorCode === ErrorCode.eOK) {
			const deviceCountry = msg[7];
			const eRet3 = ResponseParser.byteToEnum<Country>(
				deviceCountry,
				Country,
				Country.Unknown,
			);
			result.errorCode = eRet3.errorCode;
			result.country = eRet3.result;
		}

		if (result.errorCode === ErrorCode.eOK) {
			const faultStatus = msg[3];
			const eRet4 = ResponseParser.byteToEnum<AlarmFaultStatus>(
				faultStatus,
				AlarmFaultStatus,
				AlarmFaultStatus.Unknown,
			);
			result.errorCode = eRet4.errorCode;
			result.fault = eRet4.result;
		}

		if (result.errorCode === ErrorCode.eOK) {
			const ch1AlarmStatus = msg[4];
			const eRet5 = ResponseParser.byteToEnum<AlarmFaultStatus>(
				ch1AlarmStatus,
				AlarmFaultStatus,
				AlarmFaultStatus.Unknown,
			);
			result.errorCode = eRet5.errorCode;
			result.alarmfault1 = eRet5.result;
		}

		if (result.errorCode === ErrorCode.eOK) {
			const ch2AlarmStatus = msg[5];
			const eRet6 = ResponseParser.byteToEnum<AlarmFaultStatus>(
				ch2AlarmStatus,
				AlarmFaultStatus,
				AlarmFaultStatus.Unknown,
			);
			result.errorCode = eRet6.errorCode;
			result.alarmfault2 = eRet6.result;
		}

		if (result.errorCode === ErrorCode.eOK) {
			const alertStatus = msg[6];
			const eRet7 = ResponseParser.byteToEnum<AlarmFaultStatus>(
				alertStatus,
				AlarmFaultStatus,
				AlarmFaultStatus.Unknown,
			);
			result.errorCode = eRet7.errorCode;
			result.alert = eRet7.result;
		}

		if (result.errorCode === ErrorCode.eOK) {
			const deviceConfiguration = msg[10];
			const eRet8 = ResponseParser.byteToEnum<Configuration>(
				deviceConfiguration,
				Configuration,
				Configuration.Unknown,
			);
			result.errorCode = eRet8.errorCode;
			result.deviceConfiguration = eRet8.result;
		}

		if (result.errorCode === ErrorCode.eOK) {
			const relayEnabled = msg[18];
			const eRet9 = ResponseParser.byteToEnum<RelayEnabled>(
				relayEnabled,
				RelayEnabled,
				RelayEnabled.Unknown,
			);
			result.errorCode = eRet9.errorCode;
			result.relayEnabled = eRet9.result;
		}

		if (result.errorCode === ErrorCode.eOK) {
			const type = msg[12];
			result.deviceType =
				type === 0 ? DeviceType.eIntelligent : DeviceType.eStandAlone;
		}

		return result;
	}
}
