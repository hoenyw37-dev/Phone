import {
	AnswerLength,
	ErrorCode,
	DeviceStatus,
	GclCmd,
	Configuration,
	Country,
	RelayEnabled,
	Channel,
	AlarmFaultStatus,
	AnswerByteParamIndex,
	DeviceType,
} from '../faastflexCommands/commandEnum';
import {
	HEADER_SIZE,
	SW_COMM_CHECKSUM_BASE,
	MessageHeaderHandler,
	CommandDefault,
	ResponseParser,
} from '../faastflexCommands/command';
import { commonCommand } from '../faastflexCommands/CommonCommand';

export class FaastFlexDeviceType {
	public static GetDeviceType(param: { msg: Uint8Array }): {
		errorCode: ErrorCode;
		byteToSend: number;
		byteToReceive: number;
	} {
		const { errorCode, byteToSend, byteToReceive } =
			commonCommand.cmdNoParamAnsData(
				param,
				GclCmd.SW_CMD_GET_DEVICE_TYPE,
				AnswerLength.eThree,
			);

		return { errorCode, byteToSend, byteToReceive };
	}
	public static GetDeviceTypeAnswer(
		param: { msg: Uint8Array },
		byteToBeReceived: number,
		byteReceived: number,
	): { retErrorCode: ErrorCode; retDeviceType: DeviceType } {
		const { retErrorCode, retDeviceType } = this.ParseByteEnumAnswer(
			param.msg,
			byteToBeReceived,
			byteReceived,
			DeviceType.eUnknown,
			DeviceType,
		);
		return { retErrorCode, retDeviceType };
	}

	private static ParseByteEnumAnswer<RES_ENum extends number>(
		msg: Uint8Array,
		byteToBeReceived: number,
		byteReceived: number,
		defaultValue: RES_ENum,
		enumType: any,
	): { retErrorCode: ErrorCode; retDeviceType: RES_ENum } {
		let type: RES_ENum = defaultValue;
		let eRet: ErrorCode = ErrorCode.eOK;
		if (3 !== byteToBeReceived) {
			eRet = ErrorCode.eERR_ANS_INVALID_SIZE;
		}
		if (ErrorCode.eOK === eRet) {
			eRet = ResponseParser.checkAnswerMsgValidity(
				msg,
				byteToBeReceived,
				byteReceived,
			);
		}
		if (ErrorCode.eOK === eRet) {
			const { result, errorCode } = ResponseParser.getMsgAnswerParToEnum(
				msg,
				AnswerByteParamIndex.eParam_One,
				defaultValue,
				enumType,
			);
			type = result;
			eRet = errorCode;
		}
		return { retErrorCode: eRet, retDeviceType: type };
	}
}
