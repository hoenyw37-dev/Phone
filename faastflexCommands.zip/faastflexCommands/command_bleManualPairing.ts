import {
	AnswerLength,
	DeviceAuthenticated,
	ErrorCode,
	GCL_RESULT,
	GclCmd,
	HeaderPosition,
} from '../faastflexCommands/commandEnum';
import {
	HEADER_SIZE,
	SW_COMM_CHECKSUM_BASE,
	MessageHeaderHandler,
	CommandDefault,
	ResponseParser,
} from '../faastflexCommands/command';
import { commonCommand } from '../faastflexCommands/CommonCommand';

export function startManualPairing(
	param: { msg: Uint8Array },
	digit_1: number,
	digit_2: number,
	digit_3: number,
	digit_4: number,
	digit_5: number,
	digit_6: number,
	digit_7: number,
	digit_8: number,
	digit_9: number,
	digit_10: number,
	digit_11: number,
	digit_12: number,
): { errorCode: ErrorCode; byteToSend: number; byteToReceive: number } {
	const { errorCode, byteToSend, byteToReceive } =
		commonCommand.CmdTwelveParamsAnsAny(
			param,
			GclCmd.SW_CMD_START_HAND_PAIRING,
			digit_1,
			digit_2,
			digit_3,
			digit_4,
			digit_5,
			digit_6,
			digit_7,
			digit_8,
			digit_9,
			digit_10,
			digit_11,
			digit_12,
			AnswerLength.eEight,
		);

	return { errorCode, byteToSend, byteToReceive };
}

export function startManualPairingAnswer(
	param: { msg: Uint8Array },
	byteToBeReceived: number,
	byteReceived: number,
): {
	retErrorCode: ErrorCode;
	num1: number;
	num2: number;
	num3: number;
	num4: number;
	num5: number;
	num6: number;
} {
	let retErrorCode: ErrorCode = ErrorCode.eERR_UNKNOWN;
	let num1: number = 0;
	let num2: number = 0;
	let num3: number = 0;
	let num4: number = 0;
	let num5: number = 0;
	let num6: number = 0;
	retErrorCode = ResponseParser.checkAnswerMsgValidity(
		param.msg,
		byteToBeReceived,
		byteReceived,
	);
	if (retErrorCode === ErrorCode.eOK) {
		num1 = param.msg[1];
		num2 = param.msg[2];
		num3 = param.msg[3];
		num4 = param.msg[4];
		num5 = param.msg[5];
		num6 = param.msg[6];
	}
	return { retErrorCode, num1, num2, num3, num4, num5, num6 };
}
