import {
	AnswerLength,
	ErrorCode,
	DeviceStatus,
	GclCmd,
	Configuration,
	Country,
	RelayEnabled,
	Channel,
	AlarmFaultStatus,
	AnswerByteParamIndex,
	SmokeAlarmLevel,
	AlarmLevel,
	PreAlarmLevel,
} from '../faastflexCommands/commandEnum';
import {
	HEADER_SIZE,
	SW_COMM_CHECKSUM_BASE,
	MessageHeaderHandler,
	CommandDefault,
	ResponseParser,
} from '../faastflexCommands/command';
import { commonCommand } from '../faastflexCommands/CommonCommand';
import { DeviceMeasures } from '../faastflexCommands/common_objects';

interface ViewMeasuresResult {
	errorCode: ErrorCode;
	measures: DeviceMeasures;
}
export class FaastFlexDeviceMeasures {
	public static GetViewMeasures(param: { msg: Uint8Array }): {
		errorCode: ErrorCode;
		byteToSend: number;
		byteToReceive: number;
	} {
		const { errorCode, byteToSend, byteToReceive } =
			commonCommand.cmdNoParamAnsData(
				param,
				GclCmd.SW_CMD_GET_MAIN_MEASURES,
				AnswerLength.eTwentyFour,
			);

		return { errorCode, byteToSend, byteToReceive };
	}

	public static GetViewMeasuresAnswer(
		param: { msg: Uint8Array },
		byteToBeReceived: number,
		byteReceived: number,
	): ViewMeasuresResult {
		const measures = new DeviceMeasures();
		let retErrorCode: ErrorCode = ErrorCode.eERR_UNKNOWN;
		let msg = param.msg;
		retErrorCode = ResponseParser.checkAnswerMsgValidity(
			param.msg,
			byteToBeReceived,
			byteReceived,
		);
		if (retErrorCode === ErrorCode.eOK) {
			let rpm =
				msg[1] + msg[2] * 256 + msg[3] * 256 * 256 + msg[4] * 256 * 256 * 256;
			measures.RPM = ((rpm + 25) / 50) * 50;
			measures.CH1Flow = msg[5];
			measures.CH2Flow = msg[6];
			measures.CH1MinFlow = msg[7];
			measures.CH2MinFlow = msg[8];
			measures.CH1RefFlow = msg[9];
			measures.CH2RefFlow = msg[10];
			measures.CH1MaxFlow = msg[11];
			measures.CH2MaxFlow = msg[12];
			measures.CH1Temperature = msg[13];
			measures.CH1Temperature *= msg[14] === 1 ? -1 : 1;
			measures.CH2Temperature = msg[15];
			measures.CH2Temperature *= msg[16] === 1 ? -1 : 1;
			if (retErrorCode === ErrorCode.eOK) {
				const CH1Smoke = msg[17];
				const { result: enumValue, errorCode: eRet } =
					ResponseParser.byteToEnum<SmokeAlarmLevel>(
						CH1Smoke,
						SmokeAlarmLevel,
						SmokeAlarmLevel.eUnknown,
					);
				measures.CH1SmokeLevel = enumValue;
				retErrorCode = eRet;
			}
			if (retErrorCode === ErrorCode.eOK) {
				const CH2Smoke = msg[18];
				const { result: enumValue, errorCode: eRet } =
					ResponseParser.byteToEnum<SmokeAlarmLevel>(
						CH2Smoke,
						SmokeAlarmLevel,
						SmokeAlarmLevel.eUnknown,
					);
				measures.CH2SmokeLevel = enumValue;
				retErrorCode = eRet;
			}
			if (retErrorCode === ErrorCode.eOK) {
				const CH1Alarm = msg[19];
				const { result: enumValue, errorCode: eRet } =
					ResponseParser.byteToEnum<AlarmLevel>(
						CH1Alarm,
						AlarmLevel,
						AlarmLevel.eUnknown,
					);
				measures.CH1AlarmLevel = enumValue;
				retErrorCode = eRet;
			}
			if (retErrorCode === ErrorCode.eOK) {
				const CH2Alarm = msg[20];
				const { result: enumValue, errorCode: eRet } =
					ResponseParser.byteToEnum<AlarmLevel>(
						CH2Alarm,
						AlarmLevel,
						AlarmLevel.eUnknown,
					);
				measures.CH2AlarmLevel = enumValue;
				retErrorCode = eRet;
			}
			if (retErrorCode === ErrorCode.eOK) {
				const CH1PreAlarm = msg[21];
				const { result: enumValue, errorCode: eRet } =
					ResponseParser.byteToEnum<PreAlarmLevel>(
						CH1PreAlarm,
						PreAlarmLevel,
						PreAlarmLevel.eUnknown,
					);
				measures.CH1PreAlarmLevel = enumValue;
				retErrorCode = eRet;
			}

			if (retErrorCode === ErrorCode.eOK) {
				const CH2PreAlarm = msg[22];
				const { result: enumValue, errorCode: eRet } =
					ResponseParser.byteToEnum<PreAlarmLevel>(
						CH2PreAlarm,
						PreAlarmLevel,
						PreAlarmLevel.eUnknown,
					);
				measures.CH2PreAlarmLevel = enumValue;
				retErrorCode = eRet;
			}
		}
		var result: ViewMeasuresResult = {
			errorCode: retErrorCode,
			measures: measures,
		};
		return result;
	}
}
