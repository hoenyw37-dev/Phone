import {
	AnswerLength,
	ErrorCode,
	DeviceStatus,
	GclCmd,
	Configuration,
	Country,
	RelayEnabled,
	Channel,
	AlarmFaultStatus,
	AnswerByteParamIndex,
	DeviceType,
} from '../faastflexCommands/commandEnum';
import {
	HEADER_SIZE,
	SW_COMM_CHECKSUM_BASE,
	MessageHeaderHandler,
	CommandDefault,
	ResponseParser,
} from '../faastflexCommands/command';
import { commonCommand } from '../faastflexCommands/CommonCommand';

export class FaastFlexSerialNumber {
	public static GetSerialNumberEEPROM(param: { msg: Uint8Array }): {
		errorCode: ErrorCode;
		byteToSend: number;
		byteToReceive: number;
	} {
		const { errorCode, byteToSend, byteToReceive } =
			commonCommand.cmdNoParamAnsData(
				param,
				GclCmd.SW_CMD_GET_SERIAL_NUMBER,
				AnswerLength.eNine,
			);

		return { errorCode, byteToSend, byteToReceive };
	}
	public static GetSerialNumberEEPROMAnswer(
		param: { msg: Uint8Array },
		byteToBeReceived: number,
		byteReceived: number,
	): { retErrorCode: ErrorCode; retNumber: string } {
		let dd: number;
		let mm: number;
		let yy: number;
		let hh: number;
		let mi: number;
		let ss: number;
		let type: number;

		let serialNumber = 'yymmddHHMMSSxyz';
		let retErrorCode: ErrorCode = ErrorCode.eERR_UNKNOWN;
		let msg = param.msg;
		retErrorCode = ResponseParser.checkAnswerMsgValidity(
			param.msg,
			byteToBeReceived,
			byteReceived,
		);
		if (ErrorCode.eOK === retErrorCode) {
			yy = msg[1];
			mm = msg[2];
			dd = msg[3];
			hh = msg[4];
			mi = msg[5];
			ss = msg[6];
			type = msg[7];

			serialNumber = '';
			serialNumber += yy.toString().padStart(2, '0');
			serialNumber += mm.toString().padStart(2, '0');
			serialNumber += dd.toString().padStart(2, '0');
			serialNumber += hh.toString().padStart(2, '0');
			serialNumber += mi.toString().padStart(2, '0');
			serialNumber += ss.toString().padStart(2, '0');
			serialNumber += type.toString().padStart(3, '0');
		}

		return { retErrorCode, retNumber: serialNumber };
	}
}
