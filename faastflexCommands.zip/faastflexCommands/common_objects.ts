import {
	SmokeAlarmLevel,
	PreAlarmLevel,
	AlarmLevel,
	DeviceOrientation,
	RelayAlert,
	FanSpeedLevel,
	FanPWMPercCorrection,
	LatchedMode,
	AlarmMode,
	ExternalInputMode,
	ExternalInputAction,
	ExternalInputNormalState,
} from '../faastflexCommands/commandEnum';
import { LogEventId, LogEventType, LogEventZone } from './command_log';

export class DeviceMeasures {
	RPM: number = 0;
	CH1Flow: number = 0;
	CH2Flow: number = 0;
	CH1MinFlow: number = 0;
	CH2MinFlow: number = 0;
	CH1RefFlow: number = 0;
	CH2RefFlow: number = 0;
	CH1MaxFlow: number = 0;
	CH2MaxFlow: number = 0;
	CH1Temperature: number = 0;
	CH2Temperature: number = 0;
	CH1SmokeLevel: SmokeAlarmLevel = SmokeAlarmLevel.eUnknown;
	CH2SmokeLevel: SmokeAlarmLevel = SmokeAlarmLevel.eUnknown;
	CH1AlarmLevel: AlarmLevel = AlarmLevel.eUnknown;
	CH2AlarmLevel: AlarmLevel = AlarmLevel.eUnknown;
	CH1PreAlarmLevel: PreAlarmLevel = PreAlarmLevel.eUnknown;
	CH2PreAlarmLevel: PreAlarmLevel = PreAlarmLevel.eUnknown;
}

export class EventLogData {
	logEntryId?: number = 0;
	eventDateTime?: Date = new Date(0);
	eventName?: LogEventId = LogEventId.LOG_EVENT_NONE;
	eventDescription?: string = '';
	addtionalInfo?: string = '';
	eventDate?: string = '';
	eventTime?: string = '';
	eventType?: LogEventType = LogEventType.eUnknown;
	eventTypeStr?: string = '';
	logChannels?: LogEventZone = LogEventZone.eUnknown;
	eventBarColor?: string = '';
	statusIcon?: string = '';
	eventIdInfo?: string = '';
	showErrorMessage?: boolean = false;
	ch1Temperature?: number = 0;
	ch2Temperature?: number = 0;
	ch1Flow?: number = 0;
	ch2Flow?: number = 0;
	ch1Sensor?: number = 0;
	ch2Sensor?: number = 0;
	blowerRPM?: number = 0;
}

export class DeviceGeneralParams {
	DeviceOrientation: DeviceOrientation = DeviceOrientation.eUnknown;
	DeviceDateTime?: Date = new Date(0);
	Trendlog: number = 0;
	TempRelay: RelayAlert = RelayAlert.eUnknown;
	LowPowerRelay: RelayAlert = RelayAlert.eUnknown;
	BlowerSpeedLevel: FanSpeedLevel = FanSpeedLevel.eUnknown;
	BlowerSpeedCorrection: FanPWMPercCorrection = FanPWMPercCorrection.eUnknown;
}

export class DeviceChannelAndSensorParams {
	actionDelay: string = '';
	alarmDelay: string = '';
	flowFaultDelay: string = '';
	alarmLatched: LatchedMode = LatchedMode.eUnknown;
	preAlarmLatched: LatchedMode = LatchedMode.eUnknown;
	faultLatched: LatchedMode = LatchedMode.eUnknown;
	alarmMode: AlarmMode = AlarmMode.eUnknown;
	ch1PreAlarmLevel: PreAlarmLevel = PreAlarmLevel.eUnknown;
	ch1AlarmLevel: AlarmLevel = AlarmLevel.eUnknown;
	ch1FlowFaultThreshold: number = 0;
	ch1RefAirflow: number = 0;
	ch2PreAlarmLevel: PreAlarmLevel = PreAlarmLevel.eUnknown;
	ch2AlarmLevel: AlarmLevel = AlarmLevel.eUnknown;
	ch2FlowFaultThreshold: number = 0;
	ch2RefAirflow: number = 0;
	alarm2Latched: LatchedMode = LatchedMode.eUnknown;
	auxFaultLatched: LatchedMode = LatchedMode.eUnknown;
	generalFaultLatched: LatchedMode = LatchedMode.eUnknown;
}

export class DeviceGPIParams {
	GPIExternalInput: ExternalInputMode = ExternalInputMode.eUnknown;
	SupervisedExternalTriggerOnClosed: ExternalInputAction =
		ExternalInputAction.eUnknown;
	SupervisedExternalTriggerOnOpen: ExternalInputAction =
		ExternalInputAction.eUnknown;
	UnSupervisedEventTriggered: ExternalInputAction =
		ExternalInputAction.eUnknown;
	UnSupervisedNormalState: ExternalInputNormalState =
		ExternalInputNormalState.eUnknown;
}
