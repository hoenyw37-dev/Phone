export enum ErrorCode {
	eOK,
	eNOT_IMPLEMENTED,
	eERR_UNKNOWN,
	eERR_INVALID_PARAMETER,
	eERR_INVALID_BUFFER_SIZE,
	eERR_CMD_INVALID_PARAMETER,
	eERR_CMD_SET_SINGLE_LED_InvalidLedNumber,
	eERR_ANS_INVALID_SIZE,
	eERR_ANS_INVALID_CHECKSUM,
	eERR_ANS_INVALID_RANGE,
	eERR_ANS_ACK,
	eGCL_ACK = 1,
	eGCL_NACK = 2,
	eGCL_NOT_EXTENDED = 100,
	eGCL_NOT_VALID_ADDRESS = 101,
	eGCL_NOT_VALID_FREQUENCE = 102,
	eGCL_NOT_VALID_COMPENSATION = 103,
	eGCL_NOT_VALID_PARAMETER = 104,
	eGCL_NOT_VALID_SIZE = 105,
	eGCL_AD_CHANNEL_INVALID = 106,
	eGCL_RELAY_NUMBER_INVALID = 107,
	eGCL_NOT_VALID_CHANNEL = 108,
	eGCL_CHECKSUM_ERROR = 109,
	eGCL_NOT_VALID_LED_NUMBER = 110,
	eGCL_NOT_ALLOWED_COMMAND = 111,
	eGCL_WRITE_EEP_CHECKSUM_ERROR = 112,
	eGCL_COPY_EEPROM_ERROR = 113,
	eGCL_NOT_PAIRED_ERROR = 114,
	eGCL_NOT_ALLOWED_FOR_COVER_CLOSED = 117,
	eGCL_CHINESE_VARIANT = 118,
	eGCL_EUROPEAN_VARIANT = 119,
	eGCL_NOT_VALID_PASSWORD = 120,
	eGCL_CH1_NOT_AS_CH2 = 121,
	GCL_PASSWORD_DELAYED = 122,
	eGCL_NOT_IMPLEMENTED_COMMAND = 124, //Not implemented command result
	eGCL_VALID_PASSWORD = 125, //Valid password result
	eGCL_INSUFFICIENT_AUTH_LEVEL = 126, //The granted authentication level is insufficient to execute the command.
	eGCL_UNSUPPORTED_DEVICE_STATE = 127, //The command cannot be executed due to the current state of the device.
	eGCL_UNSUPPORTED_DEVICE_MODE = 128, //Command execution forbidden for current device type configuration mode (FLEX or Legacy)
}

export enum DeviceAuthenticated {
	eAuthenticated = 1,
	eNotAuthenticated = 2,
	eUnknown = 4,
}

export enum AnswerLength {
	eZero = 0,
	eOne = 1,
	eTwo = 2,
	eThree = 3,
	eFour = 4,
	eFive = 5,
	eSix = 6,
	eSeven = 7,
	eEight = 8,
	eNine = 9,
	eTen = 10,
	eEleven = 11,
	eTwelve = 12,
	eThirteen = 13,
	eFourteen = 14,
	eFifteen = 15,
	eSixteen = 16,
	eSeventeen = 17,
	eEighteen = 18,
	eNineteen = 19,
	eTwenty = 20,
	eTwentyOne = 21,
	eTwentyTwo = 22,
	eTwentyFour = 24,
	eFiveHundredFourteen = 514,
	eUnknown, // Defaults to the next incremental value
}

export enum GclCmd {
	SW_CMD_NOT_IMPLEMENTED = 0, // NOT IMPLEMENTED COMMAND
	SW_CMD_GET_LED = 2,
	SW_CMD_GET_MAIN_MEASURES = 6,
	SW_CMD_GET_LOG_ENTRY = 7,
	SW_CMD_START_SOUND_PAIRING = 10, // START PAIRING BY SOUND
	SW_CMD_GET_ULTRA = 11, // ULTRASONIC MEASUREMENT - FOR PRODUCTION
	SW_CMD_GET_DIPSWITCHES = 13, // GET ALL DIP-SWITCHES - FOR PRODUCTION
	SW_CMD_SELF_TEST_CHINA = 15, // EXECUTE CHINESE SELF TEST
	SW_CMD_GET_EXT_INPUT = 16, // READ CONF. INPUT STATE - FOR PRODUCTION
	eSW_CMD_GET_SUPPLY_VOLTAGE = 17, // GET POWER VOLTAGE
	SW_CMD_RTC_READ = 19, // RTC READ - FOR PRODUCTION
	SW_CMD_RTC_WRITE = 20, // RTC WRITE - FOR PRODUCTION
	SW_CMD_GET_REF_FLOW_L_MIN = 21, // SAVE LOG
	SW_CMD_GET_BYTE_PARAMETER = 23, // GET A PARAMETER
	SW_CMD_SET_BYTE_PARAMETER = 24, // SET A PARAMETER IN THE EEPROM
	SW_CMD_GET_STATUS = 30, // GET DEVICE STATE
	SW_CMD_FAN_CALIBRATION = 31, // PERFORM THE FAN CALIBRATION
	SW_CMD_GET_TEMPERATURE = 34, // GET TEMPERATURE - FOR PRODUCTION
	SW_CMD_CHANGE_PSW = 35, // CHANGE THE PASSWORD
	SW_CMD_GET_DISABLE = 36, // EXTENDED COMMANDS
	SW_CMD_START_NORMALIZE = 37, // START NORMALIZE PROCEDURE
	SW_CMD_RESET_FAULT = 38, // RESET ALARM AND FAULT
	SW_CMD_DISABLE = 39, // DISABLE THE DEVICE
	SW_CMD_GET_FIRMWARE_VERSION = 40, // GET FIRMWARE VERSION
	SW_CMD_GET_RPM = 41, // GET RPM - FOR PRODUCTION
	SW_CMD_SELF_TEST_EUROPE = 42, // EXECUTE TEST STEPS
	SW_CMD_READ_BLOCK_EEPROM = 43, // READ A BLOCK FROM EEPROM - FOR PRODUCTION
	SW_CMD_WRITE_BLOCK_EEPROM = 44, // WRITE BLOCK TO EEPROM - FOR PRODUCTION
	SW_CMD_ALARM_FAULT_STATE = 45, // RETURN ALARM OR FAULT CONDITION
	SW_CMD_GET_MAX_FLOW_L_MIN = 46, // MAXIMUM FLOW LITER/MINUTE
	SW_CMD_GET_MIN_FLOW_L_MIN = 47, // MINIMUM FLOW LITER/MINUTE
	SW_CMD_SOUND_10_DIGIT_TONES = 48,
	SW_CMD_GET_DEVICE_TYPE = 49, // GET DEVICE TYPE
	SW_CMD_GET_MODEL_TYPE = 50, // GET FAAST FLEX MODEL TYPE - FOR PRODUCTION
	SW_CMD_GET_COUNTRY = 51, // GET DESTINATION COUNTRY
	SW_CMD_GET_NUMBER_OF_CH = 52, // GET NUMBER OF CHANNEL
	SW_CMD_GET_PRODUCTION_DATE = 53, // GET PRODUCTION DATE - FOR PRODUCTION
	SW_CMD_SEND_DECODED_PWD_DIGITS = 54, // SEND PAIRING PASSWORD
	SW_CMD_SILENCE_BUZZER_CHINA = 55, // BUZZER DEACTIVATION, CHINA MARKET ONLY
	SW_CMD_GET_SMOKE_LEVEL = 56, // GET SMOKE LEVEL
	SW_CMD_GET_REAL_CONFIG = 57, // GET THE EEPROM STORED CONFIGURATION
	SW_CMD_SET_FAN_SPEED_WITH_CORRECTION = 58, // SWITCH ON FAN APPLYING SPEED CORRECTION
	SW_CMD_START_HAND_PAIRING = 59, // START PAIRING BY HAND
	SW_CMD_SEND_FAAST_PSW = 60, // SEND ACTUAL FAAST PASSWORD
	SW_CMD_GET_SERIAL_NUMBER = 62, // GET SERIAL FAAST FLEX NUMBER - FOR PRODUCTION
	SW_CMD_AM_I_AUTHENTICATED = 63, // GET IF THE PHONE HAS BEEN ALREADY AUTHENTICATED
	SW_CMD_IDENTIFY_DEVICE = 64, // BLINK THE LEDS TO IDENTIFY THE DEVICE
	SW_CMD_GET_PARAMS1 = 65, // GET SOME PARMS FOR BT APP
	SW_CMD_GET_PARAMS2 = 66, // GET SOME PARMS FOR BT APP
	SW_CMD_GET_PARAMS3 = 67, // GET SOME PARMS FOR BT APP
	SW_CMD_GET_PARAMS4 = 79, // GET SOME PARMS FOR BT APP [GPI Data]
	SW_CMD_NUMBER,
}
export enum GclSubCmdT {
	SW_CMD_UNKNOWN = 0,
	SW_CMD_ALARM_LEVEL = 1, // 1 : GET/SET THE ALARM LEVEL
	SW_CMD_CH_REF_FLOW = 2, // 2 : GET/SET THE REFERENCE FLOW - FOR PRODUCTION
	SW_CMD_CH_MAX_FLOW = 3, // 3 : GET/SET THE MAXIMUM FLOW
	SW_CMD_CH_MIN_FLOW = 4, // 4 : GET/SET THE MINIMUM FLOW
	SW_CMD_FAN_SPEED = 5, // 5 : GET/SET THE FAN SPEED - FOR PRODUCTION
	SW_CMD_PRE_ALARM_LEVEL = 6, // 6 : GET/SET THE PRE ALARM LEVEL
	SW_CMD_ALARM_LATCHED = 7, // 7 : GET/SET WHETHER THE ALARM IS LATCHED
	SW_CMD_PREALARM_LATCHED = 8, // 8 : GET/SET WHETHER THE PRE ALARM IS LATCHED
	SW_CMD_FAULT_LATCHED = 9, // 9 : GET/SET WHETHER THE FAULT IS LATCHED
	SW_CMD_ALARM_MODE = 10, // 10 : GET/SET THE ALARM MODE
	SW_CMD_ALARM_DELAY = 11, // 11 : GET/SET THE ALARM DELAY
	SW_CMD_PREALARM_DELAY = 12, // 12 : GET/SET THE PRE ALARM DELAY
	SW_CMD_FLOW_FAULT_DELAY = 13, // 13 : GET/SET THE FLOW FAULT DELAY
	SW_CMD_ORIENTATION = 14, // 14 : GET/SET THE ORIENTATION
	SW_CMD_RELAY_FOR_TEMPERATURE_ALERT = 15, // 15 : GET/SET WHETHER IS SET THE RELAY FOR THE TEMPERATURE ALERT
	SW_CMD_RELAY_FOR_LOW_POWER_ALERT = 16, // 16 : GET/SET WHETHER IS SET THE RELAY FOR THE LOW POWER ALERT
	// = 17,
	SW_CMD_FAN_CORRECTION = 18, // 18 : GET/SET FAN CORRECTION - FOR PRODUCTION
	SW_CMD_EXT_INPUT_ACTION_FOR_OPEN = 19, // 19 : GET/SET EXT. INPUT BALANCED ACTION FOR OPEN
	SW_CMD_EXT_INPUT_ACTION_FOR_SHORT = 20, // 20 : GET/SET EXT. INPUT BALANCED ACTION FOR SHORT
	SW_CMD_EXT_INPUT_NORMAL_STATE = 21, // 21 : GET/SET EXT. INPUT UNBALANCED NORMAL STATE
	SW_CMD_EXT_INPUT_CHANGE_STATE_ACTION = 22, // 22 : GET/SET EXT. INPUT UNBALANCED CHANGE STATE ACTION
	SW_CMD_DISABLE_TIMEOUT = 23, // 23 : GET/SET DISABLE TIMEOUT
	SW_CMD_TREND_LOG_INTERVAL = 24, // 24 : GET/SET TREND LOG INTERVAL
	// = 25,
	// = 26,
	// = 27,
	SW_CMD_FLOW_FAULT_THRESHOLD = 28,
	SW_CMD_EXT_INPUT_MODE = 29, // 29 : GET/SET EXT. INPUT mode
	SW_CMD_BOTH_ALARM_LATCHED = 30, // 30 : GET/SET CH1 AND CH2 WHETHER THE ALARM IS LATCHED
	SW_CMD_BOTH_PREALARM_LATCHED = 31, // 31 : GET/SET CH1 AND CH2 WHETHER THE PRE ALARM IS LATCHED
	SW_CMD_BOTH_FAULT_LATCHED = 32, // 32 : GET/SET CH1 AND CH2 WHETHER THE FAULT IS LATCHED
	FFI_SW_CMD_MODULE_ALARM_MODE = 50, // 50 : GET/SET MODULE ALARM MODE
	FFI_SW_CMD_SENSOR_ADDRESS = 52, // GET/SET FF INTELLIGENT SENSOR ADDRESS
	FFI_SW_CMD_AUXILIARY_FAULT_LATCHED = 61, // GET/SET FF INTELLIGENT AUX FAULT LATCHED
	FFI_SW_CMD_GENERAL_FAULT_LATCHED = 62, // GET/SET FF INTELLIGENT GENERAL FAULT LATCHED
	FFI_SET_TREND_LOG_PERIOD = 65, // GET FF INTELLIGENT TREND LOG PERIOD
	FFI_SW_CMD_FLOW_FAULT_THRESHOLD = 71, // SET FF INTELLIGENT FLOW FAULT THRESHOLD
}

export enum FfIGclCmd {
	FFI_SW_CMD_GET_FLOWMETER_MEASURES = 76, // GET FF INTELLIGENT FLOW METER PARAMETERS
	FFI_SW_CMD_GET_DIAGNOSTIC_PARAMS = 77, // GET FF INTELLIGENT DEVICE STATUS
	FFI_SW_CMD_GET_FLOW_ANOMALY_CONFIG = 78, // GET FF INTELLIGENT CHANNELS AND SENSORS DATA
	FFI_SW_CMD_GET_LOG_LINE_ENTRY = 82, // GET FF INTELLIGENT LOG ENTRY
	FFI_SW_CMD_GET_ACTIVE_FAULTS = 83, // GET FF INTELLIGENT ACTIVE FAULTS
	FFI_SW_CMD_GET_DEVICE_CONFIG = 86, // GET FF INTELLIGENT GENERAL DEVICE CONFIGURATION
}
export enum HeaderPosition {
	POS_CMD_ID = 0,
	POS_PAR_1 = 3,
	POS_PAR_2 = 4,
	POS_PAR_3 = 5,
	POS_PAR_4 = 6,
	POS_PAR_5 = 7,
	POS_PAR_6 = 8,
	POS_PAR_7 = 9,
	POS_PAR_8 = 10,
	POS_PAR_9 = 11,
	POS_PAR_10 = 12,
	POS_PAR_11 = 13,
	POS_PAR_12 = 14,
	POS_CHKSUM = 15,
}

export enum GCL_RESULT {
	eGCL_ACK = 1,
	eGCL_NACK = 2,
}
export enum AnswerByteParamIndex {
	eParam_One = 1,
	eParam_Two = 2,
	eParam_Three = 3,
	eParam_Four = 4,
	eParam_Five = 5,
	eParam_Six = 6,
}

export enum SmokeAlarmLevel {
	eDustLevel_0 = 40,
	eDustLevel_1 = 41,
	eDustLevel_2 = 42,
	eDustLevel_3 = 43,
	eDustLevel_4 = 44,
	eDustLevel_5 = 45,
	eDustLevel_6 = 46,
	eDustLevel_7 = 47,
	eDustLevel_8 = 48,
	eDustLevel_9 = 49,
	eNormal = 50,
	eAlarmLevel_0 = 110,
	eAlarmLevel_1 = 120,
	eAlarmLevel_2 = 130,
	eAlarmLevel_3 = 140,
	eAlarmLevel_4 = 150,
	eAlarmLevel_5 = 160,
	eAlarmLevel_6 = 170,
	eAlarmLevel_7 = 180,
	eAlarmLevel_8 = 190,
	eAlarmLevel_9 = 200,
	eUnknown = 0,
}
export enum AlarmLevel {
	eLevel_0 = 0,
	eLevel_1 = 1,
	eLevel_2 = 2,
	eLevel_3 = 3,
	eLevel_4 = 4,
	eLevel_5 = 5,
	eLevel_6 = 6,
	eLevel_7 = 7,
	eLevel_8 = 8,
	eLevel_9 = 9,
	eUnknown = 10,
}
export enum PreAlarmLevel {
	eLevel_0 = 0,
	eLevel_1 = 1,
	eLevel_2 = 2,
	eLevel_3 = 3,
	eLevel_4 = 4,
	eLevel_5 = 5,
	eLevel_6 = 6,
	eLevel_7 = 7,
	eLevel_8 = 8,
	eLevel_9 = 9,
	eUnknown = 10,
}
export enum PasswordValid {
	eValid,
	eInvalid,
	ePasswordDelay,
	eUnknown,
}
export enum RelayAlert {
	eUnset = 0,
	eSet = 1,
	eUnknown,
}
export enum FanSpeedLevel {
	eLevel_OFF = 0,
	eLevel_1 = 1,
	eLevel_2 = 2,
	eLevel_3 = 3,
	eLevel_4 = 4,
	eLevel_5 = 5,
	eLevel_6 = 6,
	eLevel_7 = 7,
	eLevel_8 = 8,
	eLevel_9 = 9,
	eLevel_10 = 10,
	eUnknown,
}
export enum LatchedMode {
	eUnlatched = 0,
	eLatched = 1,
	eUnknown,
}
export enum AlarmMode {
	eUnknown = 2,
	eUp_InstantFire = 1,
	eDown_Cumulative = 0,
}
//#region  Alarm Status

// Enum definition
enum AlarmFaultStatus {
	NotActive = 0,
	Active = 1,
	Unknown = 2,
}

// Description mapping object
const AlarmFaultStatusDescriptions: Record<AlarmFaultStatus, string> = {
	[AlarmFaultStatus.NotActive]: 'Not Active',
	[AlarmFaultStatus.Active]: 'Active',
	[AlarmFaultStatus.Unknown]: 'Unknown',
};

// Helper function to get description
function getAlarmFaultStatusDescription(status: AlarmFaultStatus): string {
	return AlarmFaultStatusDescriptions[status];
}

export { AlarmFaultStatus, getAlarmFaultStatusDescription };

//#endregion

//#region  Country
// Enum definition
enum Country {
	EU = 1,
	CHINA = 2,
	Unknown = 3, // In TypeScript we need to explicitly set the value
}

// Description mapping object
const CountryDescriptions: Record<Country, string> = {
	[Country.EU]: 'Europe',
	[Country.CHINA]: 'China',
	[Country.Unknown]: 'Unknown',
};

// Helper function to get description
function getCountryDescription(country: Country): string {
	return CountryDescriptions[country];
}

export { Country, getCountryDescription };

//#endregion

//#region  DeviceStatus

// Device status enum definition
enum DeviceStatus {
	MAIN_FSM_INITIALIZATION = 0, // Main FSM initialization state id value
	MAIN_FSM_NORMAL = 1, // Main FSM normal state id value
	MAIN_FSM_WAIT = 2, // Main FSM wait state id value
	MAIN_FSM_PROTECTION = 3, // Main FSM protection state id value
	MAIN_FSM_REBOOT = 4, // Main FSM software reboot state id value
	MAIN_FSM_SERVICE = 5, // Main FSM software service state id value
	MAIN_FSM_PRODUCTION = 6, // Main FSM software production state id value
	MAIN_FSM_STATE_COUNT = 7, // Main FSM state count
	UNKNOWN = 8, // Unknown state
}

// Description mapping object
const DeviceStatusDescriptions: Record<DeviceStatus, string> = {
	[DeviceStatus.MAIN_FSM_INITIALIZATION]: 'Initialization Mode',
	[DeviceStatus.MAIN_FSM_NORMAL]: 'Normal Mode',
	[DeviceStatus.MAIN_FSM_WAIT]: 'Wait Mode',
	[DeviceStatus.MAIN_FSM_PROTECTION]: 'Protection Mode',
	[DeviceStatus.MAIN_FSM_REBOOT]: 'Software reboot Mode',
	[DeviceStatus.MAIN_FSM_SERVICE]: 'Software service Mode',
	[DeviceStatus.MAIN_FSM_PRODUCTION]: 'Software production Mode',
	[DeviceStatus.MAIN_FSM_STATE_COUNT]: 'State Count',
	[DeviceStatus.UNKNOWN]: 'Unknown',
};

// Helper function to get description
function getDeviceStatusDescription(status: DeviceStatus): string {
	return DeviceStatusDescriptions[status];
}

export { DeviceStatus, getDeviceStatusDescription };
//#endregion

//#region Channel
export enum Channel {
	Channel1 = 1,
	Channel2 = 2,
	Unknown = 3,
}
//#endregion

//#region Configuration

// Configuration enum definition
enum Configuration {
	OutOfTheBox = 1,
	Extended = 0,
	Unknown = 3,
}

// Description mapping object
const ConfigurationDescriptions: Record<Configuration, string> = {
	[Configuration.OutOfTheBox]: 'Out Of The Box',
	[Configuration.Extended]: 'Extended',
	[Configuration.Unknown]: 'Unknown',
};

// Helper function to get description
function getConfigurationDescription(config: Configuration): string {
	return ConfigurationDescriptions[config];
}

export { Configuration, getConfigurationDescription };

//#endregion

//#region RelayEnabled

// RelayEnabled enum definition
enum RelayEnabled {
	Enabled = 0, // Note: maps to "Inactive"
	Disabled = 1, // Note: maps to "Active"
	Unknown = 2,
}

// Description mapping object
const RelayEnabledDescriptions: Record<RelayEnabled, string> = {
	[RelayEnabled.Enabled]: 'Inactive',
	[RelayEnabled.Disabled]: 'Active',
	[RelayEnabled.Unknown]: 'Unknown',
};

// Helper function to get description
function getRelayEnabledDescription(status: RelayEnabled): string {
	return RelayEnabledDescriptions[status];
}

export { RelayEnabled, getRelayEnabledDescription };

//#endregion

//#region Device Type
// Define the enum
enum DeviceType {
	eUnknown = 0,
	eStandAlone = 1,
	eIntelligent = 2,
}

// Define the descriptions separately
const DeviceTypeDescriptions: Record<DeviceType, string> = {
	[DeviceType.eUnknown]: 'Unknown',
	[DeviceType.eStandAlone]: 'StandAlone',
	[DeviceType.eIntelligent]: 'Intelligent',
};

// Helper function to get description
function getDeviceTypeDescription(type: DeviceType): string {
	return DeviceTypeDescriptions[type];
}
export { DeviceType, getDeviceTypeDescription };

//#endregion

//#region Model Type
// Define the enum
enum ModelType {
	eEurope_1_Channel = 10,
	eEurope_2_Channel = 20,
	eChina_1_Channel = 11,
	eChina_2_Channel = 21,
	//Intelligenr FF Model Type
	eFFI_NF_2_Channel = 30,
	eFFI_XT_2_Channel = 31,
	eFFI_MI_2_Channel = 32,

	eFFI_NF_1_Channel = 40,
	eFFI_XT_1_Channel = 41,
	eFFI_MI_1_Channel = 42,

	eUnknown = 0,
}

// Define the descriptions separately
const ModelTypeDescriptions: Record<ModelType, string> = {
	[ModelType.eEurope_1_Channel]: 'Europe 1 channel',
	[ModelType.eEurope_2_Channel]: 'Europe 2 channel2',
	[ModelType.eChina_1_Channel]: 'China 1 channel',
	[ModelType.eChina_2_Channel]: 'China 2 channel',
	[ModelType.eFFI_NF_2_Channel]: 'NF 2 channel',
	[ModelType.eFFI_XT_2_Channel]: 'XT 2 channel',
	[ModelType.eFFI_MI_2_Channel]: 'MI 2 channel',
	[ModelType.eFFI_NF_1_Channel]: 'NF 1 channel',
	[ModelType.eFFI_XT_1_Channel]: 'XT 1 channel',
	[ModelType.eFFI_MI_1_Channel]: 'MI 1 channel',
	[ModelType.eUnknown]: 'Unknown',
};

// Helper function to get description
function getModelTypeDescription(type: ModelType): string {
	return ModelTypeDescriptions[type];
}
export { ModelType, getModelTypeDescription };

//#endregion

//#region ExternalInputMode
// Define the enum
export enum ExternalInputMode {
	eUnbalanced_Open_or_Short = 0,
	eBalanced_Open_or_Short_eol = 1,
	eUnknown = 2,
}
// Define the descriptions separately
const ExternalInputModeDescriptions: Record<ExternalInputMode, string> = {
	[ExternalInputMode.eUnbalanced_Open_or_Short]: 'Unbalanced',
	[ExternalInputMode.eBalanced_Open_or_Short_eol]: 'Balanced',
	[ExternalInputMode.eUnknown]: 'Unknown',
};
// Helper function to get description
export function getExternalInputModeDescription(
	mode: ExternalInputMode,
): string {
	return ExternalInputModeDescriptions[mode];
}
//#endregion

//#region ExternalInputNormalState
// Define the enum
export enum ExternalInputNormalState {
	eOpen = 0,
	eShort = 1,
	eUnknown,
}
// Define the descriptions separately
const ExternalInputNormalStateDescriptions: Record<
	ExternalInputNormalState,
	string
> = {
	[ExternalInputNormalState.eOpen]: 'Open',
	[ExternalInputNormalState.eShort]: 'Short',
	[ExternalInputNormalState.eUnknown]: 'Unknown',
};
// Helper function to get description
export function getExternalInputNormalStateDescription(
	mode: ExternalInputNormalState,
): string {
	return ExternalInputNormalStateDescriptions[mode];
}
//#endregion

//#region ExternalInputAction
// Define the enum
export enum ExternalInputAction {
	eNone = 0,
	eResetDevice = 1,
	eTriggerExtFault = 2,
	ePerformADisableAction = 3,
	eResetAlarmAndFault = 4,
	eUnknown = 5,
}
// Define the descriptions separately
const ExternalInputActionDescriptions: Record<ExternalInputAction, string> = {
	[ExternalInputAction.eUnknown]: 'Unknown',
	[ExternalInputAction.eNone]: 'None',
	[ExternalInputAction.eResetDevice]: 'Reset Device',
	[ExternalInputAction.eTriggerExtFault]: 'Trigger Ext. Fault',
	[ExternalInputAction.ePerformADisableAction]: 'Perform Disable Action',
	[ExternalInputAction.eResetAlarmAndFault]: 'Reset Alarms and Fault',
};
// Helper function to get description
export function getExternalInputActionDescription(
	mode: ExternalInputAction,
): string {
	return ExternalInputActionDescriptions[mode];
}
//#endregion

//#region DeviceOrientation
// Define the enum
export enum DeviceOrientation {
	eDown_DetectorInverted = 0,
	eUp_Detector_Upright = 1,
	eUnknown,
}
// Define the descriptions separately
const DeviceOrientationDescription: Record<DeviceOrientation, string> = {
	[DeviceOrientation.eDown_DetectorInverted]: 'Inverted installation',
	[DeviceOrientation.eUp_Detector_Upright]: 'Upright installation',
	[DeviceOrientation.eUnknown]: 'Unknown',
};
// Helper function to get description
export function getDeviceOrientationDescription(
	mode: DeviceOrientation,
): string {
	return DeviceOrientationDescription[mode];
}
//#endregion

//#region FanPWMPercCorrection
// Define the enum
export enum FanPWMPercCorrection {
	eMinusSix = 106,
	eMinusFive = 105,
	eMinusFour = 104,
	eMinusThree = 103,
	eMinusTwo = 102,
	eMinusOne = 101,
	ePlusOne = 1,
	ePlusTwo = 2,
	ePlusThree = 3,
	ePlusFour = 4,
	ePlusFive = 5,
	ePlusSix = 6,
	eZero = 0,
	eUnknown = -1,
}
// Define the descriptions separately
const FanPWMPercCorrectionDescription: Record<FanPWMPercCorrection, string> = {
	[FanPWMPercCorrection.eMinusSix]: '-6',
	[FanPWMPercCorrection.eMinusFive]: '-5',
	[FanPWMPercCorrection.eMinusFour]: '-4',
	[FanPWMPercCorrection.eMinusThree]: '-3',
	[FanPWMPercCorrection.eMinusTwo]: '-2',
	[FanPWMPercCorrection.eMinusOne]: '-1',
	[FanPWMPercCorrection.ePlusOne]: '+1',
	[FanPWMPercCorrection.ePlusTwo]: '+2',
	[FanPWMPercCorrection.ePlusThree]: '+3',
	[FanPWMPercCorrection.ePlusFour]: '+4',
	[FanPWMPercCorrection.ePlusFive]: '+5',
	[FanPWMPercCorrection.ePlusSix]: '+6',
	[FanPWMPercCorrection.eZero]: '0',
	[FanPWMPercCorrection.eUnknown]: 'NA',
};
// Helper function to get description
export function getFanPWMPercCorrectionDescription(
	mode: FanPWMPercCorrection,
): string {
	return FanPWMPercCorrectionDescription[mode];
}
//#endregion
