import {
	AnswerLength,
	ErrorCode,
	DeviceStatus,
	GclCmd,
	Configuration,
	Country,
	RelayEnabled,
	Channel,
	AlarmFaultStatus,
	AnswerByteParamIndex,
	DeviceType,
	GclSubCmdT,
	FanSpeedLevel,
} from '../faastflexCommands/commandEnum';
import {
	HEADER_SIZE,
	SW_COMM_CHECKSUM_BASE,
	MessageHeaderHandler,
	CommandDefault,
	ResponseParser,
} from '../faastflexCommands/command';
import { commonCommand } from '../faastflexCommands/CommonCommand';

export class FaastFlexGetBlowerSpeed {
	public static GetFanSpeedLevelEEPROM(param: { msg: Uint8Array }): {
		errorCode: ErrorCode;
		byteToSend: number;
		byteToReceive: number;
	} {
		const { errorCode, byteToSend, byteToReceive } =
			commonCommand.subCmdReadNoParamAnsOneByte(
				param,
				GclSubCmdT.SW_CMD_FAN_SPEED,
			);
		return { errorCode, byteToSend, byteToReceive };
	}

	public static GetFanSpeedLevelEEPROMAnswer(
		param: { msg: Uint8Array },
		byteToBeReceived: number,
		byteReceived: number,
	): { retErrorCode: ErrorCode; fanSpeedLevel: FanSpeedLevel } {
		const { retErrorCode, retFanSpeedLevel } = this.ParseByteEnumAnswer(
			param.msg,
			byteToBeReceived,
			byteReceived,
			FanSpeedLevel.eUnknown,
			FanSpeedLevel,
		);
		return { retErrorCode, fanSpeedLevel: retFanSpeedLevel };
	}
	private static ParseByteEnumAnswer<RES_ENum extends number>(
		msg: Uint8Array,
		byteToBeReceived: number,
		byteReceived: number,
		defaultValue: RES_ENum,
		enumType: any,
	): { retErrorCode: ErrorCode; retFanSpeedLevel: RES_ENum } {
		let type: RES_ENum = defaultValue;
		let eRet: ErrorCode = ErrorCode.eOK;
		if (3 !== byteToBeReceived) {
			eRet = ErrorCode.eERR_ANS_INVALID_SIZE;
		}
		if (ErrorCode.eOK === eRet) {
			eRet = ResponseParser.checkAnswerMsgValidity(
				msg,
				byteToBeReceived,
				byteReceived,
			);
		}
		if (ErrorCode.eOK === eRet) {
			const { result, errorCode } = ResponseParser.getMsgAnswerParToEnum(
				msg,
				AnswerByteParamIndex.eParam_One,
				defaultValue,
				enumType,
			);
			type = result;
			eRet = errorCode;
		}
		return { retErrorCode: eRet, retFanSpeedLevel: type };
	}
}
