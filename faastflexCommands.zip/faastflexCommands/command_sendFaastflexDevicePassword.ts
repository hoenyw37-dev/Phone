import {
	AnswerLength,
	ErrorCode,
	DeviceStatus,
	GclCmd,
	Configuration,
	Country,
	RelayEnabled,
	Channel,
	AlarmFaultStatus,
	AnswerByteParamIndex,
	DeviceType,
	PasswordValid,
} from '../faastflexCommands/commandEnum';
import {
	HEADER_SIZE,
	SW_COMM_CHECKSUM_BASE,
	MessageHeaderHandler,
	CommandDefault,
	ResponseParser,
} from '../faastflexCommands/command';
import { commonCommand } from '../faastflexCommands/CommonCommand';

export class FaastFlexSendPasswordToDevice {
	public static SendFAASTPassword(
		param: { msg: Uint8Array },
		password1: PasswordValid,
		password2: PasswordValid,
		password3: PasswordValid,
		password4: PasswordValid,
		password5: PasswordValid,
		password6: PasswordValid,
	): {
		errorCode: ErrorCode;
		byteToSend: number;
		byteToReceive: number;
	} {
		const { errorCode, byteToSend, byteToReceive } =
			commonCommand.cmdNoParamAnsAckOnly(param, GclCmd.SW_CMD_SEND_FAAST_PSW);
		if (errorCode === ErrorCode.eOK) {
			MessageHeaderHandler.setMsgHeaderPar1(param, password1);
			MessageHeaderHandler.setMsgHeaderPar2(param, password2);
			MessageHeaderHandler.setMsgHeaderPar3(param, password3);
			MessageHeaderHandler.setMsgHeaderPar4(param, password4);
			MessageHeaderHandler.setMsgHeaderPar5(param, password5);
			MessageHeaderHandler.setMsgHeaderPar6(param, password6);
			MessageHeaderHandler.setMsgHeaderChecksum(param);
		}
		return { errorCode, byteToSend, byteToReceive };
	}
	public static SendFAASTPasswordAnswer(
		param: { msg: Uint8Array },
		byteToBeReceived: number,
		byteReceived: number,
	): { retErrorCode: ErrorCode } {
		let retErrorCode: ErrorCode = ErrorCode.eERR_UNKNOWN;
		retErrorCode = ResponseParser.checkAnswerMsgValidity(
			param.msg,
			byteToBeReceived,
			byteReceived,
		);
		return { retErrorCode };
	}

	public static ChangePassword(
		param: { msg: Uint8Array },
		password1: PasswordValid,
		password2: PasswordValid,
		password3: PasswordValid,
		password4: PasswordValid,
		password5: PasswordValid,
		password6: PasswordValid,
	): {
		errorCode: ErrorCode;
		byteToSend: number;
		byteToReceive: number;
	} {
		const { errorCode, byteToSend, byteToReceive } =
			commonCommand.cmdNoParamAnsAckOnly(param, GclCmd.SW_CMD_CHANGE_PSW);
		if (errorCode === ErrorCode.eOK) {
			MessageHeaderHandler.setMsgHeaderPar1(param, password1);
			MessageHeaderHandler.setMsgHeaderPar2(param, password2);
			MessageHeaderHandler.setMsgHeaderPar3(param, password3);
			MessageHeaderHandler.setMsgHeaderPar4(param, password4);
			MessageHeaderHandler.setMsgHeaderPar5(param, password5);
			MessageHeaderHandler.setMsgHeaderPar6(param, password6);
			MessageHeaderHandler.setMsgHeaderChecksum(param);
		}
		return { errorCode, byteToSend, byteToReceive };
	}
	public static ChangePasswordAnswer(
		param: { msg: Uint8Array },
		byteToBeReceived: number,
		byteReceived: number,
	): { retErrorCode: ErrorCode } {
		let retErrorCode: ErrorCode = ErrorCode.eERR_UNKNOWN;
		retErrorCode = ResponseParser.checkAnswerMsgValidity(
			param.msg,
			byteToBeReceived,
			byteReceived,
		);
		return { retErrorCode };
	}
}
