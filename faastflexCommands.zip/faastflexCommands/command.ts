import {
	HeaderPosition,
	ErrorCode,
	GclCmd,
	GCL_RESULT,
	AnswerByteParamIndex,
	FfIGclCmd,
} from '../faastflexCommands/commandEnum';

export const HEADER_SIZE: number = 16;
export const SW_COMM_CHECKSUM_BASE: number = 8;
type EnumType = { [key: string]: number | string };

export class CommandDefault {
	static zeroArray(param: { msg: Uint8Array }): void {
		param.msg.fill(0);
	}
	static SetCommandID(
		param: { msg: Uint8Array },
		cmdId: GclCmd | FfIGclCmd,
	): ErrorCode {
		let eRet: ErrorCode = ErrorCode.eOK;

		if (HEADER_SIZE > param.msg.length) {
			eRet = ErrorCode.eERR_INVALID_BUFFER_SIZE;
		}

		if (eRet === ErrorCode.eOK) {
			param.msg[HeaderPosition.POS_CMD_ID] = cmdId as number;
		}

		return eRet;
	}
}

export class MessageHeaderHandler {
	static set_msg_header_par(
		param: { msg: Uint8Array },
		param_value: number,
		param_indx: HeaderPosition,
	): ErrorCode {
		let eRet: ErrorCode = ErrorCode.eOK;

		if (HEADER_SIZE > param.msg.length) {
			eRet = ErrorCode.eERR_INVALID_BUFFER_SIZE;
		}

		if (eRet === ErrorCode.eOK) {
			param.msg[param_indx] = param_value;
		}

		return eRet;
	}

	static setMsgHeaderPar1(
		param: { msg: Uint8Array },
		param_value: number,
	): ErrorCode {
		return this.set_msg_header_par(
			param,
			param_value,
			HeaderPosition.POS_PAR_1,
		);
	}

	static setMsgHeaderPar2(
		param: { msg: Uint8Array },
		param_value: number,
	): ErrorCode {
		return this.set_msg_header_par(
			param,
			param_value,
			HeaderPosition.POS_PAR_2,
		); // Fixed position
	}

	static setMsgHeaderPar3(
		param: { msg: Uint8Array },
		param_value: number,
	): ErrorCode {
		return this.set_msg_header_par(
			param,
			param_value,
			HeaderPosition.POS_PAR_3,
		);
	}

	static setMsgHeaderPar4(
		param: { msg: Uint8Array },
		param_value: number,
	): ErrorCode {
		return this.set_msg_header_par(
			param,
			param_value,
			HeaderPosition.POS_PAR_4,
		);
	}

	static setMsgHeaderPar5(
		param: { msg: Uint8Array },
		param_value: number,
	): ErrorCode {
		return this.set_msg_header_par(
			param,
			param_value,
			HeaderPosition.POS_PAR_5,
		);
	}

	static setMsgHeaderPar6(
		param: { msg: Uint8Array },
		param_value: number,
	): ErrorCode {
		return this.set_msg_header_par(
			param,
			param_value,
			HeaderPosition.POS_PAR_6,
		);
	}

	static setMsgHeaderPar7(
		param: { msg: Uint8Array },
		param_value: number,
	): ErrorCode {
		return this.set_msg_header_par(
			param,
			param_value,
			HeaderPosition.POS_PAR_7,
		);
	}

	static setMsgHeaderPar8(
		param: { msg: Uint8Array },
		param_value: number,
	): ErrorCode {
		return this.set_msg_header_par(
			param,
			param_value,
			HeaderPosition.POS_PAR_8,
		);
	}

	static setMsgHeaderPar9(
		param: { msg: Uint8Array },
		param_value: number,
	): ErrorCode {
		return this.set_msg_header_par(
			param,
			param_value,
			HeaderPosition.POS_PAR_9,
		);
	}

	static setMsgHeaderPar10(
		param: { msg: Uint8Array },
		param_value: number,
	): ErrorCode {
		return this.set_msg_header_par(
			param,
			param_value,
			HeaderPosition.POS_PAR_10,
		);
	}

	static setMsgHeaderPar11(
		param: { msg: Uint8Array },
		param_value: number,
	): ErrorCode {
		return this.set_msg_header_par(
			param,
			param_value,
			HeaderPosition.POS_PAR_11,
		);
	}

	static setMsgHeaderPar12(
		param: { msg: Uint8Array },
		param_value: number,
	): ErrorCode {
		return this.set_msg_header_par(
			param,
			param_value,
			HeaderPosition.POS_PAR_12,
		);
	}

	static setMsgHeaderPar1CheckSum(
		param: { msg: Uint8Array },
		param_value: number,
	): ErrorCode {
		const eRet = this.set_msg_header_par(
			param,
			param_value,
			HeaderPosition.POS_PAR_1,
		);
		if (ErrorCode.eOK === eRet) {
			this.setMsgHeaderChecksum(param);
		}
		return eRet;
	}

	static setMsgHeaderChecksum(param: { msg: Uint8Array }): void {
		param.msg[HeaderPosition.POS_CHKSUM] = this.calcCheckSum(
			param.msg,
			HEADER_SIZE - 1,
		);
	}

	static calcCheckSum(msg: Uint8Array, bytesToBeUsed: number): number {
		let ucChecksum: number = SW_COMM_CHECKSUM_BASE;
		for (let i = 0; i < bytesToBeUsed; i++) {
			ucChecksum += msg[i];
		}
		return ucChecksum;
	}
}

export class ResponseParser {
	static ParseByteAnswer(
		msg: Readonly<Uint8Array>,
		byteToBeReceived: Readonly<number>,
		byteReceived: Readonly<number>,
	): { errorCode: ErrorCode; result: number } {
		let eRet: ErrorCode = ErrorCode.eERR_UNKNOWN;
		let result: number = 0;
		eRet = this.checkAnswerMsgValidity(msg, byteToBeReceived, byteReceived);
		if (eRet === ErrorCode.eOK) {
			if (byteToBeReceived === 3) {
				result = msg[1];
			} else {
				eRet = ErrorCode.eERR_ANS_INVALID_SIZE;
			}
		}
		return { errorCode: eRet, result };
	}
	static checkAnswerMsgValidity(
		msg: Readonly<Uint8Array>,
		byteToBeReceived: Readonly<number>,
		byteReceived: Readonly<number>,
	): ErrorCode {
		let eRet: ErrorCode = ErrorCode.eERR_UNKNOWN;

		if (byteToBeReceived !== byteReceived) {
			eRet = ErrorCode.eERR_ANS_INVALID_SIZE;
		} else if (byteToBeReceived === 0 && byteReceived === 0) {
			eRet = ErrorCode.eOK; // never here
		} else if (msg.length < byteToBeReceived) {
			eRet = ErrorCode.eERR_ANS_INVALID_SIZE;
		} else {
			const errorCode = msg[0];

			if (GCL_RESULT.eGCL_ACK !== errorCode) {
				if (this.isGclErrorCodeValid(errorCode)) {
					eRet = errorCode as ErrorCode;
				} else {
					eRet = ErrorCode.eERR_UNKNOWN;
				}
			} else {
				const byteToCheck = byteToBeReceived - 1;

				if (byteToCheck > 0) {
					if (
						msg[byteReceived - 1] !== this.calcCheckSumAnswer(msg, byteToCheck)
					) {
						eRet = ErrorCode.eERR_ANS_INVALID_CHECKSUM;
					} else if (GCL_RESULT.eGCL_ACK !== msg[0]) {
						eRet = ErrorCode.eERR_ANS_ACK;
					} else {
						eRet = ErrorCode.eOK;
					}
				} else {
					eRet = ErrorCode.eOK;
				}
			}
		}

		return eRet;
	}
	static calcCheckSumAnswer(
		msg: Readonly<Uint8Array>,
		bytesToBeUsed: Readonly<number>,
	): number {
		let ucChecksum = SW_COMM_CHECKSUM_BASE;
		for (let i = 1; i < bytesToBeUsed; i++) {
			ucChecksum = (ucChecksum + msg[i]) & 0xff;
		}
		return ucChecksum;
	}
	static isGclErrorCodeValid(errorCode: number): boolean {
		const validErrorCodes: Set<number> = new Set([
			ErrorCode.eGCL_ACK,
			ErrorCode.eGCL_NACK,
			ErrorCode.eGCL_NOT_EXTENDED,
			ErrorCode.eGCL_NOT_VALID_ADDRESS,
			ErrorCode.eGCL_NOT_VALID_FREQUENCE,
			ErrorCode.eGCL_NOT_VALID_COMPENSATION,
			ErrorCode.eGCL_NOT_VALID_PARAMETER,
			ErrorCode.eGCL_NOT_VALID_SIZE,
			ErrorCode.eGCL_AD_CHANNEL_INVALID,
			ErrorCode.eGCL_RELAY_NUMBER_INVALID,
			ErrorCode.eGCL_NOT_VALID_CHANNEL,
			ErrorCode.eGCL_CHECKSUM_ERROR,
			ErrorCode.eGCL_NOT_VALID_LED_NUMBER,
			ErrorCode.eGCL_NOT_ALLOWED_COMMAND,
			ErrorCode.eGCL_WRITE_EEP_CHECKSUM_ERROR,
			ErrorCode.eGCL_COPY_EEPROM_ERROR,
			ErrorCode.eGCL_NOT_PAIRED_ERROR,
			ErrorCode.eGCL_NOT_ALLOWED_FOR_COVER_CLOSED,
			ErrorCode.eGCL_CHINESE_VARIANT,
			ErrorCode.eGCL_EUROPEAN_VARIANT,
			ErrorCode.eGCL_NOT_VALID_PASSWORD,
			ErrorCode.eGCL_CH1_NOT_AS_CH2,
			ErrorCode.GCL_PASSWORD_DELAYED,
		]);

		return validErrorCodes.has(errorCode);
	}
	/**
	 * Converts a byte value to an enum type
	 * @param byteParam The byte value to convert
	 * @param defaultValue The default value to use if conversion fails
	 * @param enumType The enum type to convert to
	 * @returns An object with the result and error code
	 */

	public static byteToEnum<T extends number>(
		byteParam: number,
		enumObject: EnumType,
		defaultValue: T,
	): { result: T; errorCode: ErrorCode } {
		const returnValue = {
			result: defaultValue,
			errorCode: ErrorCode.eERR_ANS_INVALID_RANGE,
		};
		// Check if the byte value is a valid enum value
		const enumValues = Object.values(enumObject).filter(
			value => typeof value === 'number',
		);
		if (enumValues.includes(byteParam)) {
			try {
				returnValue.result = byteParam as unknown as T;
				returnValue.errorCode = ErrorCode.eOK;
			} catch (error) {
				// Keep default value on error
			}
		}
		return returnValue;
	}
	/**
	 * Extracts a byte value from a message array and converts it to an enum value
	 * @param msg The byte array message
	 * @param paramNum Index in the message to extract the value from
	 * @param defaultValue Default enum value to use if conversion fails
	 * @param enumType Object containing all possible enum values
	 * @returns Object containing result and error code
	 */
	public static getMsgAnswerParToEnum<T extends number>(
		msg: Readonly<Uint8Array>,
		paramNum: AnswerByteParamIndex,
		defaultValue: T,
		enumType: EnumType,
	): { result: T; errorCode: ErrorCode } {
		const returnValue = {
			result: defaultValue,
			errorCode: ErrorCode.eOK,
		};
		// Check if paramNum is a valid enum value
		const isValidParamIndex =
			Object.values(AnswerByteParamIndex).includes(paramNum);
		if (!isValidParamIndex) {
			returnValue.errorCode = ErrorCode.eERR_INVALID_PARAMETER;
		}
		if (returnValue.errorCode === ErrorCode.eOK) {
			const idx = paramNum;
			const byteResult = msg[idx];
			const enumValues = Object.values(enumType).filter(
				value => typeof value === 'number',
			);
			if (enumValues.includes(byteResult)) {
				try {
					returnValue.result = byteResult as unknown as T;
					returnValue.errorCode = ErrorCode.eOK;
				} catch (error) {
					// Keep default value on error
				}
			}
		}
		return returnValue;
	}
}
