import {
	AnswerLength,
	ErrorCode,
	GclCmd,
	RelayAlert,
	FanSpeedLevel,
	FanPWMPercCorrection,
} from '../faastflexCommands/commandEnum';
import { ResponseParser } from '../faastflexCommands/command';
import { commonCommand } from '../faastflexCommands/CommonCommand';
import { DeviceGeneralParams } from '../faastflexCommands/common_objects';
import { DeviceOrientation } from '../faastflexCommands/commandEnum';

interface GeneralParametersResult {
	errorCode: ErrorCode;
	deviceParams: DeviceGeneralParams;
}
export class FaastFlexGeneralParameters {
	public static GetGeneralParams(param: { msg: Uint8Array }): {
		errorCode: ErrorCode;
		byteToSend: number;
		byteToReceive: number;
	} {
		const { errorCode, byteToSend, byteToReceive } =
			commonCommand.cmdNoParamAnsData(
				param,
				GclCmd.SW_CMD_GET_PARAMS2,
				AnswerLength.eSixteen,
			);

		return { errorCode, byteToSend, byteToReceive };
	}

	public static GetGeneralParamsAnswer(
		param: { msg: Uint8Array },
		byteToBeReceived: number,
		byteReceived: number,
	): {
		errorCode: ErrorCode;
		deviceOrientation: DeviceOrientation;
		day: number;
		month: number;
		year: number;
		hour: number;
		minute: number;
		second: number;
		disableTimeout: number;
		trendlog: number;
		tempRelay: RelayAlert;
		lowPowerRelay: RelayAlert;
		blowerSpeedLevel: FanSpeedLevel;
		blowerSpeedCorrection: FanPWMPercCorrection;
	} {
		let retErrorCode: ErrorCode = ErrorCode.eERR_UNKNOWN;
		let resultParams = {
			errorCode: ErrorCode.eERR_UNKNOWN,
			deviceOrientation: DeviceOrientation.eUnknown,
			day: 0,
			month: 0,
			year: 0,
			hour: 0,
			minute: 0,
			second: 0,
			disableTimeout: 0,
			trendlog: 0,
			tempRelay: RelayAlert.eUnknown,
			lowPowerRelay: RelayAlert.eUnknown,
			blowerSpeedLevel: FanSpeedLevel.eUnknown,
			blowerSpeedCorrection: FanPWMPercCorrection.eUnknown,
		};
		retErrorCode = ResponseParser.checkAnswerMsgValidity(
			param.msg,
			byteToBeReceived,
			byteReceived,
		);
		const msg = param.msg;
		if (retErrorCode === ErrorCode.eOK) {
			const _deviceOrientation = msg[1];
			const { result, errorCode } =
				ResponseParser.byteToEnum<DeviceOrientation>(
					_deviceOrientation,
					DeviceOrientation,
					DeviceOrientation.eUnknown,
				);
			resultParams.deviceOrientation = result;
			retErrorCode = errorCode;
		}

		if (retErrorCode === ErrorCode.eOK) {
			resultParams.day = msg[2];
			resultParams.month = msg[3];
			resultParams.year = msg[4];
			resultParams.hour = msg[5];
			resultParams.minute = msg[6];
			resultParams.second = msg[7];
			resultParams.disableTimeout = msg[8];
			resultParams.trendlog = msg[9];
		}
		if (retErrorCode === ErrorCode.eOK) {
			const _tempRelay = msg[10];
			const { result, errorCode } = ResponseParser.byteToEnum<RelayAlert>(
				_tempRelay,
				RelayAlert,
				RelayAlert.eUnknown,
			);
			resultParams.tempRelay = result;
			retErrorCode = errorCode;
		}
		if (retErrorCode === ErrorCode.eOK) {
			const _lowPowerRelay = msg[11];
			const { result, errorCode } = ResponseParser.byteToEnum<RelayAlert>(
				_lowPowerRelay,
				RelayAlert,
				RelayAlert.eUnknown,
			);
			resultParams.lowPowerRelay = result;
			retErrorCode = errorCode;
		}
		if (retErrorCode === ErrorCode.eOK) {
			const _blowerSpeedLevel = msg[12];
			const { result, errorCode } = ResponseParser.byteToEnum<FanSpeedLevel>(
				_blowerSpeedLevel,
				FanSpeedLevel,
				FanSpeedLevel.eUnknown,
			);
			resultParams.blowerSpeedLevel = result;
			retErrorCode = errorCode;
		}
		if (retErrorCode === ErrorCode.eOK) {
			const _correctionValue = msg[13];
			const _correctionSign = msg[14];
			const correctionMap: { [key: number]: FanPWMPercCorrection } = {
				0: FanPWMPercCorrection.eZero,
				1:
					_correctionSign === 0
						? FanPWMPercCorrection.ePlusOne
						: FanPWMPercCorrection.eMinusOne,
				2:
					_correctionSign === 0
						? FanPWMPercCorrection.ePlusTwo
						: FanPWMPercCorrection.eMinusTwo,
				3:
					_correctionSign === 0
						? FanPWMPercCorrection.ePlusThree
						: FanPWMPercCorrection.eMinusThree,
				4:
					_correctionSign === 0
						? FanPWMPercCorrection.ePlusFour
						: FanPWMPercCorrection.eMinusFour,
				5:
					_correctionSign === 0
						? FanPWMPercCorrection.ePlusFive
						: FanPWMPercCorrection.eMinusFive,
				6:
					_correctionSign === 0
						? FanPWMPercCorrection.ePlusSix
						: FanPWMPercCorrection.eMinusSix,
			};

			if (_correctionValue in correctionMap) {
				resultParams.blowerSpeedCorrection = correctionMap[_correctionValue];
			} else {
				resultParams.errorCode = ErrorCode.eERR_ANS_INVALID_RANGE;
			}
		}
		resultParams.errorCode = retErrorCode;
		return resultParams;
	}
}
