import {
	AnswerLength,
	ErrorCode,
	DeviceStatus,
	GclCmd,
	Configuration,
	Country,
	RelayEnabled,
	Channel,
	AlarmFaultStatus,
	AnswerByteParamIndex,
	DeviceType,
	PasswordValid,
	GclSubCmdT,
	AlarmLevel,
} from '../faastflexCommands/commandEnum';
import {
	HEADER_SIZE,
	SW_COMM_CHECKSUM_BASE,
	MessageHeaderHandler,
	CommandDefault,
	ResponseParser,
} from '../faastflexCommands/command';
import { commonCommand } from '../faastflexCommands/CommonCommand';
import { min } from 'date-fns';
import { ms } from 'date-fns/locale';

export class FaastFlexIntelligentGetSensorAddress {
	public static GetIntelligentSetSensorAddress(
		param: { msg: Uint8Array },
		_channel: Channel,
	): {
		errorCode: ErrorCode;
		byteToSend: number;
		byteToReceive: number;
	} {
		const { errorCode, byteToSend, byteToReceive } =
			commonCommand.subCmdReadOneParamAnsData(
				param,
				GclSubCmdT.FFI_SW_CMD_SENSOR_ADDRESS,
				_channel,
			);
		return { errorCode, byteToSend, byteToReceive };
	}
	public static GetIntelligentSetSensorAddressAnswer(
		param: { msg: Uint8Array },
		byteToBeReceived: number,
		byteReceived: number,
	): { retErrorCode: ErrorCode; address: number } {
		let retErrorCode: ErrorCode = ErrorCode.eERR_UNKNOWN;
		retErrorCode = ResponseParser.checkAnswerMsgValidity(
			param.msg,
			byteToBeReceived,
			byteReceived,
		);
		let address = -1;
		if (retErrorCode === ErrorCode.eOK) {
			address = param.msg[1];
		}
		return { retErrorCode, address };
	}
}
