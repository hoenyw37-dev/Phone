import {
	AnswerLength,
	DeviceAuthenticated,
	ErrorCode,
	GCL_RESULT,
	GclCmd,
	HeaderPosition,
} from '../faastflexCommands/commandEnum';
import {
	HEADER_SIZE,
	SW_COMM_CHECKSUM_BASE,
	MessageHeaderHandler,
	CommandDefault,
	ResponseParser,
} from '../faastflexCommands/command';
import { commonCommand } from '../faastflexCommands/CommonCommand';

export class FaastFlexCheckAuthenticated {
	public static amIAuthenticated(
		param: { msg: Uint8Array },
		digit_1: number,
		digit_2: number,
		digit_3: number,
		digit_4: number,
		digit_5: number,
		digit_6: number,
		digit_7: number,
		digit_8: number,
		digit_9: number,
		digit_10: number,
		digit_11: number,
		digit_12: number,
	): { errorCode: ErrorCode; byteToSend: number; byteToReceive: number } {
		const { errorCode, byteToSend, byteToReceive } =
			commonCommand.CmdTwelveParamsAnsAny(
				param,
				GclCmd.SW_CMD_AM_I_AUTHENTICATED,
				digit_1,
				digit_2,
				digit_3,
				digit_4,
				digit_5,
				digit_6,
				digit_7,
				digit_8,
				digit_9,
				digit_10,
				digit_11,
				digit_12,
				AnswerLength.eThree,
			);

		return { errorCode, byteToSend, byteToReceive };
	}

	public static amIAuthenticatedAnswer(
		param: { msg: Uint8Array },
		byteToBeReceived: number,
		byteReceived: number,
		deviceAuthenticated: DeviceAuthenticated,
	): {
		retErrorCode: ErrorCode;
		retDeviceAuthenticated: DeviceAuthenticated;
	} {
		return this.parseAuthenticatedAnswer(
			param,
			byteToBeReceived,
			byteReceived,
			deviceAuthenticated,
		);
	}

	private static parseAuthenticatedAnswer(
		param: { msg: Uint8Array },
		byteToBeReceived: number,
		byteReceived: number,
		deviceAuthenticated: DeviceAuthenticated,
	): {
		retErrorCode: ErrorCode;
		retDeviceAuthenticated: DeviceAuthenticated;
	} {
		const GCL_AUTH: number = 80;
		const GCL_NOT_AUTH: number = 81;
		deviceAuthenticated = DeviceAuthenticated.eUnknown;
		let eRet: ErrorCode = ErrorCode.eERR_UNKNOWN;
		const { errorCode, result } = ResponseParser.ParseByteAnswer(
			param.msg,
			byteToBeReceived,
			byteReceived,
		);
		eRet = errorCode;
		if (errorCode === ErrorCode.eOK) {
			if (result === GCL_AUTH) {
				deviceAuthenticated = DeviceAuthenticated.eAuthenticated;
			} else if (result === GCL_NOT_AUTH) {
				deviceAuthenticated = DeviceAuthenticated.eNotAuthenticated;
			} else {
				deviceAuthenticated = DeviceAuthenticated.eUnknown;
			}
		}
		return {
			retErrorCode: eRet,
			retDeviceAuthenticated: deviceAuthenticated,
		};
	}
}
