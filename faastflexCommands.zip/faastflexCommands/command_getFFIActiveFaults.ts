import {
	AnswerLength,
	ErrorCode,
	DeviceStatus,
	GclCmd,
	Configuration,
	Country,
	RelayEnabled,
	Channel,
	AlarmFaultStatus,
	AnswerByteParamIndex,
	DeviceType,
	FfIGclCmd,
} from '../faastflexCommands/commandEnum';
import {
	HEADER_SIZE,
	SW_COMM_CHECKSUM_BASE,
	MessageHeaderHandler,
	CommandDefault,
	ResponseParser,
} from '../faastflexCommands/command';
import { commonCommand } from '../faastflexCommands/CommonCommand';
import { number } from 'yup';

export class FaastFlexIntelligentGetActiveFaults {
	public static FFI_GetActiveFaults(param: { msg: Uint8Array }): {
		errorCode: ErrorCode;
		byteToSend: number;
		byteToReceive: number;
	} {
		const { errorCode, byteToSend, byteToReceive } =
			commonCommand.cmdNoParamAnsData(
				param,
				FfIGclCmd.FFI_SW_CMD_GET_ACTIVE_FAULTS,
				AnswerLength.eFive,
			);

		return { errorCode, byteToSend, byteToReceive };
	}
	public static FFI_GetActiveFaultsAnswer(
		param: { msg: Uint8Array },
		byteToBeReceived: number,
		byteReceived: number,
	): {
		errorCode: ErrorCode;
		faultMask1: number[];
		faultMask2: number[];
		faultMask3: number[];
	} {
		let retErrorCode: ErrorCode = ErrorCode.eERR_UNKNOWN;
		let msg = param.msg;
		let byte1: number[] = [];
		let byte2: number[] = [];
		let byte3: number[] = [];
		retErrorCode = ResponseParser.checkAnswerMsgValidity(
			param.msg,
			byteToBeReceived,
			byteReceived,
		);
		if (ErrorCode.eOK === retErrorCode) {
			byte1 = this.parseActiveFaults(msg[1]);
			byte2 = this.parseActiveFaults(msg[2]);
			byte3 = this.parseActiveFaults(msg[3]);
		}
		return {
			errorCode: retErrorCode,
			faultMask1: byte1,
			faultMask2: byte2,
			faultMask3: byte3,
		};
	}

	private static parseActiveFaults(num: number): number[] {
		const arr = [];
		for (let i = 0; i < 8; i++) {
			arr[i] = (num >> i) & 0x01; // Get each bit
		}
		return arr;
	}
}
