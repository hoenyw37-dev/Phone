import {
	AnswerLength,
	ErrorCode,
	DeviceStatus,
	GclCmd,
	Configuration,
	Country,
	RelayEnabled,
	Channel,
	AlarmFaultStatus,
	AnswerByteParamIndex,
	DeviceType,
} from '../faastflexCommands/commandEnum';
import {
	HEADER_SIZE,
	SW_COMM_CHECKSUM_BASE,
	MessageHeaderHandler,
	CommandDefault,
	ResponseParser,
} from '../faastflexCommands/command';
import { commonCommand } from '../faastflexCommands/CommonCommand';

export class FaastFlexSelfTestEurope {
	public static StartSelfTestEurope(
		param: { msg: Uint8Array },
		nextCmd: number,
	): { errorCode: ErrorCode; byteToSend: number; byteToReceive: number } {
		const { errorCode, byteToSend, byteToReceive } =
			commonCommand.cmdNoParamAnsAckOnlyForSelfTest(
				param,
				GclCmd.SW_CMD_SELF_TEST_EUROPE,
				nextCmd,
			);
		return { errorCode, byteToSend, byteToReceive };
	}
	public static StartSelfTestEuropeAnswer(
		param: { msg: Uint8Array },
		byteToBeReceived: number,
		byteReceived: number,
	): { retErrorCode: ErrorCode } {
		let retErrorCode: ErrorCode = ErrorCode.eERR_UNKNOWN;
		retErrorCode = ResponseParser.checkAnswerMsgValidity(
			param.msg,
			byteToBeReceived,
			byteReceived,
		);
		return { retErrorCode };
	}
}
