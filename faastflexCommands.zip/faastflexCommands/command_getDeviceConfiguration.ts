import {
	AnswerLength,
	ErrorCode,
	DeviceStatus,
	GclCmd,
	Configuration,
	Country,
	RelayEnabled,
	Channel,
	AlarmFaultStatus,
	AnswerByteParamIndex,
	DeviceType,
} from '../faastflexCommands/commandEnum';
import {
	HEADER_SIZE,
	SW_COMM_CHECKSUM_BASE,
	MessageHeaderHandler,
	CommandDefault,
	ResponseParser,
} from '../faastflexCommands/command';
import { commonCommand } from '../faastflexCommands/CommonCommand';

export class FaastFlexGetDeviceConfiguration {
	public static GetRealConf(param: { msg: Uint8Array }): {
		errorCode: ErrorCode;
		byteToSend: number;
		byteToReceive: number;
	} {
		const { errorCode, byteToSend, byteToReceive } =
			commonCommand.cmdNoParamAnsData(
				param,
				GclCmd.SW_CMD_GET_REAL_CONFIG,
				AnswerLength.eTwelve,
			);

		return { errorCode, byteToSend, byteToReceive };
	}
	public static GetRealConfAnswer(
		param: { msg: Uint8Array },
		byteToBeReceived: number,
		byteReceived: number,
		deviceType: DeviceType,
	): { retErrorCode: ErrorCode; realConf: Configuration } {
		let retErrorCode: ErrorCode = ErrorCode.eERR_UNKNOWN;

		let msg = param.msg;
		let realConf: Configuration = Configuration.Unknown;
		retErrorCode = ResponseParser.checkAnswerMsgValidity(
			param.msg,
			byteToBeReceived,
			byteReceived,
		);
		if (retErrorCode === ErrorCode.eOK) {
			if (deviceType === DeviceType.eStandAlone) {
				realConf = msg[1] as Configuration;
			} else if (deviceType === DeviceType.eIntelligent) {
				realConf = msg[3] as Configuration;
			}
		}
		return { retErrorCode, realConf };
	}
}
