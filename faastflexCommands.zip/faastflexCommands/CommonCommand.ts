// CommonCommand.ts
// This file contains the common command functions used in the FAASTFlex command library.

import {
	AnswerLength,
	DeviceAuthenticated,
	ErrorCode,
	FfIGclCmd,
	GCL_RESULT,
	GclCmd,
	GclSubCmdT,
	HeaderPosition,
} from '../faastflexCommands/commandEnum';
import {
	HEADER_SIZE,
	SW_COMM_CHECKSUM_BASE,
	MessageHeaderHandler,
	CommandDefault,
	ResponseParser,
} from '../faastflexCommands/command';

export class commonCommand {
	static CmdTwelveParamsAnsAny(
		param: { msg: Uint8Array },
		cmdId: GclCmd,
		param1: number,
		param2: number,
		param3: number,
		param4: number,
		param5: number,
		param6: number,
		param7: number,
		param8: number,
		param9: number,
		param10: number,
		param11: number,
		param12: number,
		byteToReceiveInternal: AnswerLength,
	): { errorCode: ErrorCode; byteToSend: number; byteToReceive: number } {
		let eRet: ErrorCode = ErrorCode.eERR_UNKNOWN;
		let byteToSend: number = 0;
		let byteToReceive: number = 0;
		if (param.msg.length < HEADER_SIZE) {
			byteToSend = 0;
			byteToReceive = 0;
			eRet = ErrorCode.eERR_INVALID_BUFFER_SIZE;
		} else {
			CommandDefault.zeroArray(param);
			byteToSend = HEADER_SIZE;
			byteToReceive = byteToReceiveInternal;

			eRet = CommandDefault.SetCommandID(param, cmdId);

			if (eRet === ErrorCode.eOK)
				eRet = MessageHeaderHandler.setMsgHeaderPar1(param, param1);
			if (eRet === ErrorCode.eOK)
				eRet = MessageHeaderHandler.setMsgHeaderPar2(param, param2);
			if (eRet === ErrorCode.eOK)
				eRet = MessageHeaderHandler.setMsgHeaderPar3(param, param3);
			if (eRet === ErrorCode.eOK)
				eRet = MessageHeaderHandler.setMsgHeaderPar4(param, param4);
			if (eRet === ErrorCode.eOK)
				eRet = MessageHeaderHandler.setMsgHeaderPar5(param, param5);
			if (eRet === ErrorCode.eOK)
				eRet = MessageHeaderHandler.setMsgHeaderPar6(param, param6);
			if (eRet === ErrorCode.eOK)
				eRet = MessageHeaderHandler.setMsgHeaderPar7(param, param7);
			if (eRet === ErrorCode.eOK)
				eRet = MessageHeaderHandler.setMsgHeaderPar8(param, param8);
			if (eRet === ErrorCode.eOK)
				eRet = MessageHeaderHandler.setMsgHeaderPar9(param, param9);
			if (eRet === ErrorCode.eOK)
				eRet = MessageHeaderHandler.setMsgHeaderPar10(param, param10);
			if (eRet === ErrorCode.eOK)
				eRet = MessageHeaderHandler.setMsgHeaderPar11(param, param11);
			if (eRet === ErrorCode.eOK)
				eRet = MessageHeaderHandler.setMsgHeaderPar12(param, param12);

			if (eRet === ErrorCode.eOK)
				MessageHeaderHandler.setMsgHeaderChecksum(param);
		}

		return { errorCode: eRet, byteToSend, byteToReceive };
	}

	/**
	 * Prepares a command message with no parameters and expects data in the answer
	 * @param param Object containing the message buffer
	 * @param cmd The command to execute
	 * @param answerLength Expected length of the answer
	 * @returns Object with error code and bytes to send/receive
	 */
	public static cmdNoParamAnsData(
		param: { msg: Uint8Array },
		cmd: GclCmd | FfIGclCmd,
		answerLength: AnswerLength,
	): { errorCode: ErrorCode; byteToSend: number; byteToReceive: number } {
		if (!param.msg || param.msg.length < 1) {
			return {
				errorCode: ErrorCode.eERR_UNKNOWN,
				byteToSend: 0,
				byteToReceive: 0,
			};
		}

		try {
			const { errorCode, byteToSend, byteToReceive } =
				this.cmdThreeParamsWithDataAnswer(param, cmd, 0, 0, 0, answerLength);
			return { errorCode, byteToSend, byteToReceive };
		} catch (error) {
			return {
				errorCode: ErrorCode.eERR_UNKNOWN,
				byteToSend: 0,
				byteToReceive: 0,
			};
		}
	}

	public static cmdNoParamAnsAckOnly(
		param: { msg: Uint8Array },
		cmd: GclCmd,
	): { errorCode: ErrorCode; byteToSend: number; byteToReceive: number } {
		if (!param.msg || param.msg.length < 1) {
			return {
				errorCode: ErrorCode.eERR_UNKNOWN,
				byteToSend: 0,
				byteToReceive: 0,
			};
		}
		try {
			const { errorCode, byteToSend, byteToReceive } =
				this.cmdThreeParamsWithDataAnswer(
					param,
					cmd,
					0,
					0,
					0,
					AnswerLength.eOne,
				);
			return { errorCode, byteToSend, byteToReceive };
		} catch (error) {
			return {
				errorCode: ErrorCode.eERR_UNKNOWN,
				byteToSend: 0,
				byteToReceive: 0,
			};
		}
	}

	public static cmdNoParamAnsAckOnlyForSelfTest(
		param: { msg: Uint8Array },
		cmd: GclCmd,
		nextCmd: number,
	): { errorCode: ErrorCode; byteToSend: number; byteToReceive: number } {
		if (!param.msg || param.msg.length < 1) {
			return {
				errorCode: ErrorCode.eERR_UNKNOWN,
				byteToSend: 0,
				byteToReceive: 0,
			};
		}
		try {
			const { errorCode, byteToSend, byteToReceive } =
				this.cmdThreeParamsWithDataAnswer(
					param,
					cmd,
					nextCmd,
					0,
					0,
					AnswerLength.eOne,
				);
			return { errorCode, byteToSend, byteToReceive };
		} catch (error) {
			return {
				errorCode: ErrorCode.eERR_UNKNOWN,
				byteToSend: 0,
				byteToReceive: 0,
			};
		}
	}

	/**
	 * Prepares a command message with three parameters and expects data in the answer
	 * @param param Object containing the message buffer
	 * @param cmd The command to execute
	 * @param answerLength Expected length of the answer
	 * @returns Object with error code and bytes to send/receive
	 */
	private static cmdThreeParamsWithDataAnswer(
		param: { msg: Uint8Array },
		cmdId: GclCmd | FfIGclCmd,
		param1: number,
		param2: number,
		param3: number,
		byteToReceiveInternal: AnswerLength,
	): { errorCode: ErrorCode; byteToSend: number; byteToReceive: number } {
		if (!param.msg || param.msg.length < 4) {
			return {
				errorCode: ErrorCode.eERR_UNKNOWN,
				byteToSend: 0,
				byteToReceive: 0,
			};
		}

		try {
			let eRet = ErrorCode.eERR_UNKNOWN;
			let byteToSend = 0;
			let byteToReceive = 0;
			if (param.msg.length < HEADER_SIZE) {
				eRet = ErrorCode.eERR_INVALID_BUFFER_SIZE;
			} else {
				CommandDefault.zeroArray(param);
				byteToSend = HEADER_SIZE;
				byteToReceive = byteToReceiveInternal;

				eRet = CommandDefault.SetCommandID(param, cmdId);

				if (ErrorCode.eOK === eRet) {
					eRet = MessageHeaderHandler.setMsgHeaderPar1(param, param1);
				}

				if (ErrorCode.eOK === eRet) {
					eRet = MessageHeaderHandler.setMsgHeaderPar2(param, param2);
				}

				if (ErrorCode.eOK === eRet) {
					eRet = MessageHeaderHandler.setMsgHeaderPar3(param, param3);
				}

				if (ErrorCode.eOK === eRet) {
					MessageHeaderHandler.setMsgHeaderChecksum(param);
				}
			}
			return { errorCode: eRet, byteToSend, byteToReceive };
		} catch (error) {
			return {
				errorCode: ErrorCode.eERR_UNKNOWN,
				byteToSend: 0,
				byteToReceive: 0,
			};
		}
	}

	//#region Sub Command
	public static subCmdReadNoParamAnsOneByte(
		param: { msg: Uint8Array },
		cmd: GclSubCmdT,
	): { errorCode: ErrorCode; byteToSend: number; byteToReceive: number } {
		if (!param.msg || param.msg.length < 1) {
			return {
				errorCode: ErrorCode.eERR_UNKNOWN,
				byteToSend: 0,
				byteToReceive: 0,
			};
		}

		try {
			const { errorCode, byteToSend, byteToReceive } = this.cmdOneParamAnsData(
				param,
				GclCmd.SW_CMD_GET_BYTE_PARAMETER,
				cmd,
				AnswerLength.eThree,
			);
			return { errorCode, byteToSend, byteToReceive };
		} catch (error) {
			return {
				errorCode: ErrorCode.eERR_UNKNOWN,
				byteToSend: 0,
				byteToReceive: 0,
			};
		}
	}

	public static subCmdReadOneParamAnsData(
		param: { msg: Uint8Array },
		cmd: GclSubCmdT,
		param1: number,
	): { errorCode: ErrorCode; byteToSend: number; byteToReceive: number } {
		if (!param.msg || param.msg.length < 1) {
			return {
				errorCode: ErrorCode.eERR_UNKNOWN,
				byteToSend: 0,
				byteToReceive: 0,
			};
		}

		try {
			const { errorCode, byteToSend, byteToReceive } = this.cmdTwoParamsAnsData(
				param,
				GclCmd.SW_CMD_GET_BYTE_PARAMETER,
				cmd,
				param1,
				AnswerLength.eThree,
			);
			return { errorCode, byteToSend, byteToReceive };
		} catch (error) {
			return {
				errorCode: ErrorCode.eERR_UNKNOWN,
				byteToSend: 0,
				byteToReceive: 0,
			};
		}
	}

	public static subCmdWriteOneParamAnsAckOnly(
		param: { msg: Uint8Array },
		cmd: GclSubCmdT,
		param1: number,
	): { errorCode: ErrorCode; byteToSend: number; byteToReceive: number } {
		if (!param.msg || param.msg.length < 1) {
			return {
				errorCode: ErrorCode.eERR_UNKNOWN,
				byteToSend: 0,
				byteToReceive: 0,
			};
		}

		try {
			const { errorCode, byteToSend, byteToReceive } = this.cmdTwoParamsAnsData(
				param,
				GclCmd.SW_CMD_SET_BYTE_PARAMETER,
				cmd,
				param1,
				AnswerLength.eOne,
			);
			return { errorCode, byteToSend, byteToReceive };
		} catch (error) {
			return {
				errorCode: ErrorCode.eERR_UNKNOWN,
				byteToSend: 0,
				byteToReceive: 0,
			};
		}
	}

	public static subCmdWriteTwoParamAnsAckOnly(
		param: { msg: Uint8Array },
		cmd: GclSubCmdT,
		param1: number,
		param2: number,
	): { errorCode: ErrorCode; byteToSend: number; byteToReceive: number } {
		if (!param.msg || param.msg.length < 1) {
			return {
				errorCode: ErrorCode.eERR_UNKNOWN,
				byteToSend: 0,
				byteToReceive: 0,
			};
		}

		try {
			const { errorCode, byteToSend, byteToReceive } =
				this.cmdThreeParamsWithDataAnswer(
					param,
					GclCmd.SW_CMD_SET_BYTE_PARAMETER,
					cmd,
					param1,
					param2,
					AnswerLength.eOne,
				);
			return { errorCode, byteToSend, byteToReceive };
		} catch (error) {
			return {
				errorCode: ErrorCode.eERR_UNKNOWN,
				byteToSend: 0,
				byteToReceive: 0,
			};
		}
	}

	public static cmdOneParamAnsData(
		param: { msg: Uint8Array },
		cmdId: GclCmd,
		param1: number,
		byteToReceiveInternal: AnswerLength,
	): {
		errorCode: ErrorCode;
		byteToSend: number;
		byteToReceive: number;
	} {
		if (!param.msg || param.msg.length < 1) {
			return {
				errorCode: ErrorCode.eERR_UNKNOWN,
				byteToSend: 0,
				byteToReceive: 0,
			};
		}
		try {
			const { errorCode, byteToSend, byteToReceive } =
				this.cmdThreeParamsWithDataAnswer(
					param,
					cmdId,
					param1,
					0,
					0,
					byteToReceiveInternal,
				);
			return { errorCode, byteToSend, byteToReceive };
		} catch (error) {
			return {
				errorCode: ErrorCode.eERR_UNKNOWN,
				byteToSend: 0,
				byteToReceive: 0,
			};
		}
	}

	public static cmdTwoParamsAnsData(
		param: { msg: Uint8Array },
		cmdId: GclCmd,
		subCmdID: GclSubCmdT,
		param1: number,
		byteToReceiveInternal: AnswerLength,
	): {
		errorCode: ErrorCode;
		byteToSend: number;
		byteToReceive: number;
	} {
		if (!param.msg || param.msg.length < 1) {
			return {
				errorCode: ErrorCode.eERR_UNKNOWN,
				byteToSend: 0,
				byteToReceive: 0,
			};
		}
		try {
			const { errorCode, byteToSend, byteToReceive } =
				this.cmdThreeParamsWithDataAnswer(
					param,
					cmdId,
					subCmdID,
					param1,
					0,
					byteToReceiveInternal,
				);
			return { errorCode, byteToSend, byteToReceive };
		} catch (error) {
			return {
				errorCode: ErrorCode.eERR_UNKNOWN,
				byteToSend: 0,
				byteToReceive: 0,
			};
		}
	}
	//#endregion
}
