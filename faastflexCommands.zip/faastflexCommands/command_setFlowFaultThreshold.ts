import {
	AnswerLength,
	ErrorCode,
	DeviceStatus,
	GclCmd,
	Configuration,
	Country,
	RelayEnabled,
	Channel,
	AlarmFaultStatus,
	AnswerByteParamIndex,
	DeviceType,
	PasswordValid,
	GclSubCmdT,
	AlarmLevel,
} from '../faastflexCommands/commandEnum';
import {
	HEADER_SIZE,
	SW_COMM_CHECKSUM_BASE,
	MessageHeaderHandler,
	CommandDefault,
	ResponseParser,
} from '../faastflexCommands/command';
import { commonCommand } from '../faastflexCommands/CommonCommand';
import { min } from 'date-fns';

export class FaastFlexSetFlowFaultThreshold {
	public static SetFlowFaultThresholdEEPROM(
		param: { msg: Uint8Array },
		_channel: Channel,
		updateParam: number,
	): {
		errorCode: ErrorCode;
		byteToSend: number;
		byteToReceive: number;
	} {
		const { errorCode, byteToSend, byteToReceive } =
			commonCommand.subCmdWriteTwoParamAnsAckOnly(
				param,
				GclSubCmdT.SW_CMD_FLOW_FAULT_THRESHOLD,
				_channel,
				updateParam,
			);
		return { errorCode, byteToSend, byteToReceive };
	}
	public static SetFlowFaultThresholdEEPROMAnswer(
		param: { msg: Uint8Array },
		byteToBeReceived: number,
		byteReceived: number,
	): { retErrorCode: ErrorCode } {
		let retErrorCode: ErrorCode = ErrorCode.eERR_UNKNOWN;
		retErrorCode = ResponseParser.checkAnswerMsgValidity(
			param.msg,
			byteToBeReceived,
			byteReceived,
		);
		return { retErrorCode };
	}

	public static SetFFIntelligentFlowFaultThresholdEEPROM(
		param: { msg: Uint8Array },
		updateParam: number,
	): {
		errorCode: ErrorCode;
		byteToSend: number;
		byteToReceive: number;
	} {
		const { errorCode, byteToSend, byteToReceive } =
			commonCommand.subCmdWriteOneParamAnsAckOnly(
				param,
				GclSubCmdT.FFI_SW_CMD_FLOW_FAULT_THRESHOLD,
				updateParam,
			);
		return { errorCode, byteToSend, byteToReceive };
	}
	public static SetFFIntelligentFlowFaultThresholdEEPROMAnswer(
		param: { msg: Uint8Array },
		byteToBeReceived: number,
		byteReceived: number,
	): { retErrorCode: ErrorCode } {
		let retErrorCode: ErrorCode = ErrorCode.eERR_UNKNOWN;
		retErrorCode = ResponseParser.checkAnswerMsgValidity(
			param.msg,
			byteToBeReceived,
			byteReceived,
		);
		return { retErrorCode };
	}
}
