import {
	AnswerLength,
	ErrorCode,
	DeviceStatus,
	GclCmd,
	Configuration,
	Country,
	RelayEnabled,
	Channel,
	AlarmFaultStatus,
	AnswerByteParamIndex,
} from '../faastflexCommands/commandEnum';
import {
	HEADER_SIZE,
	SW_COMM_CHECKSUM_BASE,
	MessageHeaderHandler,
	CommandDefault,
	ResponseParser,
} from '../faastflexCommands/command';
import { commonCommand } from '../faastflexCommands/CommonCommand';

export class FaastFlexDeviceMode {
	public static getDeviceStatus(param: { msg: Uint8Array }): {
		errorCode: ErrorCode;
		byteToSend: number;
		byteToReceive: number;
	} {
		const { errorCode, byteToSend, byteToReceive } =
			commonCommand.cmdNoParamAnsData(
				param,
				GclCmd.SW_CMD_GET_STATUS,
				AnswerLength.eThree,
			);

		return { errorCode, byteToSend, byteToReceive };
	}
	public static getDeviceStatusAnswer(
		param: { msg: Uint8Array },
		byteToBeReceived: number,
		byteReceived: number,
	): { retErrorCode: ErrorCode; retDeviceStatus: DeviceStatus } {
		return this.parseAuthenticatedAnswer(
			param.msg,
			byteToBeReceived,
			byteReceived,
			DeviceStatus.MAIN_FSM_STATE_COUNT,
			DeviceStatus,
		);
	}

	private static parseAuthenticatedAnswer<RES_ENum extends number>(
		msg: Uint8Array,
		byteToBeReceived: number,
		byteReceived: number,
		defaultStatus: RES_ENum,
		enumType: any,
	): { retErrorCode: ErrorCode; retDeviceStatus: RES_ENum } {
		let status: RES_ENum = defaultStatus;
		let eRet: ErrorCode = ErrorCode.eOK;
		if (3 !== byteToBeReceived) {
			eRet = ErrorCode.eERR_ANS_INVALID_SIZE;
		}
		if (ErrorCode.eOK === eRet) {
			eRet = ResponseParser.checkAnswerMsgValidity(
				msg,
				byteToBeReceived,
				byteReceived,
			);
		}
		if (ErrorCode.eOK === eRet) {
			const { result, errorCode } = ResponseParser.getMsgAnswerParToEnum(
				msg,
				AnswerByteParamIndex.eParam_One,
				defaultStatus,
				enumType,
			);
			status = result;
			eRet = errorCode;
		}
		return { retErrorCode: eRet, retDeviceStatus: status };
	}
}
