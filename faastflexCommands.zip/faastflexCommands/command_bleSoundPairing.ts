import {
	AnswerLength,
	DeviceAuthenticated,
	ErrorCode,
	GCL_RESULT,
	GclCmd,
	HeaderPosition,
} from '../faastflexCommands/commandEnum';
import {
	HEADER_SIZE,
	SW_COMM_CHECKSUM_BASE,
	MessageHeaderHandler,
	CommandDefault,
	ResponseParser,
} from '../faastflexCommands/command';
import { commonCommand } from '../faastflexCommands/CommonCommand';

export class FaastFlexSoundPairing {
	public static startSoundPairing(
		param: { msg: Uint8Array },
		digit_1: number,
		digit_2: number,
		digit_3: number,
		digit_4: number,
		digit_5: number,
		digit_6: number,
		digit_7: number,
		digit_8: number,
		digit_9: number,
		digit_10: number,
		digit_11: number,
		digit_12: number,
	): { errorCode: ErrorCode; byteToSend: number; byteToReceive: number } {
		const { errorCode, byteToSend, byteToReceive } =
			commonCommand.CmdTwelveParamsAnsAny(
				param,
				GclCmd.SW_CMD_START_SOUND_PAIRING,
				digit_1,
				digit_2,
				digit_3,
				digit_4,
				digit_5,
				digit_6,
				digit_7,
				digit_8,
				digit_9,
				digit_10,
				digit_11,
				digit_12,
				AnswerLength.eOne,
			);

		return { errorCode, byteToSend, byteToReceive };
	}

	public static starSoundPairingAnswer(
		param: { msg: Uint8Array },
		byteToBeReceived: number,
		byteReceived: number,
	): ErrorCode {
		let retErrorCode: ErrorCode = ErrorCode.eERR_UNKNOWN;
		retErrorCode = ResponseParser.checkAnswerMsgValidity(
			param.msg,
			byteToBeReceived,
			byteReceived,
		);
		return retErrorCode;
	}

	//#region StartDecodedPwdDigits
	public static SoundPairingPassword(
		param: { msg: Uint8Array },
		digit_1: number,
		digit_2: number,
		digit_3: number,
		digit_4: number,
		digit_5: number,
		digit_6: number,
	): { errorCode: ErrorCode; byteToSend: number; byteToReceive: number } {
		const { errorCode, byteToSend, byteToReceive } =
			commonCommand.cmdNoParamAnsAckOnly(
				param,
				GclCmd.SW_CMD_SEND_DECODED_PWD_DIGITS,
			);
		if (errorCode === ErrorCode.eOK) {
			MessageHeaderHandler.setMsgHeaderPar1(param, digit_1);
			MessageHeaderHandler.setMsgHeaderPar2(param, digit_2);
			MessageHeaderHandler.setMsgHeaderPar3(param, digit_3);
			MessageHeaderHandler.setMsgHeaderPar4(param, digit_4);
			MessageHeaderHandler.setMsgHeaderPar5(param, digit_5);
			MessageHeaderHandler.setMsgHeaderPar6(param, digit_6);
			MessageHeaderHandler.setMsgHeaderChecksum(param);
		}

		return { errorCode, byteToSend, byteToReceive };
	}
	public static SendDecodedPwdDigitsAnswer(
		param: { msg: Uint8Array },
		byteToBeReceived: number,
		byteReceived: number,
	): { retErrorCode: ErrorCode } {
		let retErrorCode: ErrorCode = ErrorCode.eERR_UNKNOWN;
		retErrorCode = ResponseParser.checkAnswerMsgValidity(
			param.msg,
			byteToBeReceived,
			byteReceived,
		);
		return { retErrorCode };
	}
	//#endregion
}
