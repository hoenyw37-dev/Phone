import {
	AnswerLength,
	ErrorCode,
	GclCmd,
	RelayAlert,
	FanSpeedLevel,
	FanPWMPercCorrection,
	LatchedMode,
	AlarmMode,
	PreAlarmLevel,
	AlarmLevel,
	FfIGclCmd,
} from '../faastflexCommands/commandEnum';
import { ResponseParser } from '../faastflexCommands/command';
import { commonCommand } from '../faastflexCommands/CommonCommand';
import { DeviceGeneralParams } from '../faastflexCommands/common_objects';
import { DeviceOrientation } from '../faastflexCommands/commandEnum';

interface GeneralParametersResult {
	errorCode: ErrorCode;
	deviceParams: DeviceGeneralParams;
}
export class FaastFlexIntelligentChannelsAndSensorsParameters {
	public static GetFFIntelligentChannelsAndSensorParams(param: {
		msg: Uint8Array;
	}): { errorCode: ErrorCode; byteToSend: number; byteToReceive: number } {
		const { errorCode, byteToSend, byteToReceive } =
			commonCommand.cmdNoParamAnsData(
				param,
				FfIGclCmd.FFI_SW_CMD_GET_FLOW_ANOMALY_CONFIG,
				AnswerLength.eEleven,
			);

		return { errorCode, byteToSend, byteToReceive };
	}

	public static GetFFIntelligentChannelsAndSensorParamsAnswer(
		param: { msg: Uint8Array },
		byteToBeReceived: number,
		byteReceived: number,
	): {
		errorCode: ErrorCode;
		flowFaultDelay: number;
		ch1LatchAlarmRelay: LatchedMode;
		ch2LatchAlarmRelay: LatchedMode;
		generalFaultRelay: LatchedMode;
		auxFaultRelay: LatchedMode;
		alarmMode: AlarmMode;
		flowthreshold: number;
		ch1RefAirflow: number;
		ch2RefAirflow: number;
	} {
		let retErrorCode: ErrorCode = ErrorCode.eERR_UNKNOWN;
		let resultParams = {
			errorCode: ErrorCode.eERR_UNKNOWN,
			flowFaultDelay: 0,
			ch1LatchAlarmRelay: LatchedMode.eUnknown,
			ch2LatchAlarmRelay: LatchedMode.eUnknown,
			generalFaultRelay: LatchedMode.eUnknown,
			auxFaultRelay: LatchedMode.eUnknown,
			alarmMode: AlarmMode.eUnknown,
			flowthreshold: 0,
			ch1RefAirflow: 0,
			ch2RefAirflow: 0,
		};
		retErrorCode = ResponseParser.checkAnswerMsgValidity(
			param.msg,
			byteToBeReceived,
			byteReceived,
		);
		const msg = param.msg;
		if (retErrorCode === ErrorCode.eOK) {
			resultParams.flowFaultDelay = msg[1];
			resultParams.flowthreshold = msg[7];
			resultParams.ch1RefAirflow = msg[8];
			resultParams.ch2RefAirflow = msg[9];
		}
		if (retErrorCode === ErrorCode.eOK) {
			const alarm_latched = msg[2];
			const { result, errorCode } = ResponseParser.byteToEnum<LatchedMode>(
				alarm_latched,
				LatchedMode,
				LatchedMode.eUnknown,
			);
			resultParams.ch1LatchAlarmRelay = result;
			retErrorCode = errorCode;
		}
		if (retErrorCode === ErrorCode.eOK) {
			const pre_alarm_latched = msg[3];
			const { result, errorCode } = ResponseParser.byteToEnum<LatchedMode>(
				pre_alarm_latched,
				LatchedMode,
				LatchedMode.eUnknown,
			);
			resultParams.ch2LatchAlarmRelay = result;
			retErrorCode = errorCode;
		}
		if (retErrorCode === ErrorCode.eOK) {
			const fault_latched = msg[4];
			const { result, errorCode } = ResponseParser.byteToEnum<LatchedMode>(
				fault_latched,
				LatchedMode,
				LatchedMode.eUnknown,
			);
			resultParams.generalFaultRelay = result;
			retErrorCode = errorCode;
		}
		if (retErrorCode === ErrorCode.eOK) {
			const fault_latched = msg[5];
			const { result, errorCode } = ResponseParser.byteToEnum<LatchedMode>(
				fault_latched,
				LatchedMode,
				LatchedMode.eUnknown,
			);
			resultParams.auxFaultRelay = result;
			retErrorCode = errorCode;
		}
		if (retErrorCode === ErrorCode.eOK) {
			const alarm_mode = msg[6];
			const { result, errorCode } = ResponseParser.byteToEnum<AlarmMode>(
				alarm_mode,
				AlarmMode,
				AlarmMode.eUnknown,
			);
			resultParams.alarmMode = result;
			retErrorCode = errorCode;
		}
		resultParams.errorCode = retErrorCode;
		return resultParams;
	}
}
