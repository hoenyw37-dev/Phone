import {
	AnswerLength,
	ErrorCode,
	DeviceStatus,
	GclCmd,
	Configuration,
	Country,
	RelayEnabled,
	Channel,
	AlarmFaultStatus,
	AnswerByteParamIndex,
	DeviceType,
	PasswordValid,
} from '../faastflexCommands/commandEnum';
import {
	HEADER_SIZE,
	SW_COMM_CHECKSUM_BASE,
	MessageHeaderHandler,
	CommandDefault,
	ResponseParser,
} from '../faastflexCommands/command';
import { commonCommand } from '../faastflexCommands/CommonCommand';
import { min } from 'date-fns';

export class FaastFlexSetDatetimeofDevice {
	public static SetRealTimeClock(
		param: { msg: Uint8Array },
		year: number,
		month: number,
		day: number,
		hour: number,
		minute: number,
		second: number,
	): {
		errorCode: ErrorCode;
		byteToSend: number;
		byteToReceive: number;
	} {
		const { errorCode, byteToSend, byteToReceive } =
			commonCommand.cmdNoParamAnsAckOnly(param, GclCmd.SW_CMD_RTC_WRITE);
		if (errorCode === ErrorCode.eOK) {
			MessageHeaderHandler.setMsgHeaderPar1(param, day);
			MessageHeaderHandler.setMsgHeaderPar2(param, month);
			MessageHeaderHandler.setMsgHeaderPar3(param, year);
			MessageHeaderHandler.setMsgHeaderPar4(param, hour);
			MessageHeaderHandler.setMsgHeaderPar5(param, minute);
			MessageHeaderHandler.setMsgHeaderPar6(param, second);
			MessageHeaderHandler.setMsgHeaderChecksum(param);
		}
		return { errorCode, byteToSend, byteToReceive };
	}
	public static SetRealTimeClockAnswer(
		param: { msg: Uint8Array },
		byteToBeReceived: number,
		byteReceived: number,
	): { retErrorCode: ErrorCode } {
		let retErrorCode: ErrorCode = ErrorCode.eERR_UNKNOWN;
		retErrorCode = ResponseParser.checkAnswerMsgValidity(
			param.msg,
			byteToBeReceived,
			byteReceived,
		);
		return { retErrorCode };
	}
}
