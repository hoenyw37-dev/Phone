import {
	AnswerLength,
	ErrorCode,
	DeviceStatus,
	GclCmd,
	Configuration,
	Country,
	RelayEnabled,
	Channel,
	AlarmFaultStatus,
	AnswerByteParamIndex,
	DeviceType,
	GclSubCmdT,
	FanSpeedLevel,
	FanPWMPercCorrection,
} from '../faastflexCommands/commandEnum';
import {
	HEADER_SIZE,
	SW_COMM_CHECKSUM_BASE,
	MessageHeaderHandler,
	CommandDefault,
	ResponseParser,
} from '../faastflexCommands/command';
import { commonCommand } from '../faastflexCommands/CommonCommand';

export class FaastFlexGetBlowerSpeedCorrection {
	public static GetFanCorrectionEEPROM(param: { msg: Uint8Array }): {
		errorCode: ErrorCode;
		byteToSend: number;
		byteToReceive: number;
	} {
		const { errorCode, byteToSend, byteToReceive } =
			commonCommand.cmdNoParamAnsData(
				param,
				GclCmd.SW_CMD_GET_BYTE_PARAMETER,
				AnswerLength.eFour,
			);
		if (errorCode === ErrorCode.eOK) {
			MessageHeaderHandler.setMsgHeaderPar1CheckSum(
				param,
				GclSubCmdT.SW_CMD_FAN_CORRECTION,
			);
		}
		return { errorCode, byteToSend, byteToReceive };
	}

	public static GetFanCorrectionEEPROMAnswer(
		param: { msg: Uint8Array },
		byteToBeReceived: number,
		byteReceived: number,
	): { retErrorCode: ErrorCode; fanCorrection: FanPWMPercCorrection } {
		let errorCode: ErrorCode = ErrorCode.eERR_UNKNOWN;
		let retFanCorrection: FanPWMPercCorrection = FanPWMPercCorrection.eUnknown;
		errorCode = ResponseParser.checkAnswerMsgValidity(
			param.msg,
			byteToBeReceived,
			byteReceived,
		);
		if (errorCode === ErrorCode.eOK) {
			const correctionValue = param.msg[1];
			const correctionSign = param.msg[2];
			if (0 === correctionSign) {
				if (0 === correctionValue) {
					retFanCorrection = FanPWMPercCorrection.eZero;
				} else if (1 === correctionValue) {
					retFanCorrection = FanPWMPercCorrection.ePlusOne;
				} else if (2 === correctionValue) {
					retFanCorrection = FanPWMPercCorrection.ePlusTwo;
				} else if (3 === correctionValue) {
					retFanCorrection = FanPWMPercCorrection.ePlusThree;
				} else if (4 === correctionValue) {
					retFanCorrection = FanPWMPercCorrection.ePlusFour;
				} else if (5 === correctionValue) {
					retFanCorrection = FanPWMPercCorrection.ePlusFive;
				} else if (6 === correctionValue) {
					retFanCorrection = FanPWMPercCorrection.ePlusSix;
				} else {
					errorCode = ErrorCode.eERR_ANS_INVALID_RANGE;
				}
			} else if (1 === correctionSign) {
				if (1 === correctionValue) {
					retFanCorrection = FanPWMPercCorrection.eMinusOne;
				} else if (2 === correctionValue) {
					retFanCorrection = FanPWMPercCorrection.eMinusTwo;
				} else if (3 === correctionValue) {
					retFanCorrection = FanPWMPercCorrection.eMinusThree;
				} else if (4 === correctionValue) {
					retFanCorrection = FanPWMPercCorrection.eMinusFour;
				} else if (5 === correctionValue) {
					retFanCorrection = FanPWMPercCorrection.eMinusFive;
				} else if (6 === correctionValue) {
					retFanCorrection = FanPWMPercCorrection.eMinusSix;
				} else {
					errorCode = ErrorCode.eERR_ANS_INVALID_RANGE;
				}
			} else {
				errorCode = ErrorCode.eERR_ANS_INVALID_RANGE;
			}
		}
		return { retErrorCode: errorCode, fanCorrection: retFanCorrection };
	}
}
