import {
	AnswerLength,
	ErrorCode,
	DeviceStatus,
	GclCmd,
	Configuration,
	Country,
	RelayEnabled,
	Channel,
	AlarmFaultStatus,
	AnswerByteParamIndex,
	DeviceType,
} from '../faastflexCommands/commandEnum';
import {
	HEADER_SIZE,
	SW_COMM_CHECKSUM_BASE,
	MessageHeaderHandler,
	CommandDefault,
	ResponseParser,
} from '../faastflexCommands/command';
import { commonCommand } from '../faastflexCommands/CommonCommand';

export class FaastFlexGetPowerVoltage {
	public static GetPowerVoltageEEPROM(param: { msg: Uint8Array }): {
		errorCode: ErrorCode;
		byteToSend: number;
		byteToReceive: number;
	} {
		const { errorCode, byteToSend, byteToReceive } =
			commonCommand.cmdNoParamAnsData(
				param,
				GclCmd.eSW_CMD_GET_SUPPLY_VOLTAGE,
				AnswerLength.eFour,
			);

		return { errorCode, byteToSend, byteToReceive };
	}
	public static GetPowerVoltageAnswer(
		param: { msg: Uint8Array },
		byteToBeReceived: number,
		byteReceived: number,
	): {
		errorCode: ErrorCode;
		powerLSB: number;
		powerMSB: number;
	} {
		let retErrorCode: ErrorCode = ErrorCode.eERR_UNKNOWN;
		let msg = param.msg;
		let powerLSB = 0;
		let powerMSB = 0;
		retErrorCode = ResponseParser.checkAnswerMsgValidity(
			param.msg,
			byteToBeReceived,
			byteReceived,
		);
		if (ErrorCode.eOK === retErrorCode) {
			powerLSB = msg[1];
			powerMSB = msg[2];
		}
		return { errorCode: retErrorCode, powerLSB, powerMSB };
	}
}
