import {
	AnswerLength,
	ErrorCode,
	GclCmd,
} from '../faastflexCommands/commandEnum';
import {
	MessageHeaderHandler,
	ResponseParser,
} from '../faastflexCommands/command';
import { commonCommand } from '../faastflexCommands/CommonCommand';

export interface IEventLogData {
	logId?: number;
	eventDateTime?: Date;
	eventName?: LogEventId;
	eventDescription?: string;
	addtionalInfo?: string;
	eventDate?: string;
	eventTime?: string;
	eventType?: LogEventType;
	eventTypeStr?: string;
	logChannels?: LogEventZone;
	eventBarColor?: string;
	statusIcon?: string;
	eventIdInfo?: string;
	showErrorMessage?: boolean;
	ch1Temperature?: number;
	ch2Temperature?: number;
	ch1Flow?: number;
	ch2Flow?: number;
	ch1Sensor?: number;
	ch2Sensor?: number;
	blowerRPM?: number;
}

export class FaastFlexLogs {
	public static GetLogEntry(
		param: { msg: Uint8Array },
		logIndexLSB: number,
		logIndexMSB: number,
	): {
		errorCode: ErrorCode;
		byteToSend: number;
		byteToReceive: number;
	} {
		const { errorCode, byteToSend, byteToReceive } =
			commonCommand.cmdNoParamAnsData(
				param,
				GclCmd.SW_CMD_GET_LOG_ENTRY,
				AnswerLength.eTwentyOne,
			);
		if (errorCode === ErrorCode.eOK) {
			const errorSetHeaderpara1 = MessageHeaderHandler.setMsgHeaderPar1(
				param,
				logIndexLSB,
			);
			const errorSetHeaderpara2 = MessageHeaderHandler.setMsgHeaderPar2(
				param,
				logIndexMSB,
			);
			MessageHeaderHandler.setMsgHeaderChecksum(param);
		}
		return { errorCode, byteToSend, byteToReceive };
	}

	public static GetLogEntryAnswer(
		param: { msg: Uint8Array },
		byteToBeReceived: number,
		byteReceived: number,
	): {
		retErrorCode: ErrorCode;
		logEntryId: number;
		day: number;
		month: number;
		year: number;
		hour: number;
		minute: number;
		second: number;
		logEventId: LogEventId;
		temperatureChannel1: number;
		temperatureChannel2: number;
		flowChannel1: number;
		flowChannel2: number;
		sensorChannel1: number;
		sensorChannel2: number;
		blowerRPM: number;
		eventType: LogEventType;
		eventZone: LogEventZone;
	} {
		const eventLogData = {
			retErrorCode: ErrorCode.eERR_UNKNOWN,
			logEntryId: 0,
			day: 0,
			month: 0,
			year: 0,
			hour: 0,
			minute: 0,
			second: 0,
			logEventId: LogEventId.LOG_EVENT_NONE,
			temperatureChannel1: 0,
			temperatureChannel2: 0,
			flowChannel1: 0,
			flowChannel2: 0,
			sensorChannel1: 0,
			sensorChannel2: 0,
			blowerRPM: 0,
			eventType: LogEventType.eUnknown,
			eventZone: LogEventZone.eUnknown,
		};
		eventLogData.retErrorCode = ResponseParser.checkAnswerMsgValidity(
			param.msg,
			byteToBeReceived,
			byteReceived,
		);
		if (eventLogData.retErrorCode === ErrorCode.eOK) {
			eventLogData.logEntryId = param.msg[1] + param.msg[2] * 256;
			eventLogData.day = param.msg[3];
			eventLogData.month = param.msg[4];
			eventLogData.year = param.msg[5];
			eventLogData.hour = param.msg[6];
			eventLogData.minute = param.msg[7];
			eventLogData.second = param.msg[8];
			eventLogData.logEventId = param.msg[9] + 256 * param.msg[10];
			eventLogData.eventType = getEventTypeFromEventId(eventLogData.logEventId);
			eventLogData.eventZone = getEventZoneFromEventId(eventLogData.logEventId);
			if (eventLogData.logEventId !== LogEventId.LOG_EVENT_NONE) {
				eventLogData.temperatureChannel1 = param.msg[11];
				if (param.msg[12] === 1) {
					eventLogData.temperatureChannel1 = -eventLogData.temperatureChannel1;
				}
				eventLogData.flowChannel1 = param.msg[13];
				eventLogData.sensorChannel1 = param.msg[14];
				eventLogData.temperatureChannel2 = param.msg[15];
				if (param.msg[16] === 1) {
					eventLogData.temperatureChannel2 = -eventLogData.temperatureChannel2;
				}
				eventLogData.flowChannel2 = param.msg[17];
				eventLogData.sensorChannel2 = param.msg[18];

				eventLogData.blowerRPM = param.msg[19] * 100;
			}
		}
		return eventLogData;
	}
}

export enum LogEventId {
	LOG_EVENT_NONE = 0,
	LOG_EVENT_POWER_ON = 1,
	LOG_EVENT_COVER_OPENED = 2,
	LOG_EVENT_COVER_CLOSED = 3,
	LOG_EVENT_PASSWORD_ENTRY = 4,
	LOG_EVENT_PASSWORD_MODIFIED = 5,
	LOG_EVENT_PASSWORD_CORRECT = 6,
	LOG_EVENT_PASSWORD_INCORRECT = 7,
	LOG_EVENT_DISABLE_START = 8,
	LOG_EVENT_DISABLE_OVER = 9,
	LOG_EVENT_EUROPE_TEST_START = 10,
	LOG_EVENT_EUROPE_TEST_COMPLETE = 11,
	LOG_EVENT_EUROPE_TEST_LOG_WRITTEN = 12,
	LOG_EVENT_CHINA_TEST_START = 13,
	LOG_EVENT_CHINA_TEST_COMPLETE = 14,
	LOG_EVENT_GPI_RESET_DEVICE = 15,
	LOG_EVENT_GPI_START_DISABLE = 16,
	LOG_EVENT_GPI_STOP_DISABLE = 17,
	LOG_EVENT_NORMALIZE_START = 18,
	LOG_EVENT_NORMALOVER = 19,
	LOG_EVENT_NORMALIZE_FAILED_FOR_INSTABLE_FLOW = 20,
	LOG_EVENT_NORMALIZE_FAILED_FOR_OUT_OF_RANGE_FLOW = 21,
	LOG_EVENT_RESET_ALARM_FAULT_STARTED = 22,
	LOG_EVENT_CONFIGURATION_START = 23,
	LOG_EVENT_LOGSTARTED = 24,
	LOG_EVENT_LOGOVER = 25,
	LOG_EVENT_DISABLE_BUZZER_CHINA = 26,
	LOG_EVENT_DISABLE_BUZZER_EUROPE = 27,
	LOG_EVENT_WAITING_FOR_COVER = 28,
	LOG_EVENT_TO_PROTECTION = 29,
	LOG_EVENT_TO_NORMAL = 30,
	LOG_EVENT_TO_WAIT = 31,
	LOG_EVENT_TO_SERVICE = 32,
	LOG_EVENT_PAIRING_TENTATIVE = 33,
	LOG_EVENT_PAIRING_DONE = 34,
	LOG_EVENT_E2P_FACTORY_RESTORE_SUCCESS = 35,
	LOG_EVENT_E2P_FACTORY_RESTORE_FAILED = 36,
	LOG_EVENT_PASSWORD_RECOVERY = 37,
	LOG_EVENT_PID_STARTED = 38,
	LOG_EVENT_PID_OVER = 39,
	LOG_EVENT_CONFIGURATION_OVER = 40,
	LOG_EVENT_CONFIGURATION_OVER_FOR_TIMEOUT = 41,
	LOG_EVENT_PASSWORD_INCORRECT_FOR_TIMEOUT = 42,
	LOG_EVENT_PASSWORD_MODIFY_EXIT_FOR_TIMEOUT = 43,
	LOG_EVENT_HOUR_CHANGED = 44,
	LOG_EVENT_DISABLE_EXIT_FOR_TIMEOUT = 45,
	LOG_EVENT_START_PASSWORD_CHANGE = 46,
	LOG_EVENT_EUROPE_TEST_ABORT_BY_APP = 47,
	LOG_TREND_LOG_EVENT = 48,
	LOG_CLEAR_LOG_EVENT = 49,
	LOG_TEST_FAILED_EVENT = 50,
	LOG_PASSWORD_BTAPP_INCORRECT_EVENT = 51,
	LOG_PID_OVER_AT_POWER_ON = 52,
	LOG_PID_STARTED_AT_POWER_ON = 53,
	LOG_FAN_REPLACEMENT_START = 54,
	LOG_FAN_REPLACEMENT_ABORT = 55,
	LOG_FAN_OLD_VAL_MINUS_6 = 56,
	LOG_FAN_OLD_VAL_MINUS_5 = 57,
	LOG_FAN_OLD_VAL_MINUS_4 = 58,
	LOG_FAN_OLD_VAL_MINUS_3 = 59,
	LOG_FAN_OLD_VAL_MINUS_2 = 60,
	LOG_FAN_OLD_VAL_MINUS_1 = 61,
	LOG_FAN_OLD_VAL_0 = 62,
	LOG_FAN_OLD_VAL_1 = 63,
	LOG_FAN_OLD_VAL_2 = 64,
	LOG_FAN_OLD_VAL_3 = 65,
	LOG_FAN_OLD_VAL_4 = 66,
	LOG_FAN_OLD_VAL_5 = 67,
	LOG_FAN_OLD_VAL_6 = 68,
	LOG_FAN_REPLACE_TIMEOUT = 69,
	LOG_CONFIGURATION_ABORT_BY_BUTTON = 71,
	LOG_CONFIGURATION_ABORT_BY_COVER = 72,
	LOG_STARTED_BT_HAND_PAIRING = 73,
	LOG_STARTED_BT_SOUND_PAIRING = 74,
	LOG_BLE_CONNECTED = 75,
	LOG_BLE_DISCONNECTED = 76,
	LOG_TOKEN_BY_BT_INCORRECT = 77,
	LOG_TOKEN_BY_BT_CORRECT = 78,
	LOG_PARAMETER_OUT_OF_RANGE = 79,
	LOG_NORMALIZE_ABORT_BY_COVER = 80,
	LOG_NORMALIZE_ABORT_NVM_FAULT = 82,
	LOG_MODULE_BOOT_REQUESTED = 86,
	LOG_FIRMWARE_RELEASE_MISMATCH = 87,
	LOG_FIRMWARE_UPDATE_REQUESTED = 90,
	LOG_FU_SUCCESS = 91,
	LOG_FU_GENERIC_ERROR = 92,
	LOG_FU_USB_DRIVE_NOT_FOUND = 93,
	LOG_FU_PACKAGE_NOT_VALID = 94,
	LOG_FU_FLASH_WRITING_ERROR = 95,
	LOG_FU_MODULE_UPDATE_ERROR = 96,
	LOG_FU_MODULE_UPDATE_TIMEOUT = 97,
	LOG_FU_USB_READING_ERROR = 98,
	LOG_CONFIGURATION_FAULT = 101,
	LOG_EEPROM_FAULT = 102,
	LOG_BLUETOOTH_FAULT = 103,
	LOG_GPI_EXTERNAL_FAULT = 104,
	LOG_CH1_ULTRASONIC_FAULT = 105,
	LOG_CH1_HS200_COMM_ERROR = 106,
	LOG_BLOWER_FAULT = 107,
	SPARE_1 = 108,
	LOG_CH1_LOW_FLOW_FAULT = 109,
	LOG_CH1_HIGH_FLOW_FAULT = 110,
	LOG_CH2_ULTRASONIC_FAULT = 111,
	LOG_CH2_HS200_COMM_ERROR = 112,
	SPARE_2 = 113,
	LOG_CH2_LOW_FLOW_FAULT = 114,
	LOG_CH2_HIGH_FLOW_FAULT = 115,
	LOG_HIGH_POWER_FAULT = 116,
	LOG_E2_CONFIG_DIFF_DIPSWITCH_FAULT = 117,
	LOG_DATA_FLASH_FAULT = 118,
	LOG_EEPROM_CHECKSUM_FAULT = 119,
	LOG_CH1_SENSOR_DIRTY_FAULT = 120,
	LOG_CH2_SENSOR_DIRTY_FAULT = 121,
	LOG_MODULE_COMM_FAULT = 122,
	LOG_EVENT_ENABLE_BUZZER_EUROPE = 127,
	LOG_EVENT_EEPROM_WRITING_FAILURE = 128,
	LOG_ASD_EEPROM_FAILURE = 129,
	LOG_CH1_SENSOR_REPLACED = 130,
	LOG_CH2_SENSOR_REPLACED = 131,
	LOG_RTC_READ_WRITE_FAULT = 201,
	LOG_RTC_DATA_NOT_CONSISTENT = 202,
	LOG_CH1_HIGH_TEMPERATURE_ALERT = 203,
	LOG_CH1_LOW_TEMPERATURE_ALERT = 204,
	LOG_CH2_HIGH_TEMPERATURE_ALERT = 205,
	LOG_CH2_LOW_TEMPERATURE_ALERT = 206,
	LOG_LOW_SUPPLY_VOLTAGE_ALERT = 207,
	LOG_CH1_SENSOR_DIRTY_ALERT_N1 = 208,
	LOG_CH1_SENSOR_DIRTY_ALERT_N2 = 209,
	LOG_CH2_SENSOR_DIRTY_ALERT_N1 = 210,
	LOG_CH2_SENSOR_DIRTY_ALERT_N2 = 211,
	LOG_SUPPLY_VOLT_BELOW_EEPROM_WORKING_VOLT = 212,
	LOG_MAINTENANCE_ALERT = 213,
	LOG_MODULE_EEPROM_FAULT = 214,
	LOG_GENERIC_FAULT_SERVICE = 251,
	LOG_GENERIC_FAULT_INITIALIZATION = 252,
	LOG_GENERIC_FAULT_WAIT = 253,
	LOG_GENERIC_FAULT_NORMAL = 254,
	LOG_STATE_MACHINE_DEFAULT_HANDLER = 255,
	LOG_RAM_CONSISTENCY_FAILURE = 256,
	LOG_CH1_PREALARM = 301,
	LOG_CH1_ALARM = 302,
	LOG_CH2_PREALARM = 303,
	LOG_CH2_ALARM = 304,
	LOG_THRESHOLD_CALIB_START = 351,
	LOG_THRESHOLD_CALIB_INV_INPUT = 352,
	LOG_THRESHOLD_CALIB_CH1_FAILED = 353,
	LOG_THRESHOLD_CALIB_CH2_FAILED = 354,
	LOG_THRESHOLD_CALIB_CH1_SUCCESS = 355,
	LOG_THRESHOLD_CALIB_CH2_SUCCESS = 356,
	LOG_EXIT_BLUETOOTH_FAULT = 1103,
	LOG_EXIT_GPI_EXTERNAL_FAULT = 1104,
	LOG_EXIT_CH1_ULTRASONIC_FAULT = 1105,
	LOG_EXIT_CH1_HS200_COMM_ERROR = 1106,
	LOG_EXIT_BLOWER_FAULT = 1107,
	SPARE_3 = 1108,
	LOG_EXIT_CH1_LOW_FLOW_FAULT = 1109,
	LOG_EXIT_CH1_HIGH_FLOW_FAULT = 1110,
	LOG_EXIT_CH2_ULTRASONIC_FAULT = 1111,
	LOG_EXIT_CH2_HS200_COMM_ERROR = 1112,
	SPARE_4 = 1113,
	LOG_EXIT_CH2_LOW_FLOW_FAULT = 1114,
	LOG_EXIT_CH2_HIGH_FLOW_FAULT = 1115,
	LOG_SPARE1116 = 1116,
	LOG__EXIT_E2_CONFIG_DIFF_DIPSWITCH_FAULT = 1117,
	LOG_SPARE1118 = 1118,
	LOG_SPARE1119 = 1119,
	LOG_EXIT_CH1_SENSOR_DIRTY_FAULT = 1120,
	LOG_EXIT_CH2_SENSOR_DIRTY_FAULT = 1121,
	LOG_EXIT_MODULE_COMM_FAULT = 1122,
	LOG_EXIT_RTC_READ_WRITE_FAULT = 1201,
	LOG_EXIT_RTC_DATA_NOT_CONSISTENT = 1202,
	LOG_EXIT_CH1_HIGH_TEMPERATURE_ALERT = 1203,
	LOG_EXIT_CH1_LOW_TEMPERATURE_ALERT = 1204,
	LOG_EXIT_CH2_HIGH_TEMPERATURE_ALERT = 1205,
	LOG_EXIT_CH2_LOW_TEMPERATURE_ALERT = 1206,
	LOG_EXIT_LOW_SUPPLY_VOLTAGE_ALERT = 1207,
	LOG_EXIT_CH1_SENSOR_DIRTY_ALERT_N1 = 1208,
	LOG_EXIT_CH1_SENSOR_DIRTY_ALERT_N2 = 1209,
	LOG_EXIT_CH2_SENSOR_DIRTY_ALERT_N1 = 1210,
	LOG_EXIT_CH2_SENSOR_DIRTY_ALERT_N2 = 1211,
	LOG_EXIT_SUPPLY_VOLT_BELOW_EEPROM_WORKING_VOLT = 1212,
	LOG_EXIT_MAINTENANCE_ALERT = 1213,
	LOG_EXIT_MODULE_EEPROM_FAULT = 1214,
	LOG_EXIT_CH1_PREALARM = 1301,
	LOG_EXIT_CH1_ALARM = 1302,
	LOG_EXIT_CH2_PREALARM = 1303,
	LOG_EXIT_CH2_ALARM = 1304,
	LOG_CFG_CHANGE_PWD_NEEDED = 1400,
	LOG_CFG_CH1_ALARM_UNLATCHED = 1401,
	LOG_CFG_CH1_ALARM_LATCHED = 1402,
	LOG_CFG_CH2_ALARM_UNLATCHED = 1403,
	LOG_CFG_CH2_ALARM_LATCHED = 1404,
	LOG_CFG_CH1_PREALARM_UNLATCHED = 1405,
	LOG_CFG_CH1_PREALARM_LATCHED = 1406,
	LOG_CFG_CH2_PREALARM_UNLATCHED = 1407,
	LOG_CFG_CH2_PREALARM_LATCHED = 1408,
	LOG_CFG_CH1_FAULT_UNLATCHED = 1409,
	LOG_CFG_CH1_FAULT_LATCHED = 1410,
	LOG_CFG_CH2_FAULT_UNLATCHED = 1411,
	LOG_CFG_CH2_FAUT_LATCHED = 1412,
	LOG_CFG_ALARM_MODE_CUMULATIVE = 1413,
	LOG_CFG_ALARM_MODE_INSTANTANEOUS = 1414,
	LOG_CFG_RELAY_FOR_TEMPERATURE_UNSET = 1415,
	LOG_CFG_RELAY_FOR_TEMPERATURE_SET = 1416,
	LOG_CFG_RELAY_FOR_LOW_POWER_UNSET = 1417,
	LOG_CFG_RELAY_FOR_LOW_POWER_SET = 1418,
	LOG_CFG_FAN_SPEED_0 = 1419,
	LOG_CFG_FAN_SPEED_1 = 1420,
	LOG_CFG_FAN_SPEED_2 = 1421,
	LOG_CFG_FAN_SPEED_3 = 1422,
	LOG_CFG_FAN_SPEED_4 = 1423,
	LOG_CFG_FAN_SPEED_5 = 1424,
	LOG_CFG_FAN_SPEED_6 = 1425,
	LOG_CFG_FAN_SPEED_7 = 1426,
	LOG_CFG_FAN_SPEED_8 = 1427,
	LOG_CFG_FAN_SPEED_9 = 1428,
	LOG_CFG_FAN_SPEED_10 = 1429,
	LOG_CFG_CH1_ALARM_LEVEL_0 = 1430,
	LOG_CFG_CH1_ALARM_LEVEL_1 = 1431,
	LOG_CFG_CH1_ALARM_LEVEL_2 = 1432,
	LOG_CFG_CH1_ALARM_LEVEL_3 = 1433,
	LOG_CFG_CH1_ALARM_LEVEL_4 = 1434,
	LOG_CFG_CH1_ALARM_LEVEL_5 = 1435,
	LOG_CFG_CH1_ALARM_LEVEL_6 = 1436,
	LOG_CFG_CH1_ALARM_LEVEL_7 = 1437,
	LOG_CFG_CH1_ALARM_LEVEL_8 = 1438,
	LOG_CFG_CH1_ALARM_LEVEL_9 = 1439,
	LOG_CFG_CH2_ALARM_LEVEL_0 = 1440,
	LOG_CFG_CH2_ALARM_LEVEL_1 = 1441,
	LOG_CFG_CH2_ALARM_LEVEL_2 = 1442,
	LOG_CFG_CH2_ALARM_LEVEL_3 = 1443,
	LOG_CFG_CH2_ALARM_LEVEL_4 = 1444,
	LOG_CFG_CH2_ALARM_LEVEL_5 = 1445,
	LOG_CFG_CH2_ALARM_LEVEL_6 = 1446,
	LOG_CFG_CH2_ALARM_LEVEL_7 = 1447,
	LOG_CFG_CH2_ALARM_LEVEL_8 = 1448,
	LOG_CFG_CH2_ALARM_LEVEL_9 = 1449,
	LOG_CFG_CH1_PREALARM_LEVEL_0 = 1450,
	LOG_CFG_CH1_PREALARM_LEVEL_1 = 1451,
	LOG_CFG_CH1_PREALARM_LEVEL_2 = 1452,
	LOG_CFG_CH1_PREALARM_LEVEL_3 = 1453,
	LOG_CFG_CH1_PREALARM_LEVEL_4 = 1454,
	LOG_CFG_CH1_PREALARM_LEVEL_5 = 1455,
	LOG_CFG_CH1_PREALARM_LEVEL_6 = 1456,
	LOG_CFG_CH1_PREALARM_LEVEL_7 = 1457,
	LOG_CFG_CH1_PREALARM_LEVEL_8 = 1458,
	LOG_CFG_CH1_PREALARM_LEVEL_9 = 1459,
	LOG_CFG_CH2_PREALARM_LEVEL_0 = 1460,
	LOG_CFG_CH2_PREALARM_LEVEL_1 = 1461,
	LOG_CFG_CH2_PREALARM_LEVEL_2 = 1462,
	LOG_CFG_CH2_PREALARM_LEVEL_3 = 1463,
	LOG_CFG_CH2_PREALARM_LEVEL_4 = 1464,
	LOG_CFG_CH2_PREALARM_LEVEL_5 = 1465,
	LOG_CFG_CH2_PREALARM_LEVEL_6 = 1466,
	LOG_CFG_CH2_PREALARM_LEVEL_7 = 1467,
	LOG_CFG_CH2_PREALARM_LEVEL_8 = 1468,
	LOG_CFG_CH2_PREALARM_LEVEL_9 = 1469,
	LOG_CFG_EXT_INPUT_ACTION_FOR_OPEN_NONE = 1470,
	LOG_CFG_EXT_INPUT_ACTION_FOR_OPEN_RESET = 1471,
	LOG_CFG_EXT_INPUT_ACTION_FOR_OPEN_TRIGGER_EXIT_FAULT = 1472,
	LOG_CFG_EXT_INPUT_ACTION_FOR_OPEN_PERFORME_DISABLE_ACTION = 1473,
	LOG_CFG_EXT_INPUT_ACTION_FOR_SHORT_NONE = 1474,
	LOG_CFG_EXT_INPUT_ACTION_FOR_SHORT_RESET = 1475,
	LOG_CFG_EXT_INPUT_ACTION_FOR_SHORT_TRIGGER_EXIT_FAULT = 1476,
	LOG_CFG_EXT_INPUT_ACTION_FOR_SHORT_PERFORME_DISABLE_ACTION = 1477,
	LOG_CFG_EXT_INPUT_CHANGE_STATE_ACTION_NONE = 1478,
	LOG_CFG_EXT_INPUT_CHANGE_STATE_ACTION_RESET = 1479,
	LOG_CFG_EXT_INPUT_CHANGE_STATE_ACTION_TRIGGER_EXIT_FAULT = 1480,
	LOG_CFG_EXT_INPUT_CHANGE_STATE_ACTION_PERFORME_DISABLE_ACTION = 1481,
	LOG_CFG_EXT_INPUT_UNBALANCED = 1482,
	LOG_CFG_EXT_INPUT_BALANCED = 1483,
	LOG_CFG_EXT_INPUT_NORMAL_STATE_OPEN = 1484,
	LOG_CFG_EXT_INPUT_NORMAL_STATE_SHORT = 1485,
	LOG_CFG_EXT_INPUT_NORMAL_STATE_EOL = 1486,
	LOG_CMD_SILENCE_BUZZER_CHINA = 1487,
	LOG_CFG_CH1_FLOW_FAULT_THRESHOLD_1_15_PERC = 1488,
	LOG_CFG_CH1_FLOW_FAULT_THRESHOLD_16_80_PERC = 1489,
	LOG_CFG_CH2_FLOW_FAULT_THRESHOLD_1_15_PERC = 1490,
	LOG_CFG_CH2_FLOW_FAULT_THRESHOLD_16_80_PERC = 1491,
	LOG_CFG_ALARM_DELAY_0_SECS = 1492,
	LOG_CFG_ALARM_DELAY_GT_0_SECS = 1493,
	LOG_CFG_PREALARM_DELAY_0_SECS = 1494,
	LOG_CFG_PREALARM_DELAY_GT_0_SECS = 1495,
	LOG_CFG_FLOW_FAULT_DELAY_LE_30_SECS = 1496,
	LOG_CFG_FLOW_FAULT_DELAY_GT_30_SECS = 1497,
	LOG_CMD_RESET_FAULT = 1498,
	LOG_CMD_DISABLE_TIMOUT_NOT_ENABLED = 1499,
	LOG_CMD_DISABLE_TIMOUT_ENABLED = 1500,
	LOG_CFG_END = 1501,
	LOG_CFG_FAN_REPLACEMENT_COMPLETE = 1502,
	LOG_CFG_RESTART_BY_SW_COMMAND = 1503,
	LOG_CFG_DEVICE_RESET_AFTER_CLOSING_COVER = 1506,
	LOG_CFG_RESTART_AFTER_CONFIG = 1507,
	LOG_CFG_RESTART_AFTER_DF_RESTORE = 1508,
	LOG_CFG_GPI_RESET_ALARMS_AND_FAULTS = 1510,
	LOG_CFG_FACP_RESET_ALARMS_AND_FAULTS = 1511,
	LOG_GPI_SET_OPEN_ACT_RESET_ALARMS = 1533,
	LOG_GPI_SET_SHORT_ACT_RESET_ALARMS = 1534,
	LOG_GPI_SET_CS_ACT_RESET_ALARMS = 1535,
	LOG_CFG_GENERAL_FAULT_UNLATCHED = 1570,
	LOG_CFG_GENERAL_FAULT_LATCHED = 1571,
	LOG_CFG_AUX_FAULT_UNLATCHED = 1572,
	LOG_CFG_AUX_FAULT_LATCHED = 1573,
}
// Mapping descriptions (labels) to each enum value
export const LogEventIdDescription: Record<LogEventId, string> = {
	[LogEventId.LOG_EVENT_NONE]: 'None',
	[LogEventId.LOG_EVENT_POWER_ON]: 'Power On',
	[LogEventId.LOG_EVENT_COVER_OPENED]: 'Cover opened',
	[LogEventId.LOG_EVENT_COVER_CLOSED]: 'Cover closed',
	[LogEventId.LOG_EVENT_PASSWORD_ENTRY]: 'Password entry',
	[LogEventId.LOG_EVENT_PASSWORD_MODIFIED]: 'Password modified',
	[LogEventId.LOG_EVENT_PASSWORD_CORRECT]: 'Password correct',
	[LogEventId.LOG_EVENT_PASSWORD_INCORRECT]: 'Password incorrect',
	[LogEventId.LOG_EVENT_DISABLE_START]: 'To Disable',
	[LogEventId.LOG_EVENT_DISABLE_OVER]: 'Exit from Disable',
	[LogEventId.LOG_EVENT_EUROPE_TEST_START]: 'Test started',
	[LogEventId.LOG_EVENT_EUROPE_TEST_COMPLETE]: 'Test completed',
	[LogEventId.LOG_EVENT_EUROPE_TEST_LOG_WRITTEN]: 'Test log written',
	[LogEventId.LOG_EVENT_CHINA_TEST_START]: 'Test started',
	[LogEventId.LOG_EVENT_CHINA_TEST_COMPLETE]: 'Test completed',
	[LogEventId.LOG_EVENT_GPI_RESET_DEVICE]: 'GPI Reset Device',
	[LogEventId.LOG_EVENT_GPI_START_DISABLE]: 'GPI To Disable',
	[LogEventId.LOG_EVENT_GPI_STOP_DISABLE]: 'GPI Exit from Disable',
	[LogEventId.LOG_EVENT_NORMALIZE_START]: 'Normalize Start',
	[LogEventId.LOG_EVENT_NORMALOVER]: 'Normalize successfully completed',
	[LogEventId.LOG_EVENT_NORMALIZE_FAILED_FOR_INSTABLE_FLOW]:
		'Normalize failed, flow not stable',
	[LogEventId.LOG_EVENT_NORMALIZE_FAILED_FOR_OUT_OF_RANGE_FLOW]:
		'Normalize failed, flow out of range',
	[LogEventId.LOG_EVENT_RESET_ALARM_FAULT_STARTED]: 'Reset started',
	[LogEventId.LOG_EVENT_CONFIGURATION_START]: 'Change configuration request',
	[LogEventId.LOG_EVENT_LOGSTARTED]: 'Downloading Logs',
	[LogEventId.LOG_EVENT_LOGOVER]: 'Download Complete',
	[LogEventId.LOG_EVENT_DISABLE_BUZZER_CHINA]: 'Silence Alarm',
	[LogEventId.LOG_EVENT_DISABLE_BUZZER_EUROPE]: 'Disable Buzzer Button',
	[LogEventId.LOG_EVENT_WAITING_FOR_COVER]:
		'Open cover to confirm unauthorized change configuration',
	[LogEventId.LOG_EVENT_TO_PROTECTION]: 'Protection (overvolt)',
	[LogEventId.LOG_EVENT_TO_NORMAL]: 'Normal',
	[LogEventId.LOG_EVENT_TO_WAIT]: 'Wait',
	[LogEventId.LOG_EVENT_TO_SERVICE]: 'Service',
	[LogEventId.LOG_EVENT_PAIRING_TENTATIVE]: 'Pairing tentative',
	[LogEventId.LOG_EVENT_PAIRING_DONE]: 'Pairing successfully completed',
	[LogEventId.LOG_EVENT_E2P_FACTORY_RESTORE_SUCCESS]: 'Factory restore done',
	[LogEventId.LOG_EVENT_E2P_FACTORY_RESTORE_FAILED]: 'Factory restore failed',
	[LogEventId.LOG_EVENT_PASSWORD_RECOVERY]: 'Password recovery',
	[LogEventId.LOG_EVENT_PID_STARTED]: 'Flow adjustment started',
	[LogEventId.LOG_EVENT_PID_OVER]: 'Flow adjusted',
	[LogEventId.LOG_EVENT_CONFIGURATION_OVER]: 'Change configuration completed',
	[LogEventId.LOG_EVENT_CONFIGURATION_OVER_FOR_TIMEOUT]:
		'Exit from Configuration after timeout',
	[LogEventId.LOG_EVENT_PASSWORD_INCORRECT_FOR_TIMEOUT]:
		'Exit from Password entering for timeout',
	[LogEventId.LOG_EVENT_PASSWORD_MODIFY_EXIT_FOR_TIMEOUT]:
		'Exit from Password change for timeout',
	[LogEventId.LOG_EVENT_HOUR_CHANGED]: 'Time changed',
	[LogEventId.LOG_EVENT_DISABLE_EXIT_FOR_TIMEOUT]:
		'Exit from Disable after timeout',
	[LogEventId.LOG_EVENT_START_PASSWORD_CHANGE]: 'Password change requested',
	[LogEventId.LOG_EVENT_EUROPE_TEST_ABORT_BY_APP]:
		'Exit from Test for BT request',
	[LogEventId.LOG_TREND_LOG_EVENT]: 'Trend log',
	[LogEventId.LOG_CLEAR_LOG_EVENT]: 'Clear log',
	[LogEventId.LOG_TEST_FAILED_EVENT]: 'Test failed',
	[LogEventId.LOG_PASSWORD_BTAPP_INCORRECT_EVENT]:
		'Password by BT app incorrect',
	[LogEventId.LOG_PID_OVER_AT_POWER_ON]: 'PID over at power on',
	[LogEventId.LOG_PID_STARTED_AT_POWER_ON]: 'PID started at power on',
	[LogEventId.LOG_FAN_REPLACEMENT_START]: 'Blower replacement started',
	[LogEventId.LOG_FAN_REPLACEMENT_ABORT]: 'Blower replacement aborted',
	[LogEventId.LOG_FAN_REPLACE_TIMEOUT]: 'Blower replacement timeout',
	[LogEventId.LOG_CONFIGURATION_ABORT_BY_BUTTON]:
		'Abort configuration by button',
	[LogEventId.LOG_CONFIGURATION_ABORT_BY_COVER]: 'Abort configuration by cover',
	[LogEventId.LOG_STARTED_BT_HAND_PAIRING]: 'Hand pairing started',
	[LogEventId.LOG_STARTED_BT_SOUND_PAIRING]: 'Sound pairing started',
	[LogEventId.LOG_BLE_CONNECTED]: 'Bluetooth connected',
	[LogEventId.LOG_BLE_DISCONNECTED]: 'Bluetooth disconnected',
	[LogEventId.LOG_TOKEN_BY_BT_INCORRECT]: 'Token by BT app incorrect',
	[LogEventId.LOG_TOKEN_BY_BT_CORRECT]: 'Token by BT app correct',
	[LogEventId.LOG_PARAMETER_OUT_OF_RANGE]: 'Data-flash parameter out of range',
	[LogEventId.LOG_NORMALIZE_ABORT_BY_COVER]:
		'Normalization failed for cover closure',
	[LogEventId.LOG_NORMALIZE_ABORT_NVM_FAULT]:
		'Normalization failed for data Flash error',
	[LogEventId.LOG_MODULE_BOOT_REQUESTED]: 'Module boot requested',
	[LogEventId.LOG_FIRMWARE_RELEASE_MISMATCH]: 'Firmware release mismatch',
	[LogEventId.LOG_FIRMWARE_UPDATE_REQUESTED]: 'Firmware update requested',
	[LogEventId.LOG_CONFIGURATION_FAULT]: 'Configuration data not available',
	[LogEventId.LOG_EEPROM_FAULT]: 'EEPROM not readable',
	[LogEventId.LOG_BLUETOOTH_FAULT]: 'Bluetooth module error',
	[LogEventId.LOG_GPI_EXTERNAL_FAULT]: 'GPI external fault',
	[LogEventId.LOG_CH1_ULTRASONIC_FAULT]: 'Ch1 Flow gauge fault',
	[LogEventId.LOG_CH1_HS200_COMM_ERROR]: 'Ch1 sensing head communication fault',
	[LogEventId.LOG_BLOWER_FAULT]: 'Aspirator failure',
	[LogEventId.SPARE_1]: 'Ch1 flow initialization failed',
	[LogEventId.LOG_CH1_LOW_FLOW_FAULT]: 'Ch1 flow is below the min limit',
	[LogEventId.LOG_CH1_HIGH_FLOW_FAULT]: 'Ch1 flow is above the max limit',
	[LogEventId.LOG_CH2_ULTRASONIC_FAULT]: 'Ch2 ultrasonic faulty circuit',
	[LogEventId.LOG_CH2_HS200_COMM_ERROR]: 'Ch2 sensing head communication fault',
	[LogEventId.SPARE_2]: 'Ch2 flow initialization failed',
	[LogEventId.LOG_CH2_LOW_FLOW_FAULT]: 'Ch2 flow is below the min limit',
	[LogEventId.LOG_CH2_HIGH_FLOW_FAULT]: 'Ch 2 flow is above the max limit',
	[LogEventId.LOG_HIGH_POWER_FAULT]: 'Overvoltage error',
	[LogEventId.LOG_E2_CONFIG_DIFF_DIPSWITCH_FAULT]:
		'Unauthorised configuration change',
	[LogEventId.LOG_DATA_FLASH_FAULT]: 'Data Flash fault',
	[LogEventId.LOG_EEPROM_CHECKSUM_FAULT]: 'Memory Fault',
	[LogEventId.LOG_CH1_SENSOR_DIRTY_FAULT]: 'CH1 Dust Contamination',
	[LogEventId.LOG_CH2_SENSOR_DIRTY_FAULT]: 'CH2 Dust Contamination',
	[LogEventId.LOG_MODULE_COMM_FAULT]: 'Module communication fault',
	[LogEventId.LOG_EVENT_ENABLE_BUZZER_EUROPE]: 'Enable buzzer for buttons over',
	[LogEventId.LOG_EVENT_EEPROM_WRITING_FAILURE]: 'EEPROM byte writing failure',
	[LogEventId.LOG_ASD_EEPROM_FAILURE]: 'ASD EEprom operation failure',
	[LogEventId.LOG_CH1_SENSOR_REPLACED]: 'Ch1 sensor replaced',
	[LogEventId.LOG_CH2_SENSOR_REPLACED]: 'Ch2 sensor replaced',
	[LogEventId.LOG_RTC_READ_WRITE_FAULT]: 'Clock cannot be read or set',
	[LogEventId.LOG_RTC_DATA_NOT_CONSISTENT]: 'Clock data is not consistent',
	[LogEventId.LOG_CH1_HIGH_TEMPERATURE_ALERT]: 'Ch1 High Temperature Alert',
	[LogEventId.LOG_CH1_LOW_TEMPERATURE_ALERT]: 'Ch1 Low Temperature Alert',
	[LogEventId.LOG_CH2_HIGH_TEMPERATURE_ALERT]: 'Ch2 High Temperature Alert',
	[LogEventId.LOG_CH2_LOW_TEMPERATURE_ALERT]: 'Ch2 Low Temperature Alert',
	[LogEventId.LOG_LOW_SUPPLY_VOLTAGE_ALERT]: 'Low power alert',
	[LogEventId.LOG_CH1_SENSOR_DIRTY_ALERT_N1]:
		'Ch1 Sensing Head Dust Contimation Level 1',
	[LogEventId.LOG_CH1_SENSOR_DIRTY_ALERT_N2]:
		'Ch1 Sensing Head Dust Contimation Level 2',
	[LogEventId.LOG_CH2_SENSOR_DIRTY_ALERT_N1]:
		'Ch2 Sensing Head Dust Contimation Level 1',
	[LogEventId.LOG_CH2_SENSOR_DIRTY_ALERT_N2]:
		'Ch2 Sensing Head Dust Contimation Level 2',
	[LogEventId.LOG_SUPPLY_VOLT_BELOW_EEPROM_WORKING_VOLT]:
		'Low power alert, possible lost of events',
	[LogEventId.LOG_MAINTENANCE_ALERT]: 'Maintenance alert',
	[LogEventId.LOG_MODULE_EEPROM_FAULT]: 'Module EEprom fault',
	[LogEventId.LOG_GENERIC_FAULT_SERVICE]: 'Service fault',
	[LogEventId.LOG_GENERIC_FAULT_INITIALIZATION]: 'Initialization fault',
	[LogEventId.LOG_GENERIC_FAULT_WAIT]: 'Wait fault',
	[LogEventId.LOG_GENERIC_FAULT_NORMAL]: 'Normal fault',
	[LogEventId.LOG_STATE_MACHINE_DEFAULT_HANDLER]:
		'State machine default handler',
	[LogEventId.LOG_RAM_CONSISTENCY_FAILURE]: 'RAM consistency failure',
	[LogEventId.LOG_CH1_PREALARM]: 'Action ch1',
	[LogEventId.LOG_CH1_ALARM]: 'Alarm ch1',
	[LogEventId.LOG_CH2_PREALARM]: 'Action ch2',
	[LogEventId.LOG_CH2_ALARM]: 'Alarm ch2',
	[LogEventId.LOG_THRESHOLD_CALIB_START]: 'Flowmeter calibration started',
	[LogEventId.LOG_THRESHOLD_CALIB_INV_INPUT]:
		'Flowmeter calibration failed, invalid inputs',
	[LogEventId.LOG_THRESHOLD_CALIB_CH1_FAILED]: 'Flowmeter 1 calibration failed',
	[LogEventId.LOG_THRESHOLD_CALIB_CH2_FAILED]: 'Flowmeter 2 calibration failed',
	[LogEventId.LOG_THRESHOLD_CALIB_CH1_SUCCESS]:
		'Flowmeter 1 calibration succeeded',
	[LogEventId.LOG_THRESHOLD_CALIB_CH2_SUCCESS]:
		'Flowmeter 2 calibration succeeded',
	[LogEventId.LOG_EXIT_BLUETOOTH_FAULT]: 'Exit from bluetooth module error',
	[LogEventId.LOG_EXIT_GPI_EXTERNAL_FAULT]: 'Exit from GPI external fault',
	[LogEventId.LOG_EXIT_CH1_ULTRASONIC_FAULT]: 'Exit from CH1 flow sensor fault',
	[LogEventId.LOG_EXIT_CH1_HS200_COMM_ERROR]:
		'Exit from Ch1 sensing head communication fault',
	[LogEventId.LOG_EXIT_BLOWER_FAULT]: 'Exit from Aspirator Fault',
	[LogEventId.SPARE_3]: 'Exit from ch1 flow initialization failed',
	[LogEventId.LOG_EXIT_CH1_LOW_FLOW_FAULT]: 'Exit from ch1 Low flow fault',
	[LogEventId.LOG_EXIT_CH1_HIGH_FLOW_FAULT]: 'Exit from ch1 High flow fault',
	[LogEventId.LOG_EXIT_CH2_ULTRASONIC_FAULT]: 'Exit from CH2 flow sensor fault',
	[LogEventId.LOG_EXIT_CH2_HS200_COMM_ERROR]:
		'Exit from ch2 sensing head communication fault',
	[LogEventId.SPARE_4]: 'Exit from ch2 flow initialization failed',
	[LogEventId.LOG_EXIT_CH2_LOW_FLOW_FAULT]: 'Exit from ch2 Low flow fault',
	[LogEventId.LOG_EXIT_CH2_HIGH_FLOW_FAULT]: 'Exit from ch2 High flow fault',
	[LogEventId.LOG_SPARE1116]: 'Event',
	[LogEventId.LOG__EXIT_E2_CONFIG_DIFF_DIPSWITCH_FAULT]:
		'Exit from Unauthorised configuration change',
	[LogEventId.LOG_SPARE1118]: 'Event',
	[LogEventId.LOG_SPARE1119]: 'Event',
	[LogEventId.LOG_EXIT_CH1_SENSOR_DIRTY_FAULT]: 'Exit from Ch1 dirt fault',
	[LogEventId.LOG_EXIT_CH2_SENSOR_DIRTY_FAULT]: 'Exit from Ch2 dirt fault',
	[LogEventId.LOG_EXIT_RTC_READ_WRITE_FAULT]: 'Exit from clock alert',
	[LogEventId.LOG_EXIT_RTC_DATA_NOT_CONSISTENT]:
		'Exit from Invalid time base alert',
	[LogEventId.LOG_EXIT_CH1_HIGH_TEMPERATURE_ALERT]:
		'Exit from ch1 High temperature alert',
	[LogEventId.LOG_EXIT_CH1_LOW_TEMPERATURE_ALERT]:
		'Exit from ch1 Low temperature alert',
	[LogEventId.LOG_EXIT_CH2_HIGH_TEMPERATURE_ALERT]:
		'Exit from ch2 High temperature alert',
	[LogEventId.LOG_EXIT_CH2_LOW_TEMPERATURE_ALERT]:
		'Exit from ch2 Low temperature alert',
	[LogEventId.LOG_EXIT_LOW_SUPPLY_VOLTAGE_ALERT]: 'Exit from Low power alert',
	[LogEventId.LOG_EXIT_CH1_SENSOR_DIRTY_ALERT_N1]:
		'Exit from Ch1 Sensing Head Dust Contimation Level 1',
	[LogEventId.LOG_EXIT_CH1_SENSOR_DIRTY_ALERT_N2]:
		'Exit from Ch1 Sensing Head Dust Contimation Level 2',
	[LogEventId.LOG_EXIT_CH2_SENSOR_DIRTY_ALERT_N1]:
		'Exit from Ch2 Sensing Head Dust Contimation Level 1',
	[LogEventId.LOG_EXIT_CH2_SENSOR_DIRTY_ALERT_N2]:
		'Exit from Ch2 Sensing Head Dust Contimation Level 2',
	[LogEventId.LOG_EXIT_SUPPLY_VOLT_BELOW_EEPROM_WORKING_VOLT]:
		'Exit from Low power alert, events will not be written',
	[LogEventId.LOG_EXIT_MAINTENANCE_ALERT]: 'Exit from maintenance alert',
	[LogEventId.LOG_EXIT_MODULE_EEPROM_FAULT]: 'Exit from Module EEprom fault',
	[LogEventId.LOG_EXIT_CH1_PREALARM]: 'Exit from Action ch1',
	[LogEventId.LOG_EXIT_CH1_ALARM]: 'Exit from Alarm ch1',
	[LogEventId.LOG_EXIT_CH2_PREALARM]: 'Exit from Action ch2',
	[LogEventId.LOG_EXIT_CH2_ALARM]: 'Exit from Alarm ch2',
	[LogEventId.LOG_CFG_CHANGE_PWD_NEEDED]: 'Config Changed, password needed',
	[LogEventId.LOG_CFG_CH1_ALARM_UNLATCHED]: 'Ch1 Alarm relay set to unlatched',
	[LogEventId.LOG_CFG_CH1_ALARM_LATCHED]: 'Ch1 Alarm relay set to latched',
	[LogEventId.LOG_CFG_CH2_ALARM_UNLATCHED]: 'Ch2 Alarm relay set to unlatched',
	[LogEventId.LOG_CFG_CH2_ALARM_LATCHED]: 'Ch2 Alarm relay set to latched',
	[LogEventId.LOG_CFG_CH1_PREALARM_UNLATCHED]:
		'Ch1 Action relay set to unlatched',
	[LogEventId.LOG_CFG_CH1_PREALARM_LATCHED]: 'Ch1 Action relay set to latched',
	[LogEventId.LOG_CFG_CH2_PREALARM_UNLATCHED]:
		'Ch2 Action relay set to unlatched',
	[LogEventId.LOG_CFG_CH2_PREALARM_LATCHED]: 'Ch2 Action relay set to latched',
	[LogEventId.LOG_CFG_CH1_FAULT_UNLATCHED]:
		'Ch1 Flow fault relay set to unlatched',
	[LogEventId.LOG_CFG_CH1_FAULT_LATCHED]: 'Ch1 Flow fault relay set to latched',
	[LogEventId.LOG_CFG_CH2_FAULT_UNLATCHED]:
		'Ch2 Flow fault relay set to unlatched',
	[LogEventId.LOG_CFG_CH2_FAUT_LATCHED]: 'Ch2 Flow fault relay set to latched',
	[LogEventId.LOG_CFG_ALARM_MODE_CUMULATIVE]: 'Alarm mode set to cumulative',
	[LogEventId.LOG_CFG_ALARM_MODE_INSTANTANEOUS]:
		'Alarm mode set to instantaneous',
	[LogEventId.LOG_CFG_RELAY_FOR_TEMPERATURE_UNSET]:
		'Relay for temperature is unset',
	[LogEventId.LOG_CFG_RELAY_FOR_TEMPERATURE_SET]:
		'Relay for temperature is set',
	[LogEventId.LOG_CFG_RELAY_FOR_LOW_POWER_UNSET]:
		'Relay for low power is unset',
	[LogEventId.LOG_CFG_RELAY_FOR_LOW_POWER_SET]: 'Relay for low power is set',
	[LogEventId.LOG_CFG_FAN_SPEED_0]: 'Fan speed set to level 0',
	[LogEventId.LOG_CFG_FAN_SPEED_1]: 'Fan speed set to level 1',
	[LogEventId.LOG_CFG_FAN_SPEED_2]: 'Fan speed set to level 2',
	[LogEventId.LOG_CFG_FAN_SPEED_3]: 'Fan speed set to level 3',
	[LogEventId.LOG_CFG_FAN_SPEED_4]: 'Fan speed set to level 4',
	[LogEventId.LOG_CFG_FAN_SPEED_5]: 'Fan speed set to level 5',
	[LogEventId.LOG_CFG_FAN_SPEED_6]: 'Fan speed set to level 6',
	[LogEventId.LOG_CFG_FAN_SPEED_7]: 'Fan speed set to level 7',
	[LogEventId.LOG_CFG_FAN_SPEED_8]: 'Fan speed set to level 8',
	[LogEventId.LOG_CFG_FAN_SPEED_9]: 'Fan speed set to level 9',
	[LogEventId.LOG_CFG_FAN_SPEED_10]: 'Fan speed set to level 10',
	[LogEventId.LOG_CFG_CH1_ALARM_LEVEL_0]: 'Ch1 Alarm set to level 0',
	[LogEventId.LOG_CFG_CH1_ALARM_LEVEL_1]: 'Ch1 Alarm set to level 1',
	[LogEventId.LOG_CFG_CH1_ALARM_LEVEL_2]: 'Ch1 Alarm set to level 2',
	[LogEventId.LOG_CFG_CH1_ALARM_LEVEL_3]: 'Ch1 Alarm set to level 3',
	[LogEventId.LOG_CFG_CH1_ALARM_LEVEL_4]: 'Ch1 Alarm set to level 4',
	[LogEventId.LOG_CFG_CH1_ALARM_LEVEL_5]: 'Ch1 Alarm set to level 5',
	[LogEventId.LOG_CFG_CH1_ALARM_LEVEL_6]: 'Ch1 Alarm set to level 6',
	[LogEventId.LOG_CFG_CH1_ALARM_LEVEL_7]: 'Ch1 Alarm set to level 7',
	[LogEventId.LOG_CFG_CH1_ALARM_LEVEL_8]: 'Ch1 Alarm set to level 8',
	[LogEventId.LOG_CFG_CH1_ALARM_LEVEL_9]: 'Ch1 Alarm set to level 9',
	[LogEventId.LOG_CFG_CH2_ALARM_LEVEL_0]: 'Ch2 Alarm set to level 0',
	[LogEventId.LOG_CFG_CH2_ALARM_LEVEL_1]: 'Ch2 Alarm set to level 1',
	[LogEventId.LOG_CFG_CH2_ALARM_LEVEL_2]: 'Ch2 Alarm set to level 2',
	[LogEventId.LOG_CFG_CH2_ALARM_LEVEL_3]: 'Ch2 Alarm set to level 3',
	[LogEventId.LOG_CFG_CH2_ALARM_LEVEL_4]: 'Ch2 Alarm set to level 4',
	[LogEventId.LOG_CFG_CH2_ALARM_LEVEL_5]: 'Ch2 Alarm set to level 5',
	[LogEventId.LOG_CFG_CH2_ALARM_LEVEL_6]: 'Ch2 Alarm set to level 6',
	[LogEventId.LOG_CFG_CH2_ALARM_LEVEL_7]: 'Ch2 Alarm set to level 7',
	[LogEventId.LOG_CFG_CH2_ALARM_LEVEL_8]: 'Ch2 Alarm set to level 8',
	[LogEventId.LOG_CFG_CH2_ALARM_LEVEL_9]: 'Ch2 Alarm set to level 9',
	[LogEventId.LOG_CFG_CH1_PREALARM_LEVEL_0]: 'Ch1 Action set to level 0',
	[LogEventId.LOG_CFG_CH1_PREALARM_LEVEL_1]: 'Ch1 Action set to level 1',
	[LogEventId.LOG_CFG_CH1_PREALARM_LEVEL_2]: 'Ch1 Action set to level 2',
	[LogEventId.LOG_CFG_CH1_PREALARM_LEVEL_3]: 'Ch1 Action set to level 3',
	[LogEventId.LOG_CFG_CH1_PREALARM_LEVEL_4]: 'Ch1 Action set to level 4',
	[LogEventId.LOG_CFG_CH1_PREALARM_LEVEL_5]: 'Ch1 Action set to level 5',
	[LogEventId.LOG_CFG_CH1_PREALARM_LEVEL_6]: 'Ch1 Action set to level 6',
	[LogEventId.LOG_CFG_CH1_PREALARM_LEVEL_7]: 'Ch1 Action set to level 7',
	[LogEventId.LOG_CFG_CH1_PREALARM_LEVEL_8]: 'Ch1 Action set to level 8',
	[LogEventId.LOG_CFG_CH1_PREALARM_LEVEL_9]: 'Ch1 Action set to level 9',
	[LogEventId.LOG_CFG_CH2_PREALARM_LEVEL_0]: 'Ch2 Action set to level 0',
	[LogEventId.LOG_CFG_CH2_PREALARM_LEVEL_1]: 'Ch2 Action set to level 1',
	[LogEventId.LOG_CFG_CH2_PREALARM_LEVEL_2]: 'Ch2 Action set to level 2',
	[LogEventId.LOG_CFG_CH2_PREALARM_LEVEL_3]: 'Ch2 Action set to level 3',
	[LogEventId.LOG_CFG_CH2_PREALARM_LEVEL_4]: 'Ch2 Action set to level 4',
	[LogEventId.LOG_CFG_CH2_PREALARM_LEVEL_5]: 'Ch2 Action set to level 5',
	[LogEventId.LOG_CFG_CH2_PREALARM_LEVEL_6]: 'Ch2 Action set to level 6',
	[LogEventId.LOG_CFG_CH2_PREALARM_LEVEL_7]: 'Ch2 Action set to level 7',
	[LogEventId.LOG_CFG_CH2_PREALARM_LEVEL_8]: 'Ch2 Action set to level 8',
	[LogEventId.LOG_CFG_CH2_PREALARM_LEVEL_9]: 'Ch2 Action set to level 9',
	[LogEventId.LOG_CFG_EXT_INPUT_ACTION_FOR_OPEN_NONE]:
		'GPI Action for Open (Balanced) set to None',
	[LogEventId.LOG_CFG_EXT_INPUT_ACTION_FOR_OPEN_RESET]:
		'GPI Action for Open (Balanced) set to Reset',
	[LogEventId.LOG_CFG_EXT_INPUT_ACTION_FOR_OPEN_TRIGGER_EXIT_FAULT]:
		'GPI Action for Open (Balanced) set to Trigger Exit Fault',
	[LogEventId.LOG_CFG_EXT_INPUT_ACTION_FOR_OPEN_PERFORME_DISABLE_ACTION]:
		'GPI Action for Open (Balanced) set to Disable Action',
	[LogEventId.LOG_CFG_EXT_INPUT_ACTION_FOR_SHORT_NONE]:
		'GPI Action for Short (Balanced) set to None',
	[LogEventId.LOG_CFG_EXT_INPUT_ACTION_FOR_SHORT_RESET]:
		'GPI Action for Short (Balanced) set to Reset',
	[LogEventId.LOG_CFG_EXT_INPUT_ACTION_FOR_SHORT_TRIGGER_EXIT_FAULT]:
		'GPI Action for Short (Balanced) set to Trigger Exit Fault',
	[LogEventId.LOG_CFG_EXT_INPUT_ACTION_FOR_SHORT_PERFORME_DISABLE_ACTION]:
		'GPI Action for Short (Balanced) set to Disable Action',
	[LogEventId.LOG_CFG_EXT_INPUT_CHANGE_STATE_ACTION_NONE]:
		'GPI Action for Change State (Unbalanced) set to None',
	[LogEventId.LOG_CFG_EXT_INPUT_CHANGE_STATE_ACTION_RESET]:
		'GPI Action for Change State (Unbalanced) set to Reset',
	[LogEventId.LOG_CFG_EXT_INPUT_CHANGE_STATE_ACTION_TRIGGER_EXIT_FAULT]:
		'GPI Action for Change State (Unbalanced) set to Trigger Exit Fault',
	[LogEventId.LOG_CFG_EXT_INPUT_CHANGE_STATE_ACTION_PERFORME_DISABLE_ACTION]:
		'GPI Action for Change State (Unbalanced) set to Disable Action',
	[LogEventId.LOG_CFG_EXT_INPUT_UNBALANCED]: 'GPI Input Mode set to Unbalanced',
	[LogEventId.LOG_CFG_EXT_INPUT_BALANCED]: 'GPI Input Mode set to Balanced',
	[LogEventId.LOG_CFG_EXT_INPUT_NORMAL_STATE_OPEN]:
		'GPI Input State set to Open',
	[LogEventId.LOG_CFG_EXT_INPUT_NORMAL_STATE_SHORT]:
		'GPI Input State set to Short',
	[LogEventId.LOG_CFG_EXT_INPUT_NORMAL_STATE_EOL]: 'GPI Input State set to EOL',
	[LogEventId.LOG_CMD_SILENCE_BUZZER_CHINA]: 'Silence buzzer',
	[LogEventId.LOG_CFG_CH1_FLOW_FAULT_THRESHOLD_1_15_PERC]:
		'Ch1 Flow Fault Threshold set to 1-15%',
	[LogEventId.LOG_CFG_CH1_FLOW_FAULT_THRESHOLD_16_80_PERC]:
		'Ch1 Flow Fault Threshold set to 16-80%',
	[LogEventId.LOG_CFG_CH2_FLOW_FAULT_THRESHOLD_1_15_PERC]:
		'Ch2 Flow Fault Threshold set to 1-15%',
	[LogEventId.LOG_CFG_CH2_FLOW_FAULT_THRESHOLD_16_80_PERC]:
		'Ch2 Flow Fault Threshold set to 16-80%',
	[LogEventId.LOG_CFG_ALARM_DELAY_0_SECS]: 'Alarm delay set to 0 seconds',
	[LogEventId.LOG_CFG_ALARM_DELAY_GT_0_SECS]:
		'Alarm delay set to a value greater than 0 seconds',
	[LogEventId.LOG_CFG_PREALARM_DELAY_0_SECS]: 'Action delay set to 0 seconds',
	[LogEventId.LOG_CFG_PREALARM_DELAY_GT_0_SECS]:
		'Action delay set to a value greater than 0 seconds',
	[LogEventId.LOG_CFG_FLOW_FAULT_DELAY_LE_30_SECS]:
		'Flow Fault delay set to a value smaller than or equal to 30 seconds',
	[LogEventId.LOG_CFG_FLOW_FAULT_DELAY_GT_30_SECS]:
		'Flow Fault delay set to a value greater than 30 seconds',
	[LogEventId.LOG_CMD_RESET_FAULT]: 'Reset Alarms and Fault',
	[LogEventId.LOG_CMD_DISABLE_TIMOUT_NOT_ENABLED]:
		'Disable Timeout not enabled',
	[LogEventId.LOG_CMD_DISABLE_TIMOUT_ENABLED]: 'Disable Timeout enabled',
	[LogEventId.LOG_CFG_END]: 'Exit',
	[LogEventId.LOG_CFG_FAN_REPLACEMENT_COMPLETE]: 'Blower replacement completed',
	[LogEventId.LOG_CFG_RESTART_BY_SW_COMMAND]: 'Restart by SW command',
	[LogEventId.LOG_CFG_RESTART_AFTER_CONFIG]:
		'Restart after configuration change',
	[LogEventId.LOG_CFG_RESTART_AFTER_DF_RESTORE]:
		'Device reset after data-flash restore',
	[LogEventId.LOG_CFG_GPI_RESET_ALARMS_AND_FAULTS]:
		'Reset alarms and faults by GPI',
	[LogEventId.LOG_CFG_FACP_RESET_ALARMS_AND_FAULTS]:
		'Reset alarms and faults by FACP',
	[LogEventId.LOG_CFG_GENERAL_FAULT_UNLATCHED]: 'General fault relay unlatched',
	[LogEventId.LOG_CFG_GENERAL_FAULT_LATCHED]: 'General fault relay latched',
	[LogEventId.LOG_CFG_AUX_FAULT_UNLATCHED]: 'Auxiliary fault relay unlatched',
	[LogEventId.LOG_CFG_AUX_FAULT_LATCHED]: 'Auxiliary fault relay latched',
	[LogEventId.LOG_FAN_OLD_VAL_MINUS_6]: 'Fan old value -6',
	[LogEventId.LOG_FAN_OLD_VAL_MINUS_5]: 'Fan old value -5',
	[LogEventId.LOG_FAN_OLD_VAL_MINUS_4]: 'Fan old value -4',
	[LogEventId.LOG_FAN_OLD_VAL_MINUS_3]: 'Fan old value -3',
	[LogEventId.LOG_FAN_OLD_VAL_MINUS_2]: 'Fan old value -2',
	[LogEventId.LOG_FAN_OLD_VAL_MINUS_1]: 'Fan old value -1',
	[LogEventId.LOG_FAN_OLD_VAL_0]: 'Fan old value 0',
	[LogEventId.LOG_FAN_OLD_VAL_1]: 'Fan old value 1',
	[LogEventId.LOG_FAN_OLD_VAL_2]: 'Fan old value 2',
	[LogEventId.LOG_FAN_OLD_VAL_3]: 'Fan old value 3',
	[LogEventId.LOG_FAN_OLD_VAL_4]: 'Fan old value 4',
	[LogEventId.LOG_FAN_OLD_VAL_5]: 'Fan old value 5',
	[LogEventId.LOG_FAN_OLD_VAL_6]: 'Fan old value 6',
	[LogEventId.LOG_FU_SUCCESS]: 'Firmware update success',
	[LogEventId.LOG_FU_GENERIC_ERROR]: 'Firmware update generic error',
	[LogEventId.LOG_FU_USB_DRIVE_NOT_FOUND]:
		'Firmware update USB drive not found',
	[LogEventId.LOG_FU_PACKAGE_NOT_VALID]: 'Firmware update package not valid',
	[LogEventId.LOG_FU_FLASH_WRITING_ERROR]:
		'Firmware update flash writing error',
	[LogEventId.LOG_FU_MODULE_UPDATE_ERROR]: 'Firmware update module error',
	[LogEventId.LOG_FU_MODULE_UPDATE_TIMEOUT]: 'Firmware update module timeout',
	[LogEventId.LOG_FU_USB_READING_ERROR]: 'Firmware update USB reading error',
	[LogEventId.LOG_EXIT_MODULE_COMM_FAULT]:
		'Exit from module communication fault',
	[LogEventId.LOG_GPI_SET_OPEN_ACT_RESET_ALARMS]:
		'GPI set open action reset alarms',
	[LogEventId.LOG_GPI_SET_SHORT_ACT_RESET_ALARMS]:
		'GPI set short action reset alarms',
	[LogEventId.LOG_GPI_SET_CS_ACT_RESET_ALARMS]:
		'GPI set change state action reset alarms',
	[LogEventId.LOG_CFG_DEVICE_RESET_AFTER_CLOSING_COVER]:
		'Device reset after closing cover',
};
export function getLogEventIdDescription(id: LogEventId): string {
	return LogEventIdDescription[id] ?? id.toString();
}
export enum LogEventType {
	eAlarm,
	eFaultandAlert,
	eSystem,
	eUserAction,
	eUnknown,
}
export const LogEventTypeDescription: Record<LogEventType, string> = {
	[LogEventType.eAlarm]: 'Alarm',
	[LogEventType.eFaultandAlert]: 'lblFaultandAlert',
	[LogEventType.eSystem]: 'lblSystem',
	[LogEventType.eUserAction]: 'lblUserAction',
	[LogEventType.eUnknown]: 'Unknown',
};

export function getLogEventTypeDescription(type: LogEventType): string {
	return LogEventTypeDescription[type] ?? type.toString();
}
export enum LogEventZone {
	eChannelOne,
	eChannelTwo,
	eNotApplicable,
	eUnknown,
}
export const LogEventZoneDescription: Record<LogEventZone, string> = {
	[LogEventZone.eChannelOne]: 'Channel 1',
	[LogEventZone.eChannelTwo]: 'Channel 2',
	[LogEventZone.eNotApplicable]: 'NA',
	[LogEventZone.eUnknown]: 'Unknown',
};
export function getLogEventZoneDescription(zone: LogEventZone): string {
	return LogEventZoneDescription[zone] ?? zone.toString();
}

export function getEventTypeFromEventId(logEventId: LogEventId): LogEventType {
	let retVal: LogEventType;

	switch (logEventId) {
		// #region Alarms Event Logs
		case LogEventId.LOG_CH1_PREALARM:
		case LogEventId.LOG_CH1_ALARM:
		case LogEventId.LOG_CH2_PREALARM:
		case LogEventId.LOG_CH2_ALARM:
		case LogEventId.LOG_EXIT_CH1_PREALARM:
		case LogEventId.LOG_EXIT_CH1_ALARM:
		case LogEventId.LOG_EXIT_CH2_PREALARM:
		case LogEventId.LOG_EXIT_CH2_ALARM:
			retVal = LogEventType.eAlarm;
			break;
		// #endregion

		// #region Faults and Alert
		case LogEventId.LOG_CONFIGURATION_FAULT:
		case LogEventId.LOG_EEPROM_FAULT:
		case LogEventId.LOG_BLUETOOTH_FAULT:
		case LogEventId.LOG_GPI_EXTERNAL_FAULT:
		case LogEventId.LOG_CH1_ULTRASONIC_FAULT:
		case LogEventId.LOG_CH1_HS200_COMM_ERROR:
		case LogEventId.LOG_BLOWER_FAULT:
		case LogEventId.LOG_CH1_LOW_FLOW_FAULT:
		case LogEventId.LOG_CH1_HIGH_FLOW_FAULT:
		case LogEventId.LOG_CH2_ULTRASONIC_FAULT:
		case LogEventId.LOG_CH2_HS200_COMM_ERROR:
		case LogEventId.LOG_CH2_LOW_FLOW_FAULT:
		case LogEventId.LOG_CH2_HIGH_FLOW_FAULT:
		case LogEventId.LOG_HIGH_POWER_FAULT:
		case LogEventId.LOG_DATA_FLASH_FAULT:
		case LogEventId.LOG_EEPROM_CHECKSUM_FAULT:
		case LogEventId.LOG_CH1_SENSOR_DIRTY_FAULT:
		case LogEventId.LOG_CH2_SENSOR_DIRTY_FAULT:
		case LogEventId.LOG_EVENT_EEPROM_WRITING_FAILURE:
		case LogEventId.LOG_EXIT_RTC_READ_WRITE_FAULT:
		case LogEventId.LOG_GENERIC_FAULT_SERVICE:
		case LogEventId.LOG_GENERIC_FAULT_INITIALIZATION:
		case LogEventId.LOG_GENERIC_FAULT_WAIT:
		case LogEventId.LOG_GENERIC_FAULT_NORMAL:
		case LogEventId.LOG_RTC_DATA_NOT_CONSISTENT:
		case LogEventId.LOG_CH1_HIGH_TEMPERATURE_ALERT:
		case LogEventId.LOG_CH1_LOW_TEMPERATURE_ALERT:
		case LogEventId.LOG_CH2_HIGH_TEMPERATURE_ALERT:
		case LogEventId.LOG_CH2_LOW_TEMPERATURE_ALERT:
		case LogEventId.LOG_LOW_SUPPLY_VOLTAGE_ALERT:
		case LogEventId.LOG_CH1_SENSOR_DIRTY_ALERT_N1:
		case LogEventId.LOG_CH1_SENSOR_DIRTY_ALERT_N2:
		case LogEventId.LOG_CH2_SENSOR_DIRTY_ALERT_N1:
		case LogEventId.LOG_CH2_SENSOR_DIRTY_ALERT_N2:
		case LogEventId.LOG_SUPPLY_VOLT_BELOW_EEPROM_WORKING_VOLT:
		case LogEventId.LOG_RTC_READ_WRITE_FAULT:
		case LogEventId.LOG_RAM_CONSISTENCY_FAILURE:
		case LogEventId.LOG_EXIT_BLUETOOTH_FAULT:
		case LogEventId.LOG_EXIT_GPI_EXTERNAL_FAULT:
		case LogEventId.LOG_EXIT_CH1_ULTRASONIC_FAULT:
		case LogEventId.LOG_EXIT_CH1_HS200_COMM_ERROR:
		case LogEventId.LOG_EXIT_BLOWER_FAULT:
		case LogEventId.LOG_EXIT_CH1_LOW_FLOW_FAULT:
		case LogEventId.LOG_EXIT_CH1_HIGH_FLOW_FAULT:
		case LogEventId.LOG_EXIT_CH2_ULTRASONIC_FAULT:
		case LogEventId.LOG_EXIT_CH2_HS200_COMM_ERROR:
		case LogEventId.LOG_EXIT_CH2_LOW_FLOW_FAULT:
		case LogEventId.LOG_EXIT_CH2_HIGH_FLOW_FAULT:
		case LogEventId.LOG_EXIT_CH1_SENSOR_DIRTY_FAULT:
		case LogEventId.LOG_EXIT_CH2_SENSOR_DIRTY_FAULT:
		case LogEventId.LOG_EXIT_RTC_DATA_NOT_CONSISTENT:
		case LogEventId.LOG_EXIT_CH1_HIGH_TEMPERATURE_ALERT:
		case LogEventId.LOG_EXIT_CH1_LOW_TEMPERATURE_ALERT:
		case LogEventId.LOG_EXIT_CH2_HIGH_TEMPERATURE_ALERT:
		case LogEventId.LOG_EXIT_CH2_LOW_TEMPERATURE_ALERT:
		case LogEventId.LOG_EXIT_LOW_SUPPLY_VOLTAGE_ALERT:
		case LogEventId.LOG_EXIT_CH1_SENSOR_DIRTY_ALERT_N1:
		case LogEventId.LOG_EXIT_CH1_SENSOR_DIRTY_ALERT_N2:
		case LogEventId.LOG_EXIT_CH2_SENSOR_DIRTY_ALERT_N1:
		case LogEventId.LOG_EXIT_CH2_SENSOR_DIRTY_ALERT_N2:
		case LogEventId.LOG_EXIT_SUPPLY_VOLT_BELOW_EEPROM_WORKING_VOLT:
		case LogEventId.LOG__EXIT_E2_CONFIG_DIFF_DIPSWITCH_FAULT:
			retVal = LogEventType.eFaultandAlert;
			break;
		// #endregion

		// #region User Action Event Logs
		case LogEventId.LOG_CFG_CHANGE_PWD_NEEDED:
		case LogEventId.LOG_CFG_CH1_ALARM_UNLATCHED:
		case LogEventId.LOG_CFG_CH1_ALARM_LATCHED:
		case LogEventId.LOG_CFG_CH2_ALARM_UNLATCHED:
		case LogEventId.LOG_CFG_CH2_ALARM_LATCHED:
		case LogEventId.LOG_CFG_CH1_PREALARM_UNLATCHED:
		case LogEventId.LOG_CFG_CH1_PREALARM_LATCHED:
		case LogEventId.LOG_CFG_CH2_PREALARM_UNLATCHED:
		case LogEventId.LOG_CFG_CH2_PREALARM_LATCHED:
		case LogEventId.LOG_CFG_CH1_FAULT_UNLATCHED:
		case LogEventId.LOG_CFG_CH1_FAULT_LATCHED:
		case LogEventId.LOG_CFG_CH2_FAULT_UNLATCHED:
		case LogEventId.LOG_CFG_CH2_FAUT_LATCHED:
		case LogEventId.LOG_CFG_ALARM_MODE_CUMULATIVE:
		case LogEventId.LOG_CFG_ALARM_MODE_INSTANTANEOUS:
		case LogEventId.LOG_CFG_RELAY_FOR_TEMPERATURE_UNSET:
		case LogEventId.LOG_CFG_RELAY_FOR_TEMPERATURE_SET:
		case LogEventId.LOG_CFG_RELAY_FOR_LOW_POWER_UNSET:
		case LogEventId.LOG_CFG_RELAY_FOR_LOW_POWER_SET:
		case LogEventId.LOG_CFG_FAN_SPEED_0:
		case LogEventId.LOG_CFG_FAN_SPEED_1:
		case LogEventId.LOG_CFG_FAN_SPEED_2:
		case LogEventId.LOG_CFG_FAN_SPEED_3:
		case LogEventId.LOG_CFG_FAN_SPEED_4:
		case LogEventId.LOG_CFG_FAN_SPEED_5:
		case LogEventId.LOG_CFG_FAN_SPEED_6:
		case LogEventId.LOG_CFG_FAN_SPEED_7:
		case LogEventId.LOG_CFG_FAN_SPEED_8:
		case LogEventId.LOG_CFG_FAN_SPEED_9:
		case LogEventId.LOG_CFG_FAN_SPEED_10:
		case LogEventId.LOG_CFG_CH1_ALARM_LEVEL_0:
		case LogEventId.LOG_CFG_CH1_ALARM_LEVEL_1:
		case LogEventId.LOG_CFG_CH1_ALARM_LEVEL_2:
		case LogEventId.LOG_CFG_CH1_ALARM_LEVEL_3:
		case LogEventId.LOG_CFG_CH1_ALARM_LEVEL_4:
		case LogEventId.LOG_CFG_CH1_ALARM_LEVEL_5:
		case LogEventId.LOG_CFG_CH1_ALARM_LEVEL_6:
		case LogEventId.LOG_CFG_CH1_ALARM_LEVEL_7:
		case LogEventId.LOG_CFG_CH1_ALARM_LEVEL_8:
		case LogEventId.LOG_CFG_CH1_ALARM_LEVEL_9:
		case LogEventId.LOG_CFG_CH2_ALARM_LEVEL_0:
		case LogEventId.LOG_CFG_CH2_ALARM_LEVEL_1:
		case LogEventId.LOG_CFG_CH2_ALARM_LEVEL_2:
		case LogEventId.LOG_CFG_CH2_ALARM_LEVEL_3:
		case LogEventId.LOG_CFG_CH2_ALARM_LEVEL_4:
		case LogEventId.LOG_CFG_CH2_ALARM_LEVEL_5:
		case LogEventId.LOG_CFG_CH2_ALARM_LEVEL_6:
		case LogEventId.LOG_CFG_CH2_ALARM_LEVEL_7:
		case LogEventId.LOG_CFG_CH2_ALARM_LEVEL_8:
		case LogEventId.LOG_CFG_CH2_ALARM_LEVEL_9:
		case LogEventId.LOG_CFG_CH1_PREALARM_LEVEL_0:
		case LogEventId.LOG_CFG_CH1_PREALARM_LEVEL_1:
		case LogEventId.LOG_CFG_CH1_PREALARM_LEVEL_2:
		case LogEventId.LOG_CFG_CH1_PREALARM_LEVEL_3:
		case LogEventId.LOG_CFG_CH1_PREALARM_LEVEL_4:
		case LogEventId.LOG_CFG_CH1_PREALARM_LEVEL_5:
		case LogEventId.LOG_CFG_CH1_PREALARM_LEVEL_6:
		case LogEventId.LOG_CFG_CH1_PREALARM_LEVEL_7:
		case LogEventId.LOG_CFG_CH1_PREALARM_LEVEL_8:
		case LogEventId.LOG_CFG_CH1_PREALARM_LEVEL_9:
		case LogEventId.LOG_CFG_CH2_PREALARM_LEVEL_0:
		case LogEventId.LOG_CFG_CH2_PREALARM_LEVEL_1:
		case LogEventId.LOG_CFG_CH2_PREALARM_LEVEL_2:
		case LogEventId.LOG_CFG_CH2_PREALARM_LEVEL_3:
		case LogEventId.LOG_CFG_CH2_PREALARM_LEVEL_4:
		case LogEventId.LOG_CFG_CH2_PREALARM_LEVEL_5:
		case LogEventId.LOG_CFG_CH2_PREALARM_LEVEL_6:
		case LogEventId.LOG_CFG_CH2_PREALARM_LEVEL_7:
		case LogEventId.LOG_CFG_CH2_PREALARM_LEVEL_8:
		case LogEventId.LOG_CFG_CH2_PREALARM_LEVEL_9:
		case LogEventId.LOG_CFG_EXT_INPUT_ACTION_FOR_OPEN_NONE:
		case LogEventId.LOG_CFG_EXT_INPUT_ACTION_FOR_OPEN_RESET:
		case LogEventId.LOG_CFG_EXT_INPUT_ACTION_FOR_OPEN_TRIGGER_EXIT_FAULT:
		case LogEventId.LOG_CFG_EXT_INPUT_ACTION_FOR_OPEN_PERFORME_DISABLE_ACTION:
		case LogEventId.LOG_CFG_EXT_INPUT_ACTION_FOR_SHORT_NONE:
		case LogEventId.LOG_CFG_EXT_INPUT_ACTION_FOR_SHORT_RESET:
		case LogEventId.LOG_CFG_EXT_INPUT_ACTION_FOR_SHORT_TRIGGER_EXIT_FAULT:
		case LogEventId.LOG_CFG_EXT_INPUT_ACTION_FOR_SHORT_PERFORME_DISABLE_ACTION:
		case LogEventId.LOG_CFG_EXT_INPUT_CHANGE_STATE_ACTION_NONE:
		case LogEventId.LOG_CFG_EXT_INPUT_CHANGE_STATE_ACTION_RESET:
		case LogEventId.LOG_CFG_EXT_INPUT_CHANGE_STATE_ACTION_TRIGGER_EXIT_FAULT:
		case LogEventId.LOG_CFG_EXT_INPUT_CHANGE_STATE_ACTION_PERFORME_DISABLE_ACTION:
		case LogEventId.LOG_CFG_EXT_INPUT_UNBALANCED:
		case LogEventId.LOG_CFG_EXT_INPUT_BALANCED:
		case LogEventId.LOG_CFG_EXT_INPUT_NORMAL_STATE_OPEN:
		case LogEventId.LOG_CFG_EXT_INPUT_NORMAL_STATE_SHORT:
		case LogEventId.LOG_CFG_EXT_INPUT_NORMAL_STATE_EOL:
		case LogEventId.LOG_CMD_SILENCE_BUZZER_CHINA:
		case LogEventId.LOG_CFG_CH1_FLOW_FAULT_THRESHOLD_1_15_PERC:
		case LogEventId.LOG_CFG_CH1_FLOW_FAULT_THRESHOLD_16_80_PERC:
		case LogEventId.LOG_CFG_CH2_FLOW_FAULT_THRESHOLD_1_15_PERC:
		case LogEventId.LOG_CFG_CH2_FLOW_FAULT_THRESHOLD_16_80_PERC:
		case LogEventId.LOG_CFG_ALARM_DELAY_0_SECS:
		case LogEventId.LOG_CFG_ALARM_DELAY_GT_0_SECS:
		case LogEventId.LOG_CFG_PREALARM_DELAY_0_SECS:
		case LogEventId.LOG_CFG_PREALARM_DELAY_GT_0_SECS:
		case LogEventId.LOG_CFG_FLOW_FAULT_DELAY_LE_30_SECS:
		case LogEventId.LOG_CFG_FLOW_FAULT_DELAY_GT_30_SECS:
		case LogEventId.LOG_CMD_RESET_FAULT:
		case LogEventId.LOG_CFG_END:
		case LogEventId.LOG_EVENT_COVER_OPENED:
		case LogEventId.LOG_EVENT_COVER_CLOSED:
		case LogEventId.LOG_EVENT_PASSWORD_ENTRY:
		case LogEventId.LOG_EVENT_PASSWORD_MODIFIED:
		case LogEventId.LOG_EVENT_PASSWORD_CORRECT:
		case LogEventId.LOG_EVENT_PASSWORD_INCORRECT:
		case LogEventId.LOG_EVENT_EUROPE_TEST_START:
		case LogEventId.LOG_EVENT_EUROPE_TEST_COMPLETE:
		case LogEventId.LOG_EVENT_EUROPE_TEST_LOG_WRITTEN:
		case LogEventId.LOG_EVENT_CHINA_TEST_START:
		case LogEventId.LOG_EVENT_CHINA_TEST_COMPLETE:
		case LogEventId.LOG_EVENT_NORMALIZE_START:
		case LogEventId.LOG_EVENT_NORMALOVER:
		case LogEventId.LOG_EVENT_NORMALIZE_FAILED_FOR_INSTABLE_FLOW:
		case LogEventId.LOG_EVENT_NORMALIZE_FAILED_FOR_OUT_OF_RANGE_FLOW:
		case LogEventId.LOG_EVENT_RESET_ALARM_FAULT_STARTED:
		case LogEventId.LOG_EVENT_CONFIGURATION_START:
		case LogEventId.LOG_EVENT_LOGSTARTED:
		case LogEventId.LOG_EVENT_LOGOVER:
		case LogEventId.LOG_EVENT_DISABLE_BUZZER_EUROPE:
		case LogEventId.LOG_EVENT_DISABLE_BUZZER_CHINA:
		case LogEventId.LOG_EVENT_WAITING_FOR_COVER:
		case LogEventId.LOG_EVENT_PAIRING_TENTATIVE:
		case LogEventId.LOG_EVENT_PAIRING_DONE:
		case LogEventId.LOG_EVENT_E2P_FACTORY_RESTORE_FAILED:
		case LogEventId.LOG_EVENT_E2P_FACTORY_RESTORE_SUCCESS:
		case LogEventId.LOG_EVENT_PASSWORD_RECOVERY:
		case LogEventId.LOG_EVENT_CONFIGURATION_OVER:
		case LogEventId.LOG_EVENT_CONFIGURATION_OVER_FOR_TIMEOUT:
		case LogEventId.LOG_EVENT_PASSWORD_INCORRECT_FOR_TIMEOUT:
		case LogEventId.LOG_EVENT_PASSWORD_MODIFY_EXIT_FOR_TIMEOUT:
		case LogEventId.LOG_EVENT_HOUR_CHANGED:
		case LogEventId.LOG_EVENT_START_PASSWORD_CHANGE:
		case LogEventId.LOG_EVENT_EUROPE_TEST_ABORT_BY_APP:
		case LogEventId.LOG_CLEAR_LOG_EVENT:
		case LogEventId.LOG_EVENT_ENABLE_BUZZER_EUROPE:
		case LogEventId.LOG_TEST_FAILED_EVENT:
		case LogEventId.LOG_PASSWORD_BTAPP_INCORRECT_EVENT:
		case LogEventId.LOG_E2_CONFIG_DIFF_DIPSWITCH_FAULT:
		case LogEventId.LOG_FAN_REPLACEMENT_START:
		case LogEventId.LOG_FAN_REPLACEMENT_ABORT:
		case LogEventId.LOG_FAN_REPLACE_TIMEOUT:
		case LogEventId.LOG_CONFIGURATION_ABORT_BY_BUTTON:
		case LogEventId.LOG_CONFIGURATION_ABORT_BY_COVER:
		case LogEventId.LOG_STARTED_BT_HAND_PAIRING:
		case LogEventId.LOG_STARTED_BT_SOUND_PAIRING:
		case LogEventId.LOG_BLE_CONNECTED:
		case LogEventId.LOG_BLE_DISCONNECTED:
		case LogEventId.LOG_TOKEN_BY_BT_INCORRECT:
		case LogEventId.LOG_TOKEN_BY_BT_CORRECT:
		case LogEventId.LOG_NORMALIZE_ABORT_BY_COVER:
		case LogEventId.LOG_NORMALIZE_ABORT_NVM_FAULT:
		case LogEventId.LOG_CH1_SENSOR_REPLACED:
		case LogEventId.LOG_CH2_SENSOR_REPLACED:
		case LogEventId.LOG_CFG_FAN_REPLACEMENT_COMPLETE:
		case LogEventId.LOG_CFG_RESTART_BY_SW_COMMAND:
		case LogEventId.LOG_CFG_RESTART_AFTER_CONFIG:
		case LogEventId.LOG_CFG_RESTART_AFTER_DF_RESTORE:
		case LogEventId.LOG_CFG_GPI_RESET_ALARMS_AND_FAULTS:
		case LogEventId.LOG_CFG_FACP_RESET_ALARMS_AND_FAULTS:
		case LogEventId.LOG_GPI_SET_OPEN_ACT_RESET_ALARMS:
		case LogEventId.LOG_GPI_SET_SHORT_ACT_RESET_ALARMS:
		case LogEventId.LOG_GPI_SET_CS_ACT_RESET_ALARMS:
		case LogEventId.LOG_CFG_GENERAL_FAULT_UNLATCHED:
		case LogEventId.LOG_CFG_GENERAL_FAULT_LATCHED:
		case LogEventId.LOG_CFG_AUX_FAULT_UNLATCHED:
		case LogEventId.LOG_CFG_AUX_FAULT_LATCHED:
		case LogEventId.LOG_CFG_DEVICE_RESET_AFTER_CLOSING_COVER:
			retVal = LogEventType.eUserAction;
			break;
		// #endregion

		// #region System Event Logs
		case LogEventId.LOG_EVENT_NONE:
		case LogEventId.LOG_EVENT_POWER_ON:
		case LogEventId.LOG_EVENT_DISABLE_START:
		case LogEventId.LOG_EVENT_DISABLE_OVER:
		case LogEventId.LOG_EVENT_GPI_RESET_DEVICE:
		case LogEventId.LOG_EVENT_GPI_START_DISABLE:
		case LogEventId.LOG_EVENT_GPI_STOP_DISABLE:
		case LogEventId.LOG_EVENT_TO_PROTECTION:
		case LogEventId.LOG_EVENT_TO_NORMAL:
		case LogEventId.LOG_EVENT_TO_WAIT:
		case LogEventId.LOG_EVENT_TO_SERVICE:
		case LogEventId.LOG_EVENT_PID_STARTED:
		case LogEventId.LOG_EVENT_PID_OVER:
		case LogEventId.LOG_EVENT_DISABLE_EXIT_FOR_TIMEOUT:
		case LogEventId.LOG_TREND_LOG_EVENT:
		case LogEventId.LOG_PID_OVER_AT_POWER_ON:
		case LogEventId.LOG_PID_STARTED_AT_POWER_ON:
		case LogEventId.LOG_STATE_MACHINE_DEFAULT_HANDLER:
		case LogEventId.LOG_CMD_DISABLE_TIMOUT_NOT_ENABLED:
		case LogEventId.LOG_CMD_DISABLE_TIMOUT_ENABLED:
		case LogEventId.LOG_FAN_OLD_VAL_MINUS_6:
		case LogEventId.LOG_FAN_OLD_VAL_MINUS_5:
		case LogEventId.LOG_FAN_OLD_VAL_MINUS_4:
		case LogEventId.LOG_FAN_OLD_VAL_MINUS_3:
		case LogEventId.LOG_FAN_OLD_VAL_MINUS_2:
		case LogEventId.LOG_FAN_OLD_VAL_MINUS_1:
		case LogEventId.LOG_FAN_OLD_VAL_0:
		case LogEventId.LOG_FAN_OLD_VAL_1:
		case LogEventId.LOG_FAN_OLD_VAL_2:
		case LogEventId.LOG_FAN_OLD_VAL_3:
		case LogEventId.LOG_FAN_OLD_VAL_4:
		case LogEventId.LOG_FAN_OLD_VAL_5:
		case LogEventId.LOG_FAN_OLD_VAL_6:
		case LogEventId.LOG_PARAMETER_OUT_OF_RANGE:
		case LogEventId.LOG_MODULE_BOOT_REQUESTED:
		case LogEventId.LOG_FIRMWARE_RELEASE_MISMATCH:
		case LogEventId.LOG_FIRMWARE_UPDATE_REQUESTED:
		case LogEventId.LOG_FU_SUCCESS:
		case LogEventId.LOG_FU_GENERIC_ERROR:
		case LogEventId.LOG_FU_USB_DRIVE_NOT_FOUND:
		case LogEventId.LOG_FU_PACKAGE_NOT_VALID:
		case LogEventId.LOG_FU_FLASH_WRITING_ERROR:
		case LogEventId.LOG_FU_MODULE_UPDATE_ERROR:
		case LogEventId.LOG_FU_MODULE_UPDATE_TIMEOUT:
		case LogEventId.LOG_FU_USB_READING_ERROR:
		case LogEventId.LOG_MODULE_COMM_FAULT:
		case LogEventId.LOG_ASD_EEPROM_FAILURE:
		case LogEventId.LOG_MAINTENANCE_ALERT:
		case LogEventId.LOG_MODULE_EEPROM_FAULT:
		case LogEventId.LOG_EXIT_MODULE_COMM_FAULT:
		case LogEventId.LOG_EXIT_MAINTENANCE_ALERT:
		case LogEventId.LOG_EXIT_MODULE_EEPROM_FAULT:
		case LogEventId.LOG_THRESHOLD_CALIB_START:
		case LogEventId.LOG_THRESHOLD_CALIB_INV_INPUT:
		case LogEventId.LOG_THRESHOLD_CALIB_CH1_FAILED:
		case LogEventId.LOG_THRESHOLD_CALIB_CH2_FAILED:
		case LogEventId.LOG_THRESHOLD_CALIB_CH1_SUCCESS:
		case LogEventId.LOG_THRESHOLD_CALIB_CH2_SUCCESS:
		case LogEventId.SPARE_1:
		case LogEventId.SPARE_2:
		case LogEventId.SPARE_3:
		case LogEventId.SPARE_4:
		case LogEventId.LOG_SPARE1116:
		case LogEventId.LOG_SPARE1118:
		case LogEventId.LOG_SPARE1119:
			retVal = LogEventType.eSystem;
			break;
		// #endregion

		default:
			retVal = LogEventType.eUnknown;
			break;
	}

	return retVal;
}

export function getEventZoneFromEventId(logEventId: LogEventId): LogEventZone {
	let retVal: LogEventZone;

	switch (logEventId) {
		case LogEventId.LOG_CH1_ULTRASONIC_FAULT:
		case LogEventId.LOG_CH1_HS200_COMM_ERROR:
		case LogEventId.LOG_CH1_LOW_FLOW_FAULT:
		case LogEventId.LOG_CH1_HIGH_FLOW_FAULT:
		case LogEventId.LOG_CH1_SENSOR_DIRTY_FAULT:
		case LogEventId.LOG_CH1_HIGH_TEMPERATURE_ALERT:
		case LogEventId.LOG_CH1_LOW_TEMPERATURE_ALERT:
		case LogEventId.LOG_CH1_SENSOR_DIRTY_ALERT_N1:
		case LogEventId.LOG_CH1_SENSOR_DIRTY_ALERT_N2:
		case LogEventId.LOG_CH1_PREALARM:
		case LogEventId.LOG_CH1_ALARM:
		case LogEventId.LOG_EXIT_CH1_ULTRASONIC_FAULT:
		case LogEventId.LOG_EXIT_CH1_HS200_COMM_ERROR:
		case LogEventId.LOG_EXIT_CH1_LOW_FLOW_FAULT:
		case LogEventId.LOG_EXIT_CH1_HIGH_FLOW_FAULT:
		case LogEventId.LOG_EXIT_CH1_SENSOR_DIRTY_FAULT:
		case LogEventId.LOG_EXIT_CH1_HIGH_TEMPERATURE_ALERT:
		case LogEventId.LOG_EXIT_CH1_LOW_TEMPERATURE_ALERT:
		case LogEventId.LOG_EXIT_CH1_SENSOR_DIRTY_ALERT_N1:
		case LogEventId.LOG_EXIT_CH1_SENSOR_DIRTY_ALERT_N2:
		case LogEventId.LOG_EXIT_CH1_PREALARM:
		case LogEventId.LOG_EXIT_CH1_ALARM:
		case LogEventId.LOG_CFG_CH1_ALARM_UNLATCHED:
		case LogEventId.LOG_CFG_CH1_ALARM_LATCHED:
		case LogEventId.LOG_CFG_CH1_PREALARM_UNLATCHED:
		case LogEventId.LOG_CFG_CH1_PREALARM_LATCHED:
		case LogEventId.LOG_CFG_CH1_FAULT_UNLATCHED:
		case LogEventId.LOG_CFG_CH1_FAULT_LATCHED:
		case LogEventId.LOG_CFG_CH1_ALARM_LEVEL_0:
		case LogEventId.LOG_CFG_CH1_ALARM_LEVEL_1:
		case LogEventId.LOG_CFG_CH1_ALARM_LEVEL_2:
		case LogEventId.LOG_CFG_CH1_ALARM_LEVEL_3:
		case LogEventId.LOG_CFG_CH1_ALARM_LEVEL_4:
		case LogEventId.LOG_CFG_CH1_ALARM_LEVEL_5:
		case LogEventId.LOG_CFG_CH1_ALARM_LEVEL_6:
		case LogEventId.LOG_CFG_CH1_ALARM_LEVEL_7:
		case LogEventId.LOG_CFG_CH1_ALARM_LEVEL_8:
		case LogEventId.LOG_CFG_CH1_ALARM_LEVEL_9:
		case LogEventId.LOG_CFG_CH1_PREALARM_LEVEL_0:
		case LogEventId.LOG_CFG_CH1_PREALARM_LEVEL_1:
		case LogEventId.LOG_CFG_CH1_PREALARM_LEVEL_2:
		case LogEventId.LOG_CFG_CH1_PREALARM_LEVEL_3:
		case LogEventId.LOG_CFG_CH1_PREALARM_LEVEL_4:
		case LogEventId.LOG_CFG_CH1_PREALARM_LEVEL_5:
		case LogEventId.LOG_CFG_CH1_PREALARM_LEVEL_6:
		case LogEventId.LOG_CFG_CH1_PREALARM_LEVEL_7:
		case LogEventId.LOG_CFG_CH1_PREALARM_LEVEL_8:
		case LogEventId.LOG_CFG_CH1_PREALARM_LEVEL_9:
		case LogEventId.LOG_CFG_CH1_FLOW_FAULT_THRESHOLD_1_15_PERC:
		case LogEventId.LOG_CFG_CH1_FLOW_FAULT_THRESHOLD_16_80_PERC:
		case LogEventId.LOG_THRESHOLD_CALIB_CH1_FAILED:
		case LogEventId.LOG_THRESHOLD_CALIB_CH1_SUCCESS:
		case LogEventId.LOG_CH1_SENSOR_REPLACED:
			retVal = LogEventZone.eChannelOne;
			break;

		case LogEventId.LOG_CH2_ULTRASONIC_FAULT:
		case LogEventId.LOG_CH2_HS200_COMM_ERROR:
		case LogEventId.LOG_CH2_LOW_FLOW_FAULT:
		case LogEventId.LOG_CH2_HIGH_FLOW_FAULT:
		case LogEventId.LOG_CH2_SENSOR_DIRTY_FAULT:
		case LogEventId.LOG_CH2_HIGH_TEMPERATURE_ALERT:
		case LogEventId.LOG_CH2_LOW_TEMPERATURE_ALERT:
		case LogEventId.LOG_CH2_SENSOR_DIRTY_ALERT_N1:
		case LogEventId.LOG_CH2_SENSOR_DIRTY_ALERT_N2:
		case LogEventId.LOG_CH2_PREALARM:
		case LogEventId.LOG_CH2_ALARM:
		case LogEventId.LOG_EXIT_CH2_ULTRASONIC_FAULT:
		case LogEventId.LOG_EXIT_CH2_HS200_COMM_ERROR:
		case LogEventId.LOG_EXIT_CH2_LOW_FLOW_FAULT:
		case LogEventId.LOG_EXIT_CH2_HIGH_FLOW_FAULT:
		case LogEventId.LOG_EXIT_CH2_SENSOR_DIRTY_FAULT:
		case LogEventId.LOG_EXIT_CH2_HIGH_TEMPERATURE_ALERT:
		case LogEventId.LOG_EXIT_CH2_LOW_TEMPERATURE_ALERT:
		case LogEventId.LOG_EXIT_CH2_SENSOR_DIRTY_ALERT_N1:
		case LogEventId.LOG_EXIT_CH2_SENSOR_DIRTY_ALERT_N2:
		case LogEventId.LOG_EXIT_CH2_PREALARM:
		case LogEventId.LOG_EXIT_CH2_ALARM:
		case LogEventId.LOG_CFG_CH2_ALARM_UNLATCHED:
		case LogEventId.LOG_CFG_CH2_ALARM_LATCHED:
		case LogEventId.LOG_CFG_CH2_PREALARM_UNLATCHED:
		case LogEventId.LOG_CFG_CH2_PREALARM_LATCHED:
		case LogEventId.LOG_CFG_CH2_FAULT_UNLATCHED:
		case LogEventId.LOG_CFG_CH2_FAUT_LATCHED:
		case LogEventId.LOG_CFG_CH2_ALARM_LEVEL_0:
		case LogEventId.LOG_CFG_CH2_ALARM_LEVEL_1:
		case LogEventId.LOG_CFG_CH2_ALARM_LEVEL_2:
		case LogEventId.LOG_CFG_CH2_ALARM_LEVEL_3:
		case LogEventId.LOG_CFG_CH2_ALARM_LEVEL_4:
		case LogEventId.LOG_CFG_CH2_ALARM_LEVEL_5:
		case LogEventId.LOG_CFG_CH2_ALARM_LEVEL_6:
		case LogEventId.LOG_CFG_CH2_ALARM_LEVEL_7:
		case LogEventId.LOG_CFG_CH2_ALARM_LEVEL_8:
		case LogEventId.LOG_CFG_CH2_ALARM_LEVEL_9:
		case LogEventId.LOG_CFG_CH2_PREALARM_LEVEL_0:
		case LogEventId.LOG_CFG_CH2_PREALARM_LEVEL_1:
		case LogEventId.LOG_CFG_CH2_PREALARM_LEVEL_2:
		case LogEventId.LOG_CFG_CH2_PREALARM_LEVEL_3:
		case LogEventId.LOG_CFG_CH2_PREALARM_LEVEL_4:
		case LogEventId.LOG_CFG_CH2_PREALARM_LEVEL_5:
		case LogEventId.LOG_CFG_CH2_PREALARM_LEVEL_6:
		case LogEventId.LOG_CFG_CH2_PREALARM_LEVEL_7:
		case LogEventId.LOG_CFG_CH2_PREALARM_LEVEL_8:
		case LogEventId.LOG_CFG_CH2_PREALARM_LEVEL_9:
		case LogEventId.LOG_CFG_CH2_FLOW_FAULT_THRESHOLD_1_15_PERC:
		case LogEventId.LOG_CFG_CH2_FLOW_FAULT_THRESHOLD_16_80_PERC:
		case LogEventId.LOG_THRESHOLD_CALIB_CH2_FAILED:
		case LogEventId.LOG_THRESHOLD_CALIB_CH2_SUCCESS:
		case LogEventId.LOG_CH2_SENSOR_REPLACED:
			retVal = LogEventZone.eChannelTwo;
			break;

		default:
			retVal = LogEventZone.eNotApplicable;
			break;
	}

	return retVal;
}
