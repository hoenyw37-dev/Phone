import {
	AnswerLength,
	ErrorCode,
	DeviceStatus,
	GclCmd,
	Configuration,
	Country,
	RelayEnabled,
	Channel,
	AlarmFaultStatus,
	AnswerByteParamIndex,
	DeviceType,
	PasswordValid,
	GclSubCmdT,
} from '../faastflexCommands/commandEnum';
import {
	HEADER_SIZE,
	SW_COMM_CHECKSUM_BASE,
	MessageHeaderHandler,
	CommandDefault,
	ResponseParser,
} from '../faastflexCommands/command';
import { commonCommand } from '../faastflexCommands/CommonCommand';
import { min } from 'date-fns';

export class FaastFlexSetAlarmDelay {
	public static SetAlarmDelayEEPROM(
		param: { msg: Uint8Array },
		updateParam: number,
	): {
		errorCode: ErrorCode;
		byteToSend: number;
		byteToReceive: number;
	} {
		const { errorCode, byteToSend, byteToReceive } =
			commonCommand.subCmdWriteOneParamAnsAckOnly(
				param,
				GclSubCmdT.SW_CMD_ALARM_DELAY,
				updateParam,
			);
		return { errorCode, byteToSend, byteToReceive };
	}
	public static SetAlarmDelayEEPROMAnswer(
		param: { msg: Uint8Array },
		byteToBeReceived: number,
		byteReceived: number,
	): { retErrorCode: ErrorCode } {
		let retErrorCode: ErrorCode = ErrorCode.eERR_UNKNOWN;
		retErrorCode = ResponseParser.checkAnswerMsgValidity(
			param.msg,
			byteToBeReceived,
			byteReceived,
		);
		return { retErrorCode };
	}
}
