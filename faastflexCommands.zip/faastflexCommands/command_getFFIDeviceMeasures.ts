import {
	AnswerLength,
	ErrorCode,
	DeviceStatus,
	GclCmd,
	Configuration,
	Country,
	RelayEnabled,
	Channel,
	AlarmFaultStatus,
	AnswerByteParamIndex,
	SmokeAlarmLevel,
	AlarmLevel,
	PreAlarmLevel,
	FfIGclCmd,
} from '../faastflexCommands/commandEnum';
import {
	HEADER_SIZE,
	SW_COMM_CHECKSUM_BASE,
	MessageHeaderHandler,
	CommandDefault,
	ResponseParser,
} from '../faastflexCommands/command';
import { commonCommand } from '../faastflexCommands/CommonCommand';
import { DeviceMeasures } from '../faastflexCommands/common_objects';

interface ViewMeasuresResult {
	errorCode: ErrorCode;
	measures: DeviceMeasures;
}
export class FaastFlexIntelligentDeviceMeasures {
	public static GetFaastFlexIntelligentViewMeasures(param: {
		msg: Uint8Array;
	}): { errorCode: ErrorCode; byteToSend: number; byteToReceive: number } {
		const { errorCode, byteToSend, byteToReceive } =
			commonCommand.cmdNoParamAnsData(
				param,
				FfIGclCmd.FFI_SW_CMD_GET_FLOWMETER_MEASURES,
				AnswerLength.eSixteen,
			);

		return { errorCode, byteToSend, byteToReceive };
	}

	public static GetFaastFlexIntelligentViewMeasuresAnswer(
		param: { msg: Uint8Array },
		byteToBeReceived: number,
		byteReceived: number,
	): ViewMeasuresResult {
		const measures = new DeviceMeasures();
		let retErrorCode: ErrorCode = ErrorCode.eERR_UNKNOWN;
		let msg = param.msg;
		retErrorCode = ResponseParser.checkAnswerMsgValidity(
			param.msg,
			byteToBeReceived,
			byteReceived,
		);
		if (retErrorCode === ErrorCode.eOK) {
			let rpm = msg[1] + msg[2] * 256;
			measures.RPM = rpm;
			measures.CH1Flow = msg[3];
			measures.CH2Flow = msg[4];
			measures.CH1MinFlow = msg[5];
			measures.CH2MinFlow = msg[6];
			measures.CH1RefFlow = msg[7];
			measures.CH2RefFlow = msg[8];
			measures.CH1MaxFlow = msg[9];
			measures.CH2MaxFlow = msg[10];
			measures.CH1Temperature = msg[11];
			measures.CH1Temperature *= msg[12] === 1 ? -1 : 1;
			measures.CH2Temperature = msg[13];
			measures.CH2Temperature *= msg[14] === 1 ? -1 : 1;
		}
		var result: ViewMeasuresResult = {
			errorCode: retErrorCode,
			measures: measures,
		};
		return result;
	}
}
