import {
	AnswerLength,
	ErrorCode,
	ExternalInputAction,
	ExternalInputMode,
	ExternalInputNormalState,
	GclCmd,
} from '../faastflexCommands/commandEnum';
import {
	MessageHeaderHandler,
	ResponseParser,
} from '../faastflexCommands/command';
import { commonCommand } from '../faastflexCommands/CommonCommand';

export interface DeviceGPIParams {
	GPIExternalInput: ExternalInputMode;
	SupervisedExternalTriggerOnClosed: ExternalInputAction;
	SupervisedExternalTriggerOnOpen: ExternalInputAction;
	UnSupervisedEventTriggered: ExternalInputAction;
	UnSupervisedNormalState: ExternalInputNormalState;
}

export class FaastFlexGPIParameters {
	public static GetGPIParams(param: { msg: Uint8Array }): {
		errorCode: ErrorCode;
		byteToSend: number;
		byteToReceive: number;
	} {
		const { errorCode, byteToSend, byteToReceive } =
			commonCommand.cmdNoParamAnsData(
				param,
				GclCmd.SW_CMD_GET_PARAMS4,
				AnswerLength.eSeven,
			);
		return { errorCode, byteToSend, byteToReceive };
	}

	public static GetGPIParamsAnswer(
		param: { msg: Uint8Array },
		byteToBeReceived: number,
		byteReceived: number,
	): {
		retErrorCode: ErrorCode;
		_externalInput: ExternalInputMode;
		_supervisedTriggerOnClosed: ExternalInputAction;
		_supervisedTriggerOnOpen: ExternalInputAction;
		_unSupervisedEventTriggered: ExternalInputAction;
		_unSupervisedNormalState: ExternalInputNormalState;
	} {
		let retErrorCode: ErrorCode = ErrorCode.eERR_UNKNOWN;
		let _externalInput: ExternalInputMode = ExternalInputMode.eUnknown;
		let _supervisedTriggerOnClosed: ExternalInputAction =
			ExternalInputAction.eUnknown;
		let _supervisedTriggerOnOpen: ExternalInputAction =
			ExternalInputAction.eUnknown;
		let _unSupervisedEventTriggered: ExternalInputAction =
			ExternalInputAction.eUnknown;
		let _unSupervisedNormalState: ExternalInputNormalState =
			ExternalInputNormalState.eUnknown;
		retErrorCode = ResponseParser.checkAnswerMsgValidity(
			param.msg,
			byteToBeReceived,
			byteReceived,
		);
		const msg = param.msg;
		if (retErrorCode === ErrorCode.eOK) {
			const { result, errorCode } =
				ResponseParser.byteToEnum<ExternalInputMode>(
					msg[1],
					ExternalInputMode,
					ExternalInputMode.eUnknown,
				);
			retErrorCode = errorCode;
			_externalInput = result;
		}
		if (retErrorCode === ErrorCode.eOK) {
			const { result, errorCode } =
				ResponseParser.byteToEnum<ExternalInputNormalState>(
					msg[2],
					ExternalInputNormalState,
					ExternalInputNormalState.eUnknown,
				);
			retErrorCode = errorCode;
			_unSupervisedNormalState = result;
		}
		if (retErrorCode === ErrorCode.eOK) {
			const { result, errorCode } =
				ResponseParser.byteToEnum<ExternalInputAction>(
					msg[3],
					ExternalInputAction,
					ExternalInputAction.eUnknown,
				);
			retErrorCode = errorCode;
			_unSupervisedEventTriggered = result;
		}
		if (retErrorCode === ErrorCode.eOK) {
			const { result, errorCode } =
				ResponseParser.byteToEnum<ExternalInputAction>(
					msg[4],
					ExternalInputAction,
					ExternalInputAction.eUnknown,
				);
			retErrorCode = errorCode;
			_supervisedTriggerOnOpen = result;
		}
		if (retErrorCode === ErrorCode.eOK) {
			const { result, errorCode } =
				ResponseParser.byteToEnum<ExternalInputAction>(
					msg[5],
					ExternalInputAction,
					ExternalInputAction.eUnknown,
				);
			retErrorCode = errorCode;
			_supervisedTriggerOnClosed = result;
		}
		return {
			retErrorCode,
			_externalInput,
			_supervisedTriggerOnClosed,
			_supervisedTriggerOnOpen,
			_unSupervisedEventTriggered,
			_unSupervisedNormalState,
		};
	}
}
