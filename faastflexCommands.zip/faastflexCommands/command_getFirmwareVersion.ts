import {
	AnswerLength,
	ErrorCode,
	DeviceStatus,
	GclCmd,
	Configuration,
	Country,
	RelayEnabled,
	Channel,
	AlarmFaultStatus,
	AnswerByteParamIndex,
	DeviceType,
} from '../faastflexCommands/commandEnum';
import {
	HEADER_SIZE,
	SW_COMM_CHECKSUM_BASE,
	MessageHeaderHandler,
	CommandDefault,
	ResponseParser,
} from '../faastflexCommands/command';
import { commonCommand } from '../faastflexCommands/CommonCommand';

interface FirmwareVersionResult {
	errorCode: ErrorCode;
	currentVersionRelease: number;
	currentVersionMajor: number;
	currentVersionMinor: number;
	currentVersionBuild: number;
}

export class FaastFlexFirmwareVersion {
	public static GetFirmwareVersion(param: { msg: Uint8Array }): {
		errorCode: ErrorCode;
		byteToSend: number;
		byteToReceive: number;
	} {
		const { errorCode, byteToSend, byteToReceive } =
			commonCommand.cmdNoParamAnsData(
				param,
				GclCmd.SW_CMD_GET_FIRMWARE_VERSION,
				AnswerLength.eEighteen,
			);

		return { errorCode, byteToSend, byteToReceive };
	}
	public static GetFirmwareVersionAnswer(
		param: { msg: Uint8Array },
		byteToBeReceived: number,
		byteReceived: number,
	): FirmwareVersionResult {
		let retErrorCode: ErrorCode = ErrorCode.eERR_UNKNOWN;
		let msg = param.msg;
		const result: FirmwareVersionResult = {
			errorCode: ErrorCode.eOK,
			currentVersionRelease: 0,
			currentVersionMajor: 0,
			currentVersionMinor: 0,
			currentVersionBuild: 0,
		};

		retErrorCode = ResponseParser.checkAnswerMsgValidity(
			param.msg,
			byteToBeReceived,
			byteReceived,
		);
		if (ErrorCode.eOK === retErrorCode) {
			result.currentVersionRelease = this.toUInt32(msg, 1);
			result.currentVersionMajor = this.toUInt32(msg, 5);
			result.currentVersionMinor = this.toUInt32(msg, 9);
			result.currentVersionBuild = this.toUInt32(msg, 13);
		}
		return result;
	}
	// Utility function to convert bytes to UInt32 (equivalent to BitConverter.ToUInt32 in c#)
	private static toUInt32(bytes: Uint8Array, offset: number): number {
		return (
			bytes[offset] |
			(bytes[offset + 1] << 8) |
			(bytes[offset + 2] << 16) |
			(bytes[offset + 3] << 24)
		);
	}
}
