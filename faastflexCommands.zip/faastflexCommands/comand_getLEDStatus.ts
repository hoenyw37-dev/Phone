import {
	AnswerLength,
	ErrorCode,
	DeviceStatus,
	GclCmd,
	Configuration,
	Country,
	RelayEnabled,
	Channel,
	AlarmFaultStatus,
	AnswerByteParamIndex,
	DeviceType,
} from '../faastflexCommands/commandEnum';
import {
	HEADER_SIZE,
	SW_COMM_CHECKSUM_BASE,
	MessageHeaderHandler,
	CommandDefault,
	ResponseParser,
} from '../faastflexCommands/command';
import { commonCommand } from '../faastflexCommands/CommonCommand';

interface LEDStatusResult {
	errorCode: ErrorCode;
	AlarmStatus1: AlarmFaultStatus;
	AlarmStatus2: AlarmFaultStatus;
	preAlarmFault1: AlarmFaultStatus;
	preAlarmFault2: AlarmFaultStatus;
	FaultStatus: AlarmFaultStatus;
}

export class FaastFlexLEDStatus {
	public static GetHMILed(param: { msg: Uint8Array }): {
		errorCode: ErrorCode;
		byteToSend: number;
		byteToReceive: number;
	} {
		const { errorCode, byteToSend, byteToReceive } =
			commonCommand.cmdNoParamAnsData(
				param,
				GclCmd.SW_CMD_ALARM_FAULT_STATE,
				AnswerLength.eSeven,
			);

		return { errorCode, byteToSend, byteToReceive };
	}
	public static GetHMILedAnswer(
		param: { msg: Uint8Array },
		byteToBeReceived: number,
		byteReceived: number,
	): LEDStatusResult {
		let retErrorCode: ErrorCode = ErrorCode.eERR_UNKNOWN;
		let msg = param.msg;
		var returnValue: LEDStatusResult = {
			errorCode: ErrorCode.eERR_UNKNOWN,
			AlarmStatus1: AlarmFaultStatus.Unknown,
			AlarmStatus2: AlarmFaultStatus.Unknown,
			preAlarmFault1: AlarmFaultStatus.Unknown,
			preAlarmFault2: AlarmFaultStatus.Unknown,
			FaultStatus: AlarmFaultStatus.Unknown,
		};
		retErrorCode = ResponseParser.checkAnswerMsgValidity(
			param.msg,
			byteToBeReceived,
			byteReceived,
		);
		returnValue.errorCode = retErrorCode;
		if (retErrorCode === ErrorCode.eOK) {
			const { result, errorCode } = ResponseParser.getMsgAnswerParToEnum(
				msg,
				AnswerByteParamIndex.eParam_One,
				AlarmFaultStatus.Unknown,
				AlarmFaultStatus,
			);
			returnValue.errorCode = errorCode;
			returnValue.FaultStatus = result;
		}
		if (retErrorCode === ErrorCode.eOK) {
			const { result, errorCode } = ResponseParser.getMsgAnswerParToEnum(
				msg,
				AnswerByteParamIndex.eParam_Two,
				AlarmFaultStatus.Unknown,
				AlarmFaultStatus,
			);
			returnValue.errorCode = errorCode;
			returnValue.preAlarmFault1 = result;
		}
		if (retErrorCode === ErrorCode.eOK) {
			const { result, errorCode } = ResponseParser.getMsgAnswerParToEnum(
				msg,
				AnswerByteParamIndex.eParam_Three,
				AlarmFaultStatus.Unknown,
				AlarmFaultStatus,
			);
			returnValue.errorCode = errorCode;
			returnValue.AlarmStatus1 = result;
		}
		if (retErrorCode === ErrorCode.eOK) {
			const { result, errorCode } = ResponseParser.getMsgAnswerParToEnum(
				msg,
				AnswerByteParamIndex.eParam_Four,
				AlarmFaultStatus.Unknown,
				AlarmFaultStatus,
			);
			returnValue.errorCode = errorCode;
			returnValue.preAlarmFault2 = result;
		}
		if (retErrorCode === ErrorCode.eOK) {
			const { result, errorCode } = ResponseParser.getMsgAnswerParToEnum(
				msg,
				AnswerByteParamIndex.eParam_Five,
				AlarmFaultStatus.Unknown,
				AlarmFaultStatus,
			);
			returnValue.errorCode = errorCode;
			returnValue.AlarmStatus2 = result;
		}

		return returnValue;
	}
}
