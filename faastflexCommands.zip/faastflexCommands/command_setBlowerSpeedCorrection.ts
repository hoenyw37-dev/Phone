import {
	AnswerLength,
	ErrorCode,
	DeviceStatus,
	GclCmd,
	Configuration,
	Country,
	RelayEnabled,
	Channel,
	AlarmFaultStatus,
	AnswerByteParamIndex,
	DeviceType,
	PasswordValid,
	GclSubCmdT,
	FanSpeedLevel,
	FanPWMPercCorrection,
} from '../faastflexCommands/commandEnum';
import {
	HEADER_SIZE,
	SW_COMM_CHECKSUM_BASE,
	MessageHeaderHandler,
	CommandDefault,
	ResponseParser,
} from '../faastflexCommands/command';
import { commonCommand } from '../faastflexCommands/CommonCommand';
import { min } from 'date-fns';

export class FaastFlexSetBlowerSpeedCorrection {
	public static SetFanCorrectionEEPROM(
		param: { msg: Uint8Array },
		fanSpeed: FanPWMPercCorrection,
	): {
		errorCode: ErrorCode;
		byteToSend: number;
		byteToReceive: number;
	} {
		let correctionValue: number = 0;
		let signValue: number = 0;
		let errorCode: ErrorCode = ErrorCode.eOK;
		let byteToSend: number = 0;
		let byteToReceive: number = 0;
		switch (fanSpeed) {
			case FanPWMPercCorrection.eMinusSix:
				correctionValue = 6;
				signValue = 1;
				break;
			case FanPWMPercCorrection.eMinusFive:
				correctionValue = 5;
				signValue = 1;
				break;
			case FanPWMPercCorrection.eMinusFour:
				correctionValue = 4;
				signValue = 1;
				break;
			case FanPWMPercCorrection.eMinusThree:
				correctionValue = 3;
				signValue = 1;
				break;
			case FanPWMPercCorrection.eMinusTwo:
				correctionValue = 2;
				signValue = 1;
				break;
			case FanPWMPercCorrection.eMinusOne:
				correctionValue = 1;
				signValue = 1;
				break;
			case FanPWMPercCorrection.eZero:
				correctionValue = 0;
				signValue = 0;
				break;
			case FanPWMPercCorrection.ePlusSix:
				correctionValue = 6;
				signValue = 0;
				break;
			case FanPWMPercCorrection.ePlusFive:
				correctionValue = 5;
				signValue = 0;
				break;
			case FanPWMPercCorrection.ePlusFour:
				correctionValue = 4;
				signValue = 0;
				break;
			case FanPWMPercCorrection.ePlusThree:
				correctionValue = 3;
				signValue = 0;
				break;
			case FanPWMPercCorrection.ePlusTwo:
				correctionValue = 2;
				signValue = 0;
				break;
			case FanPWMPercCorrection.ePlusOne:
				correctionValue = 1;
				signValue = 0;
				break;
			default:
				errorCode = ErrorCode.eERR_INVALID_PARAMETER;
				correctionValue = 0;
				signValue = 0;
				break;
		}
		if (errorCode === ErrorCode.eOK) {
			const value = commonCommand.subCmdWriteTwoParamAnsAckOnly(
				param,
				GclSubCmdT.SW_CMD_FAN_CORRECTION,
				correctionValue,
				signValue,
			);
			errorCode = value.errorCode;
			byteToSend = value.byteToSend;
			byteToReceive = value.byteToReceive;
		}
		return { errorCode, byteToSend, byteToReceive };
	}
	public static SetFanCorrectionEEPROMAnswer(
		param: { msg: Uint8Array },
		byteToBeReceived: number,
		byteReceived: number,
	): { retErrorCode: ErrorCode } {
		let retErrorCode: ErrorCode = ErrorCode.eERR_UNKNOWN;
		retErrorCode = ResponseParser.checkAnswerMsgValidity(
			param.msg,
			byteToBeReceived,
			byteReceived,
		);
		return { retErrorCode };
	}
}
