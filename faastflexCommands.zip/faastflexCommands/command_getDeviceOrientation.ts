import {
	AnswerLength,
	ErrorCode,
	DeviceStatus,
	GclCmd,
	Configuration,
	Country,
	RelayEnabled,
	Channel,
	AlarmFaultStatus,
	AnswerByteParamIndex,
	DeviceType,
	GclSubCmdT,
} from '../faastflexCommands/commandEnum';
import {
	HEADER_SIZE,
	SW_COMM_CHECKSUM_BASE,
	MessageHeaderHandler,
	CommandDefault,
	ResponseParser,
} from '../faastflexCommands/command';
import { commonCommand } from '../faastflexCommands/CommonCommand';

export class FaastFlexDeviceOrientation {
	public static GetDeviceOrientationEEPROM(param: { msg: Uint8Array }): {
		errorCode: ErrorCode;
		byteToSend: number;
		byteToReceive: number;
	} {
		const { errorCode, byteToSend, byteToReceive } =
			commonCommand.subCmdReadNoParamAnsOneByte(
				param,
				GclSubCmdT.SW_CMD_ORIENTATION,
			);

		return { errorCode, byteToSend, byteToReceive };
	}

	public static GetDeviceOrientationEEPROMAnswer(
		param: { msg: Uint8Array },
		byteToBeReceived: number,
		byteReceived: number,
	): { retErrorCode: ErrorCode; orientation: DeviceOrientation } {
		const { retErrorCode, retOrientation } = this.ParseByteEnumAnswer(
			param.msg,
			byteToBeReceived,
			byteReceived,
			DeviceOrientation.eUnknown,
			DeviceOrientation,
		);
		return { retErrorCode, orientation: retOrientation };
	}
	private static ParseByteEnumAnswer<RES_ENum extends number>(
		msg: Uint8Array,
		byteToBeReceived: number,
		byteReceived: number,
		defaultValue: RES_ENum,
		enumType: any,
	): { retErrorCode: ErrorCode; retOrientation: RES_ENum } {
		let type: RES_ENum = defaultValue;
		let eRet: ErrorCode = ErrorCode.eOK;
		if (3 !== byteToBeReceived) {
			eRet = ErrorCode.eERR_ANS_INVALID_SIZE;
		}
		if (ErrorCode.eOK === eRet) {
			eRet = ResponseParser.checkAnswerMsgValidity(
				msg,
				byteToBeReceived,
				byteReceived,
			);
		}
		if (ErrorCode.eOK === eRet) {
			const { result, errorCode } = ResponseParser.getMsgAnswerParToEnum(
				msg,
				AnswerByteParamIndex.eParam_One,
				defaultValue,
				enumType,
			);
			type = result;
			eRet = errorCode;
		}
		return { retErrorCode: eRet, retOrientation: type };
	}
}
export enum DeviceOrientation {
	eUnknown = 2,
	eUp_Detector_Upright = 1,
	eDown_DetectorInverted = 0,
}
const DeviceOrientationDescription: Record<DeviceOrientation, string> = {
	[DeviceOrientation.eUp_Detector_Upright]: 'Upright installation',
	[DeviceOrientation.eDown_DetectorInverted]: 'Inverted installation',
	[DeviceOrientation.eUnknown]: 'Unknown',
};
export function getDeviceOrientationDescription(
	type: DeviceOrientation,
): string {
	return DeviceOrientationDescription[type] ?? type.toString();
}
