import {
	AnswerLength,
	ErrorCode,
	GclCmd,
	RelayAlert,
	FanSpeedLevel,
	FanPWMPercCorrection,
	LatchedMode,
	AlarmMode,
	PreAlarmLevel,
	AlarmLevel,
} from '../faastflexCommands/commandEnum';
import { ResponseParser } from '../faastflexCommands/command';
import { commonCommand } from '../faastflexCommands/CommonCommand';
import { DeviceGeneralParams } from '../faastflexCommands/common_objects';
import { DeviceOrientation } from '../faastflexCommands/commandEnum';

interface GeneralParametersResult {
	errorCode: ErrorCode;
	deviceParams: DeviceGeneralParams;
}
export class FaastFlexChannelsAndSensorsParameters {
	public static GetChannelsAndSensorParams(param: { msg: Uint8Array }): {
		errorCode: ErrorCode;
		byteToSend: number;
		byteToReceive: number;
	} {
		const { errorCode, byteToSend, byteToReceive } =
			commonCommand.cmdNoParamAnsData(
				param,
				GclCmd.SW_CMD_GET_PARAMS3,
				AnswerLength.eTwenty,
			);

		return { errorCode, byteToSend, byteToReceive };
	}

	public static GetChannelsAndSensorParamsAnswer(
		param: { msg: Uint8Array },
		byteToBeReceived: number,
		byteReceived: number,
	): {
		errorCode: ErrorCode;
		preAlarmDelay: number;
		alarmDelay: number;
		flowFaultDelay: number;
		alarmLatched: LatchedMode;
		preAlarmLatched: LatchedMode;
		faultLatched: LatchedMode;
		alarmMode: AlarmMode;
		ch1PreAlarmLevel: PreAlarmLevel;
		ch1AlarmLevel: AlarmLevel;
		ch1Flowthreshold: number;
		ch1RefAirflow: number;
		ch2PreAlarmLevel: PreAlarmLevel;
		ch2AlarmLevel: AlarmLevel;
		ch2Flowthreshold: number;
		ch2RefAirflow: number;
	} {
		let retErrorCode: ErrorCode = ErrorCode.eERR_UNKNOWN;
		let resultParams = {
			errorCode: ErrorCode.eERR_UNKNOWN,
			preAlarmDelay: 0,
			alarmDelay: 0,
			flowFaultDelay: 0,
			alarmLatched: LatchedMode.eUnknown,
			preAlarmLatched: LatchedMode.eUnknown,
			faultLatched: LatchedMode.eUnknown,
			alarmMode: AlarmMode.eUnknown,
			ch1PreAlarmLevel: PreAlarmLevel.eUnknown,
			ch1AlarmLevel: AlarmLevel.eUnknown,
			ch1Flowthreshold: 0,
			ch1RefAirflow: 0,
			ch2PreAlarmLevel: PreAlarmLevel.eUnknown,
			ch2AlarmLevel: AlarmLevel.eUnknown,
			ch2Flowthreshold: 0,
			ch2RefAirflow: 0,
		};
		retErrorCode = ResponseParser.checkAnswerMsgValidity(
			param.msg,
			byteToBeReceived,
			byteReceived,
		);
		const msg = param.msg;
		if (retErrorCode === ErrorCode.eOK) {
			resultParams.preAlarmDelay = msg[1];
			resultParams.alarmDelay = msg[2];
			resultParams.flowFaultDelay = msg[3];
			resultParams.ch1Flowthreshold = msg[15];
			resultParams.ch2Flowthreshold = msg[16];
			resultParams.ch1RefAirflow = msg[17];
			resultParams.ch2RefAirflow = msg[18];
		}
		if (retErrorCode === ErrorCode.eOK) {
			const alarm_latched = msg[6];
			const { result, errorCode } = ResponseParser.byteToEnum<LatchedMode>(
				alarm_latched,
				LatchedMode,
				LatchedMode.eUnknown,
			);
			resultParams.alarmLatched = result;
			retErrorCode = errorCode;
		}
		if (retErrorCode === ErrorCode.eOK) {
			const pre_alarm_latched = msg[4];
			const { result, errorCode } = ResponseParser.byteToEnum<LatchedMode>(
				pre_alarm_latched,
				LatchedMode,
				LatchedMode.eUnknown,
			);
			resultParams.preAlarmLatched = result;
			retErrorCode = errorCode;
		}
		if (retErrorCode === ErrorCode.eOK) {
			const fault_latched = msg[8];
			const { result, errorCode } = ResponseParser.byteToEnum<LatchedMode>(
				fault_latched,
				LatchedMode,
				LatchedMode.eUnknown,
			);
			resultParams.faultLatched = result;
			retErrorCode = errorCode;
		}
		if (retErrorCode === ErrorCode.eOK) {
			const alarm_mode = msg[10];
			const { result, errorCode } = ResponseParser.byteToEnum<AlarmMode>(
				alarm_mode,
				AlarmMode,
				AlarmMode.eUnknown,
			);
			resultParams.alarmMode = result;
			retErrorCode = errorCode;
		}
		if (retErrorCode === ErrorCode.eOK) {
			const ch1_preAlarm_level = msg[11];
			const { result, errorCode } = ResponseParser.byteToEnum<PreAlarmLevel>(
				ch1_preAlarm_level,
				PreAlarmLevel,
				PreAlarmLevel.eUnknown,
			);
			resultParams.ch1PreAlarmLevel = result;
			retErrorCode = errorCode;
		}
		if (retErrorCode === ErrorCode.eOK) {
			const ch1_alarm_level = msg[13];
			const { result, errorCode } = ResponseParser.byteToEnum<AlarmLevel>(
				ch1_alarm_level,
				AlarmLevel,
				AlarmLevel.eUnknown,
			);
			resultParams.ch1AlarmLevel = result;
			retErrorCode = errorCode;
		}
		if (retErrorCode === ErrorCode.eOK) {
			const ch2_preAlarm_level = msg[12];
			const { result, errorCode } = ResponseParser.byteToEnum<PreAlarmLevel>(
				ch2_preAlarm_level,
				PreAlarmLevel,
				PreAlarmLevel.eUnknown,
			);
			resultParams.ch2PreAlarmLevel = result;
			retErrorCode = errorCode;
		}
		if (retErrorCode === ErrorCode.eOK) {
			const ch2_alarm_level = msg[14];
			const { result, errorCode } = ResponseParser.byteToEnum<AlarmLevel>(
				ch2_alarm_level,
				AlarmLevel,
				AlarmLevel.eUnknown,
			);
			resultParams.ch2AlarmLevel = result;
			retErrorCode = errorCode;
		}
		resultParams.errorCode = retErrorCode;
		return resultParams;
	}
}
