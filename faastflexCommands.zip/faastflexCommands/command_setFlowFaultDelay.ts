import {
	AnswerLength,
	ErrorCode,
	DeviceStatus,
	GclCmd,
	Configuration,
	Country,
	RelayEnabled,
	Channel,
	AlarmFaultStatus,
	AnswerByteParamIndex,
	DeviceType,
	PasswordValid,
	GclSubCmdT,
} from '../faastflexCommands/commandEnum';
import {
	HEADER_SIZE,
	SW_COMM_CHECKSUM_BASE,
	MessageHeaderHandler,
	CommandDefault,
	ResponseParser,
} from '../faastflexCommands/command';
import { commonCommand } from '../faastflexCommands/CommonCommand';
import { min } from 'date-fns';

export class FaastFlexSetFlowFaultDelay {
	public static SetFlowFaultDelayEEPROM(
		param: { msg: Uint8Array },
		updateParam: number,
	): {
		errorCode: ErrorCode;
		byteToSend: number;
		byteToReceive: number;
	} {
		let errorCode: ErrorCode;
		let byteToSend: number;
		let byteToReceive: number;

		if (updateParam > 250) {
			errorCode = ErrorCode.eERR_INVALID_PARAMETER;
			byteToSend = 0;
			byteToReceive = 0;
		} else {
			const result = commonCommand.subCmdWriteOneParamAnsAckOnly(
				param,
				GclSubCmdT.SW_CMD_FLOW_FAULT_DELAY,
				updateParam,
			);
			errorCode = result.errorCode;
			byteToSend = result.byteToSend;
			byteToReceive = result.byteToReceive;
		}
		return { errorCode, byteToSend, byteToReceive };
	}
	public static SetFlowFaultDelayEEPROMAnswer(
		param: { msg: Uint8Array },
		byteToBeReceived: number,
		byteReceived: number,
	): { retErrorCode: ErrorCode } {
		let retErrorCode: ErrorCode = ErrorCode.eERR_UNKNOWN;
		retErrorCode = ResponseParser.checkAnswerMsgValidity(
			param.msg,
			byteToBeReceived,
			byteReceived,
		);
		return { retErrorCode };
	}
}
