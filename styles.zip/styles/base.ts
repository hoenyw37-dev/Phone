import { Dimensions, DimensionValue, StyleSheet } from 'react-native';
import {
	responsiveFontSize,
	responsiveHeight,
	responsiveWidth,
} from '@global/responsiveUI';

export const dimensions = {
	fullHeight: Dimensions.get('window').height,
	fullWidth: Dimensions.get('window').width,
};

export const commonColors = {
	backgroundColor_Blue: '#1792E5',
	backgroundColor_White: '#FFFFFF',
	textColor_Blue: '#1792E5',
	textColor_White: '#FFFFFF',
	textColor_Black: '#000000',
	textColor_Grey: '#808080',
	backgroundColor_TransparentGrey: 'rgba(0, 0, 0, 0.5)',
	lineColor: '#909090',
	lineColorLight: '#ccc',
	shadowColor: '#000',
	textBoxBorderColor: '#909090', //'#ccc',
	warningColor: 'red',
	switchColor: '#212F3D',
	GrayShade1: '#101010',
	GrayShade2: '#9D9D9D',
	GrayShade4: '#D0D0D0',
	GrayShade6: '#606060',
	LightGrayBackground: '#f2f2f2',
};

export const commonSizes = {
	cornerRadius: responsiveWidth(1.5),

	textSizeXS: responsiveFontSize(1),
	textSizeS: responsiveFontSize(1.5),
	textSizeXL: responsiveFontSize(3),
	textSizeM: responsiveFontSize(1.8),
	textSizeM1: responsiveFontSize(2),
	textSizeL: responsiveFontSize(2.2),
	textSizeL1: responsiveFontSize(2.5),

	checkBoxScale: responsiveFontSize(0.15),

	lineThicknessXS: responsiveWidth(0.1),
	lineThicknessS: responsiveWidth(0.2),
	lineThickness: responsiveWidth(0.3),

	textBoxHeight_M: responsiveHeight(4),
	textBoxHeight_L: responsiveHeight(5),

	textBoXBorderWidthXS: responsiveWidth(0.2),
	textBoXBorderWidthS: responsiveWidth(0.3),
	textBoXBorderWidthM: responsiveWidth(0.5),
	textBoXBorderWidthL: responsiveWidth(0.6),

	paddingM_Percent: '2%' as DimensionValue,
	paddingS_Percent: '1%' as DimensionValue,
	paddingL_Percent: '3%' as DimensionValue,
	paddingXL_Percent: '4%' as DimensionValue,
	paddingXXL_Percent: '7%' as DimensionValue,

	widthXS_Pixel: responsiveWidth(0.5),
	widthM_Pixel: responsiveWidth(2),
	widthS_Pixel: responsiveWidth(1),
	widthL_Pixel: responsiveWidth(3),
	widthXL_Pixel: responsiveWidth(4),
	widthXXL_Pixel: responsiveWidth(5),

	heightXS_Pixel: responsiveHeight(0.5),
	heightM_Pixel: responsiveHeight(2),
	heightS_Pixel: responsiveHeight(1),
	heightL_Pixel: responsiveHeight(3),
	heightXL_Pixel: responsiveHeight(5),
	heightXXL_Pixel: responsiveHeight(6),

	iconHeightS_Pixel: responsiveFontSize(2),
	iconWidthS_Pixel: responsiveFontSize(2),
	iconHeightM_Pixel: responsiveFontSize(3),
	iconWidthM_Pixel: responsiveFontSize(3),
	iconHeightL_Pixel: responsiveFontSize(4),
	iconWidthL_Pixel: responsiveFontSize(4),
	iconHeightXL_Pixel: responsiveFontSize(6),
	iconWidthXL_Pixel: responsiveFontSize(6),
	iconHeightXXL_Pixel: responsiveFontSize(6),
	iconWidthXXL_Pixel: responsiveFontSize(6),
};

export const commonStyles = StyleSheet.create({
	box: {
		backgroundColor: commonColors.backgroundColor_White,
		marginTop: commonSizes.heightM_Pixel,
		marginHorizontal: commonSizes.widthM_Pixel,
		borderRadius: commonSizes.cornerRadius,
		flexDirection: 'row',
		justifyContent: 'space-between',
		alignItems: 'center',
		shadowColor: commonColors.shadowColor,
		shadowOffset: { width: 0, height: 2 },
		shadowOpacity: 0.1,
		shadowRadius: 4,
		elevation: 6,
	},
	boxHeading: {
		fontSize: commonSizes.textSizeL,
		fontWeight: '600',
		color: commonColors.textColor_Black,
		marginTop: commonSizes.heightM_Pixel,
		marginLeft: commonSizes.widthM_Pixel,
	},
	boxDescription: {
		fontSize: commonSizes.textSizeM,
		fontWeight: '500',
		marginTop: commonSizes.heightS_Pixel,
		color: commonColors.textColor_Grey,
		marginLeft: commonSizes.widthM_Pixel,
		marginBottom: commonSizes.heightM_Pixel,
	},
	boxContent: {
		flex: 1,
	},
	boxClickableMenu: {
		height: '100%',
		justifyContent: 'center',
	},
	boxMenuPopUp: {
		flexDirection: 'row',
		alignItems: 'center',
		marginRight: commonSizes.widthXL_Pixel,
	},
	boxMenuText: {
		color: commonColors.textColor_Black,
		fontSize: commonSizes.textSizeL,
		marginLeft: commonSizes.widthM_Pixel,
	},
	boxIcon: {
		marginLeft: commonSizes.widthM_Pixel,
	},
	picker: {
		// height: 50,
		color: commonColors.textColor_Black,
	},
	pickerItems: {
		// height: 50,
		color: commonColors.textColor_Black,
		fontSize: commonSizes.textSizeS,
	},
	errorInput: {
		borderColor: commonColors.warningColor,
	},
	errorText: {
		color: commonColors.warningColor,
		marginTop: commonSizes.heightXS_Pixel,
		marginLeft: commonSizes.widthM_Pixel,
		fontSize: commonSizes.textSizeS,
	},
	verticalLine: {
		height: '80%',
		width: commonSizes.lineThickness,
		backgroundColor: commonColors.lineColor,
	},
	horizontalLine: {
		height: commonSizes.lineThickness,
		width: '100%',
		alignSelf: 'center',
		backgroundColor: commonColors.lineColor,
	},
});
