import { DataSource } from 'typeorm';
import { DeviceParameterEntity } from '@ff_dataAccess/deviceParametersDataAccess/deviceParameterEntity';
import {
	convertDeviceParameterEntityToDeviceParameter,
	convertDeviceParameterToDeviceParameterEntity,
} from '@ff_dataAccess/deviceParametersDataAccess/deviceParameterDataConversion';
import { DeviceParametersModel } from '@ff_model/deviceParametersModel';

export const getAllDeviceParameters = async (
	dataSource: DataSource,
): Promise<DeviceParametersModel[]> => {
	console.log('LOADING DEVICE PARAMETERS');
	const rawresult = await dataSource.manager.find(DeviceParameterEntity);
	const result = rawresult.map(convertDeviceParameterEntityToDeviceParameter);
	return result;
};

export const getDeviceParameter = async (
	dataSource: DataSource,
	deviceId: number,
): Promise<DeviceParametersModel> => {
	console.log(`LOADING DEVICE PARAMETER FOR ID: ${deviceId}`);
	const rawresult = await dataSource.manager.findOne(DeviceParameterEntity, {
		where: { Id: deviceId },
	});
	if (!rawresult) {
		console.log(`No device parameter found for ID: ${deviceId}`);
		throw new Error(`No device parameter found for ID: ${deviceId}`);
	}
	return convertDeviceParameterEntityToDeviceParameter(rawresult);
};

export const addDeviceParameter = async (
	dataSource: DataSource,
	deviceParameter: DeviceParametersModel,
): Promise<DeviceParametersModel> => {
	const deviceParameterEntity =
		convertDeviceParameterToDeviceParameterEntity(deviceParameter);
	const newDeviceParameter = await dataSource.manager.save(
		DeviceParameterEntity,
		deviceParameterEntity,
	);
	return convertDeviceParameterEntityToDeviceParameter(newDeviceParameter);
};

export const addAllDeviceParameters = async (
	dataSource: DataSource,
	deviceParameters: DeviceParametersModel[],
): Promise<DeviceParametersModel[]> => {
	const deviceParameterEntities = deviceParameters.map(
		convertDeviceParameterToDeviceParameterEntity,
	);
	const newDeviceParameters = await dataSource.manager.save(
		DeviceParameterEntity,
		deviceParameterEntities,
	);
	return newDeviceParameters.map(convertDeviceParameterEntityToDeviceParameter);
};

export const updateDeviceParameter = async (
	dataSource: DataSource,
	deviceParameterId: number,
	updates: Partial<DeviceParametersModel>,
): Promise<Boolean> => {
	const existingDeviceParameter = await dataSource.manager.findOne(
		DeviceParameterEntity,
		{ where: { Id: deviceParameterId } },
	);
	if (!existingDeviceParameter) {
		console.log(`Device Parameter with ID: ${deviceParameterId} not found.`);
		return false;
	}

	// Convert to model, apply updates, then convert back to entity
	const existingDeviceParameterModel =
		convertDeviceParameterEntityToDeviceParameter(existingDeviceParameter);
	const updatedDeviceParameterModel = {
		...existingDeviceParameterModel,
		...updates,
	};
	const convertedDeviceParameterEntity =
		convertDeviceParameterToDeviceParameterEntity(updatedDeviceParameterModel);

	console.log(
		'UPDATED DEVICE PARAMETER ENTITY...',
		convertedDeviceParameterEntity,
	);
	const result = await dataSource.manager.update(
		DeviceParameterEntity,
		deviceParameterId,
		convertedDeviceParameterEntity,
	);
	if (result.affected && result.affected > 0) {
		console.log(
			`Successfully updated device parameter with ID: ${deviceParameterId}`,
		);
		return true;
	} else {
		console.log(
			`Failed to update device parameter with ID: ${deviceParameterId}`,
		);
		return false;
	}
};

export const deleteDeviceParameter = async (
	dataSource: DataSource,
	deviceParameterId: number,
): Promise<{ success: boolean }> => {
	//console.log(projectEntity);
	const result = await dataSource.manager.delete(
		DeviceParameterEntity,
		deviceParameterId,
	);
	if (result.affected && result.affected > 0) {
		console.log(
			`Successfully deleted device parameter with ID: ${deviceParameterId}`,
		);
		return { success: true };
	} else {
		console.log(
			`Failed to delete device parameter with ID: ${deviceParameterId}`,
		);
		return { success: false };
	}
};
