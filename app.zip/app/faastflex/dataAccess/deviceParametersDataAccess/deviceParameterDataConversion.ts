import { DeviceParameterEntity } from '@ff_dataAccess/deviceParametersDataAccess/deviceParameterEntity';
import { DeviceParametersModel } from '@ff_model/deviceParametersModel';

export const convertDeviceParameterEntityToDeviceParameter = (
	entity: DeviceParameterEntity,
): DeviceParametersModel => {
	return {
		deviceId: entity.DeviceId,
		deviceName: entity.DeviceName,
		installationDate: entity.InstallationDate,
		trendLogDisabled: entity.TrendLogDisabled,
		temperatureFaultRelay: entity.TemperatureFaultRelay,
		lowPowerFaultRelay: entity.LowPowerFaultRelay,
		gpiState: entity.GPIState,
		externalInputNormalState: entity.ExternalInputNormalState,
		unbalancedEventTriggered: entity.UnbalancedEventTriggered,
		externalTriggerOnOpen: entity.ExternalTriggerOnOpen,
		externalTriggerOnClosed: entity.ExternalTriggerOnClosed,
		blowerSpeed: entity.BlowerSpeed,
		blowerCorrection: entity.BlowerCorrection,
		channel1ActionLevel: entity.Channel1ActionLevel,
		channel1AlarmLevel: entity.Channel1AlarmLevel,
		channel2ActionLevel: entity.Channel2ActionLevel,
		channel2AlarmLevel: entity.Channel2AlarmLevel,
		actionDelay: entity.ActionDelay,
		alarmDelay: entity.AlarmDelay,
		flowFaultDelay: entity.FlowFaultDelay,
		alarmLatched: entity.AlarmLatched,
		actionLatched: entity.ActionLatched,
		faultLatched: entity.FaultLatched,
		referenceFlowCh1: entity.ReferenceFlowCh1,
		referenceFlowCh2: entity.ReferenceFlowCh2,
		flowFaultThresholdCh1: entity.FlowFaultThresholdCh1,
		flowFaultThresholdCh2: entity.FlowFaultThresholdCh2,
		deviceAlarmMode: entity.DeviceAlarmMode,
		gpInputState: entity.GPInputState,
		channels: entity.Channels,
		deviceType: entity.DeviceType,

		// Adding missing required properties
		password: '', // Default value or retrieve from entity if available
		timeOutDisabled: 0, // Default value or retrieve from entity if available
		isChannel2Disabled: false, // Default value or retrieve from entity if available
		createdDateTime: new Date(), // Current date or retrieve from entity if available
		installationDateTime: new Date(), // Using InstallationDate as fallback

		alarm2Latched: entity.Alarm2Latched ?? 0,
		auxFaultLatched: entity.AuxFaultLatched ?? 0,
		generalFaultLatched: entity.GeneralFaultLatched ?? 0,
	};
};

export const convertDeviceParameterToDeviceParameterEntity = (
	dpModel: DeviceParametersModel,
): DeviceParameterEntity => {
	const entity = new DeviceParameterEntity();
	entity.DeviceId = dpModel.deviceId;
	entity.DeviceName = dpModel.deviceName;
	entity.InstallationDate = dpModel.installationDate;
	entity.TrendLogDisabled = dpModel.trendLogDisabled;
	entity.TemperatureFaultRelay = dpModel.temperatureFaultRelay;
	entity.LowPowerFaultRelay = dpModel.lowPowerFaultRelay;
	entity.GPIState = dpModel.gpiState;
	entity.ExternalInputNormalState = dpModel.externalInputNormalState;
	entity.UnbalancedEventTriggered = dpModel.unbalancedEventTriggered;
	entity.ExternalTriggerOnOpen = dpModel.externalTriggerOnOpen;
	entity.ExternalTriggerOnClosed = dpModel.externalTriggerOnClosed;
	entity.BlowerSpeed = dpModel.blowerSpeed;
	entity.BlowerCorrection = dpModel.blowerCorrection;
	entity.Channel1ActionLevel = dpModel.channel1ActionLevel;
	entity.Channel1AlarmLevel = dpModel.channel1AlarmLevel;
	entity.Channel2ActionLevel = dpModel.channel2ActionLevel;
	entity.Channel2AlarmLevel = dpModel.channel2AlarmLevel;
	entity.ActionDelay = dpModel.actionDelay;
	entity.AlarmDelay = dpModel.alarmDelay;
	entity.FlowFaultDelay = dpModel.flowFaultDelay;
	entity.AlarmLatched = dpModel.alarmLatched;
	entity.ActionLatched = dpModel.actionLatched;
	entity.FaultLatched = dpModel.faultLatched;
	entity.ReferenceFlowCh1 = dpModel.referenceFlowCh1;
	entity.ReferenceFlowCh2 = dpModel.referenceFlowCh2;
	entity.FlowFaultThresholdCh1 = dpModel.flowFaultThresholdCh1;
	entity.FlowFaultThresholdCh2 = dpModel.flowFaultThresholdCh2;
	entity.DeviceAlarmMode = dpModel.deviceAlarmMode;
	entity.GPInputState = dpModel.gpInputState;
	entity.Channels = dpModel.channels;
	entity.DeviceType = dpModel.deviceType;

	entity.Alarm2Latched = dpModel.alarm2Latched;
	entity.AuxFaultLatched = dpModel.auxFaultLatched;
	entity.GeneralFaultLatched = dpModel.generalFaultLatched;
	return entity;
};
