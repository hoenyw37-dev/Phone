import {
	Entity,
	Column,
	PrimaryGeneratedColumn,
	OneToMany,
} from 'typeorm/browser';

@Entity('DeviceParameter')
export class DeviceParameterEntity {
	@PrimaryGeneratedColumn()
	Id!: number;

	@Column({ type: 'int' })
	DeviceId!: number;

	@Column({ type: 'date' })
	InstallationDate!: Date;

	@Column({ type: 'int' })
	TrendLogDisabled!: number;

	@Column({ type: 'int' })
	TemperatureFaultRelay!: number;

	@Column({ type: 'int' })
	LowPowerFaultRelay!: number;

	@Column({ type: 'boolean' })
	GPIState!: boolean;

	@Column({ type: 'int' })
	GPInputState!: number;

	@Column({ type: 'int' })
	ExternalInputNormalState!: number;

	@Column({ type: 'int' })
	UnbalancedEventTriggered!: number;

	@Column({ type: 'int' })
	ExternalTriggerOnOpen!: number;

	@Column({ type: 'int' })
	ExternalTriggerOnClosed!: number;

	@Column({ type: 'int' })
	BlowerSpeed!: number;

	@Column({ type: 'varchar' })
	BlowerCorrection!: string;

	@Column({ type: 'int' })
	Channel1ActionLevel!: number;

	@Column({ type: 'int' })
	Channel1AlarmLevel!: number;

	@Column({ type: 'int' })
	Channel2ActionLevel!: number;

	@Column({ type: 'int' })
	Channel2AlarmLevel!: number;

	@Column({ type: 'int' })
	ActionDelay!: number;

	@Column({ type: 'int' })
	AlarmDelay!: number;

	@Column({ type: 'int' })
	FlowFaultDelay!: number;

	@Column({ type: 'int' })
	AlarmLatched!: number;

	@Column({ type: 'int' })
	ActionLatched!: number;

	@Column({ type: 'int' })
	FaultLatched!: number;

	@Column({ type: 'int' })
	ReferenceFlowCh1!: number;

	@Column({ type: 'int' })
	ReferenceFlowCh2!: number;

	@Column({ type: 'int' })
	FlowFaultThresholdCh1!: number;

	@Column({ type: 'int' })
	FlowFaultThresholdCh2!: number;

	@Column({ type: 'int' })
	DeviceAlarmMode!: number;

	@Column({ type: 'int' })
	Channels!: number;

	@Column({ type: 'varchar' })
	DeviceName!: string;

	@Column({ type: 'int' })
	Alarm2Latched?: number;

	@Column({ type: 'int' })
	AuxFaultLatched?: number;

	@Column({ type: 'int' })
	GeneralFaultLatched?: number;

	@Column({ type: 'int' })
	DeviceType!: number;
}
