import { Entity, Column, PrimaryGeneratedColumn } from 'typeorm/browser';

@Entity('Devices')
export class DeviceEntity {
	@PrimaryGeneratedColumn({ type: 'int' })
	deviceId!: number;

	@Column({ type: 'text' })
	deviceName!: string;

	@Column({ type: 'text', nullable: true })
	lastConnected?: string | null;

	@Column({ type: 'text', nullable: true })
	createdDateTime?: string | null;

	@Column({ type: 'text', nullable: true })
	productionDate?: string | null;

	@Column({ type: 'boolean', nullable: true })
	isManualPairingCompleted?: boolean | null;

	@Column({ type: 'text', nullable: true })
	deviceMacAddress?: string | null;

	@Column({ type: 'text', nullable: true })
	deviceCountryCode?: string | null;

	@Column({ type: 'text', nullable: true })
	deviceOrientation?: string | null;

	@Column({ type: 'text', nullable: true })
	deviceType?: string | null;

	@Column({ type: 'text', nullable: true })
	deviceSerialNumber?: string | null;

	@Column({ type: 'text', nullable: true })
	deviceModelNumber?: string | null;

	@Column({ type: 'text', nullable: true })
	firmwareVersion?: string | null;

	@Column({ type: 'text', nullable: true })
	deviceLocation?: string | null;

	@Column({ type: 'int', nullable: true })
	channels?: number | null;

	@Column({ type: 'text', nullable: true })
	pipeConfiguration?: string | null;

	@Column({ type: 'int', nullable: true })
	pipeLength?: number | null;

	@Column({ type: 'int', nullable: true })
	projectId?: number | null;

	@Column({ type: 'int', nullable: true })
	minTransportTime?: number | null;

	@Column({ type: 'int', nullable: true })
	maxTransportTime?: number | null;

	@Column({ type: 'boolean', nullable: true })
	isConfigDataFetched?: boolean | null;
}
