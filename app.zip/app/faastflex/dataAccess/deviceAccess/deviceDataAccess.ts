import { DataSource } from 'typeorm';
import { DeviceEntity } from './deviceEntity';
import {
	convertDeviceEntityToDevice,
	convertDeviceToDeviceEntity,
} from './deviceConversion';
import { DeviceModel } from '@ff_model/deviceModel';

export const addDevice = async (
	dataSource: DataSource,
	device: DeviceModel,
): Promise<DeviceModel> => {
	//await validateProjectCount(dataSource);
	await validateDeviceNameDistinct(dataSource, device.deviceName);

	const deviceEntity = convertDeviceToDeviceEntity(device);
	//console.log(projectEntity);
	const newDeviceData = await dataSource.manager.save(
		DeviceEntity,
		deviceEntity,
	);
	return convertDeviceEntityToDevice(newDeviceData);
};

export const validateDeviceNameDistinct = async (
	dataSource: DataSource,
	deviceName: string,
): Promise<void> => {
	const existingDevice = await dataSource.manager.findOne(DeviceEntity, {
		where: { deviceName: deviceName },
	});
	if (existingDevice) {
		console.log('Device name already exists');
	}
};

export const getAllDevices = async (
	dataSource: DataSource,
): Promise<DeviceModel[]> => {
	const rawresult = await dataSource.manager.find(DeviceEntity);
	const result = rawresult.map(convertDeviceEntityToDevice);
	return result;
};

export const getDeviceById = async (
	dataSource: DataSource,
	deviceId: number,
): Promise<DeviceModel | null> => {
	const deviceEntity = await dataSource.manager.findOne(DeviceEntity, {
		where: { deviceId: deviceId },
	});
	return deviceEntity ? convertDeviceEntityToDevice(deviceEntity) : null;
};

export const getDevicesByProjectId = async (
	dataSource: DataSource,
	projectId: number,
): Promise<DeviceModel[]> => {
	const deviceEntities = await dataSource.manager.find(DeviceEntity, {
		where: { projectId: projectId },
	});
	return deviceEntities.map(convertDeviceEntityToDevice);
};

export const updateDevice = async (
	dataSource: DataSource,
	deviceId: number,
	updates: Partial<DeviceModel>,
): Promise<Boolean> => {
	const existingDevice = await dataSource.manager.findOne(DeviceEntity, {
		where: { deviceId: deviceId },
	});
	if (!existingDevice) {
		console.log(`Device with ID: ${deviceId} not found.`);
		return false;
	}
	if (updates.deviceName) {
		await validateDeviceNameDistinct(dataSource, updates.deviceName);
	}

	const existingDeviceModel = convertDeviceEntityToDevice(existingDevice);
	const updatedDeviceModel = { ...existingDeviceModel, ...updates };
	const newdeviceEntity = convertDeviceToDeviceEntity(updatedDeviceModel);
	const result = await dataSource.manager.update(
		DeviceEntity,
		deviceId,
		newdeviceEntity,
	);
	if (result.affected && result.affected > 0) {
		console.log(`Successfully updated device with ID: ${deviceId}`);
		return true;
	} else {
		console.log(`Failed to update device with ID: ${deviceId}`);
		return false;
	}
};

export const deleteDevice = async (
	dataSource: DataSource,
	deviceId: number,
): Promise<{ success: boolean }> => {
	const result = await dataSource.manager.delete(DeviceEntity, deviceId);
	if (result.affected && result.affected > 0) {
		console.log(`Successfully deleted device with ID: ${deviceId}`);
		return { success: true };
	} else {
		console.log(`Failed to delete device with ID: ${deviceId}`);
		return { success: false };
	}
};

export const deleteDeviceByProjectId = async (
	dataSource: DataSource,
	projectId: number,
): Promise<{ success: boolean }> => {
	const result = await dataSource.manager.delete(DeviceEntity, {
		ProjectId: projectId,
	});
	if (result.affected && result.affected > 0) {
		console.log(`Successfully deleted device with Project ID: ${projectId}`);
		return { success: true };
	} else {
		console.log(`Failed to delete device with Project ID: ${projectId}`);
		return { success: false };
	}
};
