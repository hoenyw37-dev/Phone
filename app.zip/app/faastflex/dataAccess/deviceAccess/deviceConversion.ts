import { DeviceEntity } from '@ff_dataAccess/deviceAccess/deviceEntity.ts';
import { DeviceModel } from '@ff_model/deviceModel.ts';
import { AppConstants } from '@global/GlobalConstants/globalConstants';
import {
	Country,
	DeviceOrientation,
	DeviceType,
	getCountryDescription,
	getDeviceOrientationDescription,
	getDeviceTypeDescription,
} from '@faastflexCommands/commandEnum';

export const convertDeviceEntityToDevice = (
	entity: DeviceEntity,
): DeviceModel => {
	const model = new DeviceModel();
	try {
		model.deviceId = entity.deviceId;
		model.deviceName =
			entity.deviceName ?? 'Faast Flex Device ' + `${entity.deviceId}`;
		model.deviceLocation = entity.deviceLocation ?? AppConstants.Unknown;
		model.channels = entity.channels ?? 0;
		model.pipeConfiguration = entity.pipeConfiguration ?? '';
		model.pipeLength = entity.pipeLength ?? 0;
		model.minTransportTime = entity.minTransportTime ?? 0;
		model.maxTransportTime = entity.maxTransportTime ?? 0;
		model.lastConnected = entity.lastConnected ?? new Date().toISOString();
		model.createdDateTime = entity.createdDateTime ?? new Date().toISOString();
		model.productionDate = entity.productionDate ?? AppConstants.Unknown;
		model.isManualPairingCompleted = entity.isManualPairingCompleted ?? false;
		model.deviceMacAddress =
			entity.deviceMacAddress ?? AppConstants.NotYetConnected;
		model.deviceCountryCode =
			entity.deviceCountryCode ?? getCountryDescription(Country.Unknown);
		model.deviceOrientation =
			entity.deviceOrientation ??
			getDeviceOrientationDescription(DeviceOrientation.eUnknown);
		model.deviceType =
			entity.deviceType ?? getDeviceTypeDescription(DeviceType.eUnknown);
		model.deviceSerialNumber =
			entity.deviceSerialNumber ?? AppConstants.Unknown;
		model.deviceModelNumber = entity.deviceModelNumber ?? AppConstants.NA;
		model.firmwareVersion = entity.firmwareVersion ?? '';
		model.projectId = entity.projectId ?? 0;
		model.isConfigDataFetched = entity.isConfigDataFetched ?? false;
	} catch (error) {
		console.error('Error converting DeviceEntity to DeviceModel:', error);
	}

	return model;
};

export const convertDeviceToDeviceEntity = (
	model: DeviceModel,
): DeviceEntity => {
	const entity = new DeviceEntity();
	entity.deviceName = model.deviceName;
	entity.deviceLocation = model.deviceLocation;
	entity.channels = model.channels;
	entity.pipeConfiguration = model.pipeConfiguration;
	entity.pipeLength = model.pipeLength;
	entity.minTransportTime = model.minTransportTime;
	entity.maxTransportTime = model.maxTransportTime;
	entity.lastConnected = model.lastConnected;
	entity.createdDateTime = model.createdDateTime;
	entity.productionDate = model.productionDate;
	entity.isManualPairingCompleted = model.isManualPairingCompleted;
	entity.deviceMacAddress = model.deviceMacAddress;
	entity.deviceCountryCode = model.deviceCountryCode;
	entity.deviceOrientation = model.deviceOrientation;
	entity.deviceType = model.deviceType;
	entity.deviceSerialNumber = model.deviceSerialNumber;
	entity.deviceModelNumber = model.deviceModelNumber;
	entity.firmwareVersion = model.firmwareVersion;
	entity.projectId = model.projectId;
	entity.isConfigDataFetched = model.isConfigDataFetched;
	return entity;
};
