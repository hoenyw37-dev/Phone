import {
	Entity,
	Column,
	PrimaryGeneratedColumn,
	OneToMany,
} from 'typeorm/browser';

@Entity('DeviceTests')
export class TestEntity {
	@PrimaryGeneratedColumn()
	id!: number;

	@Column({ type: 'int', nullable: true })
	testId?: number | null;

	@Column({ type: 'varchar' })
	testNameKey!: string;

	@Column({ type: 'varchar' })
	testDescriptionKey!: string;

	@Column({ type: 'boolean' })
	isTestPassed!: boolean;

	@Column({ type: 'boolean' })
	isTestFailed!: boolean;

	@Column({ type: 'boolean' })
	isTested!: boolean;

	@Column({ type: 'boolean' })
	isVisibleTestStatus!: boolean;

	@Column({ type: 'boolean' })
	isTestInProgress!: boolean;

	@Column({ type: 'varchar' })
	testStatustext!: string;

	@Column({ type: 'varchar' })
	passButtonText!: string;

	@Column({ type: 'boolean' })
	isButtonsEnable!: boolean;

	@Column({ type: 'int' })
	deviceId!: number;
}
