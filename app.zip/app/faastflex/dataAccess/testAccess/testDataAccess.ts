import { DataSource } from 'typeorm';
import { TestEntity } from './testEntity';
import {
	convertTestEntityToTest,
	convertTestToTestEntity,
} from './testDataConversion';
import { TestsModel } from '../../model/testModel';

export const getAllTests = async (
	dataSource: DataSource,
): Promise<TestsModel[]> => {
	console.log('LOADING TESTS');
	const rawresult = await dataSource.manager.find(TestEntity);
	const result = rawresult.map(convertTestEntityToTest);
	return result;
};

export const getAllTestsByID = async (
	dataSource: DataSource,
	deviceId: number,
): Promise<TestsModel[]> => {
	console.log('LOADING TEST BY ID');
	const rawresult = await dataSource.manager.find(TestEntity, {
		where: { deviceId },
	});
	const result = rawresult.map(convertTestEntityToTest);
	return result;
};
export const addTest = async (
	dataSource: DataSource,
	test: TestsModel,
): Promise<TestsModel> => {
	//TODO: Move this conversion to business class
	const testEntity = convertTestToTestEntity(test);
	const newTestEnt = await dataSource.manager.save(TestEntity, testEntity);
	const newTest = convertTestEntityToTest(newTestEnt);
	return newTest;
};

export const addAllTests = async (
	dataSource: DataSource,
	tests: TestsModel[],
): Promise<TestsModel[]> => {
	//TODO: Move this conversion to business class
	const testEntities = tests.map(convertTestToTestEntity);
	const newTestEnts = await dataSource.manager.save(TestEntity, testEntities);
	const newTests = newTestEnts.map(convertTestEntityToTest);
	return newTests;
};

export const updateTest = async (
	dataSource: DataSource,
	testId: number,
	updates: Partial<TestsModel>,
): Promise<Boolean> => {
	// Get the existing test
	const existingTest = await dataSource.manager.findOne(TestEntity, {
		where: { testId },
	});
	if (!existingTest) {
		console.log(`Test with ID: ${testId} not found.`);
		return false;
	}

	// Convert to model, apply updates, then convert back to entity
	const existingTestModel = convertTestEntityToTest(existingTest);
	const updatedTestModel = { ...existingTestModel, ...updates };
	const testEntity = convertTestToTestEntity(updatedTestModel);

	console.log('UPDATED TEST ENTITY...', testEntity);
	const result = await dataSource.manager.update(
		TestEntity,
		testId,
		testEntity,
	);
	if (result.affected && result.affected > 0) {
		console.log(`Successfully updated test with ID: ${testId}`);
		return true;
	} else {
		console.log(`Failed to update test with ID: ${testId}`);
		return false;
	}
};

export const deleteTest = async (
	dataSource: DataSource,
	testId: number,
): Promise<{ success: boolean }> => {
	//console.log(testEntity);
	const result = await dataSource.manager.delete(TestEntity, testId);
	if (result.affected && result.affected > 0) {
		console.log(`Successfully deleted test with ID: ${testId}`);
		return { success: true };
	} else {
		console.log(`Failed to delete test with ID: ${testId}`);
		return { success: false };
	}
};
