import { TestEntity } from './testEntity';
import { TestsModel } from '../../model/testModel';

export const convertTestEntityToTest = (entity: TestEntity): TestsModel => {
	return {
		id: entity.id ?? 0,
		testId: entity.testId ?? 0,
		testNameKey: entity.testNameKey,
		testDescriptionKey: entity.testDescriptionKey,
		isTestPassed: entity.isTestPassed,
		isTestFailed: entity.isTestFailed,
		isTested: entity.isTested,
		isVisibleTestStatus: entity.isVisibleTestStatus,
		isTestInProgress: entity.isTestInProgress,
		testStatustext: entity.testStatustext,
		passButtonText: entity.passButtonText,
		isButtonsEnable: entity.isButtonsEnable,
		deviceId: entity.deviceId,
	};
};

export const convertTestToTestEntity = (test: TestsModel): TestEntity => {
	const entity = new TestEntity();
	entity.testId = test.testId;
	entity.testNameKey = test.testNameKey;
	entity.testDescriptionKey = test.testDescriptionKey;
	entity.isTestPassed = test.isTestPassed;
	entity.isTestFailed = test.isTestFailed;
	entity.isTestInProgress = test.isTestInProgress;
	entity.isTested = test.isTested;
	entity.isVisibleTestStatus = test.isVisibleTestStatus;
	entity.testStatustext = test.testStatustext;
	entity.passButtonText = test.passButtonText;
	entity.isButtonsEnable = test.isButtonsEnable;
	entity.deviceId = test.deviceId;
	return entity;
};
