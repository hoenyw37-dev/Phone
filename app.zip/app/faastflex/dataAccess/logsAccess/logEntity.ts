import { Entity, PrimaryGeneratedColumn, Column } from 'typeorm';

@Entity('EventLog')
export class EventLogEntity {
	@PrimaryGeneratedColumn()
	Id!: number;

	@Column({ type: 'int' })
	logId?: number | null;

	@Column({ type: 'varchar' })
	eventDateTime?: string | null;

	@Column({ type: 'int' })
	eventName?: number | null;

	@Column({ type: 'varchar' })
	eventDescription?: string | null;

	@Column({ type: 'varchar', nullable: true })
	addtionalInfo?: string | null;

	@Column({ type: 'varchar', nullable: true })
	eventDate?: string;

	@Column({ type: 'varchar', nullable: true })
	eventTime?: string | null;

	@Column({ type: 'int', nullable: true })
	eventType?: number | null;

	@Column({ type: 'varchar', nullable: true })
	eventTypeStr?: string | null;

	@Column({ type: 'int', nullable: true })
	logChannel?: number | null;

	@Column({ type: 'varchar', nullable: true })
	logChannelsStr?: string | null;

	@Column({ type: 'varchar', nullable: true })
	eventBarColor?: string | null;

	@Column({ type: 'varchar', nullable: true })
	statusIcon?: string | null;

	@Column({ type: 'varchar', nullable: true })
	eventIdInfo?: string | null | null;

	@Column({ type: 'boolean', nullable: true })
	showErrorMessage?: boolean | null;

	@Column({ type: 'varchar', nullable: true })
	deviceMacAddress?: string | null;

	@Column({ type: 'int', nullable: true })
	ch1Temperature?: number;

	@Column({ type: 'int', nullable: true })
	ch2Temperature?: number | null;

	@Column({ type: 'int', nullable: true })
	ch1Flow?: number | null;

	@Column({ type: 'int', nullable: true })
	ch2Flow?: number | null;

	@Column({ type: 'int', nullable: true })
	ch1Sensor?: number | null;

	@Column({ type: 'int', nullable: true })
	ch2Sensor?: number | null;

	@Column({ type: 'int', nullable: true })
	blowerRPM?: number | null;
}
