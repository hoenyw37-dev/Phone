import { DataSource } from 'typeorm';
import { EventLogEntity } from './logEntity';
import {
	convertEventLogEntityToEventLog,
	convertEventLogToEventLogEntity,
} from './logDataConversion';
import { EventLogModel } from '../../model/eventLogModel';

export const getAllEventLogs = async (
	dataSource: DataSource,
): Promise<EventLogModel[]> => {
	console.log('LOADING TEST HISTORY');
	const rawresult = await dataSource.manager.find(EventLogEntity);
	const result = rawresult.map(convertEventLogEntityToEventLog);
	return result;
};

export const getAllEventLogsByMACAddress = async (
	dataSource: DataSource,
	macAddress: string,
): Promise<EventLogModel[]> => {
	console.log(`LOADING TEST HISTORY FOR DEVICE: ${macAddress}`);
	const rawresult = await dataSource.manager.find(EventLogEntity, {
		where: { deviceMacAddress: macAddress },
	});
	const result = rawresult.map(convertEventLogEntityToEventLog);
	return result;
};

export const getEventLog = async (
	dataSource: DataSource,
	Id: number,
): Promise<EventLogModel> => {
	console.log(`LOADING TEST HISTORY FOR ID: ${Id}`);
	const rawresult = await dataSource.manager.findOne(EventLogEntity, {
		where: { logId: Id },
	});
	if (!rawresult) {
		console.log(`No test history found for ID: ${Id}`);
		throw new Error(`No test history found for ID: ${Id}`);
	}
	return convertEventLogEntityToEventLog(rawresult);
};

export const addEventLog = async (
	dataSource: DataSource,
	eventLog: EventLogModel,
): Promise<EventLogModel> => {
	const eventLogEntity = convertEventLogToEventLogEntity(eventLog);
	const newEventLog = await dataSource.manager.save(
		EventLogEntity,
		eventLogEntity,
	);
	return convertEventLogEntityToEventLog(newEventLog);
};

export const addAllEventLogs = async (
	dataSource: DataSource,
	eventLogs: EventLogModel[],
): Promise<EventLogModel[]> => {
	const eventLogEntities = eventLogs.map(convertEventLogToEventLogEntity);
	const newEventLogs = await dataSource.manager.save(
		EventLogEntity,
		eventLogEntities,
	);
	const newLogs = newEventLogs.map(convertEventLogEntityToEventLog);
	return newLogs;
};

export const deleteLogs = async (
	dataSource: DataSource,
	id: number,
): Promise<{ success: boolean }> => {
	//console.log(projectEntity);
	const result = await dataSource.manager.delete(EventLogEntity, id);
	if (result.affected && result.affected > 0) {
		console.log(`Successfully deleted test history with ID: ${id}`);
		return { success: true };
	} else {
		console.log(`Failed to delete test history with ID: ${id}`);
		return { success: false };
	}
};

export const deleteAllLogs = async (
	dataSource: DataSource,
	macAddress: string,
): Promise<{ success: boolean }> => {
	const result = await dataSource.manager.delete(EventLogEntity, {
		deviceMacAddress: macAddress,
	});
	if (result.affected && result.affected > 0) {
		console.log(
			`Successfully deleted all test history for device: ${macAddress}`,
		);
		return { success: true };
	} else {
		console.log(`Failed to delete all test history for device: ${macAddress}`);
		return { success: false };
	}
};
