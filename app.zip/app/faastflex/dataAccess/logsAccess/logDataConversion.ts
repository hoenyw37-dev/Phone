import { EventLogEntity } from './logEntity';
import { EventLogModel } from '../../model/eventLogModel';

export const convertEventLogEntityToEventLog = (
	entity: EventLogEntity,
): EventLogModel => {
	const model = new EventLogModel();
	model.Id = entity.Id;
	model.logId = entity.logId ?? 0;
	model.eventDateTime = entity.eventDateTime ?? new Date().toISOString();
	model.eventName = entity.eventName ?? 105;
	model.eventDescription = entity.eventDescription ?? '';
	model.addtionalInfo = entity.addtionalInfo ? entity.addtionalInfo : '';
	model.eventDate = entity.eventDate ?? '';
	model.eventTime = entity.eventTime ?? '';
	model.eventType = entity.eventType ?? 4;
	model.eventTypeStr = entity.eventTypeStr ?? '';
	model.logChannel = entity.logChannel ?? 0;
	model.logChannelsStr = entity.logChannelsStr ?? '';
	model.eventBarColor = entity.eventBarColor ?? '';
	model.statusIcon = entity.statusIcon ?? '';
	model.eventIdInfo = entity.eventIdInfo ?? '';
	model.showErrorMessage = entity.showErrorMessage ?? false;
	model.ch1Temperature = entity.ch1Temperature ?? 0;
	model.ch2Temperature = entity.ch2Temperature ?? 0;
	model.ch1Flow = entity.ch1Flow ?? 0;
	model.ch2Flow = entity.ch2Flow ?? 0;
	model.ch1Sensor = entity.ch1Sensor ?? 0;
	model.ch2Sensor = entity.ch2Sensor ?? 0;
	model.blowerRPM = entity.blowerRPM ?? 0;
	model.deviceMacAddress = entity.deviceMacAddress ?? '';
	return model;
};

export const convertEventLogToEventLogEntity = (
	eventLog: EventLogModel,
): EventLogEntity => {
	const entity = new EventLogEntity();
	entity.logId = eventLog.logId;
	entity.eventDateTime = eventLog.eventDateTime;
	entity.eventName = eventLog.eventName;
	entity.eventDescription = eventLog.eventDescription;
	entity.addtionalInfo = eventLog.addtionalInfo ?? '';
	entity.eventDate = eventLog.eventDate;
	entity.eventTime = eventLog.eventTime;
	entity.eventType = eventLog.eventType;
	entity.eventTypeStr = eventLog.eventTypeStr;
	entity.logChannel = eventLog.logChannel;
	entity.logChannelsStr = eventLog.logChannelsStr;
	entity.eventBarColor = eventLog.eventBarColor;
	entity.statusIcon = eventLog.statusIcon;
	entity.eventIdInfo = eventLog.eventIdInfo ? entity.eventIdInfo : '';
	entity.showErrorMessage = eventLog.showErrorMessage;
	entity.ch1Temperature = eventLog.ch1Temperature;
	entity.ch2Temperature = eventLog.ch2Temperature;
	entity.ch1Flow = eventLog.ch1Flow;
	entity.ch2Flow = eventLog.ch2Flow;
	entity.ch1Sensor = eventLog.ch1Sensor;
	entity.ch2Sensor = eventLog.ch2Sensor;
	entity.blowerRPM = eventLog.blowerRPM;
	entity.deviceMacAddress = eventLog.deviceMacAddress;
	return entity;
};
