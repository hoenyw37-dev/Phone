import {
	Entity,
	Column,
	PrimaryGeneratedColumn,
	OneToMany,
} from 'typeorm/browser';

@Entity('DeviceTestHistory')
export class TestHistoryEntity {
	@PrimaryGeneratedColumn()
	id!: number;

	@Column({ type: 'int' })
	testHistoryId!: number;

	@Column({ type: 'boolean' })
	isTestPassed!: boolean;

	@Column({ type: 'boolean' })
	isTestFailed!: boolean;

	@Column({ type: 'boolean' })
	isTestTested!: boolean;

	@Column({ type: 'boolean' })
	isVisibleTestStatus!: boolean;

	@Column({ type: 'varchar' })
	testStatustext!: string;

	@Column({ type: 'int' })
	deviceId!: number;
}
