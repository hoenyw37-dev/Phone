import { TestHistoryEntity } from './testHistoryEntity';
import { TestsHistoryModel } from '../../model/testHistoryModel';

export const convertTestHistoryEntityToTestHistory = (
	entity: TestHistoryEntity,
): TestsHistoryModel => {
	return {
		id: entity.id ?? 0,
		testHistoryId: entity.testHistoryId,
		isTestPassed: entity.isTestPassed,
		isTestFailed: entity.isTestFailed,
		isVisibleTestStatus: entity.isVisibleTestStatus,
		isTestTested: entity.isTestTested,
		deviceId: entity.deviceId,
		testStatustext: entity.testStatustext,
	};
};

export const convertTestHistoryToTestHistoryEntity = (
	test: TestsHistoryModel,
): TestHistoryEntity => {
	const entity = new TestHistoryEntity();
	entity.testHistoryId = test.testHistoryId;
	entity.isTestPassed = test.isTestPassed;
	entity.isTestFailed = test.isTestFailed;
	entity.isTestTested = test.isTestTested;
	entity.isVisibleTestStatus = test.isVisibleTestStatus;
	entity.testStatustext = test.testStatustext;
	entity.deviceId = test.deviceId;
	return entity;
};
