import { DataSource } from 'typeorm';
import { TestHistoryEntity } from './testHistoryEntity';
import {
	convertTestHistoryEntityToTestHistory,
	convertTestHistoryToTestHistoryEntity,
} from './testHistoryDataConversion';
import { TestsHistoryModel } from '../../model/testHistoryModel';

export const getAllTestHistory = async (
	dataSource: DataSource,
	deviceId: number,
): Promise<TestsHistoryModel[]> => {
	console.log('LOADING TEST HISTORY');
	const rawresult = await dataSource.manager.find(TestHistoryEntity, {
		where: { deviceId },
	});
	const result = rawresult.map(convertTestHistoryEntityToTestHistory);
	return result;
};

export const getTestHistory = async (
	dataSource: DataSource,
	testId: number,
): Promise<TestsHistoryModel> => {
	console.log(`LOADING TEST HISTORY FOR ID: ${testId}`);
	const rawresult = await dataSource.manager.findOne(TestHistoryEntity, {
		where: { id: testId },
	});
	if (!rawresult) {
		console.log(`No test history found for ID: ${testId}`);
		throw new Error(`No test history found for ID: ${testId}`);
	}
	return convertTestHistoryEntityToTestHistory(rawresult);
};

export const addTestHistory = async (
	dataSource: DataSource,
	testHistory: TestsHistoryModel,
): Promise<TestsHistoryModel> => {
	const testHistoryEntity = convertTestHistoryToTestHistoryEntity(testHistory);
	const newTestHistory = await dataSource.manager.save(
		TestHistoryEntity,
		testHistoryEntity,
	);
	return convertTestHistoryEntityToTestHistory(newTestHistory);
};

export const addAllTestHistory = async (
	dataSource: DataSource,
	testHistories: TestsHistoryModel[],
): Promise<TestsHistoryModel[]> => {
	const testHistoryEntities = testHistories.map(
		convertTestHistoryToTestHistoryEntity,
	);
	const newTestHistories = await dataSource.manager.save(
		TestHistoryEntity,
		testHistoryEntities,
	);
	const newTests = newTestHistories.map(convertTestHistoryEntityToTestHistory);
	return newTests;
};

export const updateTestHistory = async (
	dataSource: DataSource,
	testHistoryId: number,
	deviceId: number,
	updates: Partial<TestsHistoryModel>,
): Promise<Boolean> => {
	const existingTestHistory = await dataSource.manager.findOne(
		TestHistoryEntity,
		{ where: { testHistoryId, deviceId } },
	);
	if (!existingTestHistory) {
		console.log(`Test with ID: ${testHistoryId} not found.`);
		return false;
	}
	// Convert to model, apply updates, then convert back to entity
	const existingTestHistoryModel =
		convertTestHistoryEntityToTestHistory(existingTestHistory);
	const updatedTestHistoryModel = { ...existingTestHistoryModel, ...updates };
	const convertedTestHistoryEntity = convertTestHistoryToTestHistoryEntity(
		updatedTestHistoryModel,
	);

	console.log('UPDATED TEST HISTORY ENTITY...', convertedTestHistoryEntity);
	const result = await dataSource.manager.update(
		TestHistoryEntity,
		existingTestHistory.id,
		convertedTestHistoryEntity,
	);
	if (result.affected && result.affected > 0) {
		console.log(
			`Successfully updated test history with ID: ${existingTestHistory.id}`,
		);
		return true;
	} else {
		console.log(
			`Failed to update test history with ID: ${existingTestHistory.id}`,
		);
		return false;
	}
};

export const deleteTestHistory = async (
	dataSource: DataSource,
	testHistoryId: number,
): Promise<{ success: boolean }> => {
	//console.log(projectEntity);
	const result = await dataSource.manager.delete(
		TestHistoryEntity,
		testHistoryId,
	);
	if (result.affected && result.affected > 0) {
		console.log(`Successfully deleted test history with ID: ${testHistoryId}`);
		return { success: true };
	} else {
		console.log(`Failed to delete test history with ID: ${testHistoryId}`);
		return { success: false };
	}
};

export const deleteTestHistoryByDeviceId = async (
	dataSource: DataSource,
	deviceId: number,
): Promise<{ success: boolean; deletedCount: number }> => {
	// First check if any records exist for this deviceId
	const existingRecords = await dataSource.manager.find(TestHistoryEntity, {
		where: { deviceId },
	});

	if (existingRecords.length === 0) {
		console.log(`No test history records found for device ID: ${deviceId}`);
		return { success: true, deletedCount: 0 };
	}

	// Proceed with deletion if records exist
	const result = await dataSource.manager.delete(TestHistoryEntity, {
		deviceId,
	});
	if (result.affected && result.affected > 0) {
		console.log(
			`Successfully deleted ${result.affected} test history records for device ID: ${deviceId}`,
		);
		return { success: true, deletedCount: result.affected };
	} else {
		console.log(
			`Failed to delete test history records for device ID: ${deviceId}`,
		);
		return { success: false, deletedCount: 0 };
	}
};
