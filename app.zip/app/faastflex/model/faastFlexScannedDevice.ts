import { BluetoothDevice } from '../../../bleCommunicator/bleService';

export class FaastFlexScannedDevice {
	constructor() {
		this.connectedDevice = {
			address: '',
			name: '',
			rssi: 0,
			status: '',
			connected: false,
		};
		this.lastPairedOfflineDeviceName = '';
		this.isLastConnectedWithSelectedDevice = false;
		this.pairingStatus = '';
		this.signalStrength = '';
	}

	connectedDevice: BluetoothDevice;

	lastPairedOfflineDeviceName: string;

	isLastConnectedWithSelectedDevice: boolean;

	pairingStatus: string;

	signalStrength: string;
}
