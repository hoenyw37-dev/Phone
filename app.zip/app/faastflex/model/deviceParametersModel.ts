import { AppConstants } from '@global/GlobalConstants/globalConstants.ts';
import {
	AlarmMode,
	DeviceType,
	ExternalInputAction,
	ExternalInputMode,
	ExternalInputNormalState,
	FanSpeedLevel,
	LatchedMode,
	RelayAlert,
} from '@faastflexCommands/commandEnum.ts';
export class DeviceParametersModel {
	// General parameters
	password: string = '';
	deviceId: number = 0;
	installationDate: Date = new Date();
	timeOutDisabled: number = 0;
	trendLogDisabled: number = 0;
	temperatureFaultRelay: RelayAlert = RelayAlert.eUnset;
	lowPowerFaultRelay: RelayAlert = RelayAlert.eUnset;
	gpiState: boolean = false;
	externalInputNormalState: ExternalInputNormalState =
		ExternalInputNormalState.eUnknown;
	unbalancedEventTriggered: ExternalInputAction = ExternalInputAction.eNone;
	externalTriggerOnOpen: ExternalInputAction = ExternalInputAction.eNone;
	externalTriggerOnClosed: ExternalInputAction = ExternalInputAction.eNone;
	blowerSpeed: FanSpeedLevel = FanSpeedLevel.eUnknown;
	blowerCorrection: string = AppConstants.NA;

	// DeviceType
	deviceType: DeviceType = DeviceType.eUnknown;

	// Channel and sensors
	channel1ActionLevel: number = 0;
	channel1AlarmLevel: number = 0;
	channel2ActionLevel: number = 0;
	channel2AlarmLevel: number = 0;
	isChannel2Disabled: boolean = false;
	actionDelay: number = 0;
	alarmDelay: number = 0;
	flowFaultDelay: number = 0;
	alarmLatched: LatchedMode = LatchedMode.eUnknown;
	actionLatched: LatchedMode = LatchedMode.eUnknown;
	faultLatched: LatchedMode = LatchedMode.eUnknown;
	referenceFlowCh1: number = 0;
	referenceFlowCh2: number = 0;
	flowFaultThresholdCh1: number = 0;
	flowFaultThresholdCh2: number = 0;
	deviceAlarmMode: AlarmMode = AlarmMode.eUnknown;
	createdDateTime: Date = new Date();
	installationDateTime: Date = new Date();
	gpInputState: ExternalInputMode = ExternalInputMode.eUnknown;
	deviceName: string = 'Faast Flex Device 1';
	channels: number = 0;
	alarm2Latched: LatchedMode = LatchedMode.eUnknown;
	auxFaultLatched: LatchedMode = LatchedMode.eUnknown;
	generalFaultLatched: LatchedMode = LatchedMode.eUnknown;
}
