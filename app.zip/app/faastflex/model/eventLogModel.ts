import {
	LogEventId,
	LogEventType,
	LogEventZone,
} from '@faastflexCommands/command_log';

export class EventLogModel {
	Id: number = 0;
	logId: number = 0;
	eventDateTime: string = new Date().toISOString();
	eventName: LogEventId = LogEventId.LOG_EVENT_NONE;
	eventDescription: string = '';
	addtionalInfo: string = '';
	eventDate: string = '';
	eventTime: string = '';
	eventType: LogEventType = LogEventType.eUnknown;
	eventTypeStr: string = '';
	logChannel: number = 0;
	logChannelsStr: string = '';
	eventBarColor: string = '#FFD153';
	statusIcon: string = 'DisabledStatus.png';
	eventIdInfo: string = '';
	showErrorMessage: boolean = false;
	ch1Temperature: number = 0;
	ch2Temperature: number = 0;
	ch1Flow: number = 0;
	ch2Flow: number = 0;
	ch1Sensor: number = 0;
	ch2Sensor: number = 0;
	blowerRPM: number = 0;
	deviceMacAddress: string = '';
}
