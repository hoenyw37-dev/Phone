export class TestsHistoryModel {
	id: number = 0;
	deviceId: number = 0;
	testHistoryId: number = 0;
	isTestPassed: boolean = false;
	isTestFailed: boolean = false;
	isTestTested: boolean = false;
	isVisibleTestStatus: boolean = false;
	testStatustext: string = 'Pass.png';
}
