import { BaseDetailsModel } from '../../../global/Model/BaseDetailsModel.ts';
import { SmokeAlarmLevel } from '@faastflexCommands/commandEnum.ts';

export class Channels implements BaseDetailsModel {
	constructor() {}
	id: number = 0;
	user: string = '';
	lastModifiedDate: string = '';
	isUpdated: boolean = false;

	public deviceId: number = 0;
	public rate: number = 0;
	public temperature: string = '';
	public channel: string = '';
	public smokeLevel: SmokeAlarmLevel = SmokeAlarmLevel.eUnknown;
	public alarmLevel: number = 0;
	public preAlarmLevel: number = 0;
	public minFlowRate: number = 0;
	public maxFlowRate: number = 0;
	public refFlowRate: number = 0;
}
