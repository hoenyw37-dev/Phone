import {
	Configuration,
	Country,
	DeviceAuthenticated,
	DeviceOrientation,
	DeviceStatus,
	DeviceType,
	getConfigurationDescription,
	getCountryDescription,
	getDeviceOrientationDescription,
	getDeviceStatusDescription,
	getDeviceTypeDescription,
	getRelayEnabledDescription,
	RelayEnabled,
} from '@faastflexCommands/commandEnum.ts';
import { Channels } from './channels.ts';
import { dateToStringFormatter } from '@ff_utils/dateTimeFormatter.ts';
import { AppConstants } from '../../../global/GlobalConstants/globalConstants.ts';

export class DeviceModel {
	deviceId: number = 0;
	deviceName: string = 'Faast Flex Device 1';
	deviceLocation: string = AppConstants.Unknown;
	channels: number = 0;
	pipeConfiguration: string = 'I';
	pipeLength: number = 0;
	minTransportTime: number = 0;
	maxTransportTime: number = 0;
	lastConnected: string = new Date().toISOString();
	createdDateTime: string = new Date().toISOString();
	productionDate: string = AppConstants.Unknown;
	isDeviceConnected: boolean = false;
	isManualPairingCompleted: boolean = false;
	blowerRPMSpeed: number = 0;
	deviceConfig: Configuration = Configuration.Unknown;
	deviceConfigStr: string = getConfigurationDescription(Configuration.Unknown);
	deviceMacAddress: string = AppConstants.NotYetConnected;
	deviceCountryCode: string = getCountryDescription(Country.Unknown);
	deviceOrientation: string = getDeviceOrientationDescription(
		DeviceOrientation.eUnknown,
	);
	deviceType: string = getDeviceTypeDescription(DeviceType.eUnknown);
	deviceSerialNumber: string = AppConstants.Unknown;
	deviceModelNumber: string = AppConstants.NA;
	firmwareVersion: string = '';
	deviceStatusStr: string = getDeviceStatusDescription(DeviceStatus.UNKNOWN);
	statusIcon: string = '';
	deviceStatus: DeviceStatus = DeviceStatus.UNKNOWN;
	isDeviceExpanded: boolean = false;
	projectId: number = 0;
	lastConnectedString: string = dateToStringFormatter(
		this.lastConnected,
		'dd MMM yyyy',
	);
	authenticatedStatus: DeviceAuthenticated = DeviceAuthenticated.eUnknown;
	deviceStateString: string = getDeviceStateDescription(DeviceState.eUnknown);
	deviceState: DeviceState = DeviceState.eUnknown;
	stateIcon: string = '';
	relayEnabled: RelayEnabled = RelayEnabled.Unknown;
	relayEnabledStr: string = getRelayEnabledDescription(RelayEnabled.Unknown);
	isConfigDataFetched: boolean = false;
	listOfChannels: Channels[] = [];
	transportationTime: string =
		this.minTransportTime + ' - ' + this.maxTransportTime + ' sec';
}

export enum SmokeAlarmLevel {
	Low,
	Medium,
	High,
}
//#region  Country
// Enum definition
enum DeviceState {
	eAlarm = 1,
	eNormal = 2,
	eFault = 3,
	eAction = 4,
	eAlert = 5,
	eUnknown = 6,
}

// Description mapping object
const DeviceStateDescriptions: Record<DeviceState, string> = {
	[DeviceState.eAlarm]: 'Alarm',
	[DeviceState.eNormal]: 'Normal',
	[DeviceState.eFault]: 'Fault',
	[DeviceState.eAction]: 'Action',
	[DeviceState.eAlert]: 'Alert',
	[DeviceState.eUnknown]: 'Unknown',
};

// Helper function to get description
function getDeviceStateDescription(state: DeviceState): string {
	return DeviceStateDescriptions[state];
}

export { DeviceState, getDeviceStateDescription };

//#endregion

export type EventLogClass = {};
