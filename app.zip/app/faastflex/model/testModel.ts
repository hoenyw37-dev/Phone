export class TestsModel {
	id: number = 0;
	testId: number = 0;
	deviceId: number = 0;
	testNameKey: string = '';
	testDescriptionKey: string = '';
	isTestPassed: boolean = false;
	isTestFailed: boolean = false;
	isTestInProgress: boolean = false;
	isTested: boolean = false;
	isVisibleTestStatus: boolean = false;
	testStatustext: string = '';
	passButtonText: string = '';
	isButtonsEnable: boolean = false;
}
