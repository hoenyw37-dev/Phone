// Create a TimeSpan class in a separate file
export class TimeSpan {
	private milliseconds: number = 0;

	constructor(hours: number = 0, minutes: number = 0, seconds: number = 0) {
		this.milliseconds = (hours * 3600 + minutes * 60 + seconds) * 1000;
	}
	getHours(): number {
		return Math.floor(this.milliseconds / (1000 * 60 * 60));
	}

	getMinutes(): number {
		return Math.floor(this.milliseconds / (1000 * 60)) % 60;
	}

	getSeconds(): number {
		return Math.floor(this.milliseconds / 1000) % 60;
	}
}
