// Add this import at the top of your file
import { Alert } from 'react-native';

/**
 * Shows a confirmation dialog and returns a Promise that resolves to the user's choice
 * @param message The message to display in the dialog
 * @param title The title of the dialog
 * @param confirmText Text for the confirm button
 * @param cancelText Text for the cancel button
 * @returns Promise that resolves to true if confirmed, false if canceled
 */
export const confirmAlert = async (
	message: string,
	title: string,
	confirmText: string = 'Positive',
	cancelText: string = 'Negative',
): Promise<boolean> => {
	return new Promise(resolve => {
		Alert.alert(
			title,
			message,
			[
				{
					text: cancelText,
					style: 'cancel',
					onPress: () => resolve(false),
				},
				{
					text: confirmText,
					onPress: () => resolve(true),
				},
			],
			{ cancelable: false },
		);
	});
};
