import { format, isValid } from 'date-fns';

export const dateToStringFormatter = (
	dateString: string,
	formatString: string,
): string => {
	const date = new Date(dateString);
	if (!date || !isValid(date)) {
		return '';
	}
	try {
		return format(date, formatString);
	} catch (error) {
		console.error('Error formatting date:', error);
		return '';
	}
};
