export class stringFunction {
	public static isStringNullOrEmpty(value: string | null | undefined): boolean {
		if (value === null || value === undefined) {
			return true;
		}
		return value.trim() === '';
	}
}
