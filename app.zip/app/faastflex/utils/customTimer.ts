// CustomTimer class for React Native
export class CustomTimer {
	private intervalId: NodeJS.Timeout | null = null;
	private readonly timespan: number; // in milliseconds
	private readonly callback: () => void;
	private isCancelled: boolean = false;

	constructor(timespan: number, callback: () => void) {
		this.timespan = timespan;
		this.callback = callback;
	}

	public start(): void {
		this.isCancelled = false;
		this.intervalId = setInterval(() => {
			if (this.isCancelled) {
				this.stop();
				return;
			}
			this.callback();
		}, this.timespan);
	}

	public stop(): void {
		if (this.intervalId) {
			clearInterval(this.intervalId);
			this.intervalId = null;
		}
		this.isCancelled = true;
	}
}
