class SoundPairingDecoder {
	static ErrorCode = {
		eOK: 'eOK',
		eUnknown: 'eUnknown',
		eERR_INPUT_RECORD_TOO_SHORT: 'eERR_INPUT_RECORD_TOO_SHORT',
		eERR_INPUT_INVALID_INPUT_LENGTH: 'eERR_INPUT_INVALID_INPUT_LENGTH',
		eEERR_INPUT_SAMPLING_FREQUENCY: 'eEERR_INPUT_SAMPLING_FREQUENCY',
		eEERR_FIRST_DIGIT_NOT_FOUND: 'eEERR_FIRST_DIGIT_NOT_FOUND',
		eERR_DIGIT_NOT_FOUND: 'eERR_DIGIT_NOT_FOUND',
	};

	// Declare class properties
	private m_overlapping_divider: number;
	private m_frequency_limits: number[];
	private m_frequency_first: number[] | null;
	private m_frequency_second: number[] | null;
	private m_sampling_frequency: number;
	private m_windows_sample: number;
	private m_cos_first: number[][] | null;
	private m_sin_first: number[][] | null;
	private m_cos_second: number[][] | null;
	private m_sin_second: number[][] | null;

	static getRecordingTime() {
		console.log('Getting recording time: 6000ms');
		return 6000; // Fixed recording time in milliseconds
	}
	constructor() {
		console.log('Initializing SoundPairingDecoder');
		this.m_overlapping_divider = 5;
		this.m_frequency_limits = [
			2460.0, 2540.0, 2620.0, 2700.0, 2780.0, 2860.0, 2940.0, 3020.0, 3100.0,
			3180.0, 3260.0,
		];
		this.m_frequency_first = null;
		this.m_frequency_second = null;
		this.m_sampling_frequency = 0;
		this.m_windows_sample = 0;
		this.m_cos_first = null;
		this.m_sin_first = null;
		this.m_cos_second = null;
		this.m_sin_second = null;
	}
	async getDigits(
		sampleRate: number,
		pcmData: number[],
		recordingTimeMs: number,
		digits: number[],
	) {
		console.log('=== getDigits CALLED ===');
		console.log(
			`With parameters: sampleRate=${sampleRate}, recordingTimeMs=${recordingTimeMs}`,
		);
		console.log(`PCM data length: ${pcmData.length}`);

		try {
			// If no digits array is provided, create one
			if (!digits || !Array.isArray(digits)) {
				digits = new Array(6).fill(0);
			} else {
				// Reset the provided array
				digits.fill(0);
			}

			console.log('Reset digits array to zeros');

			const validationError = this.validateInput(
				pcmData,
				sampleRate,
				recordingTimeMs,
			);

			console.log(`Validation result: ${validationError}`);
			if (validationError !== SoundPairingDecoder.ErrorCode.eOK) {
				console.log(`VALIDATION ERROR: ${validationError}`);
				return validationError;
			}

			console.log('Input validation passed, running decoder...');
			const result = this.run(pcmData, digits);

			// Return the result code, the digits array will be modified by reference
			return result;
		} catch (error) {
			console.error('EXCEPTION in getDigits:', error);
			return SoundPairingDecoder.ErrorCode.eUnknown;
		}
	}

	validateInput(
		signal: number[],
		samplingFrequency: number,
		recordedTimeMilliseconds: number,
	) {
		console.log('=== validateInput CALLED ===');
		console.log(`Sampling frequency: ${samplingFrequency}`);
		console.log(`Signal length: ${signal.length}`);
		console.log(`Recorded time: ${recordedTimeMilliseconds}ms`);

		// 1. Sample rate validation (with override)
		if (samplingFrequency < 12000) {
			console.warn('OVERRIDING SAMPLE RATE VALIDATION FOR TESTING');
			this.m_sampling_frequency = 16000; // Force minimum workable rate
			samplingFrequency = 16000;
		}

		this.m_sampling_frequency = samplingFrequency;
		console.log(
			`Effective processing sample rate: ${this.m_sampling_frequency}`,
		);

		// 2. Empty signal check
		if (signal.length === 0) {
			console.error('ERROR: Empty signal');
			return SoundPairingDecoder.ErrorCode.eERR_INPUT_RECORD_TOO_SHORT;
		}

		// 3. Recording duration check
		const recordingTimeMs = SoundPairingDecoder.getRecordingTime();
		console.log(`Required recording time: ${recordingTimeMs}ms`);
		console.log(`Provided recording time: ${recordedTimeMilliseconds}ms`);

		if (recordedTimeMilliseconds < 1000) {
			// Absolute minimum
			console.error('ERROR: Recording too short (<1s)');
			return SoundPairingDecoder.ErrorCode.eERR_INPUT_RECORD_TOO_SHORT;
		}

		// 4. Sample count validation (relaxed)
		const estimatedSampleNumber =
			(samplingFrequency * recordedTimeMilliseconds) / 1000.0;
		const realSampleNumber = signal.length;
		const percDiff =
			((realSampleNumber - estimatedSampleNumber) / estimatedSampleNumber) *
			100.0;

		console.log('=== SAMPLE COUNT VALIDATION ===');
		console.log(`Estimated samples: ${estimatedSampleNumber}`);
		console.log(`Actual samples: ${realSampleNumber}`);
		console.log(`Difference: ${percDiff.toFixed(2)}%`);
		console.log(`Threshold: -30.0%`);

		if (percDiff < -30.0) {
			console.warn(
				`WARNING: Sample count low (${percDiff.toFixed(2)}%) but continuing`,
			);
			// Continue processing despite the warning
		}

		// 5. Additional quality checks
		const firstNonZero = signal.findIndex(s => Math.abs(s) > 0.001);
		if (firstNonZero === -1) {
			console.error('ERROR: Signal appears completely silent');
			return SoundPairingDecoder.ErrorCode.eERR_INPUT_RECORD_TOO_SHORT;
		} else if (firstNonZero > signal.length * 0.1) {
			console.warn(`WARNING: Signal starts with ${firstNonZero} zero samples`);
		}

		console.log('Input validation passed successfully');
		return SoundPairingDecoder.ErrorCode.eOK;
	}

	run(binaryRawData: number[], password: number[]) {
		console.log('=== run METHOD CALLED ===');
		console.log(`Binary data length: ${binaryRawData.length}`);

		password.fill(0);
		console.log('Password array reset to zeros');

		console.log('Initializing frequency tables...');
		this.init();
		console.log('Frequency tables initialized');

		console.log('Searching for first digit marker...');
		const searchResult = this.searchForFirstDigit(binaryRawData);
		console.log(`First digit search result: ${JSON.stringify(searchResult)}`);

		if (searchResult.errorCode !== SoundPairingDecoder.ErrorCode.eOK) {
			console.log(`ERROR searching for first digit: ${searchResult.errorCode}`);
			return searchResult.errorCode;
		}

		// Get the marker position
		let firstDigitIndex = searchResult.firstDigitIndex;
		console.log(`Found first digit marker at position ${firstDigitIndex}`);

		// IMPORTANT: Use the exact same calculation as C# code
		// C#: digitStartIndex += (UInt32)(0.6720 * m_sampling_frequency);
		// Using the precise constant 0.6720 for exact compatibility
		firstDigitIndex += Math.floor(0.672 * this.m_sampling_frequency);
		console.log(`Adjusted start index to ${firstDigitIndex}`);

		// Extract all 6 digits with the exact same spacing as C#
		for (let i = 0; i < 6; i++) {
			console.log(`Extracting digit ${i + 1} from position ${firstDigitIndex}`);

			const digitError = this.getDigit(
				binaryRawData,
				firstDigitIndex,
				password,
				i,
			);

			if (digitError !== SoundPairingDecoder.ErrorCode.eOK) {
				console.log(`ERROR extracting digit ${i + 1}: ${digitError}`);
				return digitError;
			}

			console.log(`Successfully extracted digit ${i + 1}: ${password[i]}`);

			// Use EXACTLY the same calculation as C# for precise compatibility
			firstDigitIndex += Math.floor(0.672 * this.m_sampling_frequency);
			console.log(`Next digit position: ${firstDigitIndex}`);
		}

		console.log('Successfully decoded all digits:', password);
		return SoundPairingDecoder.ErrorCode.eOK;
	}

	// Replace the init method
	init() {
		console.log('=== init METHOD CALLED ===');

		try {
			// Define frequency resolution same as in C#
			const frequency_resolution_hz = 10.0;

			console.log(`Frequency range: 2400Hz - 3300Hz`);
			console.log(`Frequency resolution: ${frequency_resolution_hz}Hz`);

			// IMPORTANT: Use exactly the same formula as C# to calculate window size
			// C#: m_windows_sample = (UInt32)((1.0 * m_sampling_frequency) / frequency_resolution_hz + 0.5);
			this.m_windows_sample = Math.floor(
				(1.0 * this.m_sampling_frequency) / frequency_resolution_hz + 0.5,
			);

			console.log(
				`Window size set to ${this.m_windows_sample} samples (${(
					(this.m_windows_sample / this.m_sampling_frequency) *
					1000
				).toFixed(2)}ms)`,
			);

			console.log('Initializing sin/cos lookup tables');

			// Initialize frequency vectors first
			const freqResult = this.initFrequencyVectors();
			if (freqResult !== SoundPairingDecoder.ErrorCode.eOK) {
				console.error('Failed to initialize frequency vectors');
				return freqResult;
			}

			// Then initialize sin/cos tables
			const sinCosResult = this.initSinCos();
			if (sinCosResult !== SoundPairingDecoder.ErrorCode.eOK) {
				console.error('Failed to initialize sin/cos tables');
				return sinCosResult;
			}

			return SoundPairingDecoder.ErrorCode.eOK;
		} catch (error) {
			console.error('Exception in init:', error);
			return SoundPairingDecoder.ErrorCode.eUnknown;
		}
	}

	// Replace the initFrequencyVectors method
	initFrequencyVectors() {
		console.log('=== initFrequencyVectors CALLED ===');

		// Calculate the array length correctly
		const freqMin = 2400.0;
		const freqMax = 3300.0;
		const frequency_resolution_hz = 10.0;

		// Calculate number of frequency points
		const numFrequencyPoints =
			Math.floor((freqMax - freqMin) / frequency_resolution_hz) + 1;
		console.log(
			`Creating frequency arrays with ${numFrequencyPoints} elements`,
		);

		// Initialize arrays with correct size
		this.m_frequency_first = new Array(numFrequencyPoints).fill(0);
		this.m_frequency_second = new Array(numFrequencyPoints).fill(0);

		// Fill in frequency values
		for (let i = 0; i < numFrequencyPoints; i++) {
			this.m_frequency_first[i] = freqMin + i * frequency_resolution_hz;
			this.m_frequency_second[i] = 2 * this.m_frequency_first[i]; // Second harmonic
		}

		console.log(`First frequency range: ${freqMin}Hz - ${freqMax}Hz`);
		console.log(`Second frequency range: ${2 * freqMin}Hz - ${2 * freqMax}Hz`);

		return SoundPairingDecoder.ErrorCode.eOK;
	}

	// Replace the initSinCos method
	initSinCos() {
		console.log('=== initSinCos CALLED ===');
		console.log(`Window sample size: ${this.m_windows_sample}`);
		if (!this.m_frequency_first) {
			console.error('Frequency arrays not initialized');
			return SoundPairingDecoder.ErrorCode.eUnknown;
		}
		console.log(`Number of frequencies: ${this.m_frequency_first.length}`);

		// Safely calculate array sizes
		if (!this.m_frequency_first.length) {
			console.error('Frequency arrays not initialized');
			return SoundPairingDecoder.ErrorCode.eUnknown;
		}

		const numFrequencies = this.m_frequency_first.length;
		console.log(`Creating sin/cos arrays...`);

		// Create sin/cos arrays with correct dimensions
		this.m_sin_first = new Array(numFrequencies);
		this.m_cos_first = new Array(numFrequencies);
		this.m_sin_second = new Array(numFrequencies);
		this.m_cos_second = new Array(numFrequencies);

		// Initialize nested arrays
		for (let i = 0; i < numFrequencies; i++) {
			this.m_sin_first[i] = new Array(this.m_windows_sample).fill(0);
			this.m_cos_first[i] = new Array(this.m_windows_sample).fill(0);
			this.m_sin_second[i] = new Array(this.m_windows_sample).fill(0);
			this.m_cos_second[i] = new Array(this.m_windows_sample).fill(0);
		}

		// Calculate the period between samples
		const sample_period = 1.0 / this.m_sampling_frequency;
		console.log(`Sample period: ${sample_period}`);

		// Now calculate sin/cos values
		console.log(`Calculating sin/cos values...`);
		for (let i = 0; i < numFrequencies; i++) {
			for (let j = 0; j < this.m_windows_sample; j++) {
				// First frequency range
				const angle1 =
					2.0 * Math.PI * this.m_frequency_first[i] * j * sample_period;
				this.m_sin_first[i][j] = Math.sin(angle1);
				this.m_cos_first[i][j] = Math.cos(angle1);

				// Second frequency range (harmonic)
				const freqSecond = this.m_frequency_second
					? this.m_frequency_second[i]
					: 0;
				const angle2 = 2.0 * Math.PI * freqSecond * j * sample_period;
				this.m_sin_second[i][j] = Math.sin(angle2);
				this.m_cos_second[i][j] = Math.cos(angle2);
			}
		}

		console.log(`Sin/cos calculation completed`);
		return SoundPairingDecoder.ErrorCode.eOK;
	}

	searchForFirstDigit(binaryRawData: number[]) {
		console.log('=== searchForFirstDigit CALLED ===');
		console.log(`Audio data length: ${binaryRawData.length}`);
		console.log(`Window size: ${this.m_windows_sample}`);

		let firstDigitFound = false;
		let firstDigitFoundCounter = 0;
		let firstDigitFoundIndex = 0;
		let firstDigitIndex = 0;

		const k = 0.7;
		const loopUpperLimit = binaryRawData.length - this.m_windows_sample - 1;
		const loopStep = Math.floor(
			this.m_windows_sample / this.m_overlapping_divider,
		);

		console.log(`Search range: 0 to ${loopUpperLimit} with step ${loopStep}`);
		console.log(`Windows to check: ${Math.floor(loopUpperLimit / loopStep)}`);

		const currFreq1 = new Array(
			this.m_frequency_first ? this.m_frequency_first.length : 0,
		).fill(0);
		const currFreq2 = new Array(
			this.m_frequency_second ? this.m_frequency_second.length : 0,
		).fill(0);
		const currFreqMulFlt = new Array(
			this.m_frequency_first ? this.m_frequency_first.length : 0,
		).fill(0);
		const vDigit = new Array(10).fill(0);

		let errorCode = SoundPairingDecoder.ErrorCode.eEERR_FIRST_DIGIT_NOT_FOUND;
		let checkCount = 0;
		let markerChecks = 0;

		// CRITICAL FIX: Return both the error code and the found index
		for (let i = 0; i < loopUpperLimit; i += loopStep) {
			checkCount++;

			// Log progress periodically
			if (checkCount % 100 === 0) {
				console.log(
					`Checking position ${i} (${((i / loopUpperLimit) * 100).toFixed(
						1,
					)}% complete)`,
				);
			}

			this.calcInstFreq(i, binaryRawData, currFreq1, currFreq2);

			for (let j = 0; j < currFreqMulFlt.length; j++) {
				currFreqMulFlt[j] =
					currFreqMulFlt[j] * k + (1 - k) * currFreq1[j] * currFreq2[j];
			}

			this.calcDigit(currFreqMulFlt, vDigit);

			// Log marker detection information periodically
			if (checkCount % 100 === 0) {
				console.log(`Position ${i} bin values:`, [...vDigit]);
				console.log(
					`Bin 7 value: ${vDigit[7]}, second strongest: ${Math.max(
						...vDigit.filter((_, idx) => idx !== 7),
					)}`,
				);
			}

			const isFreq = this.calcIsFreq(vDigit);

			if (isFreq) {
				markerChecks++;
				console.log(`[${markerChecks}] MARKER DETECTED at position ${i}`);

				if (!firstDigitFound) {
					console.log('First marker detection');
					firstDigitFound = true;
					firstDigitFoundIndex = i;
					firstDigitFoundCounter = 1;
				} else {
					firstDigitFoundCounter++;
					console.log(
						`Consecutive marker detection #${firstDigitFoundCounter}`,
					);

					if (firstDigitFoundCounter > 1) {
						console.log(`MARKER CONFIRMED at position ${firstDigitFoundIndex}`);
						firstDigitIndex = firstDigitFoundIndex;
						errorCode = SoundPairingDecoder.ErrorCode.eOK;
						break;
					}
				}
			} else {
				if (firstDigitFound) {
					console.log(`Lost marker at position ${i}, resetting detection`);
				}
				firstDigitFound = false;
				firstDigitFoundIndex = 0;
				firstDigitFoundCounter = 0;
			}
		}

		console.log(`First digit search complete. Error code: ${errorCode}`);
		console.log(`First digit index: ${firstDigitIndex}`);
		console.log(
			`Checked ${checkCount} windows, found ${markerChecks} potential markers`,
		);

		// CRITICAL FIX: Return both errorCode and firstDigitIndex
		return {
			errorCode: errorCode,
			firstDigitIndex: firstDigitIndex,
		};
	}

	calcInstFreq(
		iStart: number,
		signal: number[],
		currFreq1: number[],
		currFreq2: number[],
	) {
		// Only log periodically to avoid flooding console
		const shouldLog = iStart % 50000 === 0;
		if (shouldLog) {
			console.log(`=== calcInstFreq at position ${iStart} ===`);
		}

		if (!this.m_frequency_first) {
			console.error('m_frequency_first is null in calcInstFreq');
			return;
		}
		for (let i = 0; i < this.m_frequency_first.length; i++) {
			let intCos1 = 0;
			let intSin1 = 0;
			let intCos2 = 0;
			let intSin2 = 0;

			for (let j = 0; j < this.m_windows_sample; j++) {
				if (iStart + j >= signal.length) {
					if (shouldLog)
						console.log(`Warning: Position ${iStart + j} out of bounds`);
					break;
				}

				const currX = signal[iStart + j];

				if (this.m_cos_first && this.m_cos_first[i]) {
					intCos1 += currX * this.m_cos_first[i][j];
				}
				if (this.m_sin_first && this.m_sin_first[i]) {
					intSin1 += currX * this.m_sin_first[i][j];
				}

				if (this.m_cos_second && this.m_cos_second[i]) {
					intCos2 += currX * this.m_cos_second[i][j];
				}
				if (this.m_sin_second && this.m_sin_second[i]) {
					intSin2 += currX * this.m_sin_second[i][j];
				}
			}

			currFreq1[i] = Math.sqrt(intCos1 * intCos1 + intSin1 * intSin1);
			currFreq2[i] = Math.sqrt(intCos2 * intCos2 + intSin2 * intSin2);
		}

		if (shouldLog) {
			console.log(
				`First freq max: ${Math.max(...currFreq1)} at ${currFreq1.indexOf(
					Math.max(...currFreq1),
				)}`,
			);
			console.log(
				`Second freq max: ${Math.max(...currFreq2)} at ${currFreq2.indexOf(
					Math.max(...currFreq2),
				)}`,
			);
		}
	}

	calcDigit(vFreq: number[], vDigit: number[]) {
		// Limited logging to reduce console noise
		const shouldLog = Math.random() < 0.01; // Log ~1% of calls

		if (shouldLog) {
			console.log('=== calcDigit CALLED ===');
		}

		vDigit.fill(0);

		let lastLimitFound = 0;

		if (!this.m_frequency_first) {
			console.error('Frequency array m_frequency_first is not initialized.');
			return;
		}
		for (let i = 0; i < vFreq.length; i++) {
			const currFrequency = this.m_frequency_first[i];
			const binPopulation = vFreq[i];

			for (
				let p = lastLimitFound;
				p < this.m_frequency_limits.length - 1;
				p++
			) {
				if (
					this.m_frequency_limits[p] <= currFrequency &&
					currFrequency <= this.m_frequency_limits[p + 1]
				) {
					if (binPopulation > vDigit[p]) {
						vDigit[p] = binPopulation;
						lastLimitFound = p;
					}

					break;
				}
			}
		}

		if (shouldLog) {
			console.log('Digit bins:', [...vDigit]);
			console.log(
				`Strongest bin: ${vDigit.indexOf(Math.max(...vDigit))} (${Math.max(
					...vDigit,
				)})`,
			);
		}
	}

	calcIsFreq(vDigit: number[]) {
		// Limited logging
		const shouldLog = Math.random() < 0.01;

		if (shouldLog) {
			console.log('=== calcIsFreq CALLED ===');
			console.log('Digit bins:', [...vDigit]);
		}

		let firstMaxValue = 0;
		let secondMaxValue = 0;
		let idxFirstMax = -1;

		for (let i = 0; i < vDigit.length; i++) {
			if (vDigit[i] > firstMaxValue) {
				firstMaxValue = vDigit[i];
				idxFirstMax = i;
			}
		}

		for (let i = 0; i < vDigit.length; i++) {
			if (i !== idxFirstMax && vDigit[i] > secondMaxValue) {
				secondMaxValue = vDigit[i];
			}
		}

		const ratio = firstMaxValue / (secondMaxValue || 0.00001); // Avoid division by zero
		const isDetected =
			firstMaxValue > 8.0 * secondMaxValue && idxFirstMax === 7;

		if (shouldLog || isDetected) {
			console.log(
				`Max bin: ${idxFirstMax} (${firstMaxValue}), Second: ${secondMaxValue}`,
			);
			console.log(
				`Ratio: ${ratio}, Threshold: 8.0, Is bin 7: ${idxFirstMax === 7}`,
			);
			console.log(`Is marker: ${isDetected}`);
		}

		return isDetected;
	}

	getDigit(
		binaryRawData: number[],
		digitStartIndex: number,
		password: number[],
		index: number,
	) {
		console.log(`=== getDigit CALLED for position ${index} ===`);
		console.log(`Start index: ${digitStartIndex}`);

		const vDigit = new Array(10).fill(0);
		const vDigitHist = new Array(10).fill(0);

		// FIX: Calculate upper limit based on digit window size (0.4s)
		const loopUpperLimit = Math.min(
			digitStartIndex + Math.floor(0.4 * this.m_sampling_frequency),
			binaryRawData.length - this.m_windows_sample - 1,
		);

		const loopStep = Math.floor(
			this.m_windows_sample / this.m_overlapping_divider,
		);
		console.log(
			`Search range: ${digitStartIndex} to ${loopUpperLimit}, step ${loopStep}`,
		);

		if (!this.m_frequency_first || !this.m_frequency_second) {
			console.error('Frequency arrays not initialized');
			return SoundPairingDecoder.ErrorCode.eUnknown;
		}
		const currFreq1 = new Array(this.m_frequency_first.length).fill(0);
		const currFreq2 = new Array(this.m_frequency_second.length).fill(0);
		const currFreqMul = new Array(this.m_frequency_second.length).fill(0);

		// CRITICAL ERROR: Wrong logic in the loop below
		for (let i = digitStartIndex; i < loopUpperLimit; i += loopStep) {
			// This logic is incorrect - should process the entire window before finding max
			if (i > digitStartIndex + 0.4 * this.m_sampling_frequency) {
				console.log(
					'WARNING: Trying to extract digit before processing entire window',
				);
				const maxValue = Math.max(...vDigitHist);
				const maxIndex = vDigitHist.indexOf(maxValue);

				console.log(
					`Early digit extraction: value=${maxValue}, index=${maxIndex}`,
				);
				// CRITICAL FIX: Store the digit value (maxIndex), not the password index
				password[index] = maxIndex;
				return SoundPairingDecoder.ErrorCode.eOK;
			}

			this.calcInstFreq(i, binaryRawData, currFreq1, currFreq2);

			// Calculate the product of frequency strengths
			for (let h = 0; h < currFreqMul.length; h++) {
				currFreqMul[h] = currFreq1[h] * currFreq2[h];
			}

			this.calcDigit(currFreqMul, vDigit);

			// Accumulate values for histogram
			for (let h = 0; h < vDigitHist.length; h++) {
				vDigitHist[h] += vDigit[h];
			}

			// Log progress every few steps
			if ((i - digitStartIndex) % (loopStep * 5) === 0) {
				console.log(
					`Processing ${
						((i - digitStartIndex) / (loopUpperLimit - digitStartIndex)) * 100
					}% complete`,
				);
				console.log(`Current histogram:`, [...vDigitHist]);
			}
		}

		// After processing the entire window, find the strongest frequency bin
		const maxValue = Math.max(...vDigitHist);
		const maxIndex = vDigitHist.indexOf(maxValue);

		console.log(`Final histogram for digit ${index}:`, [...vDigitHist]);
		console.log(`Detected digit ${maxIndex} with strength ${maxValue}`);

		// CRITICAL FIX: Store the digit value (maxIndex), not the password index
		password[index] = maxIndex;

		if (maxValue > 0) {
			console.log(
				`Successfully extracted digit ${maxIndex} at position ${index}`,
			);
			return SoundPairingDecoder.ErrorCode.eOK;
		}

		console.log('Failed to extract digit - no strong frequency');
		return SoundPairingDecoder.ErrorCode.eERR_DIGIT_NOT_FOUND;
	}
}

export default SoundPairingDecoder;
