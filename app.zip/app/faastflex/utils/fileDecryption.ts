import CryptoJS from 'crypto-js';
import { XMLParser, XMLBuilder } from 'fast-xml-parser';
import { DeviceParametersModel } from '../model/deviceParametersModel';

// Encryption key matching the C# implementation
const ENCRYPTION_KEY = 'A9s4rLp2Xt6oGq1ZvN7bPw8eFm3yHxUcDjI5KgO0hVfCnYlMzWkQ';

/**
 * Creates a 32-byte key from the passcode, matching the C# implementation
 * @param passcode The encryption passcode
 * @returns WordArray representing the 32-byte key
 */
function deriveKey(passcode: string): CryptoJS.lib.WordArray {
	// Create a 32-byte buffer
	const keyBytes = new Array(32).fill(0);
	const passcodeBytes = CryptoJS.enc.Utf8.parse(passcode);

	// Copy passcode bytes to key buffer (matching C# Array.Copy behavior)
	const passcodeByteArray = [];
	for (let i = 0; i < passcodeBytes.sigBytes; i++) {
		const wordIndex = Math.floor(i / 4);
		const byteIndex = i % 4;
		const word = passcodeBytes.words[wordIndex] || 0;
		const byte = (word >>> (8 * (3 - byteIndex))) & 0xff;
		passcodeByteArray.push(byte);
	}

	const copyLength = Math.min(keyBytes.length, passcodeByteArray.length);
	for (let i = 0; i < copyLength; i++) {
		keyBytes[i] = passcodeByteArray[i];
	}

	// Convert byte array back to WordArray
	const words: number[] = [];
	for (let i = 0; i < keyBytes.length; i += 4) {
		const word =
			(keyBytes[i] << 24) |
			(keyBytes[i + 1] << 16) |
			(keyBytes[i + 2] << 8) |
			keyBytes[i + 3];
		words.push(word);
	}

	return CryptoJS.lib.WordArray.create(words, 32);
}

/**
 * Encrypts data using AES with the same parameters as C# RijndaelManaged
 * @param plainData The data to encrypt as string
 * @param passcode The encryption passcode
 * @returns Base64 encoded encrypted data
 */
export function encryptData(plainData: string, passcode: string): string {
	try {
		// Derive the 32-byte key
		const key = deriveKey(passcode);

		// Create 16-byte zero IV (matching C# implementation)
		const iv = CryptoJS.lib.WordArray.create([0, 0, 0, 0], 16);

		// Convert plain data to WordArray
		const plainText = CryptoJS.enc.Utf8.parse(plainData);

		// Encrypt using AES
		const encrypted = CryptoJS.AES.encrypt(plainText, key, {
			iv: iv,
			mode: CryptoJS.mode.CBC,
			padding: CryptoJS.pad.Pkcs7,
		});

		// Convert to base64 string
		const result = encrypted.ciphertext.toString(CryptoJS.enc.Base64);

		return result;
	} catch (error) {
		console.error('Encryption failed:', error);
		throw new Error('Failed to encrypt data');
	}
}

/**
 * Decrypts data using AES with the same parameters as C# RijndaelManaged
 * @param encryptedData Base64 encoded encrypted data
 * @param passcode The encryption passcode
 * @returns Decrypted data as string
 */
export function decryptData(encryptedData: string, passcode: string): string {
	try {
		// Derive the 32-byte key
		const key = deriveKey(passcode);

		// Create 16-byte zero IV (matching C# implementation)
		const iv = CryptoJS.lib.WordArray.create([0, 0, 0, 0], 16);

		// Convert base64 encrypted data to WordArray
		const encrypted = CryptoJS.enc.Base64.parse(encryptedData);
		console.log('Base64 parsed successfully');

		// Decrypt using AES
		const decrypted = CryptoJS.AES.decrypt(
			{ ciphertext: encrypted } as CryptoJS.lib.CipherParams,
			key,
			{
				iv: iv,
				mode: CryptoJS.mode.CBC,
				padding: CryptoJS.pad.Pkcs7,
			},
		);

		const result = decrypted.toString(CryptoJS.enc.Utf8);

		return result;
	} catch (error) {
		console.error('Decryption failed:', error);
		throw new Error('Failed to decrypt data');
	}
}

/**
 * Parses XML string to JavaScript object
 * @param xmlString The XML string to parse
 * @returns Promise resolving to parsed object
 */
export function parseXmlToObject(xmlString: string): Promise<any> {
	return new Promise((resolve, reject) => {
		try {
			const parser = new XMLParser({
				ignoreAttributes: false,
				attributeNamePrefix: '$',
				textNodeName: '#text',
				parseAttributeValue: true,
				trimValues: true,
			});

			const result = parser.parse(xmlString);
			resolve(result);
		} catch (error) {
			reject(
				new Error(
					`XML parsing failed: ${
						error instanceof Error ? error.message : 'Unknown error'
					}`,
				),
			);
		}
	});
}

/**
 * Converts .NET XML serialized object to JavaScript object structure
 * This handles the specific XML structure that C# XmlSerializer creates
 * @param xmlObject Parsed XML object from fast-xml-parser
 * @returns Converted JavaScript object
 */
export function convertXmlToDeviceParameters(xmlObject: any): any {
	try {
		console.log(
			'Full XML object structure:',
			JSON.stringify(xmlObject, null, 2),
		);

		// The XML structure from C# XmlSerializer typically has a root element
		// We need to navigate to the actual data
		// const rootKeys = Object.keys(xmlObject);
		// console.log('Root keys:', rootKeys);

		// if (rootKeys.length === 0) {
		//     throw new Error('Invalid XML structure');
		// }

		const modelName = DeviceParametersModel.name;
		// Get the root element (usually the class name from C#)
		let rootElement = xmlObject[modelName];
		console.log('Root element:', rootElement);
		console.log('Root element keys:', Object.keys(rootElement || {}));

		// If the root element is not an object, return the xmlObject itself
		// if (typeof rootElement !== 'object' || rootElement === null) {
		//     console.log('Root element is not an object, returning xmlObject');
		//     return xmlObject;
		// }

		return rootElement;
	} catch (error) {
		console.error('Error converting XML to device parameters:', error);
		throw new Error('Failed to convert XML to device parameters');
	}
}

export async function decryptAndParseConfigFile(
	fileContent: string,
	fileName: string,
): Promise<any> {
	try {
		const isEncrypted = fileName.toLowerCase().endsWith('.sfc');

		const decryptedXml = decryptData(fileContent, ENCRYPTION_KEY);
		// Parse XML to object
		const xmlObject = await parseXmlToObject(decryptedXml);
		console.log('XML parsed successfully, Parsed XML object:', xmlObject);

		// Convert XML structure to device parameters
		const deviceParams = convertXmlToDeviceParameters(xmlObject);
		console.log('Converted to device parameters:', deviceParams);

		return deviceParams;
	} catch (error) {
		console.error('Error processing config file:', error);
		throw new Error(
			`Failed to process configuration file: ${
				error instanceof Error ? error.message : 'Unknown error'
			}`,
		);
	}
}

/**
 * Converts JavaScript object to XML string and encrypts it
 * @param deviceParameters The device parameters object to encrypt
 * @param passcode The encryption passcode (defaults to ENCRYPTION_KEY)
 * @returns Base64 encoded encrypted XML data
 */
export function encryptAndSerializeConfigFile(
	deviceParameters: any,
	passcode: string = ENCRYPTION_KEY,
): string {
	try {
		// Create XML builder with similar options to parser
		const builder = new XMLBuilder({
			ignoreAttributes: false,
			attributeNamePrefix: '$',
			textNodeName: '#text',
			format: true,
			indentBy: '  ',
			suppressEmptyNode: true,
		});

		// Wrap the device parameters in a root element similar to C# XmlSerializer structure
		const xmlObject = {
			'?xml': {
				'@version': '1.0',
				'@encoding': 'utf-8',
			},
			DeviceParametersModel: deviceParameters,
		};

		// Convert object to XML string
		const xmlString = builder.build(xmlObject);
		console.log('Generated XML:', xmlString);

		// Encrypt the XML string
		const encryptedData = encryptData(xmlString, passcode);

		return encryptedData;
	} catch (error) {
		console.error('Error encrypting config file:', error);
		throw new Error(
			`Failed to encrypt configuration file: ${
				error instanceof Error ? error.message : 'Unknown error'
			}`,
		);
	}
}
