import React from 'react';
//import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import DeviceList from '@faastflex/screens/deviceList';
import DeviceDetailsScreen from '@faastflex/screens/deviceDetailsScreen';
import DeviceParameterScreen from '@faastflex/screens/deviceParameterScreen';
import DeviceTestScreen from '@faastflex/screens/deviceTestScreen';
import PerformDeviceTestScreen from '@faastflex/screens/performDeviceTestScreen';
import { CreatetemplateModalPopup } from '@faastflex/screens/createtemplateModalPopup';
import CreateTemplateScreen from '@faastflex/screens/createTemplateScreen';
import CreateOrEditDeviceScreen from '@faastflex/screens/createOrEditDeviceScreen';
import FFIDeviceParameterScreen from '@faastflex/screens/ffiDeviceParameterScreen';
import { AppConstants } from '@global/GlobalConstants/globalConstants';

const Stack = createNativeStackNavigator();

export const FaastflexNavigation = () => {
	return (
		<Stack.Group>
			<Stack.Screen
				name={AppConstants.DeviceListScreen}
				component={DeviceList}
				options={{ headerShown: false }}
			/>
			<Stack.Screen
				name={AppConstants.DeviceDetailsScreen}
				component={DeviceDetailsScreen}
				options={{ headerShown: false }}
			/>
			<Stack.Screen
				name={AppConstants.DeviceParameterScreen}
				component={DeviceParameterScreen}
				options={{ headerShown: false }}
			/>
			<Stack.Screen
				name={AppConstants.FFIDeviceParameterScreen}
				component={FFIDeviceParameterScreen}
				options={{ headerShown: false }}
			/>
			<Stack.Screen
				name={AppConstants.DeviceTestScreen}
				component={DeviceTestScreen}
				options={{ headerShown: false }}
			/>
			<Stack.Screen
				name={AppConstants.PerformDeviceTestScreen}
				component={PerformDeviceTestScreen}
				options={{ headerShown: false }}
			/>
			<Stack.Screen
				name={AppConstants.CreateTemplateScreen}
				component={CreateTemplateScreen}
				options={{ headerShown: false }}
			/>
			<Stack.Screen
				name={AppConstants.CreatetemplateModalPopup}
				component={CreatetemplateModalPopup}
				options={{ headerShown: false }}
			/>
			<Stack.Screen
				name={AppConstants.CreateOrEditDeviceScreen}
				component={CreateOrEditDeviceScreen}
				options={{ headerShown: false }}
			/>
		</Stack.Group>
	);
};
