import { ObscurationUnit } from '../faastflexEnum/obscurationUnit';

const obscurationData: Array<[string, string]> = [
	['0.014% obs/ft', '0.046% obs/m'],
	['0.02% obs/ft', '0.066% obs/m'],
	['0.03% obs/ft', '0.098% obs/m'],
	['0.05% obs/ft', '0.164% obs/m'],
	['0.10% obs/ft', '0.328% obs/m'],
	['0.20% obs/ft', '0.656% obs/m'],
	['0.50% obs/ft', '1.640% obs/m'],
	['1.00% obs/ft', '3.281% obs/m'],
	['1.50% obs/ft', '4.921% obs/m'],
	['2.00% obs/ft', '6.562% obs/m'],
];

export const convertValueToObscurationUnit = (
	value: number,
	obscurationType: ObscurationUnit,
): string => {
	try {
		if (value < 0 || value >= obscurationData.length) {
			return value.toString();
		}

		switch (obscurationType) {
			case ObscurationUnit.Alarm:
				return value.toString();
			case ObscurationUnit.Imperial:
				return obscurationData[value][0];
			case ObscurationUnit.Metric:
				return obscurationData[value][1];
			default:
				return value.toString();
		}
	} catch (error) {
		console.error('Error converting obscuration value:', error);
		return value.toString();
	}
};

/**
 * Convert alarm level from selected unit back to percentage
 */
export const convertBackObscurationUnitToValue = (
	displayValue: number,
	unit: ObscurationUnit,
): number => {
	if (unit === ObscurationUnit.Alarm) {
		return displayValue; // Already in percentage
	} else if (unit === ObscurationUnit.Imperial) {
		// Convert %/ft back to %
		const percentValue = displayValue / 0.3048;
		return Math.round(percentValue);
	} else if (unit === ObscurationUnit.Metric) {
		// Convert %/m back to %
		const percentValue = displayValue / 1.0;
		return Math.round(percentValue);
	}
	return displayValue;
};

/**
 * Get unit label for display
 */
export const getUnitLabel = (unit: ObscurationUnit): string => {
	switch (unit) {
		case ObscurationUnit.Alarm:
			return '';
		case ObscurationUnit.Imperial:
			return 'obs/ft';
		case ObscurationUnit.Metric:
			return 'obs/m';
		default:
			return '%';
	}
};
