import { DeviceStatus } from '@faastflexCommands/commandEnum';
import { DeviceState } from '../model/deviceModel';
import ServiceIcon from '@assets/images/ServiceIcon.svg';
import NormalIcon from '@assets/images/NormalIcon.svg';
import Alarm from '@assets/images/Alarm.svg';
import DisabledStatus from '@assets/images/DisabledStatus.svg';

export const getStateIcon = (deviceState: DeviceState) => {
	switch (deviceState) {
		case DeviceState.eAlarm:
			return <Alarm width={10} height={10} />;
		case DeviceState.eAction:
			return <Alarm width={10} height={10} />;
		case DeviceState.eFault:
			return <ServiceIcon width={10} height={10} />;
		case DeviceState.eAlert:
			return <ServiceIcon width={10} height={10} />;
		case DeviceState.eNormal:
			return <NormalIcon width={10} height={10} />;
		case DeviceState.eUnknown:
			return <DisabledStatus width={10} height={10} />;
		default:
			return <DisabledStatus width={10} height={10} />;
	}
};
export const getStatusIcon = (deviceStatus: DeviceStatus) => {
	switch (deviceStatus) {
		case DeviceStatus.MAIN_FSM_INITIALIZATION:
			return <ServiceIcon width={10} height={10} />;
		case DeviceStatus.MAIN_FSM_NORMAL:
			return <NormalIcon width={10} height={10} />;
		case DeviceStatus.MAIN_FSM_PRODUCTION:
			return <ServiceIcon width={10} height={10} />;
		case DeviceStatus.MAIN_FSM_PROTECTION:
			return <Alarm width={10} height={10} />;
		case DeviceStatus.MAIN_FSM_REBOOT:
			return <ServiceIcon width={10} height={10} />;
		case DeviceStatus.MAIN_FSM_SERVICE:
			return <ServiceIcon width={10} height={10} />;
		case DeviceStatus.MAIN_FSM_STATE_COUNT:
			return <ServiceIcon width={10} height={10} />;
		case DeviceStatus.MAIN_FSM_WAIT:
			return <ServiceIcon width={10} height={10} />;
		case DeviceStatus.UNKNOWN:
			return <DisabledStatus width={10} height={10} />;
		default:
			return <DisabledStatus width={10} height={10} />;
	}
};
