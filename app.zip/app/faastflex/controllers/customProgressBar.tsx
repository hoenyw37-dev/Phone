import React, { useEffect, useRef } from 'react';
import { View, Text, StyleSheet, Animated } from 'react-native';

interface ProgressBarProps {
	percentage: number; // Value between 0-100
	height?: number;
	backgroundColor?: string;
	fillColor?: string;
	borderRadius?: number;
	showPercentageText?: boolean;
	textColor?: string;
	textSize?: number;
	animated?: boolean;
	animationDuration?: number;
}

const CustomProgressBar: React.FC<ProgressBarProps> = ({
	percentage,
	height = 10,
	backgroundColor = '#E0E0E0',
	fillColor = '#1791E4',
	borderRadius = 5,
	showPercentageText = false,
	textColor = '#000000',
	textSize = 12,
	animated = true,
	animationDuration = 500,
}) => {
	// Ensure percentage is between 0 and 100
	const validPercentage = Math.min(100, Math.max(0, percentage));

	// Animation setup
	const widthAnim = useRef(new Animated.Value(0)).current;

	useEffect(() => {
		if (animated) {
			Animated.timing(widthAnim, {
				toValue: validPercentage,
				duration: animationDuration,
				useNativeDriver: false,
			}).start();
		} else {
			widthAnim.setValue(validPercentage);
		}
	}, [validPercentage, animated, animationDuration]);

	return (
		<View style={styles.progressContainer}>
			<View
				style={[styles.container, { height, backgroundColor, borderRadius }]}>
				<Animated.View
					style={[
						styles.fill,
						{
							width: widthAnim.interpolate({
								inputRange: [0, 100],
								outputRange: ['0%', '100%'],
							}),
							backgroundColor: fillColor,
							borderRadius,
						},
					]}
				/>
			</View>

			{showPercentageText && (
				<Text
					style={[
						styles.percentageText,
						{ color: textColor, fontSize: textSize },
					]}>
					{`${Math.round(validPercentage)}%`}
				</Text>
			)}
		</View>
	);
};

const styles = StyleSheet.create({
	progressContainer: {
		width: '100%',
	},
	container: {
		width: '100%',
		overflow: 'hidden',
	},
	fill: {
		height: '100%',
	},
	percentageText: {
		marginTop: 5,
		textAlign: 'right',
	},
});

export default CustomProgressBar;
