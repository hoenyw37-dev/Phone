import React from 'react';
import {
	TouchableOpacity,
	Image,
	Text,
	ImageSourcePropType,
	StyleSheet,
	View,
	ImageStyle,
	TextStyle,
	ViewStyle,
} from 'react-native';

// Equivalent to the C# enum
export enum ImageOrientation {
	ImageToLeft = 0,
	ImageOnTop = 1,
	ImageToRight = 2,
	ImageOnBottom = 3,
	ImageCentered = 4,
}

// Props interface with TypeScript
interface ImageButtonProps {
	source: ImageSourcePropType;
	disabledSource?: ImageSourcePropType;
	text: string;
	onPress: () => void;
	disabled?: boolean;
	orientation?: ImageOrientation;
	imageWidth?: number;
	imageHeight?: number;
	imageTintColor?: string;
	disabledImageTintColor?: string;
	style?: ViewStyle;
	textStyle?: TextStyle;
	imageStyle?: ImageStyle;
}

const ImageButton: React.FC<ImageButtonProps> = ({
	source,
	disabledSource,
	text,
	onPress,
	disabled = false,
	orientation = ImageOrientation.ImageToLeft,
	imageWidth = 50,
	imageHeight = 50,
	imageTintColor,
	disabledImageTintColor,
	style,
	textStyle,
	imageStyle,
}) => {
	// Determine which image source to use
	const imageSource = disabled && disabledSource ? disabledSource : source;

	// Determine the tint color for the image
	const tintColor =
		disabled && disabledImageTintColor
			? disabledImageTintColor
			: imageTintColor;

	// Get flex direction based on orientation
	const getFlexDirection = () => {
		switch (orientation) {
			case ImageOrientation.ImageToLeft:
				return 'row';
			case ImageOrientation.ImageOnTop:
				return 'column';
			case ImageOrientation.ImageToRight:
				return 'row-reverse';
			case ImageOrientation.ImageOnBottom:
				return 'column-reverse';
			default:
				return 'row';
		}
	};

	return (
		<TouchableOpacity
			style={[
				styles.container,
				{ flexDirection: getFlexDirection() },
				orientation === ImageOrientation.ImageCentered && styles.centered,
				style,
			]}
			onPress={onPress}
			disabled={disabled}
			activeOpacity={0.7}>
			{orientation === ImageOrientation.ImageCentered ? (
				// For centered image, use absolute positioning
				<>
					<View style={styles.centeredImageContainer}>
						<Image
							source={imageSource}
							style={[
								{
									width: imageWidth > 0 ? imageWidth : 50,
									height: imageHeight > 0 ? imageHeight : 50,
									tintColor: tintColor,
								},
								imageStyle,
							]}
							resizeMode='contain'
						/>
					</View>
					<Text style={[styles.text, textStyle]}>{text}</Text>
				</>
			) : (
				// For other orientations, use flex layout
				<>
					<Image
						source={imageSource}
						style={[
							{
								width: imageWidth > 0 ? imageWidth : 50,
								height: imageHeight > 0 ? imageHeight : 50,
								tintColor: tintColor,
							},
							styles.image,
							imageStyle,
						]}
						resizeMode='contain'
					/>
					<Text style={[styles.text, textStyle]}>{text}</Text>
				</>
			)}
		</TouchableOpacity>
	);
};

const styles = StyleSheet.create({
	container: {
		padding: 10,
		alignItems: 'center',
		justifyContent: 'center',
		borderRadius: 5,
		backgroundColor: '#DDDDDD',
	},
	centered: {
		position: 'relative',
		justifyContent: 'center',
		alignItems: 'center',
	},
	centeredImageContainer: {
		position: 'absolute',
		top: 0,
		left: 0,
		right: 0,
		bottom: 0,
		justifyContent: 'center',
		alignItems: 'center',
	},
	image: {
		marginHorizontal: 5,
	},
	text: {
		textAlign: 'center',
		fontSize: 16,
	},
});

export default ImageButton;
