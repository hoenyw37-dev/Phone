import React, { ReactElement } from 'react';
import {
	TouchableOpacity,
	Text,
	StyleSheet,
	View,
	TextStyle,
	ViewStyle,
} from 'react-native';

// Equivalent to the C# enum
export enum SvgOrientation {
	SvgToLeft = 0,
	SvgOnTop = 1,
	SvgToRight = 2,
	SvgOnBottom = 3,
	SvgCentered = 4,
}

// Props interface with TypeScript
interface SvgButtonProps {
	svgComponent: ReactElement;
	disabledSvgComponent?: ReactElement;
	text: string;
	onPress: () => void;
	disabled?: boolean;
	orientation?: SvgOrientation;
	svgWidth?: number;
	svgHeight?: number;
	style?: ViewStyle;
	textStyle?: TextStyle;
	svgContainerStyle?: ViewStyle;
	touchDisabled?: boolean;
}

const ImageButtonSVG: React.FC<SvgButtonProps> = ({
	svgComponent,
	disabledSvgComponent,
	text,
	onPress,
	disabled = false,
	orientation = SvgOrientation.SvgToLeft,
	svgWidth = 50,
	svgHeight = 50,
	style,
	textStyle,
	svgContainerStyle,
	touchDisabled = false,
}) => {
	// Determine which SVG component to use
	const SvgToRender =
		disabled && disabledSvgComponent ? disabledSvgComponent : svgComponent;

	// Clone the SVG element with new dimensions
	const renderSvgWithSize = () => {
		return React.cloneElement(SvgToRender, {
			width: svgWidth,
			height: svgHeight,
			opacity: touchDisabled ? 0.5 : 1.0,
		});
	};

	return (
		<TouchableOpacity
			style={[
				styles.container,
				// Always use column to stack items vertically
				{ flexDirection: 'column' },
				style,
			]}
			onPress={onPress}
			activeOpacity={0.7}
			disabled={touchDisabled}>
			<View style={[styles.svgContainer, svgContainerStyle]}>
				{renderSvgWithSize()}
			</View>
			<Text style={[styles.text, textStyle]}>{text}</Text>
		</TouchableOpacity>
	);
};

const styles = StyleSheet.create({
	container: {
		padding: 10,
		alignItems: 'center', // Center children horizontally
		justifyContent: 'center',
		borderRadius: 5,
		backgroundColor: '#DDDDDD',
	},
	svgContainer: {
		justifyContent: 'center',
		alignItems: 'center',
		marginBottom: 5, // Add space between SVG and text
	},
	text: {
		textAlign: 'center',
		fontSize: 16,
	},
});

export default ImageButtonSVG;
