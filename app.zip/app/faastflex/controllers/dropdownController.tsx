import React from 'react';
import {
	View,
	Text,
	StyleSheet,
	TouchableOpacity,
	Platform,
} from 'react-native';
import ActionSheet from 'react-native-action-sheet';
import TripleDotIconWhite from '@assets/images/TripleDotIconWhite.svg';
import TripleDotIconGrey from '@assets/images/TripleDotIconGrey.svg';

export interface MenuOptionItem {
	label: string;
	onSelect: () => void;
}

interface MoreMenuProps {
	menuOptions: MenuOptionItem[];
	triggerText?: string;
	triggerTextStyle?: object;
	iconHeight?: number;
	iconWidth?: number;
	// Optional: configure cancel/destructive/title/message for iOS
	title?: string;
	message?: string; // iOS only
	cancelLabel?: string; // will be appended to options for iOS
	destructiveIndex?: number; // index in options for iOS
	tintColor?: string; // iOS only
	touchDisabled?: boolean;
	grayIcon?: boolean;
}

const DropdownMenu = ({
	menuOptions,
	triggerText,
	triggerTextStyle = {},
	iconHeight = 30,
	iconWidth = 30,
	cancelLabel = 'Cancel',
	touchDisabled = false,
	grayIcon = false,
}: MoreMenuProps) => {
	// Determine which SVG component to use
	const SvgToRender = grayIcon ? <TripleDotIconGrey /> : <TripleDotIconWhite />;

	// Clone the SVG element with new dimensions
	const renderSvgWithSize = () => {
		return React.cloneElement(SvgToRender, {
			width: iconWidth,
			height: iconHeight,
			opacity: touchDisabled ? 0.5 : 1.0,
		});
	};
	// Build options array from menuOptions labels
	const optionLabels = menuOptions.map(o => o.label);

	// iOS supports cancel/destructive indices; Android does not (has back button)
	const isIOS = Platform.OS === 'ios';

	// For iOS, append a cancel label (optional but conventional)
	const finalOptions = isIOS ? [...optionLabels, cancelLabel] : optionLabels;
	const cancelButtonIndex = isIOS ? finalOptions.length - 1 : undefined;

	const showActionSheet = () => {
		ActionSheet.showActionSheetWithOptions(
			{
				options: finalOptions,
				cancelButtonIndex: cancelButtonIndex,
			},
			(buttonIndex?: number) => {
				// Android: undefined on outside touch/back press (per npm docs).
				// iOS: cancel index returns that index; handle by ignoring.
				if (typeof buttonIndex !== 'number') {
					console.log('button clicked :', buttonIndex);
					return;
				}

				// If iOS and user tapped "Cancel", ignore
				if (isIOS && cancelButtonIndex === buttonIndex) return;

				const selected = menuOptions[buttonIndex];
				if (selected?.onSelect) {
					selected.onSelect();
				}
			},
		);
	};

	return (
		<View>
			<TouchableOpacity
				onPress={showActionSheet}
				accessibilityRole='button'
				accessibilityLabel='More options'
				disabled={touchDisabled}>
				<View style={styles.triggerContainer}>
					{renderSvgWithSize()}
					{triggerText && (
						<Text style={[styles.buttonText, triggerTextStyle]}>
							{triggerText}
						</Text>
					)}
				</View>
			</TouchableOpacity>
		</View>
	);
};

const styles = StyleSheet.create({
	triggerContainer: {
		flexDirection: 'column',
		alignItems: 'center',
		justifyContent: 'center',
	},
	buttonText: {
		color: '#000000',
		fontSize: 14,
		textAlign: 'center',
	},
});

export default DropdownMenu;
