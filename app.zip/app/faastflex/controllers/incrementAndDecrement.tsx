import React, { useState, useEffect } from 'react';
import { View, Text, TouchableOpacity, StyleSheet } from 'react-native';
import { Control, Controller, FieldValues, Path } from 'react-hook-form';
import {
	convertValueToObscurationUnit,
	convertBackObscurationUnitToValue,
} from '@faastflex/converters/obscurationUnitConverter.ts';
import { ObscurationUnit } from '../faastflexEnum/obscurationUnit';

// Original props for the base component
interface IncrementDecrementProps {
	label: string;
	value: number;
	setValue: (value: number) => void;
	min: number;
	max: number;
	belowText: string;
	refState?: number;
	referingLabel?: string;
	referencingState?: number;
	refernceingLabel?: string;
	incrementor?: number;
	decrementor?: number;
	isDisabled?: boolean;
	obscurationType?: ObscurationUnit;
}

// The original base component
const IncrementDecrement: React.FC<IncrementDecrementProps> = ({
	label,
	value,
	setValue,
	min,
	max,
	belowText,
	incrementor = 1,
	decrementor = 1,
	refState,
	referingLabel,
	referencingState,
	isDisabled = false,
	obscurationType = ObscurationUnit.Alarm,
}) => {
	const [error, setError] = useState<string>('');
	const [referencingStateerror, setReferencingStateError] =
		useState<string>(``);

	const handleIncrement = () => {
		const tempval = value + incrementor;
		if (isDisabled) return; // Prevent increment if disabled
		if (referencingState !== undefined && tempval > referencingState) {
			setReferencingStateError('');
		}
		if (refState !== undefined) {
			if (tempval >= refState) {
				return;
			}
		}

		if (tempval <= max) {
			setValue(tempval);
			setError(''); // Clear the error if the value is valid
		} else {
			setError(`Enter Value cannot exceed ${max}`);
		}
	};

	const handleDecrement = () => {
		if (isDisabled) return; // Prevent decrement if disabled

		const tempval = value - decrementor;

		// Check minimum boundary first
		if (tempval < min) {
			setError(`Enter Value cannot be less than ${min}`);
			return;
		}

		// Clear errors and set value
		setError('');
		setValue(tempval);

		// Handle reference state validation
		if (referencingState !== undefined) {
			if (tempval <= referencingState) {
				// Special case: allow when both values are 0
				if (referencingState === 0 && tempval === 0) {
					setReferencingStateError('');
				} else {
					setReferencingStateError(
						`${label} should be greater than ${referingLabel}`,
					);
				}
			} else {
				setReferencingStateError('');
			}
		}
	};

	// Check if both values are 0 to suppress error display
	const shouldShowReferencingError = () => {
		// Don't show error if both values are 0
		if (
			(referencingState === 0 && value === 0) ||
			(refState === 0 && value === 0)
		) {
			return false;
		}

		// Don't show error if current value is actually valid
		if (referencingState !== undefined && value > referencingState) {
			return false;
		}
		if (refState !== undefined && value < refState) {
			return false;
		}

		return referencingStateerror && referencingStateerror.length > 0;
	};

	return (
		<View style={styles.section}>
			<Text style={styles.sectionText}>{label}</Text>
			<View
				style={[
					styles.wrapper,
					isDisabled ? { opacity: 0.5, elevation: 0 } : {},
				]}
				pointerEvents={isDisabled ? 'none' : 'auto'}>
				<TouchableOpacity style={styles.decrementor} onPress={handleDecrement}>
					<Text style={styles.decrementBtn}>-</Text>
				</TouchableOpacity>
				<Text style={styles.number}>
					{convertValueToObscurationUnit(value, obscurationType)}
				</Text>
				<TouchableOpacity style={styles.incrementor} onPress={handleIncrement}>
					<Text style={styles.incrementBtn}>+</Text>
				</TouchableOpacity>
			</View>
			{shouldShowReferencingError() ? (
				<Text style={styles.errorText}>{referencingStateerror}</Text>
			) : (
				<Text style={styles.belowText}>{belowText}</Text>
			)}
		</View>
	);
};

const styles = StyleSheet.create({
	section: {
		marginBottom: 10,
	},
	sectionText: {
		fontSize: 16,
		fontWeight: '400',
	},
	wrapper: {
		flexDirection: 'row',
		justifyContent: 'space-between',
		alignItems: 'center',
		borderWidth: 1,
		borderColor: '#adb5bd',
		elevation: 2,
		borderRadius: 3,
		backgroundColor: '#fff',
		shadowColor: '#000',
		shadowOffset: { width: 0, height: 2 },
		shadowOpacity: 0.25,
		shadowRadius: 3.84,
	},
	number: {
		fontSize: 20,
		fontWeight: '400',
		color: '#495057',
	},
	incrementor: {
		padding: 10,
		borderLeftWidth: 1,
		borderColor: '#adb5bd',
	},
	decrementor: {
		padding: 10,
		borderRightWidth: 1,
		borderColor: '#adb5bd',
	},
	incrementBtn: {
		fontSize: 20,
		fontWeight: '600',
		paddingHorizontal: 15,
		color: '#343a40',
	},
	decrementBtn: {
		fontSize: 20,
		fontWeight: '900',
		paddingHorizontal: 15,
		color: '#343a40',
	},
	belowText: {
		fontSize: 12,
		fontWeight: '400',
		color: '#adb5bd',
		marginTop: 5,
	},
	errorText: {
		color: 'red',
		fontSize: 12,
		fontWeight: '400',
		marginTop: 5,
	},
});

// Export both the regular component and the controlled version
export default IncrementDecrement;
