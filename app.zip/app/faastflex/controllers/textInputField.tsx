import React from 'react';
import { View, TextInput, Text, StyleSheet } from 'react-native';
import { Controller } from 'react-hook-form';
import { TextInputFieldProps } from './TextInputFieldProps';
import { commonColors, commonSizes } from '@styles/base';

export default function TextInputField({
	name,
	control,
	placeholder,
	title,
	isRequired,
	errorMessage,
	maxChar,
	isDisable = false,
	value,
	onChangeText,
}: TextInputFieldProps & {
	value?: string;
	onChangeText?: (text: string) => void;
}) {
	return (
		<View style={styles.inputContainer}>
			{title && (
				<Text style={styles.fieldTitle}>
					{title}{' '}
					{isRequired && (
						<Text style={{ color: commonColors.warningColor }}>*</Text>
					)}
				</Text>
			)}
			{typeof value !== 'undefined' && typeof onChangeText === 'function' ? (
				<TextInput
					style={[styles.input, errorMessage ? styles.errorBorder : null]}
					onChangeText={onChangeText}
					value={value}
					placeholder={placeholder}
					placeholderTextColor={commonColors.textBoxBorderColor}
					maxLength={maxChar}
					editable={!isDisable}
				/>
			) : (
				<Controller
					control={control}
					name={name}
					render={({ field: { onChange, value } }) => (
						<TextInput
							style={[styles.input, errorMessage ? styles.errorBorder : null]}
							onChangeText={onChange}
							value={value}
							placeholder={placeholder}
							placeholderTextColor={commonColors.textBoxBorderColor}
							maxLength={maxChar}
							editable={!isDisable}
						/>
					)}
				/>
			)}
			{errorMessage && <Text style={styles.errorText}>{errorMessage}</Text>}
		</View>
	);
}

const styles = StyleSheet.create({
	inputContainer: {
		marginBottom: commonSizes.heightM_Pixel,
	},
	input: {
		height: commonSizes.textBoxHeight_L,
		borderColor: commonColors.textBoxBorderColor,
		borderWidth: commonSizes.textBoXBorderWidthXS,
		borderRadius: commonSizes.cornerRadius,
		paddingHorizontal: commonSizes.paddingM_Percent,
		color: commonColors.textColor_Grey,
		fontSize: commonSizes.textSizeM,
		marginTop: commonSizes.heightS_Pixel,
	},
	errorText: {
		color: commonColors.warningColor,
		marginTop: commonSizes.heightXS_Pixel,
		marginLeft: commonSizes.widthM_Pixel,
		fontSize: commonSizes.textSizeM,
	},
	errorBorder: {
		borderColor: commonColors.warningColor,
	},
	fieldTitle: {
		color: commonColors.textColor_Black,
		fontSize: commonSizes.textSizeL,
		fontWeight: '500',
	},
});
