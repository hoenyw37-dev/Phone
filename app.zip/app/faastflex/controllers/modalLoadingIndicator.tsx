import React from 'react';
import { View, Modal, ActivityIndicator, Text, StyleSheet } from 'react-native';

interface LoadingModalProps {
	visible?: boolean;
	message?: string;
}

export const ModalLoadingIndicator: React.FC<LoadingModalProps> = ({
	visible,
	message = '',
}) => {
	if (!visible) return null;

	return (
		<View style={styles.overlay}>
			<View style={styles.loadingBox}>
				<ActivityIndicator size='large' color='#fff' />
				{message !== '' && <Text style={styles.message}>{message}</Text>}
			</View>
		</View>
	);
};

const styles = StyleSheet.create({
	overlay: {
		position: 'absolute',
		top: 0,
		left: 0,
		right: 0,
		bottom: 0,
		backgroundColor: 'rgba(0,0,0,0.7)',
		justifyContent: 'center',
		alignItems: 'center',
		zIndex: 9999,
	},
	loadingBox: {
		backgroundColor: 'rgba(50, 50, 50, 0.8)',
		padding: 20,
		borderRadius: 10,
		alignItems: 'center',
		justifyContent: 'center',
		minWidth: 150,
		maxWidth: '80%',
	},
	message: {
		color: '#fff',
		marginTop: 10,
		fontSize: 16,
	},
});
