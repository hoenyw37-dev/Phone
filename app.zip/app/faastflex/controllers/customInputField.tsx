import React from 'react';
import { Controller } from 'react-hook-form';
import {
	View,
	Text,
	TextInput,
	StyleSheet,
	TextInputProps,
	KeyboardTypeOptions,
} from 'react-native';
import { commonColors, commonSizes } from '@styles/base';

interface CustomInputProps {
	name: string;
	control: any;
	placeholder: string;
	title: string;
	isRequired: boolean;
	errorMessage: string | undefined;
	belowText?: string;
	minValue?: number;
	maxValue?: number;
	unit?: string;
	isDisable?: boolean;
	keyboardType?: KeyboardTypeOptions;
	maxLength?: number;
	customOpacity?: number;
}

const CustomInput: React.FC<CustomInputProps> = ({
	name,
	control,
	placeholder,
	title,
	isRequired,
	errorMessage,
	belowText,
	minValue, // Minimum value for numeric input
	maxValue, // Maximum value for numeric input
	unit, // Unit of measurement (e.g., "kg", "cm")
	isDisable = false, // Flag to disable the input field
	keyboardType = 'default', // Keyboard type for numeric input
	maxLength = 100, // Maximum length of input
	customOpacity = 1, // Opacity for disabled state
}) => {
	return (
		<View style={styles.section}>
			{title && (
				<Text style={styles.fieldTitle}>
					{title}{' '}
					{isRequired && (
						<Text style={{ color: commonColors.warningColor }}>*</Text>
					)}
				</Text>
			)}
			<Controller
				control={control}
				rules={{ required: isRequired, min: minValue, max: maxValue }}
				name={name}
				render={({ field: { onChange, value }, fieldState: { error } }) => (
					<View>
						<View style={[styles.inputWrapper, { opacity: customOpacity }]}>
							<TextInput
								style={[styles.input, isDisable && { color: '#495057' }]}
								placeholder={placeholder}
								value={value === 0 || value ? String(value) : ''}
								onChangeText={text => {
									// For numeric inputs, handle empty strings properly and allow only numbers
									if (
										keyboardType === 'numeric' ||
										keyboardType === 'number-pad'
									) {
										// Remove any non-numeric characters
										const numericValue = text.replace(/[^0-9]/g, '');

										if (numericValue === '') {
											// When field is empty, pass empty string
											onChange('');
										} else {
											// Convert to number and pass to form control
											onChange(Number(numericValue));
										}
									} else {
										onChange(text);
									}
								}}
								editable={!isDisable}
								keyboardType={keyboardType}
								maxLength={maxLength}
							/>
							{unit && <Text style={styles.inputRightText}>{unit}</Text>}
						</View>
						{!errorMessage ? (
							<Text style={styles.belowText}>{belowText}</Text>
						) : (
							<Text style={styles.errorText}>{errorMessage}</Text>
						)}
					</View>
				)}
			/>
		</View>
	);
};

const styles = StyleSheet.create({
	section: {
		marginBottom: 10,
	},
	sectionText: {
		fontSize: 16,
		fontWeight: '400',
	},
	inputWrapper: {
		flexDirection: 'row',
		alignItems: 'center',
		justifyContent: 'space-between',
		height: commonSizes.textBoxHeight_L,
		borderColor: commonColors.textBoxBorderColor,
		borderWidth: commonSizes.textBoXBorderWidthXS,
		borderRadius: commonSizes.cornerRadius,
		paddingHorizontal: commonSizes.paddingM_Percent,
		color: commonColors.textColor_Grey,
		fontSize: commonSizes.textSizeM,
		marginTop: commonSizes.heightS_Pixel,
	},
	input: {
		flex: 1,
		padding: 10,
		color: '#6c757d', // Text Filed Color
		fontSize: 16,
	},
	inputRightText: {
		fontSize: 14,
		color: 'rgba(100,100,100,0.5)',
	},
	belowText: {
		paddingTop: 5,
		fontSize: 13,
		color: 'rgba(100,100,100,0.5)',
	},
	errorText: {
		color: 'red',
		fontSize: 12,
		fontWeight: '400',
		marginTop: 5,
	},
	fieldTitle: {
		color: commonColors.textColor_Black,
		fontSize: 15,
		fontWeight: '500',
	},
});

export default CustomInput;
