import React from 'react';
import {
	View,
	Text,
	FlatList,
	TouchableOpacity,
	StyleSheet,
	GestureResponderEvent,
} from 'react-native';

interface DropDownProps {
	isVisible: boolean;
	items: string[];
	tempSelectedItem: string | null;
	onItemPress: (item: string) => void;
	onCancel: (event: GestureResponderEvent) => void;
	onConfirm: (event: GestureResponderEvent) => void;
}

const DropDown: React.FC<DropDownProps> = ({
	isVisible,
	items,
	tempSelectedItem,
	onItemPress,
	onCancel,
	onConfirm,
}) => {
	if (!isVisible) return null;

	return (
		<View style={styles.modalOverlay}>
			<View style={styles.modalContent}>
				<Text style={styles.modalHeader}>Tap Event Trigger</Text>
				{/* Scrollable List */}
				<FlatList
					data={items}
					keyExtractor={(item, index) => index.toString()}
					style={styles.list}
					renderItem={({ item }) => (
						<TouchableOpacity
							style={[
								styles.listItem,
								tempSelectedItem === item && styles.selectedItem, // Highlight selected item
							]}
							onPress={() => onItemPress(item)}>
							<Text
								style={[
									styles.listItemText,
									tempSelectedItem === item && {
										color: '#fff',
									},
								]}>
								{item}
							</Text>
						</TouchableOpacity>
					)}
					persistentScrollbar={true} // Ensure the scrollbar is always visible
				/>

				{/* Dialog Box Buttons */}
				<View style={styles.dialogButtons}>
					<TouchableOpacity style={styles.cancelButton} onPress={onCancel}>
						<Text style={styles.buttonText}>Cancel</Text>
					</TouchableOpacity>
					<TouchableOpacity style={styles.okButton} onPress={onConfirm}>
						<Text style={styles.buttonText}>OK</Text>
					</TouchableOpacity>
				</View>
			</View>
		</View>
	);
};

const styles = StyleSheet.create({
	modalOverlay: {
		position: 'absolute',
		top: 0,
		left: 0,
		right: 0,
		bottom: 0,
		backgroundColor: 'rgba(0,0,0,0.5)',
		justifyContent: 'center',
		alignItems: 'center',
		zIndex: 1,
	},
	modalContent: {
		width: '90%',
		backgroundColor: 'white',
		elevation: 5,
		paddingHorizontal: 16,
		paddingTop: 20,
		paddingBottom: 8,
		borderRadius: 10,
	},
	modalHeader: {
		fontSize: 18,
		fontWeight: 'bold',
		marginBottom: 20,
	},
	list: {
		maxHeight: 200, // Limit the height of the list to make it scrollable
		borderWidth: 1,
		borderColor: '#adb5bd',
		borderRadius: 5,
		marginBottom: 10,
	},
	listItem: {
		padding: 15,
		borderBottomWidth: 1,
		borderBottomColor: '#adb5bd',
	},
	listItemText: {
		fontSize: 16,
	},
	selectedItem: {
		backgroundColor: '#007AFF', // Highlight color for selected item
	},
	dialogButtons: {
		flexDirection: 'row',
		justifyContent: 'flex-end',
	},
	cancelButton: {
		padding: 10,
		marginRight: 5,
	},
	okButton: {
		padding: 10,
		marginLeft: 5,
	},
	buttonText: {
		color: '#000',
		fontWeight: 'bold',
		fontSize: 16,
	},
});

export default DropDown;
