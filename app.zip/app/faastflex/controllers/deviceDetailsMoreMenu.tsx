// DeviceMenuSheet.tsx
import React from 'react';
import { View, TouchableOpacity, Text } from 'react-native';
import { SheetManager } from 'react-native-actions-sheet';

export default function DeviceDetailsMoreMenu({ payload }: any) {
	const {
		t,
		_isENSelfTestAvailable,
		ConfigureDeviceParamterCommand,
		PerformDeviceTestCommand,
	} = payload;

	return (
		<View style={{ padding: 20 }}>
			<TouchableOpacity
				onPress={() => {
					ConfigureDeviceParamterCommand();
					SheetManager.hide('DeviceDetailsMoreMenuSheet');
				}}
				style={{ marginBottom: 10 }}>
				<Text>{t('ConfigureDevice')}</Text>
			</TouchableOpacity>
			{true && (
				<TouchableOpacity
					onPress={() => {
						PerformDeviceTestCommand();
						SheetManager.hide('DeviceDetailsMoreMenuSheet');
					}}>
					<Text>{t('PerformDeviceTest')}</Text>
				</TouchableOpacity>
			)}
			<TouchableOpacity
				onPress={() => SheetManager.hide('DeviceDetailsMoreMenuSheet')}>
				<Text style={{ color: 'red' }}>{t('Cancel')}</Text>
			</TouchableOpacity>
		</View>
	);
}
