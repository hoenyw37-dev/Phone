import { commonSizes, commonColors, commonStyles } from '@styles/base';
import { tr } from 'date-fns/locale';
import { t } from 'i18next';
import React from 'react';
import {
	View,
	Text,
	TextInput,
	TouchableOpacity,
	StyleSheet,
} from 'react-native';
import { ScrollView } from 'react-native-actions-sheet';

interface PasswordModalProps {
	onClose: () => void;
	password: string;
	setPassword: (password: string) => void;
	maximumLength?: number;
}

const PasswordModal: React.FC<PasswordModalProps> = ({
	onClose,
	password,
	setPassword,
	maximumLength = 6,
}) => {
	const [localPassword, setLocalPassword] = React.useState<string>(''); // Local password state
	const [reenterPassword, setReenterPassword] = React.useState<string>('');
	const [isSamePassword, setIsSamePassword] = React.useState<boolean>(false); // true for match, false for mismatch
	const [isPasswordEmpty, setIsPasswordEmpty] = React.useState<boolean>(false); // true for empty, false for not empty
	const [isReenterPasswordEmpty, setIsReenterPasswordEmpty] =
		React.useState<boolean>(false); // true for empty, false for not empty
	const [isPasswordLengthNotSix, setIsPasswordLengthNotSix] =
		React.useState<boolean>(false); // true for length not six, false for length six
	const [isReenterPasswordLengthNotSix, setIsReenterPasswordLengthNotSix] =
		React.useState<boolean>(false); // true for length not six, false for length six

	// Validating the password and re-entered password on Click on Ok Button
	const onValidate = () => {
		if (localPassword.length !== maximumLength || localPassword == '') {
			onNewPasswordValidate();
			return;
		}
		if (reenterPassword.length !== maximumLength || reenterPassword == '') {
			onReEnterPasswordValidate();
			return;
		}
		if (
			localPassword === reenterPassword &&
			localPassword.length === maximumLength
		) {
			setPassword(localPassword);
			onClose();
			setIsSamePassword(false);
			setIsPasswordEmpty(false);
			setIsReenterPasswordEmpty(false);
			setIsPasswordLengthNotSix(false);
			setIsReenterPasswordLengthNotSix(false);
		} else {
			setIsSamePassword(true);
			onNewPasswordValidate();
			onReEnterPasswordValidate();
		}
	};

	const onNewPasswordValidate = () => {
		setIsPasswordEmpty(false);
		setIsPasswordLengthNotSix(false);
		if (localPassword == '') {
			setIsPasswordEmpty(true);
		}
		if (localPassword?.length !== maximumLength) {
			setIsPasswordLengthNotSix(true);
		}
	};

	const onReEnterPasswordValidate = () => {
		setIsReenterPasswordEmpty(false);
		setIsReenterPasswordLengthNotSix(false);
		if (reenterPassword == '') {
			setIsReenterPasswordEmpty(true);
		}
		if (reenterPassword?.length !== maximumLength) {
			setIsReenterPasswordLengthNotSix(true);
		}
	};

	// Handling password change and re-enter password change
	const handlePasswordChange = (text: string) => {
		// Only allow numeric characters (0-9)
		const numericOnly = text.replace(/[^0-9]/g, '');
		setLocalPassword(numericOnly); // Update the local password state
		setIsPasswordEmpty(false); // Reset the empty state
		setIsPasswordLengthNotSix(false);
	};
	const handleReenterPasswordChange = (text: string) => {
		// Only allow numeric characters (0-9)
		const numericOnly = text.replace(/[^0-9]/g, '');
		setReenterPassword(numericOnly); // Update the re-enter password state
		setIsReenterPasswordEmpty(false);
		setIsReenterPasswordLengthNotSix(false);
	};

	return (
		<View style={styles.modalOverlay}>
			<View style={styles.modalContainer}>
				<View style={styles.headerContainer}>
					<Text style={styles.headerText}>{t('NewPassword')}</Text>
				</View>
				<View style={styles.contentContainer}>
					<Text style={styles.inputLabel}>{t('EnterNewPassword')}</Text>
					<TextInput
						placeholder={t('EnterPassword')}
						placeholderTextColor={commonColors.textBoxBorderColor}
						style={styles.textInput}
						onChangeText={text => handlePasswordChange(text)}
						onBlur={onNewPasswordValidate}
						value={localPassword}
						secureTextEntry={true}
						maxLength={maximumLength}
						keyboardType='numeric'
					/>
					<Text style={styles.helperText}>{t('PasswordRules')}</Text>
					{isPasswordEmpty && (
						<Text style={styles.errorMessage}>
							{t('NewPasswordEmptyErrorMsg')}{' '}
						</Text>
					)}
					{isPasswordLengthNotSix && (
						<Text style={styles.errorMessage}>
							{t('NewPasswordLengthErrorMsg')}{' '}
						</Text>
					)}
					<Text style={styles.inputLabel}>{t('ReEnterPassword')}</Text>
					<TextInput
						placeholder={t('ReEnterPassword')}
						placeholderTextColor={commonColors.textBoxBorderColor}
						style={styles.textInput}
						onChangeText={text => handleReenterPasswordChange(text)}
						onBlur={onReEnterPasswordValidate}
						value={reenterPassword}
						secureTextEntry={true}
						maxLength={maximumLength}
						keyboardType='numeric'
					/>
					{isReenterPasswordEmpty && (
						<Text style={styles.errorMessage}>
							{t('ConfirmPasswordEmptyErrorMsg')}{' '}
						</Text>
					)}
					{isReenterPasswordLengthNotSix && (
						<Text style={styles.errorMessage}>
							{t('ConfirmPasswordLengthErrorMsg')}{' '}
						</Text>
					)}
					{isSamePassword && (
						<Text style={styles.errorMessage}>
							{t('ConfirmPasswordMatchErrorMsg')}
						</Text>
					)}

					<View style={styles.buttonGroup}>
						<TouchableOpacity style={styles.cancelButton} onPress={onClose}>
							<Text style={styles.cancelButtonText}>{t('cancel')}</Text>
						</TouchableOpacity>
						<TouchableOpacity onPress={onValidate} style={styles.confirmButton}>
							<Text style={styles.confirmButtonText}>{t('ok')}</Text>
						</TouchableOpacity>
					</View>
				</View>
			</View>
		</View>
	);
};

const styles = StyleSheet.create({
	modalOverlay: {
		position: 'absolute',
		top: 0,
		left: 0,
		right: 0,
		bottom: 0,
		backgroundColor: commonColors.backgroundColor_TransparentGrey,
		justifyContent: 'center',
		alignItems: 'center',
		zIndex: 1,
	},
	modalContainer: {
		width: '80%',
		backgroundColor: commonColors.backgroundColor_White,
		elevation: 10,
		paddingHorizontal: commonSizes.widthL_Pixel,
		borderRadius: commonSizes.cornerRadius,
		shadowColor: commonColors.shadowColor,
		shadowOffset: { width: 0, height: 2 },
		shadowOpacity: 0.1,
		shadowRadius: 4,
	},
	headerContainer: {
		width: '100%',
	},
	contentContainer: {
		width: '100%',
		backgroundColor: commonColors.backgroundColor_White,
		paddingHorizontal: commonSizes.widthL_Pixel,
	},
	headerText: {
		fontSize: commonSizes.textSizeL,
		fontWeight: '600',
		color: commonColors.textColor_Black,
		paddingHorizontal: commonSizes.widthXL_Pixel,
		paddingVertical: commonSizes.heightS_Pixel,
		borderBottomWidth: commonSizes.lineThickness,
		borderBottomColor: commonColors.lineColor,
	},
	inputLabel: {
		fontSize: commonSizes.textSizeS,
		fontWeight: 'bold',
		color: commonColors.textColor_Black,
		marginTop: commonSizes.heightM_Pixel,
	},
	textInput: {
		borderWidth: commonSizes.textBoXBorderWidthS,
		borderColor: commonColors.textBoxBorderColor,
		marginVertical: commonSizes.heightS_Pixel,
		color: commonColors.textColor_Black,
		fontSize: commonSizes.textSizeM,
		borderRadius: commonSizes.cornerRadius,
	},
	helperText: {
		color: commonColors.textColor_Grey,
		fontSize: commonSizes.textSizeS,
	},
	errorMessage: {
		color: commonColors.warningColor,
		fontSize: commonSizes.textSizeS,
		marginTop: commonSizes.heightXS_Pixel,
	},
	buttonGroup: {
		flexDirection: 'row',
		justifyContent: 'flex-end',
		marginTop: commonSizes.heightM_Pixel,
	},
	cancelButton: {
		marginRight: commonSizes.widthXXL_Pixel,
		paddingVertical: commonSizes.heightS_Pixel,
		paddingHorizontal: commonSizes.widthM_Pixel,
	},
	cancelButtonText: {
		fontSize: commonSizes.textSizeL,
		color: commonColors.textColor_Grey,
		fontWeight: '600',
	},
	confirmButton: {
		marginRight: commonSizes.widthXL_Pixel,
		paddingVertical: commonSizes.heightS_Pixel,
		paddingHorizontal: commonSizes.widthM_Pixel,
	},
	confirmButtonText: {
		fontSize: commonSizes.textSizeL,
		color: commonColors.textColor_Blue,
		fontWeight: '600',
	},
});

export default PasswordModal;
