import React from 'react';
import { View, Text, Image, StyleSheet, Modal } from 'react-native';
import { commonColors } from '@styles/base';
import InfoIconGray from '@assets/images/InfoIconGray.svg';

interface TimeoutPopupProps {
	isVisible: boolean;
	onClose?: () => void;
	message?: string;
}

const TimeoutPopup: React.FC<TimeoutPopupProps> = ({
	isVisible,
	onClose,
	message = 'Unable to sync data due to timeout. Please reinitiate connection.',
}) => {
	return (
		<Modal
			transparent={true}
			visible={isVisible}
			animationType='fade'
			onRequestClose={onClose}>
			<View style={styles.modalBackground}>
				<View style={styles.popupContainer}>
					<InfoIconGray height={42} width={42} />
					<Text style={styles.message}>{message}</Text>
				</View>
			</View>
		</Modal>
	);
};

const styles = StyleSheet.create({
	modalBackground: {
		flex: 1,
		backgroundColor: 'rgba(0, 0, 0, 0.5)',
		justifyContent: 'center',
		alignItems: 'center',
	},
	popupContainer: {
		backgroundColor: '#F2F2F2',
		borderRadius: 10,
		padding: 20,
		alignItems: 'center',
		width: '80%',
		shadowColor: '#000',
		shadowOffset: { width: 0, height: 2 },
		shadowOpacity: 0.25,
		shadowRadius: 3.84,
		elevation: 5,
	},
	infoIcon: {
		width: 60,
		height: 60,
		marginBottom: 20,
	},
	message: {
		fontSize: 18,
		fontWeight: 'bold',
		textAlign: 'center',
		color: commonColors.textColor_Black,
		marginHorizontal: 20,
	},
});

export default TimeoutPopup;
