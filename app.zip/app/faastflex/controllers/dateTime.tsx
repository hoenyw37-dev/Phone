import React from 'react';
import {
	View,
	Text,
	TouchableOpacity,
	StyleSheet,
	Platform,
} from 'react-native';
import DateTimePicker, {
	DateTimePickerEvent,
} from '@react-native-community/datetimepicker';
import { commonColors, commonSizes } from '@styles/base';

interface DateTimeProps {
	selectedDate: Date;
	setSelectedDate: (date: Date) => void;
	selectedTime: Date;
	setSelectedTime: (time: Date) => void;
}

const DateTime: React.FC<DateTimeProps> = ({
	selectedDate,
	setSelectedDate,
	selectedTime,
	setSelectedTime,
}) => {
	const [showDatePicker, setShowDatePicker] = React.useState<boolean>(false);
	const [showTimePicker, setShowTimePicker] = React.useState<boolean>(false);

	const onDateChange = (event: DateTimePickerEvent, date?: Date) => {
		setShowDatePicker(false);
		if (date) {
			setSelectedDate(date);
		}
	};

	const onTimeChange = (event: DateTimePickerEvent, time?: Date) => {
		setShowTimePicker(false);
		if (time) {
			setSelectedTime(time);
		}
	};

	return (
		<View style={styles.container}>
			<View
				style={{
					flexDirection: 'row',
					justifyContent: 'flex-start',
					width: '100%',
				}}>
				<TouchableOpacity
					onPress={() => setShowDatePicker(true)}
					style={{
						borderBottomWidth: 1,
						marginRight: 20,
						borderColor: showDatePicker ? '#007AFF' : undefined,
					}}>
					<Text style={{ color: '#000', fontSize: 16 }}>{`${selectedDate
						.getDate()
						.toString()
						.padStart(2, '0')}-${(selectedDate.getMonth() + 1)
						.toString()
						.padStart(2, '0')}-${selectedDate.getFullYear()}`}</Text>
				</TouchableOpacity>

				<TouchableOpacity
					onPress={() => setShowTimePicker(true)}
					style={{
						borderBottomWidth: 1,
						borderColor: showDatePicker ? '#007AFF' : undefined,
					}}>
					<Text style={{ color: '#000', fontSize: 16 }}>
						{selectedTime.toLocaleTimeString([], {
							hour: '2-digit',
							minute: '2-digit',
						})}
					</Text>
				</TouchableOpacity>
			</View>

			{/* Date Picker */}
			{showDatePicker && (
				<DateTimePicker
					value={selectedDate}
					mode='date'
					display={Platform.OS === 'ios' ? 'spinner' : 'default'}
					onChange={onDateChange}
				/>
			)}

			{/* Time Picker */}
			{showTimePicker && (
				<DateTimePicker
					value={selectedTime}
					mode='time'
					display={Platform.OS === 'ios' ? 'spinner' : 'default'}
					onChange={onTimeChange}
				/>
			)}
		</View>
	);
};

const styles = StyleSheet.create({
	container: {
		flex: 1,
		justifyContent: 'center',
		alignItems: 'center',
		marginBottom: commonSizes.heightM_Pixel,
		marginTop: 5,
	},
});

export default DateTime;
