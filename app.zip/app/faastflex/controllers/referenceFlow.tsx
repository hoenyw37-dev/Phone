import React from 'react';
import {
	View,
	Text,
	TextInput,
	TouchableOpacity,
	StyleSheet,
} from 'react-native';

interface ReferenceFlowProps {
	value: number;
	setValue: (value: number) => void;
	onNormalize: () => void;
}

const ReferenceFlow: React.FC<ReferenceFlowProps> = ({
	value,
	setValue,
	onNormalize,
}) => {
	return (
		<View style={styles.referencedFlow}>
			<View style={styles.referencedFlowHeader}>
				<Text>Reference Flow</Text>
				<TouchableOpacity onPress={onNormalize}>
					<Text style={styles.referencedFlowHeaderBtn}>
						Normalize Parameters
					</Text>
				</TouchableOpacity>
			</View>
			<View
				style={{
					flexDirection: 'row',
					alignItems: 'center',
					borderWidth: 1,
					borderColor: '#adb5bd',
					justifyContent: 'space-between',
					borderRadius: 5,
					paddingHorizontal: 10,
					paddingVertical: 5,
				}}>
				<TextInput
					style={styles.referencedFlowInput}
					placeholder='24'
					onChangeText={text => setValue(Number(text))}
					keyboardType='numeric'
					value={value.toString()}
				/>
				<Text style={{ marginLeft: 10, color: '#adb5bd' }}>L/min</Text>
			</View>
		</View>
	);
};

const styles = StyleSheet.create({
	referencedFlow: {
		marginVertical: 10,
	},
	referencedFlowHeader: {
		flexDirection: 'row',
		justifyContent: 'space-between',
		alignItems: 'center',
		paddingVertical: 10,
	},
	referencedFlowHeaderBtn: {
		color: '#007AFF',
	},
	referencedFlowInput: {},
});

export default ReferenceFlow;
