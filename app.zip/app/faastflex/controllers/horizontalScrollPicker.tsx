import { commonColors } from '@styles/base';
import React, { useRef, useState } from 'react';
import {
	FlatList,
	StyleSheet,
	Text,
	TouchableOpacity,
	View,
	Dimensions,
} from 'react-native';

const SCREEN_WIDTH = Dimensions.get('window').width;
const ITEM_WIDTH = 60;

interface HorizontalScrollPickerProps {
	list: number[];
	selectedNumber: number;
	onSelectItem?: (item: number) => void;
	clearSelection?: boolean;
}

export default function HorizontalScrollPicker({
	list,
	selectedNumber,
	onSelectItem,
	clearSelection = false,
}: HorizontalScrollPickerProps) {
	const flatListRef = useRef<FlatList<any>>(null);
	const [selectedIndex, setSelectedIndex] = useState(
		list.findIndex(num => num === selectedNumber),
	);

	React.useEffect(() => {
		if (clearSelection) {
			setSelectedIndex(-1);
			onSelectItem && onSelectItem(-1);
		}
	}, [clearSelection, onSelectItem]);

	React.useEffect(() => {
		const newIndex = list.findIndex(num => num === selectedNumber);
		if (newIndex !== selectedIndex) {
			setSelectedIndex(newIndex);
		}
	}, [selectedNumber, list]);

	const handleSelect = (index: number) => {
		setSelectedIndex(index);
		onSelectItem && onSelectItem(list[index]);
		flatListRef.current?.scrollToIndex({
			index,
			animated: true,
			viewPosition: 0.5,
		});
	};

	const renderItem = ({ item, index }: { item: number; index: number }) => (
		<TouchableOpacity
			style={{ marginHorizontal: 0 }}
			activeOpacity={1}
			onPress={() => handleSelect(index)}>
			<View
				style={[
					styles.itemContainer,
					selectedIndex === index && styles.selectedItem,
				]}>
				<Text
					style={[
						styles.itemText,
						selectedIndex === index && styles.selectedItemText,
					]}>
					{item}
				</Text>
			</View>
		</TouchableOpacity>
	);

	return (
		<View style={styles.container}>
			<FlatList
				ref={flatListRef}
				data={list}
				renderItem={renderItem}
				keyExtractor={item => item.toString()}
				horizontal
				showsHorizontalScrollIndicator={false}
				getItemLayout={(_, index) => ({
					length: ITEM_WIDTH,
					offset: ITEM_WIDTH * index,
					index,
				})}
				initialScrollIndex={selectedIndex >= 0 ? selectedIndex : undefined}
				ItemSeparatorComponent={() => (
					<View
						style={{
							width: 1,
							height: '100%',
							backgroundColor: commonColors.textColor_Grey,
						}}
					/>
				)}
			/>
		</View>
	);
}

const styles = StyleSheet.create({
	container: {
		justifyContent: 'center',
		alignItems: 'center',
		padding: 0,
		borderColor: commonColors.textColor_Grey,
		borderWidth: 1,
	},
	itemContainer: {
		flex: 1,
		width: ITEM_WIDTH,
		alignItems: 'center',
		padding: 0,
		borderWidth: 0,
	},
	selectedItem: {
		backgroundColor: commonColors.backgroundColor_Blue,
		padding: 0,
	},
	itemText: {
		fontSize: 32,
		fontWeight: '600',
		color: '#000',
	},
	selectedItemText: {
		color: '#fff',
	},
});
