/**
 * Represents obscuration unit types
 */
export enum ObscurationUnit {
	Alarm = 1,
	Imperial = 2,
	Metric = 3,
}

/**
 * Display text mappings for ObscurationUnit values
 */
const ObscurationUnitText: Record<ObscurationUnit, string> = {
	[ObscurationUnit.Alarm]: 'AlarmLevel',
	[ObscurationUnit.Imperial]: 'lblImperialUnit',
	[ObscurationUnit.Metric]: 'lblMetricUnit',
};

/**
 * Gets the display text for an ObscurationUnit value
 */
export function getObscurationUnitText(unit: ObscurationUnit): string {
	return ObscurationUnitText[unit];
}
