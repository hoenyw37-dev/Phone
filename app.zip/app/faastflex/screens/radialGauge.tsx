import React from 'react';
import { View, StyleSheet, Text, StyleProp, TextStyle } from 'react-native';
import { CircularProgress } from 'react-native-circular-progress';

interface SemiCircularProgressBarProps {
	value: number;
	maxValue?: number;
	minValue?: number;
	radius?: number;
	color?: string;
	textStyle?: StyleProp<TextStyle>;
	rangeTextStyle?: StyleProp<TextStyle>;
	showRange?: boolean;
	startLabel?: string;
	endLabel?: string;
}

const SemiCircularProgressBar: React.FC<SemiCircularProgressBarProps> = ({
	value,
	maxValue = 7000,
	minValue = 0,
	radius = 100,
	color = 'green',
	textStyle = {},
	rangeTextStyle = {},
	showRange = true,
}) => {
	const paddingForLabels = 20;

	return (
		<View
			style={[
				styles.container,
				{ paddingBottom: showRange ? paddingForLabels : 0 },
			]}>
			<View style={styles.gaugeContainer}>
				{showRange && (
					<>
						<Text style={[styles.rangeText, styles.startText, rangeTextStyle]}>
							{minValue.toString()}
						</Text>

						<Text style={[styles.rangeText, styles.endText, rangeTextStyle]}>
							{maxValue.toString()}
						</Text>
					</>
				)}

				<CircularProgress
					size={radius}
					width={10}
					fill={((value - minValue) / (maxValue - minValue)) * 100}
					tintColor={color}
					backgroundColor='#e0e0e0'
					arcSweepAngle={270}
					rotation={-135}
					lineCap='round'>
					{() => (
						<View style={styles.centerTextContainer}>
							<Text style={[styles.centerText, textStyle]}>
								{`${Math.round(value)}`}
							</Text>
							<Text style={[styles.secondLineText, textStyle]}>RPM</Text>
						</View>
					)}
				</CircularProgress>
			</View>
		</View>
	);
};

const styles = StyleSheet.create({
	container: {
		justifyContent: 'center',
		alignItems: 'center',
		position: 'relative',
	},
	gaugeContainer: {
		position: 'relative',
	},
	centerText: {
		fontSize: 16,
		fontWeight: 'bold',
		color: '#000',
	},
	rangeText: {
		position: 'absolute',
		fontSize: 12,
		color: '#666',
		bottom: -15,
	},
	startText: {
		left: 10,
		transform: [{ translateY: -10 }],
	},
	endText: {
		right: -5,
		transform: [{ translateY: -10 }],
	},
	centerTextContainer: {
		alignItems: 'center',
		justifyContent: 'center',
	},
	secondLineText: {
		fontSize: 12,
		color: '#666',
		marginTop: 2,
		fontWeight: 'bold',
	},
});

export default SemiCircularProgressBar;
