import React, { useEffect, useRef, useState } from 'react';
import {
	View,
	Text,
	StyleSheet,
	TouchableOpacity,
	FlatList,
	SafeAreaView,
	Image,
	BackHandler,
} from 'react-native';
import { SafeAreaView as SafeAreaContextView } from 'react-native-safe-area-context';
import { TestsModel } from '@ff_model/testModel';
import { TestsHistoryModel } from '@ff_model/testHistoryModel';
import { useDatabase } from '../../../global/DatabaseContext';
import { useAppDispatch } from '../../../global/hooks';
import { addAllNewTests, fetchTestsById } from '@ff_redux/testRedux/testsThunk';
import {
	addAllNewTestHistory,
	fetchTestHistory,
	updateExistingTestHistory,
	deleteTestHistoryByDevice,
} from '@ff_redux/testHistoryRedux/testHistoryThunk';
import { BluetoothDevice } from 'bleCommunicator/bleService';
import { DeviceModel } from '@ff_model/deviceModel';
import { useTranslation } from 'react-i18next';
import Toast from 'react-native-toast-message';
import GreenTick from '@assets/images/GreenTick.svg';
import Pass from '@assets/images/Pass.svg';
import Fail from '@assets/images/Fail.svg';
import faastflexBluetoothCommunicator from 'faastflexCommunicator/faastflexBluetoothCommunicator.ts';
import LeftArrowWhite from '@assets/images/LeftArrowWhite.svg';
import { AppConstants } from '@global/GlobalConstants/globalConstants';
import {
	DeviceType,
	ErrorCode,
	getDeviceTypeDescription,
} from '../../../faastflexCommands/commandEnum.ts';

// Progress bar component
const ProgressBar = ({
	progress,
	total,
	status,
}: {
	progress: number;
	total: number;
	status: string;
}) => {
	return (
		<View style={styles.progressContainer}>
			<View style={styles.progressBarBg}>
				<View
					style={[
						styles.progressBarFill,
						{ width: `${(progress / total) * 100}%` },
					]}
				/>
			</View>
			<Text style={styles.progressText}>{status}</Text>
		</View>
	);
};

export default function DeviceTestScreen({ route, navigation }: any) {
	//Database
	const dispatch = useAppDispatch();
	const { dataSource } = useDatabase();
	const { t } = useTranslation();

	//Properties
	const [testsUI, setTestsUI] = useState<TestsModel[]>([]);
	const [progress, setProgress] = useState(0);
	const [totalTests, setTotalTests] = useState(0);
	const [testStatus, setTestStatus] = useState('0/0 Tested');
	const [passed, setPassed] = useState(0);
	const [failed, setFailed] = useState(0);
	const [deviceChannels, setDeviceChannels] = useState(0);
	const ConnectedDeviceobj = useRef<BluetoothDevice | null>();

	const isDeviceResponding = useRef<boolean>(true);
	const currentDevice = useRef<DeviceModel>(new DeviceModel());
	const currentDeviceId = useRef<number>(0);
	const isTestBegin = useRef<boolean>(false);
	const allTests = useRef<TestsModel[]>([]);
	const deviceTypeRef = useRef<string>(
		getDeviceTypeDescription(DeviceType.eStandAlone),
	);
	const isInitialized = useRef<boolean>(false);

	//#region  On Screen Appeared
	useEffect(() => {
		InitializeAsync();
	}, []);

	useEffect(() => {
		const unsubscribe = navigation.addListener('focus', () => {
			OnPageAppeared();
		});
		return unsubscribe;
	}, [navigation]);
	//#endregion

	//#region Prevent Device Back Functionality
	useEffect(() => {
		const backHandler = BackHandler.addEventListener(
			'hardwareBackPress',
			() => {
				return true; // Return true to prevent default back behavior
			},
		);

		return () => backHandler.remove();
	}, []);

	//iOS
	useEffect(() => {
		navigation.setOptions({
			gestureEnabled: false, // Disable swipe back gesture
		});
	}, [navigation]);
	//#endregion

	async function InitializeAsync() {
		if (
			route.params !== null &&
			route.params !== undefined &&
			route.params.connectedDevice !== null
		) {
			ConnectedDeviceobj.current = route.params
				.connectedDevice as BluetoothDevice;
		}
		if (
			route.params !== null &&
			route.params !== undefined &&
			route.params.selectedItem !== null
		) {
			let device = route.params.selectedItem as DeviceModel;
			currentDevice.current = device;
			currentDeviceId.current = currentDevice.current.deviceId;
			if (
				currentDevice.current.deviceType ===
				getDeviceTypeDescription(DeviceType.eUnknown)
			) {
				if (ConnectedDeviceobj.current !== null) {
					await CheckDeviceType();
				}
			} else {
				deviceTypeRef.current = currentDevice.current.deviceType;
			}
		}
		if (ConnectedDeviceobj.current !== null && currentDeviceId.current > 0) {
			var testHistory = await dispatch(
				fetchTestHistory({
					dataSource,
					deviceId: currentDeviceId.current,
				}),
			).unwrap();
			if (
				testHistory !== null &&
				testHistory !== undefined &&
				testHistory.length > 0
			) {
				const testedCount = testHistory.filter(x => x.isTestTested).length;
				if (testedCount > 0) {
					await Promise.all(
						testHistory.map(async historyTest => {
							if (historyTest.isTestTested) {
								await updateTestHistory(historyTest);
							}
						}),
					);
				}
			}
		}
		await GetAllTests();
		isInitialized.current = true;
	}
	const OnPageAppeared = () => {
		isTestBegin.current = false;
		if (isInitialized.current && currentDeviceId.current > 0) {
			GetAllTests();
		}
	};
	async function CheckDeviceType() {
		const deviceTypeResult =
			await faastflexBluetoothCommunicator.GetDeviceType();
		if (deviceTypeResult.error === ErrorCode.eOK) {
			deviceTypeRef.current = deviceTypeResult.deviceType;
		}
	}
	const GetAllTests = async () => {
		try {
			const dbTests = await initializeTests();
			var testHistory = await dispatch(
				fetchTestHistory({
					dataSource,
					deviceId: currentDeviceId.current,
				}),
			).unwrap();

			const filteredTestHistory = Array.isArray(testHistory) ? testHistory : [];

			if (filteredTestHistory === null || filteredTestHistory.length === 0) {
				var testHistories = await initializeTestHistory();
				await dispatch(
					addAllNewTestHistory({
						dataSource,
						testHistoryArray: testHistories,
					}),
				);
				setTestsUI(dbTests);
				allTests.current = dbTests;
			} else {
				let updatedTests = [...dbTests];
				// Process each test history item
				filteredTestHistory.forEach(historyItem => {
					// Find the index of the test in our array
					const testIndex = dbTests.findIndex(
						test => test.testId === historyItem.testHistoryId,
					);

					if (testIndex !== -1) {
						// Create a new test object with updated properties
						const updatedTest = {
							...dbTests[testIndex],
							isTested: historyItem.isTestTested,
							isTestFailed: historyItem.isTestFailed,
							isTestPassed: historyItem.isTestPassed,
							isVisibleTestStatus: historyItem.isVisibleTestStatus,
							testStatustext: historyItem.testStatustext,
						};

						// Replace the old test with the updated one
						updatedTests[testIndex] = updatedTest;
					}
				});

				// Update both state variables with the new tests array
				setTestsUI(updatedTests);
				allTests.current = updatedTests;
			}

			await updateProgress();
		} catch (error) {
			console.error('Error initializing test data:', error);
		}
	};

	async function updateProgress() {
		// Count how many tests have been tested (passed or failed)
		const deviceTested = allTests.current.filter(
			test => test.isTestPassed || test.isTestFailed,
		).length;

		// Calculate progress ratio
		const testProgress =
			allTests.current.length > 0
				? (deviceTested / allTests.current.length) * 100
				: 0;

		// Create status text
		const testStatus = `${deviceTested}/${allTests.current.length} ${t(
			'Tested',
		)}`;

		// Count passed and failed tests
		const passed = allTests.current.filter(test => test.isTestPassed).length;
		const failed = allTests.current.filter(test => test.isTestFailed).length;

		// Update state with calculated values
		setTotalTests(allTests.current.length);
		setProgress(testProgress);
		setTestStatus(testStatus);
		setPassed(passed);
		setFailed(failed);

		return { deviceTested, testProgress, passed, failed };
	}
	const updateTestHistory = async (historyTest: TestsHistoryModel) => {
		try {
			// Create updated history test object with reset properties
			const updatedHistoryTest: TestsHistoryModel = {
				...historyTest,
				isTestTested: false,
				isTestFailed: false,
				isTestPassed: false,
				testStatustext: '',
				isVisibleTestStatus: false,
			};

			// Update in database through Redux
			await dispatch(
				updateExistingTestHistory({
					dataSource,
					testHistoryId: updatedHistoryTest.testHistoryId,
					deviceId: updatedHistoryTest.deviceId,
					updates: updatedHistoryTest,
				}),
			);
		} catch (error) {
			console.error('Error updating test history:', error);
		}
	};
	async function initializeTests(): Promise<TestsModel[]> {
		if (
			deviceTypeRef.current ===
			getDeviceTypeDescription(DeviceType.eIntelligent)
		) {
			const testModels: TestsModel[] = [
				{
					id: 0,
					testNameKey: 'lblAllLedsRed',
					testDescriptionKey: 'descAllLedsRed',
					isTested: false,
					deviceId: currentDeviceId.current,
					testId: 1,
					isTestPassed: false,
					isTestFailed: false,
					isTestInProgress: false,
					testStatustext: '',
					isVisibleTestStatus: false,
					passButtonText: 'PASS',
					isButtonsEnable: true,
				},
				{
					id: 1,
					testNameKey: 'lblAllLedsGreen',
					testDescriptionKey: 'descAllLedsGreen',
					isTested: false,
					deviceId: currentDeviceId.current,
					testId: 2,
					isTestPassed: false,
					isTestFailed: false,
					isTestInProgress: false,
					testStatustext: '',
					isVisibleTestStatus: false,
					passButtonText: 'PASS',
					isButtonsEnable: true,
				},
				{
					id: 2,
					testNameKey: 'lblAllLedsYellow',
					testDescriptionKey: 'descAllLedsYellow',
					isTested: false,
					deviceId: currentDeviceId.current,
					testId: 3,
					isTestPassed: false,
					isTestFailed: false,
					isTestInProgress: false,
					testStatustext: '',
					isVisibleTestStatus: false,
					passButtonText: 'PASS',
					isButtonsEnable: true,
				},
				{
					id: 3,
					testNameKey: 'lblPowerLedGreen',
					testDescriptionKey: 'descPowerLedGreen',
					isTested: false,
					deviceId: currentDeviceId.current,
					testId: 4,
					isTestPassed: false,
					isTestFailed: false,
					isTestInProgress: false,
					testStatustext: '',
					isVisibleTestStatus: false,
					passButtonText: 'PASS',
					isButtonsEnable: true,
				},
				{
					id: 4,
					testNameKey: 'lblGeneralFaultTest',
					testDescriptionKey: 'descGeneralFaultTest',
					isTested: false,
					deviceId: currentDeviceId.current,
					testId: 5,
					isTestPassed: false,
					isTestFailed: false,
					isTestInProgress: false,
					testStatustext: '',
					isVisibleTestStatus: false,
					passButtonText: 'PASS',
					isButtonsEnable: true,
				},
				{
					id: 5,
					testNameKey: 'lblAuxFaultTest',
					testDescriptionKey: 'descAuxFaultTest',
					isTested: false,
					deviceId: currentDeviceId.current,
					testId: 6,
					isTestPassed: false,
					isTestFailed: false,
					isTestInProgress: false,
					testStatustext: '',
					isVisibleTestStatus: false,
					passButtonText: 'PASS',
					isButtonsEnable: true,
				},
				{
					id: 6,
					testNameKey: 'lblAlarm1LedRed',
					testDescriptionKey: 'descAlarm1LedRed',
					isTested: false,
					deviceId: currentDeviceId.current,
					testId: 7,
					isTestPassed: false,
					isTestFailed: false,
					isTestInProgress: false,
					testStatustext: '',
					isVisibleTestStatus: false,
					passButtonText: 'PASS',
					isButtonsEnable: true,
				},
				{
					id: 7,
					testNameKey: 'lblCH1GPOTest',
					testDescriptionKey: 'descCH1GPOTest',
					isTested: false,
					deviceId: currentDeviceId.current,
					testId: 8,
					isTestPassed: false,
					isTestFailed: false,
					isTestInProgress: false,
					testStatustext: '',
					isVisibleTestStatus: false,
					passButtonText: 'PASS',
					isButtonsEnable: true,
				},
			];
			// Add additional tests if the device has 2 channels
			if (
				currentDevice.current !== null &&
				currentDevice.current.channels === 2
			) {
				testModels.push(
					{
						id: 8,
						testNameKey: 'lblAlarm2LedRed',
						testDescriptionKey: 'descAlarm2LedRed',
						isTested: false,
						deviceId: currentDeviceId.current,
						testId: 9,
						isTestPassed: false,
						isTestFailed: false,
						isTestInProgress: false,
						testStatustext: '',
						isVisibleTestStatus: false,
						passButtonText: 'PASS',
						isButtonsEnable: true,
					},
					{
						id: 9,
						testNameKey: 'lblCH2GPOTest',
						testDescriptionKey: 'descCH2GPOTest',
						isTested: false,
						deviceId: currentDeviceId.current,
						testId: 10,
						isTestPassed: false,
						isTestFailed: false,
						isTestInProgress: false,
						testStatustext: '',
						isVisibleTestStatus: false,
						passButtonText: 'PASS',
						isButtonsEnable: true,
					},
				);
			}

			return testModels;
		} else {
			const testModels: TestsModel[] = [
				{
					id: 0,
					testNameKey: 'lblAllLedsRed',
					testDescriptionKey: 'descAllLedsRed',
					isTested: false,
					deviceId: currentDeviceId.current,
					testId: 1,
					isTestPassed: false,
					isTestFailed: false,
					isTestInProgress: false,
					testStatustext: '',
					isVisibleTestStatus: false,
					passButtonText: 'PASS',
					isButtonsEnable: true,
				},
				{
					id: 1,
					testNameKey: 'lblAllLedsGreen',
					testDescriptionKey: 'descAllLedsGreen',
					isTested: false,
					deviceId: currentDeviceId.current,
					testId: 2,
					isTestPassed: false,
					isTestFailed: false,
					isTestInProgress: false,
					testStatustext: '',
					isVisibleTestStatus: false,
					passButtonText: 'PASS',
					isButtonsEnable: true,
				},
				{
					id: 2,
					testNameKey: 'lblAllLedsYellow',
					testDescriptionKey: 'descAllLedsYellow',
					isTested: false,
					deviceId: currentDeviceId.current,
					testId: 3,
					isTestPassed: false,
					isTestFailed: false,
					isTestInProgress: false,
					testStatustext: '',
					isVisibleTestStatus: false,
					passButtonText: 'PASS',
					isButtonsEnable: true,
				},
				{
					id: 3,
					testNameKey: 'lblPowerLedGreen',
					testDescriptionKey: 'descPowerLedGreen',
					isTested: false,
					deviceId: currentDeviceId.current,
					testId: 4,
					isTestPassed: false,
					isTestFailed: false,
					isTestInProgress: false,
					testStatustext: '',
					isVisibleTestStatus: false,
					passButtonText: 'PASS',
					isButtonsEnable: true,
				},
				{
					id: 4,
					testNameKey: 'lblAction1LedRed',
					testDescriptionKey: 'descAction1LedRed',
					isTested: false,
					deviceId: currentDeviceId.current,
					testId: 5,
					isTestPassed: false,
					isTestFailed: false,
					isTestInProgress: false,
					testStatustext: '',
					isVisibleTestStatus: false,
					passButtonText: 'PASS',
					isButtonsEnable: true,
				},
				{
					id: 5,
					testNameKey: 'lblAlarm1LedRed',
					testDescriptionKey: 'descAlarm1LedRed',
					isTested: false,
					deviceId: currentDeviceId.current,
					testId: 6,
					isTestPassed: false,
					isTestFailed: false,
					isTestInProgress: false,
					testStatustext: '',
					isVisibleTestStatus: false,
					passButtonText: 'PASS',
					isButtonsEnable: true,
				},
				{
					id: 6,
					testNameKey: 'lblFault1LedYellow',
					testDescriptionKey: 'descFaultLed1Yellow',
					isTested: false,
					deviceId: currentDeviceId.current,
					testId: 7,
					isTestPassed: false,
					isTestFailed: false,
					isTestInProgress: false,
					testStatustext: '',
					isVisibleTestStatus: false,
					passButtonText: 'PASS',
					isButtonsEnable: true,
				},
			];
			// Add additional tests if the device has 2 channels
			if (
				currentDevice.current !== null &&
				currentDevice.current.channels === 2
			) {
				testModels.push(
					{
						id: 7,
						testNameKey: 'lblAction2LedRed',
						testDescriptionKey: 'descAction2LedRed',
						isTested: false,
						deviceId: currentDeviceId.current,
						testId: 8,
						isTestPassed: false,
						isTestFailed: false,
						isTestInProgress: false,
						testStatustext: '',
						isVisibleTestStatus: false,
						passButtonText: 'PASS',
						isButtonsEnable: true,
					},
					{
						id: 8,
						testNameKey: 'lblAlarm2LedRed',
						testDescriptionKey: 'descAlarm2LedRed',
						isTested: false,
						deviceId: currentDeviceId.current,
						testId: 9,
						isTestPassed: false,
						isTestFailed: false,
						isTestInProgress: false,
						testStatustext: '',
						isVisibleTestStatus: false,
						passButtonText: 'PASS',
						isButtonsEnable: true,
					},
					{
						id: 9,
						testNameKey: 'lblFault2LedYellow',
						testDescriptionKey: 'descFault2LedYellow',
						isTested: false,
						deviceId: currentDeviceId.current,
						testId: 10,
						isTestPassed: false,
						isTestFailed: false,
						isTestInProgress: false,
						testStatustext: '',
						isVisibleTestStatus: false,
						passButtonText: 'PASS',
						isButtonsEnable: true,
					},
				);
			}

			return testModels;
		}
	}

	async function initializeTestHistory(): Promise<TestsHistoryModel[]> {
		if (
			deviceTypeRef.current ===
			getDeviceTypeDescription(DeviceType.eIntelligent)
		) {
			const testHistorys: TestsHistoryModel[] = [
				{
					id: 0,
					testHistoryId: 1,
					deviceId: currentDeviceId.current,
					isTestFailed: false,
					isTestPassed: false,
					isTestTested: false,
					isVisibleTestStatus: false,
					testStatustext: '',
				},
				{
					id: 1,
					testHistoryId: 2,
					deviceId: currentDeviceId.current,
					isTestFailed: false,
					isTestPassed: false,
					isTestTested: false,
					isVisibleTestStatus: false,
					testStatustext: '',
				},
				{
					id: 2,
					testHistoryId: 3,
					deviceId: currentDeviceId.current,
					isTestFailed: false,
					isTestPassed: false,
					isTestTested: false,
					isVisibleTestStatus: false,
					testStatustext: '',
				},
				{
					id: 3,
					testHistoryId: 4,
					deviceId: currentDeviceId.current,
					isTestFailed: false,
					isTestPassed: false,
					isTestTested: false,
					isVisibleTestStatus: false,
					testStatustext: '',
				},
				{
					id: 4,
					testHistoryId: 5,
					deviceId: currentDeviceId.current,
					isTestFailed: false,
					isTestPassed: false,
					isTestTested: false,
					isVisibleTestStatus: false,
					testStatustext: '',
				},
				{
					id: 5,
					testHistoryId: 6,
					deviceId: currentDeviceId.current,
					isTestFailed: false,
					isTestPassed: false,
					isTestTested: false,
					isVisibleTestStatus: false,
					testStatustext: '',
				},
				{
					id: 6,
					testHistoryId: 7,
					deviceId: currentDeviceId.current,
					isTestFailed: false,
					isTestPassed: false,
					isTestTested: false,
					isVisibleTestStatus: false,
					testStatustext: '',
				},
				{
					id: 7,
					testHistoryId: 8,
					deviceId: currentDeviceId.current,
					isTestFailed: false,
					isTestPassed: false,
					isTestTested: false,
					isVisibleTestStatus: false,
					testStatustext: '',
				},
			];
			if (
				currentDevice.current !== null &&
				currentDevice.current.channels === 2
			) {
				testHistorys.push(
					{
						id: 8,
						testHistoryId: 9,
						deviceId: currentDeviceId.current,
						isTestFailed: false,
						isTestPassed: false,
						isTestTested: false,
						isVisibleTestStatus: false,
						testStatustext: '',
					},
					{
						id: 9,
						testHistoryId: 10,
						deviceId: currentDeviceId.current,
						isTestFailed: false,
						isTestPassed: false,
						isTestTested: false,
						isVisibleTestStatus: false,
						testStatustext: '',
					},
				);
			}
			return testHistorys;
		} else {
			const testHistorys: TestsHistoryModel[] = [
				{
					id: 0,
					testHistoryId: 1,
					deviceId: currentDeviceId.current,
					isTestFailed: false,
					isTestPassed: false,
					isTestTested: false,
					isVisibleTestStatus: false,
					testStatustext: '',
				},
				{
					id: 1,
					testHistoryId: 2,
					deviceId: currentDeviceId.current,
					isTestFailed: false,
					isTestPassed: false,
					isTestTested: false,
					isVisibleTestStatus: false,
					testStatustext: '',
				},
				{
					id: 2,
					testHistoryId: 3,
					deviceId: currentDeviceId.current,
					isTestFailed: false,
					isTestPassed: false,
					isTestTested: false,
					isVisibleTestStatus: false,
					testStatustext: '',
				},
				{
					id: 3,
					testHistoryId: 4,
					deviceId: currentDeviceId.current,
					isTestFailed: false,
					isTestPassed: false,
					isTestTested: false,
					isVisibleTestStatus: false,
					testStatustext: '',
				},
				{
					id: 4,
					testHistoryId: 5,
					deviceId: currentDeviceId.current,
					isTestFailed: false,
					isTestPassed: false,
					isTestTested: false,
					isVisibleTestStatus: false,
					testStatustext: '',
				},
				{
					id: 5,
					testHistoryId: 6,
					deviceId: currentDeviceId.current,
					isTestFailed: false,
					isTestPassed: false,
					isTestTested: false,
					isVisibleTestStatus: false,
					testStatustext: '',
				},
				{
					id: 6,
					testHistoryId: 7,
					deviceId: currentDeviceId.current,
					isTestFailed: false,
					isTestPassed: false,
					isTestTested: false,
					isVisibleTestStatus: false,
					testStatustext: '',
				},
			];
			if (
				currentDevice.current !== null &&
				currentDevice.current.channels === 2
			) {
				testHistorys.push(
					{
						id: 7,
						testHistoryId: 8,
						deviceId: currentDeviceId.current,
						isTestFailed: false,
						isTestPassed: false,
						isTestTested: false,
						isVisibleTestStatus: false,
						testStatustext: '',
					},
					{
						id: 8,
						testHistoryId: 9,
						deviceId: currentDeviceId.current,
						isTestFailed: false,
						isTestPassed: false,
						isTestTested: false,
						isVisibleTestStatus: false,
						testStatustext: '',
					},
					{
						id: 9,
						testHistoryId: 10,
						deviceId: currentDeviceId.current,
						isTestFailed: false,
						isTestPassed: false,
						isTestTested: false,
						isVisibleTestStatus: false,
						testStatustext: '',
					},
				);
			}
			return testHistorys;
		}
	}

	const handleBeginTest = async () => {
		if (isTestBegin.current) return;

		isTestBegin.current = true;

		var testHistory = await dispatch(
			fetchTestHistory({ dataSource, deviceId: currentDeviceId.current }),
		).unwrap();

		if (
			testHistory !== null &&
			testHistory !== undefined &&
			testHistory.length > 0
		) {
			const testedCount = testHistory.filter(x => x.isTestTested).length;
			if (testedCount > 0) {
				testHistory.forEach(async historyTest => {
					if (historyTest.isTestTested) {
						await updateTestHistory(historyTest);
					}
				});
			}
		}
		try {
			if (ConnectedDeviceobj.current !== null) {
				const tests = await initializeTests();
				setTestsUI(tests);
				navigation.navigate(AppConstants.PerformDeviceTestScreen, {
					tests,
					deviceId: currentDeviceId.current,
					connectedDevice: ConnectedDeviceobj.current,
				});
			} else {
				Toast.show({
					type: 'error',
					text1: t('PlsConnectDevice'),
					position: 'bottom',
				});
				isTestBegin.current = false;
			}
		} catch (error) {
			Toast.show({
				type: 'error',
				text1: t('PlsConnectDevice'),
				position: 'bottom',
			});

			// Handle error appropriately
			isTestBegin.current = false;
		}
	};

	const handleUITestList = async (type: string) => {
		switch (type) {
			case 'all':
				setTestsUI(allTests.current);
				break;
			case 'pass':
				const passedTests = Array.isArray(allTests.current)
					? allTests.current.filter(x => x.isTestPassed === true)
					: [];
				setPassed(passedTests.length);
				setTestsUI(passedTests);
				break;
			case 'fail':
				const failedTests = Array.isArray(allTests.current)
					? allTests.current.filter(x => x.isTestFailed === true)
					: [];
				setFailed(failedTests.length);
				setTestsUI(failedTests);
				break;
			default:
				setTestsUI(allTests.current);
		}
	};
	const BackButtonCommand = () => {
		navigation.goBack();
	};
	const renderHeader = () => {
		return (
			<SafeAreaContextView edges={['top']} style={styles.safeHeader}>
				<View
					style={[
						styles.headerSection,
						{
							backgroundColor: '#000',
							alignItems: 'center',
						},
					]}>
					<View
						style={{
							flexDirection: 'row',
							alignItems: 'center',
							paddingHorizontal: 10,
							height: '100%',
							backgroundColor: '#000',
						}}>
						<TouchableOpacity
							onPress={() => BackButtonCommand()}
							style={{
								height: '100%',
								padding: 0,
								margin: 0,
								justifyContent: 'center',
							}}>
							<LeftArrowWhite height={30} width={30} />
						</TouchableOpacity>

						<View style={[{ flex: 2 }]}>
							<Text
								style={{
									color: '#fff',
									fontSize: 18,
									fontWeight: 'bold',
									textAlign: 'center',
								}}>
								{t('devicetest')}
							</Text>
						</View>
					</View>
				</View>
			</SafeAreaContextView>
		);
	};

	return (
		<View style={styles.safeArea}>
			{renderHeader()}
			{/* Progress Bar */}
			<View style={styles.section}>
				<View style={styles.progressContainer}>
					<View style={styles.progressBarBg}>
						<View style={[styles.progressBarFill, { width: `${progress}%` }]} />
					</View>
					<Text style={styles.progressText}>{testStatus}</Text>
				</View>
			</View>

			{/* Filters */}
			<View style={styles.filtersRow}>
				<TouchableOpacity
					style={[styles.filterCell, styles.firstCell]}
					onPress={() => handleUITestList('all')}>
					<Text style={styles.filterText}>{t('all')}</Text>
				</TouchableOpacity>

				<TouchableOpacity
					style={styles.filterCell}
					onPress={() => handleUITestList('pass')}>
					<Pass height={24} width={24} />
					<Text style={styles.filterCount}>{passed}</Text>
				</TouchableOpacity>

				<TouchableOpacity
					style={styles.filterCell}
					onPress={() => handleUITestList('fail')}>
					<Fail height={24} width={24} />
					<Text style={styles.filterCount}>{failed}</Text>
				</TouchableOpacity>
			</View>

			{/* Test List */}
			<FlatList
				data={testsUI}
				keyExtractor={(_, i) => i.toString()}
				style={{ flex: 1 }}
				contentContainerStyle={{ paddingBottom: 24 }}
				renderItem={({ item, index }) => (
					<View
						style={[
							styles.testItem,
							index % 2 === 0 && styles.testItemHighlighted,
						]}>
						<Text style={styles.testTitle}>{t(item.testNameKey)}</Text>
						<Text style={styles.testDesc}>{t(item.testDescriptionKey)}</Text>
					</View>
				)}
			/>

			{/* Begin Test Button */}
			<View style={styles.buttonContainer}>
				<TouchableOpacity
					style={styles.button}
					onPress={() => {
						handleBeginTest();
					}}>
					<Text style={styles.buttonText}>{t('BeginTest')}</Text>
				</TouchableOpacity>
			</View>
		</View>
	);
}
const styles = StyleSheet.create({
	safeArea: {
		flex: 1,
		backgroundColor: '#fff',
	},
	header: {
		backgroundColor: '#333',
		flexDirection: 'row',
		alignItems: 'center',
		height: 56,
		paddingHorizontal: 16,
	},
	headerTitle: {
		color: '#fff',
		fontSize: 22,
		fontWeight: '500',
		marginLeft: 16,
	},
	section: {
		backgroundColor: '#fff',
		paddingTop: 16,
		paddingBottom: 8,
		paddingHorizontal: 16,
		borderBottomWidth: 1,
		borderBottomColor: '#eee',
	},
	progressContainer: {
		flexDirection: 'row',
		alignItems: 'center',
	},
	progressBarBg: {
		flex: 1,
		height: 6,
		backgroundColor: '#ddd',
		borderRadius: 3,
		marginRight: 12,
	},
	progressBarFill: {
		height: 6,
		backgroundColor: 'green',
		borderRadius: 3,
	},
	progressText: {
		color: '#bdbdbd',
		fontSize: 18,
		fontWeight: '500',
		minWidth: 80,
		textAlign: 'left',
	},
	filtersRow: {
		flexDirection: 'row',
		backgroundColor: '#fff',
		paddingVertical: 12,
		borderBottomWidth: 1,
		borderBottomColor: '#eee',
		justifyContent: 'space-evenly',
	},
	filterCell: {
		flexDirection: 'row',
		alignItems: 'center',
		flex: 1,
		justifyContent: 'center',
		borderLeftWidth: 1,
		borderLeftColor: '#ddd',
	},
	firstCell: {
		borderLeftWidth: 0,
	},
	filterText: {
		fontSize: 18,
		color: '#888',
		marginRight: 6,
	},
	filterCount: {
		fontSize: 18,
		color: '#888',
		marginLeft: 4,
	},
	testItem: {
		padding: 16,
		borderBottomWidth: 1,
		borderBottomColor: '#e6e6e6',
		backgroundColor: '#fff',
	},
	testItemHighlighted: {
		backgroundColor: '#eee',
	},
	testTitle: {
		fontSize: 22,
		fontWeight: '500',
		color: '#222',
		marginBottom: 4,
	},
	testDesc: {
		fontSize: 16,
		color: '#888',
	},
	buttonContainer: {
		paddingHorizontal: 32,
		paddingVertical: 20,
		backgroundColor: '#fff',
	},
	button: {
		backgroundColor: '#00B7FA',
		borderRadius: 4,
		alignItems: 'center',
		paddingVertical: 14,
	},
	buttonText: {
		color: '#fff',
		fontSize: 18,
		fontWeight: 'bold',
		letterSpacing: 1,
	},
	headerSection: {
		backgroundColor: '#000',
		height: 56,
		width: '100%',
	},
	safeHeader: {
		backgroundColor: '#000',
	},
});
