import React, { ReactElement, useEffect, useRef, useState } from 'react';
import {
	View,
	StyleSheet,
	SafeAreaView,
	ScrollView,
	Text,
	TextInput,
	TouchableOpacity,
	Image,
	Alert,
	Modal,
	Platform,
	Linking,
	BackHandler,
	ActivityIndicator,
} from 'react-native';
import {
	SafeAreaView as SafeAreaContextView,
	SafeAreaProvider,
} from 'react-native-safe-area-context';
import { MenuProvider } from 'react-native-popup-menu';
import { check, request, PERMISSIONS, RESULTS } from 'react-native-permissions';
import * as yup from 'yup';
import { yupResolver } from '@hookform/resolvers/yup';
import { Controller, useForm } from 'react-hook-form';
import DropDown from '@ff_controllers/dropdown.tsx';
import SingleButtonFooter from '@components/singleButtonFooter';
import RadioButton from '@components/RadioButton';
import TextInputField from '@ff_controllers/textInputField.tsx';
import DateTime from '@ff_controllers/dateTime.tsx';
import CustomInput from '@ff_controllers/customInputField.tsx';
import PasswordModal from '@ff_controllers/passwordModal.tsx';
import { commonColors, commonSizes } from '@styles/base';
import dropdownIcon from '@assets/images/DropDownIcon.svg';
import IncrementDecrement from '@ff_controllers/incrementAndDecrement.tsx';
import TimeoutPopup from '@ff_controllers/timeoutPopup.tsx';
import { ObscurationUnit } from '@faastflex/faastflexEnum/obscurationUnit.ts';
import { useDatabase } from '../../../global/DatabaseContext.tsx';
import { useAppDispatch } from '../../../global/hooks.ts';
import {
	addNewDeviceParameter,
	updateExistingDeviceParameter,
	fetchDeviceParameter,
} from '@ff_redux/deviceParameterRedux/deviceParameterThunk.ts';

import { DeviceModel } from '@ff_model/deviceModel.ts';
import { delay } from '@ff_utils/timeDelay.ts';
//import { TimeSpan } from '@ff_utils/timeSpan.ts';
import {
	AlarmLevel,
	AlarmMode,
	Channel,
	Configuration,
	Country,
	DeviceStatus,
	DeviceType,
	ErrorCode,
	ExternalInputAction,
	ExternalInputMode,
	ExternalInputNormalState,
	FanPWMPercCorrection,
	FanSpeedLevel,
	getConfigurationDescription,
	getCountryDescription,
	getDeviceOrientationDescription,
	getDeviceTypeDescription,
	getExternalInputActionDescription,
	getExternalInputNormalStateDescription,
	getFanPWMPercCorrectionDescription,
	LatchedMode,
	PreAlarmLevel,
	RelayAlert,
} from '@faastflexCommands/commandEnum.ts';
import { DeviceGPIParams } from '@faastflexCommands/common_objects.ts';
import faastflexBluetoothCommunicator from '@faastflexCommunicator/faastflexBluetoothCommunicator.ts';
import { DeviceParametersModel } from '@ff_model/deviceParametersModel.ts';
import { confirmAlert } from '@ff_utils/confirmAlert.ts';
import DropdownMenu from '@ff_controllers/dropdownController.tsx';
import { useLoading } from '../../../global/GlobalContext/LoadingContext.tsx';
import Toast from 'react-native-toast-message';
import RNPickerSelect from 'react-native-picker-select';
import { updateExistingDevice } from '../redux/deviceRedux/devicesThunk';
import RNFS from 'react-native-fs';
import { pick } from '@react-native-documents/picker';
import {
	decryptAndParseConfigFile,
	encryptAndSerializeConfigFile,
} from '@ff_utils/fileDecryption';
// import { examineFileContent, testJustDecryption, testDecryptionBasics } from '../../@ff_utils/debugDecryption';
import { BluetoothDevice } from 'bleCommunicator/bleService.ts';
import { useTranslation } from 'react-i18next';
import QRScanner from '@components/QRScanner.tsx';
import CustomProgressBar from '@ff_controllers/customProgressBar.tsx';
import LeftArrowWhite from '@assets/images/LeftArrowWhite.svg';
import Dashboard from '@assets/images/Dashboard.svg';
import DashboardEnabled from '@assets/images/DashboardEnabled.svg';
import General from '@assets/images/General.svg';
import GeneralEnabled from '@assets/images/GeneralEnabled.svg';
import ImageButtonSVG from '@ff_controllers/imageButtonSVG.tsx';
import AspiratorQR from '@assets/images/AspiratorQR.svg';
import AspiratorChange from '@assets/images/AspiratorChange.svg';
import AspiratorCover from '@assets/images/AspiratorCover.svg';
import AspiratorCoverRemoval from '@assets/images/AspiratorCoverRemoval.svg';
import PassIcon from '@assets/images/Pass.svg';
import FailIcon from '@assets/images/Fail.svg';
import { CustomTimer } from '@ff_utils/customTimer.ts';
import BluetoothConnected from '@assets/images/BluetoothConnected.svg';
import BluetoothDisabled from '@assets/images/BluetoothDisabled.svg';
import SyncWhite from '@assets/images/SyncWhite.svg';
import SyncBlue from '@assets/images/SyncBlue.svg';
import stringFormat from '@ff_utils/stringFormat.ts';
import DropDownIcon from '@assets/images/DropDownIcon.svg';
import { AppConstants } from '@global/GlobalConstants/globalConstants.ts';
import useSyncedState from '@global/Hooks/useSyncedState.ts';
import CheckBox from '@react-native-community/checkbox';
import HorizontalScrollPicker from '@ff_controllers/horizontalScrollPicker.tsx';
import ResetBlue from '@assets/images/ResetBlue.svg';
import { get } from 'react-native/Libraries/TurboModule/TurboModuleRegistry';
import { StackActions, useNavigation } from '@react-navigation/native';
import { ModalLoadingIndicator } from '../controllers/modalLoadingIndicator.tsx';
import Share from 'react-native-share';

//#region Constants
const FF_DateTime = 'DateTime';
const FF_TrendLogDisabled = 'TrendLogDisabled';
const FF_TemperatureFaultRelay = 'TemperatureFaultRelay';
const FF_GPIInputStateSupervised = 'GPIInputStateSupervised';
const FF_ExternalTriggerOnOpen = 'ExternalTriggerOnOpen';
const FF_ExternalTriggerOnClosed = 'ExternalTriggerOnClosed';
const FF_GPIInputStateUnSupervised = 'GPIInputStateUnSupervised';
const FF_ExternalInputNormalState = 'ExternalInputNormalState';
const FF_UnbalancedEventTriggered = 'UnbalancedEventTriggered';
const FF_BlowerSpeed = 'BlowerSpeed';
const FF_FlowFaultDelay = 'FlowFaultDelay';
const FF_GeneralFaultLatched = 'GeneralFaultLatched';
const FF_AuxFaultLatched = 'AuxFaultLatched';
const FF_AlarmMode = 'AlarmMode';
const FF_Alarm1Latched = 'Alarm1Latched';
const FF_Alarm2Latched = 'Alarm2Latched';
const FF_FlowFaultThreshold = 'FlowFaultThreshold';

const GPI_Open = 'Open';
const GPI_Short = 'Short';
const GPI_None = 'None';
const GPI_RestAlarmsAndFault = 'Rest Alarms and Fault';
const GPI_PerformDisableAction = 'Perform Disable Action';
const GPI_TriggerExtFault = 'Trigger Ext. Fault';
const GPI_ResetDevice = 'Reset Device';
//#endregion
interface AddressChangeData {
	newAddressD1: number;
	newAddressD2: number;
}

const AddressChangeSchema = yup.object().shape({
	newAddressD1: yup
		.number()
		.required('New Address D1 is required')
		.typeError('New Address D1 must be a number')
		.min(0, 'New Address D1 must be a positive number')
		.max(159, 'New Address D1 must be less than 159'),
	newAddressD2: yup
		.number()
		.required('New Address D2 is required')
		.typeError('New Address D2 must be a number')
		.min(0, 'New Address D2 must be a positive number')
		.max(159, 'New Address D2 must be less than 159'),
});

interface GeneralParametersData {
	Orientation: string;
	selectedDate: Date;
	selectedTime: Date;
	TrendLogInterval: number;
	isTemparatureFaultSetRelays: number;
	// isLowPowerFaultSetRelays: number;
	blowerSpeed: number;
	blowerCorrection: string;
}

const GeneralSchema = yup.object().shape({
	TrendLogInterval: yup
		.number()
		.required('Trend Log Interval is required')
		.typeError('Trend Log Interval is Required')
		.integer('Trend Log Interval must be an integer')
		.min(0, 'Trend Log Interval must be between 0 and 240 seconds')
		.max(240, 'Trend Log Interval must be between 0 and 240 seconds'),
});

interface ChannelsAndSensorsData {
	FlowFaultDelay: number;
	Alarm1Configuration: number;
	Alarm2Configuration: number;
	GeneralFaultConfiguration: number;
	AuxFaultConfiguration: number;
	AlarmMode: number;
	Referenceflow1: number;
	FlowFaultThreshold: number;
	FlowFaultThresholdValue: number;
	Referenceflow2?: number;
}
const ChannelAndSensorsSchema = yup.object().shape({
	FlowFaultDelay: yup
		.number()
		.required('Flow Fault Delay is required')
		.typeError('Flow Fault Delay must Requird')
		.integer('Flow Fault Delay must be an integer')
		.min(0, 'Flow Fault Delay must be between 0 and 240 seconds')
		.max(240, 'Flow Fault Delay must be between 0 and 240 seconds'),

	Referenceflow1: yup.number().required('Reference Flow is required'),
	FlowFaultThreshold: yup.number().required('Flow Fault Threshold is required'),
	FlowFaultThresholdValue: yup
		.number()
		.required('Use EN54 Limit is required')
		.min(0, 'Value Should be any integer between 10 and 80')
		.max(80, 'Value Should be any integer between 10 and 80'),
	Referenceflow2: yup.number().when([], (fields, schema, context: any) => {
		return context && context.IsChannel2Available
			? schema.required('Reference Flow is required')
			: schema.notRequired();
	}),
});
export default function FFIDeviceParameterScreen({ route, navigation }: any) {
	//#region Export DeviceParametersModel to Downloads folder
	const exportDeviceParameters = async () => {
		try {
			// Use the encryption function to create encrypted XML data
			const encryptedData = encryptAndSerializeConfigFile(
				deviceParameters.current,
			);

			const fileName = `DeviceParameters_${Date.now()}.sfc`;
			// Write to app's downloads directory
			const directoryPath =
				Platform.OS === 'ios'
					? RNFS.DocumentDirectoryPath
					: RNFS.DownloadDirectoryPath;

			const filePath = `${directoryPath}/${fileName}`;

			// Write the encrypted data as base64 to the file
			await RNFS.writeFile(filePath, encryptedData, 'base64');

			const answer = await confirmAlert(
				stringFormat(t('DeviceExportedAndShareConfirmation'), filePath),
				t('lblExported'),
				t('Share'),
				t('Cancel_PascalCase'),
			);
			if (answer) {
				try {
					const shareOptions = {
						title: fileName,
						url: Platform.OS === 'ios' ? filePath : `file://${filePath}`,
						type: 'text/plain',
						filename: fileName,
						failOnCancel: false,
					};
					await Share.open(shareOptions)
						.then(res => {
							console.log('Share result:', res);
							Toast.show({
								type: 'success',
								text1: stringFormat(t('DeviceExported'), filePath),
								text2: fileName,
								position: 'bottom',
							});
						})
						.catch(error => {
							console.log('Share error:', error);
							if (
								error.message &&
								error.message.includes('User did not share')
							) {
								console.log('User cancelled share');
							} else {
								Alert.alert(t('warning'), t('msgPleaseTryAgain'), [
									{ text: t('ok') },
								]);
							}
						});
				} catch (error) {
					Alert.alert(t('warning'), t('msgPleaseTryAgain'), [
						{ text: t('ok') },
					]);
				}
			}
		} catch (error: any) {
			Alert.alert(t('warning'), t('msgPleaseTryAgain'), [{ text: t('ok') }]);
		}
	};
	//#endregion

	//#region Map XML data to DeviceParametersModel
	function mapXmlDataToDeviceParameters(
		deviceParams: DeviceParametersModel,
		xmlData: any,
	) {
		try {
			// Handle date/time properties
			if (xmlData.installationDateTime) {
				const dateValue = xmlData.installationDateTime;
				deviceParams.installationDateTime = new Date(dateValue);
				deviceParams.installationDate = new Date(dateValue);
			}
			// Handle numeric properties
			if (xmlData.trendLogDisabled !== undefined)
				deviceParams.trendLogDisabled = Number(xmlData.trendLogDisabled);
			if (xmlData.actionDelay !== undefined)
				deviceParams.actionDelay = Number(xmlData.actionDelay);
			if (xmlData.alarmDelay !== undefined)
				deviceParams.alarmDelay = Number(xmlData.alarmDelay);
			if (xmlData.flowFaultDelay !== undefined)
				deviceParams.flowFaultDelay = Number(xmlData.flowFaultDelay);
			if (xmlData.blowerCorrection !== undefined)
				deviceParams.blowerCorrection = String(xmlData.blowerCorrection);

			// Handle enum properties
			if (xmlData.temperatureFaultRelay !== undefined)
				deviceParams.temperatureFaultRelay = Number(
					xmlData.temperatureFaultRelay,
				);
			if (xmlData.lowPowerFaultRelay !== undefined)
				deviceParams.lowPowerFaultRelay = Number(xmlData.lowPowerFaultRelay);
			if (xmlData.blowerSpeed !== undefined)
				deviceParams.blowerSpeed = Number(xmlData.blowerSpeed);
			if (xmlData.alarmLatched !== undefined)
				deviceParams.alarmLatched = Number(xmlData.alarmLatched);
			if (xmlData.actionLatched !== undefined)
				deviceParams.actionLatched = Number(xmlData.actionLatched);
			if (xmlData.faultLatched !== undefined)
				deviceParams.faultLatched = Number(xmlData.faultLatched);
			//if (xmlData.deviceAlarmMode !== undefined) deviceParams.deviceAlarmMode = Number(xmlData.deviceAlarmMode);

			// Handle channel properties
			if (xmlData.channel1ActionLevel !== undefined)
				deviceParams.channel1ActionLevel = Number(xmlData.channel1ActionLevel);
			if (xmlData.channel1AlarmLevel !== undefined)
				deviceParams.channel1AlarmLevel = Number(xmlData.channel1AlarmLevel);
			if (xmlData.flowFaultThresholdCh1 !== undefined)
				deviceParams.flowFaultThresholdCh1 = Number(
					xmlData.flowFaultThresholdCh1,
				);
			if (xmlData.referenceFlowCh1 !== undefined)
				deviceParams.referenceFlowCh1 = Number(xmlData.referenceFlowCh1);

			if (xmlData.channel2ActionLevel !== undefined)
				deviceParams.channel2ActionLevel = Number(xmlData.channel2ActionLevel);
			if (xmlData.channel2AlarmLevel !== undefined)
				deviceParams.channel2AlarmLevel = Number(xmlData.channel2AlarmLevel);
			if (xmlData.flowFaultThresholdCh2 !== undefined)
				deviceParams.flowFaultThresholdCh2 = Number(
					xmlData.flowFaultThresholdCh2,
				);
			if (xmlData.referenceFlowCh2 !== undefined)
				deviceParams.referenceFlowCh2 = Number(xmlData.referenceFlowCh2);

			// Handle GPI properties
			if (xmlData.gpInputState !== undefined)
				deviceParams.gpInputState = Number(xmlData.gpInputState);
			if (xmlData.externalInputNormalState !== undefined)
				deviceParams.externalInputNormalState = Number(
					xmlData.externalInputNormalState,
				);
			if (xmlData.unbalancedEventTriggered !== undefined)
				deviceParams.unbalancedEventTriggered = Number(
					xmlData.unbalancedEventTriggered,
				);
			if (xmlData.externalTriggerOnClosed !== undefined)
				deviceParams.externalTriggerOnClosed = Number(
					xmlData.externalTriggerOnClosed,
				);
			if (xmlData.externalTriggerOnOpen !== undefined)
				deviceParams.externalTriggerOnOpen = Number(
					xmlData.externalTriggerOnOpen,
				);

			// Handle boolean properties
			if (xmlData.gpiState !== undefined)
				deviceParams.gpiState = Boolean(xmlData.gpiState);

			// Handle device identification properties
			if (xmlData.deviceId) deviceParams.deviceId = xmlData.deviceId;
			if (xmlData.deviceName) deviceParams.deviceName = xmlData.deviceName;
			if (xmlData.channels !== undefined)
				deviceParams.channels = Number(xmlData.channels);

			//Handle Intelligent Device specific parameters
			if (xmlData.alarm2Latched !== undefined)
				deviceParams.alarm2Latched = Number(xmlData.alarm2Latched);
			if (xmlData.auxFaultLatched !== undefined)
				deviceParams.auxFaultLatched = Number(xmlData.auxFaultLatched);
			if (xmlData.generalFaultLatched !== undefined)
				deviceParams.generalFaultLatched = Number(xmlData.generalFaultLatched);

			console.log('Mapped XML data to device parameters successfully');
			console.log('Filled Data is ', deviceParams);
		} catch (error) {
			console.error('Error mapping XML data to device parameters:', error);
			throw new Error('Failed to map configuration data');
		}
	}
	//#endregion

	//#region Import DeviceParametersModel from Downloads folder
	const filePickerInProgressRef = useRef<boolean>(false);
	const handleImport = async () => {
		if (filePickerInProgressRef.current) {
			console.log('File picker already in progress, ignoring new request');
			return;
		}

		try {
			filePickerInProgressRef.current = true;
			const res = await pick({
				type: [Platform.OS === 'ios' ? 'public.data' : '*/*'],
				allowMultiSelection: false,
				mode: 'open',
				copyTo: 'cachesDirectory',
			});
			console.log('array', res);

			await Promise.all(
				res.map(async file => {
					console.log('Selected file:', file.uri);

					try {
						const fileName = file.name || '';

						let filePath = file.uri;
						if (Platform.OS === 'ios') {
							filePath = decodeURIComponent(file.uri.replace('file://', ''));
						} else {
							filePath = file.uri;
						}

						let fileContent: string;

						// For encrypted files, read as base64 since they contain binary data
						console.log('Reading encrypted .sfc file as base64...');
						fileContent = await RNFS.readFile(filePath, 'base64');

						let parsed;

						console.log('Processing encrypted .sfc file...');
						try {
							parsed = await decryptAndParseConfigFile(fileContent, fileName);
							console.log('Full pipeline worked! Parsed result:', parsed);
						} catch (parseError) {
							console.log('XML parsing failed:', parseError);
							throw parseError;
						}
						console.log('Decrypted and parsed .sfc file:', parsed);
						Toast.show({
							type: 'success',
							text1: 'Encrypted File Decrypted',
							text2: 'Successfully decrypted configuration file from old app',
							position: 'bottom',
						});

						let channels = 0;
						if (parsed.channels) {
							channels = Number(parsed.channels);
						} else if (parsed.Channels) {
							channels = Number(parsed.Channels);
						}

						if (channels !== deviceParameters.current.channels) {
							Alert.alert('Error', t('Channel Mismatch'), [{ text: 'ok' }]);
							return;
						}
						const importedDeviceType = parsed.deviceType;
						if (
							importedDeviceType === undefined ||
							importedDeviceType === DeviceType.eStandAlone
						) {
							Alert.alert('Error', t('Device Type Not Supported'), [
								{ text: 'ok' },
							]);
							return;
						}

						const importedParams = new DeviceParametersModel();
						// Handle different data structures based on source
						mapXmlDataToDeviceParameters(importedParams, parsed);

						console.log('Imported device parameters:', importedParams);

						// Validate and assign imported values to form
						AssignImportedValuesToYup(importedParams);

						Toast.show({
							type: 'success',
							text1: 'Import Successful',
							text2: `Configuration imported successfully from ${fileName}`,
							position: 'bottom',
						});
					} catch (parseError) {
						console.error('Error parsing file:', parseError);
						Toast.show({
							type: 'error',
							text1: 'Import Failed',
							text2:
								parseError instanceof Error
									? parseError.message
									: 'Could not parse the selected file',
							position: 'bottom',
						});
					}
				}),
			);
		} catch (err) {
			console.log('File picker error:', err);
			Toast.show({
				type: 'error',
				text1: 'File Selection Failed',
				text2: 'Could not select or read the file',
				position: 'bottom',
			});
		} finally {
			filePickerInProgressRef.current = false;
		}
	};
	//#endregion

	//#region
	async function AssignImportedValuesToYup(
		deviceParams: DeviceParametersModel,
	) {
		//#region General Parameters
		if (deviceParams !== null && deviceParams !== undefined) {
			const alarm1c =
				selectedDeviceRef.current.deviceCountryCode ===
				getCountryDescription(Country.CHINA)
					? LatchedMode.eLatched
					: deviceParams.alarmLatched;
			const alarm2c =
				selectedDeviceRef.current.deviceCountryCode ===
				getCountryDescription(Country.CHINA)
					? LatchedMode.eLatched
					: deviceParams.alarm2Latched;
			const fanspeed = deviceParams.blowerSpeed;
			const generalfaultc = deviceParams.generalFaultLatched;
			const auxfaultc = deviceParams.auxFaultLatched;
			const alamm = deviceParams.deviceAlarmMode;
			generalClearErrors();
			generalSetValue('selectedDate', deviceParams.installationDateTime);
			generalSetValue('selectedTime', deviceParams.installationDateTime);
			generalSetValue('TrendLogInterval', deviceParams.trendLogDisabled);
			generalSetValue(
				'isTemparatureFaultSetRelays',
				deviceParams.temperatureFaultRelay === 0
					? 1
					: deviceParams.temperatureFaultRelay === 1
					? 0
					: 2,
			);

			if (IsGPIVisible && IsGPIEnabledConfig) {
				setGpiInputState(deviceParams.gpiState === true ? 1 : 0);
				setGpiNormalState(deviceParams.externalInputNormalState);
				setUnbalancedEventTriggered(deviceParams.unbalancedEventTriggered);
				setEventTriggerOnClose(deviceParams.externalTriggerOnClosed);
				setEventTriggerOnOpen(deviceParams.externalTriggerOnOpen);
			}

			if (fanspeed === 0) {
				generalSetValue('blowerSpeed', 0);
			} else if (fanspeed === 1) {
				generalSetValue('blowerSpeed', 1);
			} else {
				generalSetValue('blowerSpeed', 1);
			}

			generalSetValue('blowerCorrection', deviceParams.blowerCorrection);

			//#endregion

			//#region Channel and Sensors Parameters
			csClearErrors();
			csSetValue('FlowFaultDelay', deviceParams.flowFaultDelay);
			if (alarm1c === LatchedMode.eLatched) {
				csSetValue('Alarm1Configuration', 0);
			} else if (alarm1c === LatchedMode.eUnlatched) {
				csSetValue('Alarm1Configuration', 1);
			}
			if (alarm2c === LatchedMode.eLatched) {
				csSetValue('Alarm2Configuration', 0);
			} else if (alarm2c === LatchedMode.eUnlatched) {
				csSetValue('Alarm2Configuration', 1);
			}
			if (generalfaultc === LatchedMode.eLatched) {
				csSetValue('GeneralFaultConfiguration', 0);
			} else if (generalfaultc === LatchedMode.eUnlatched) {
				csSetValue('GeneralFaultConfiguration', 1);
			}
			if (auxfaultc === LatchedMode.eLatched) {
				csSetValue('AuxFaultConfiguration', 0);
			} else if (auxfaultc === LatchedMode.eUnlatched) {
				csSetValue('AuxFaultConfiguration', 1);
			}
			// if(alamm === AlarmMode.eUp_InstantFire){
			//     csSetValue('AlarmMode', 0);
			// }
			// else if(alamm === AlarmMode.eDown_Cumulative){
			//     csSetValue('AlarmMode', 1);
			// }
			csSetValue('Referenceflow1', deviceParams.referenceFlowCh1);
			csSetValue('FlowFaultThresholdValue', deviceParams.flowFaultThresholdCh1);
			csSetValue(
				'FlowFaultThreshold',
				deviceParams.flowFaultThresholdCh1 === 15 ? 0 : 1,
			);
			csSetValue('Referenceflow2', deviceParams.referenceFlowCh2);
			//#endregion
		}
	}
	//#endregion

	//#region
	function FetchValuesFromYup(): DeviceParametersModel {
		let devParams = new DeviceParametersModel();

		const selectedDate = generalWatch('selectedDate');
		const selectedTime = generalWatch('selectedTime');
		if (selectedDate !== null) {
			const installDate = new Date(
				selectedDate.getFullYear(),
				selectedDate.getMonth(),
				selectedDate.getDate(),
				selectedTime.getHours(),
				selectedTime.getMinutes(),
				selectedTime.getSeconds(),
			);
			devParams.installationDate = installDate;
		}

		const trendLogInterval = generalWatch('TrendLogInterval');
		devParams.trendLogDisabled = trendLogInterval;

		const isTemparatureFaultSetRelays = generalWatch(
			'isTemparatureFaultSetRelays',
		);
		devParams.temperatureFaultRelay = isTemparatureFaultSetRelays;

		if (IsGPIVisible && IsGPIEnabledConfig) {
			devParams.gpiState = gpiInputState === 1;
			devParams.externalInputNormalState = gpiNormalState;
			devParams.unbalancedEventTriggered = unbalancedEventTriggered;
			devParams.externalTriggerOnClosed = eventTriggerOnClose;
			devParams.externalTriggerOnOpen = eventTriggerOnOpen;
		}
		const blowerSpeed = generalWatch('blowerSpeed');
		devParams.blowerSpeed = blowerSpeed;
		const blowerCorrection = generalWatch('blowerCorrection');
		devParams.blowerCorrection = blowerCorrection;

		const flowFaultDelay = csWatch('FlowFaultDelay');
		devParams.flowFaultDelay = flowFaultDelay;

		const alarm1Config = csWatch('Alarm1Configuration');
		devParams.alarmLatched = alarm1Config;

		const alarm2Config = csWatch('Alarm2Configuration');
		devParams.alarm2Latched = alarm2Config;

		const generalFault = csWatch('GeneralFaultConfiguration');
		devParams.generalFaultLatched = generalFault;

		const auxFault = csWatch('AuxFaultConfiguration');
		devParams.auxFaultLatched = auxFault;

		const alarmMode = csWatch('AlarmMode');
		devParams.deviceAlarmMode = alarmMode;

		const ffThreshold = csWatch('FlowFaultThresholdValue');
		devParams.flowFaultThresholdCh1 = ffThreshold;

		return devParams;
	}
	//#endregion
	//#region Properties

	//Database
	const dispatch = useAppDispatch();
	const { dataSource } = useDatabase();
	const { t } = useTranslation();

	const [isChannel, setIsChannel] = useState(2);
	const [detectorNum, setDetectorNum] = useState(2);
	const { showLoadingIndicator, hideLoadingIndicator } = useLoading();
	// Current active field for dropdown
	const [currentField, setCurrentField] = useState<string>('');
	const [isGPIDropDownModalVisible, setGPIDropDownModalVisible] =
		useState<boolean>(false);
	const [tempSelectedItem, setTempSelectedItem] = useState<string | null>(null);
	const [password, setPassword] = useState<string>('');
	const [isPasswordModalVisible, setPasswordModalVisible] = useState(false);
	const [RealConfiguration, setRealConfiguration] =
		useState<string>('Extented');
	const [showTimeoutPopup, setShowTimeoutPopup] = useState(false);
	const timeoutTimerRef = React.useRef<NodeJS.Timeout | null>(null);
	const [isGeneralParameterVisible, setIsGeneralParameterVisible] =
		useState<boolean>(true);
	const [isChannelsAndSensorsVisible, setIsChannelsAndSensorsVisible] =
		useState<boolean>(false);
	const [isSensorAddressVisible, setIsSensorAddressVisible] =
		useState<boolean>(false);
	const [IsQRScannerVisible, setIsQRScannerVisible] = useState<boolean>(false);

	const [IsAddSparepartVisible, setIsAddSparepartVisible] = useState(false);
	const [selectedObscurationUnit, setSelectedObscurationUnit] =
		useState<ObscurationUnit | null>(null);
	const [selectedDevice, setSelectedDevice, selectedDeviceRef] =
		useSyncedState<DeviceModel>(new DeviceModel());
	const [IsEnabledConfig, setIsEnabledConfig] = useState<boolean>(false);
	const [IsSyncEnabled, setIsSyncEnabled] = useState<boolean>(false);
	const [IsRealConfigOutOfBox, setIsRealConfigOutOfBox] =
		useState<boolean>(false);
	const [isChannel1Visible, setIsChannel1Visible] = useState<boolean>(false);
	const [isChannel2Visible, setIsChannel2Visible] = useState<boolean>(false);
	const [IsGPIVisible, setIsGPIVisible] = useState<boolean>(false);
	const [DeviceConfig, setDeviceConfig] = useState<string>('Default');
	const [IsChannel2Available, setIsChannel2Available] =
		useState<boolean>(false);
	const [GPIInputState1, setGPIInputState1] = useState<boolean>(true);
	const [
		IsUnbalancedEventtriggeredlistVisible,
		setIsUnbalancedEventtriggeredlistVisible,
	] = useState<boolean>(false);
	const [IsEventtriggeredOpenlistVisible, setIsEventtriggeredOpenlistVisible] =
		useState<boolean>(false);
	const [IsGPIEnabledConfig, setIsGPIEnabledConfig] = useState<boolean>(false);
	const [deviceOrientation, setDeviceOrientation] = useState<string>('');
	const selectedInstallationDateRef = useRef<Date>(new Date());
	const [selectedInstallationTimeSpan, setSelectedInstallationTimeSpan] =
		useState<Date>(new Date());
	const [BluetoothImage, setBluetoothImage] = useState<string>(
		'PanelDisconnected.png',
	);
	const [TextColorChange, setTextColorChange] = useState<string>('#1791E4');
	let generalParams: string[] = [];
	let retryGeneralParams: string[] = [];

	const [tempFaultRelay, setTempFaultRelay] = useState<RelayAlert>(
		RelayAlert.eUnknown,
	);
	const [lowpowerFaultRelay, setLowpowerFaultRelay] = useState<RelayAlert>(
		RelayAlert.eUnknown,
	);
	const [importConfiginProgress, setImportConfiginProgress] =
		useState<boolean>(false);
	let channelsAndSensorsParams: string[] = [];
	let retryChannelsAndSensorsParams: string[] = [];
	const [alarmLatchMode, setAlarmLatchMode] = useState<LatchedMode>(
		LatchedMode.eUnknown,
	);
	const [preAlarmLatchMode, setPreAlarmLatchMode] = useState<LatchedMode>(
		LatchedMode.eUnknown,
	);
	const [faultLatchMode, setFaultLatchMode] = useState<LatchedMode>(
		LatchedMode.eUnknown,
	);
	// const [ffAlarmMode, setFFAlarmMode] = useState<AlarmMode>(AlarmMode.eUnknown);
	const ConnectedDeviceobj = useRef<BluetoothDevice | null>();
	const deviceParameters = useRef<DeviceParametersModel>(
		new DeviceParametersModel(),
	);

	const [currentAddress, setCurrentAddress] = useState<number>(-1);

	const [offlineMode, setOfflineMode] = useState<boolean>(false);
	const [isChineseDevice, setIsChineseDevice] = useState<boolean>(false);

	// Add these useState hooks in your component
	const [gpiInputState, setGpiInputState] = useState<number>(1);
	const [gpiNormalState, setGpiNormalState] =
		useState<ExternalInputNormalState>(ExternalInputNormalState.eShort);
	const [unbalancedEventTriggered, setUnbalancedEventTriggered] =
		useState<ExternalInputAction>(ExternalInputAction.eResetAlarmAndFault);
	const [eventTriggerOnClose, setEventTriggerOnClose] =
		useState<ExternalInputAction>(ExternalInputAction.eResetAlarmAndFault);
	const [eventTriggerOnOpen, setEventTriggerOnOpen] =
		useState<ExternalInputAction>(ExternalInputAction.eResetAlarmAndFault);

	function getExternalInputActionItems(): Array<{
		label: string;
		value: ExternalInputAction;
	}> {
		return [
			{
				label: getExternalInputActionDescription(ExternalInputAction.eNone),
				value: ExternalInputAction.eNone,
			},
			{
				label: getExternalInputActionDescription(
					ExternalInputAction.eResetDevice,
				),
				value: ExternalInputAction.eResetDevice,
			},
			{
				label: getExternalInputActionDescription(
					ExternalInputAction.eTriggerExtFault,
				),
				value: ExternalInputAction.eTriggerExtFault,
			},
			{
				label: getExternalInputActionDescription(
					ExternalInputAction.ePerformADisableAction,
				),
				value: ExternalInputAction.ePerformADisableAction,
			},
			{
				label: getExternalInputActionDescription(
					ExternalInputAction.eResetAlarmAndFault,
				),
				value: ExternalInputAction.eResetAlarmAndFault,
			},
		];
	}

	function getExternalInputNormalStateItems(): Array<{
		label: string;
		value: ExternalInputNormalState;
	}> {
		return [
			{
				label: getExternalInputNormalStateDescription(
					ExternalInputNormalState.eOpen,
				),
				value: ExternalInputNormalState.eOpen,
			},
			{
				label: getExternalInputNormalStateDescription(
					ExternalInputNormalState.eShort,
				),
				value: ExternalInputNormalState.eShort,
			},
		];
	}

	//#region Save Failed Message

	// General parameters save failure flags
	const [deviceDateSaveFailed, setDeviceDateSaveFailed] =
		useState<boolean>(false);
	const [trendLogIntervalSaveFailed, setTrendLogIntervalSaveFailed] =
		useState<boolean>(false);
	const [tempFaultSetsRelaysSaveFailed, setTempFaultSetsRelaysSaveFailed] =
		useState<boolean>(false);
	const [gpiSaveFailed, setGPISaveFailed] = useState<boolean>(false);
	const [aspiratorSpeedSaveFailed, setAspiratorSpeedSaveFailed] =
		useState<boolean>(false);

	// Channels and sensors save failure flags
	const [flowFaultDelaySaveFailed, setFlowFaultDelaySaveFailed] =
		useState<boolean>(false);
	const [alarm1ConfigSaveFailed, setAlarm1ConfigSaveFailed] =
		useState<boolean>(false);
	const [alarm2ConfigSaveFailed, setAlarm2ConfigSaveFailed] =
		useState<boolean>(false);
	const [generalFaultConfigSaveFailed, setGeneralFaultConfigSaveFailed] =
		useState<boolean>(false);
	const [auxFaultConfigSaveFailed, setAuxFaultConfigSaveFailed] =
		useState<boolean>(false);
	const [alarmModeSaveFailed, setAlarmModeSaveFailed] =
		useState<boolean>(false);
	const [flowFaultThresholdSaveFailed, setFlowFaultThresholdSaveFailed] =
		useState<boolean>(false);
	//#endregion

	//#endregion
	//#region  On Screen Appeared
	useEffect(() => {
		console.log('Route params:', route.params);
		initializeAsync();
	}, []);

	useEffect(() => {
		const unsubscribe = navigation.addListener('focus', () => {
			OnPageAppeared();
		});
		return unsubscribe;
	}, [navigation]);
	//#endregion

	//#region Prevent Device Back Functionality
	useEffect(() => {
		const backHandler = BackHandler.addEventListener(
			'hardwareBackPress',
			() => {
				return true; // Return true to prevent default back behavior
			},
		);

		return () => backHandler.remove();
	}, []);

	//iOS
	useEffect(() => {
		navigation.setOptions({
			gestureEnabled: false, // Disable swipe back gesture
		});
	}, [navigation]);
	//#endregion

	const {
		control: generalControl,
		handleSubmit: generalHandleSubmit,
		formState: { errors: generalErrors },
		setValue: generalSetValue,
		watch: generalWatch,
		clearErrors: generalClearErrors,
		trigger: generalTrigger,
	} = useForm<GeneralParametersData>({
		resolver: yupResolver(GeneralSchema as any),
		mode: 'onChange',
		defaultValues: {
			Orientation: '',
			selectedDate: new Date(),
			selectedTime: new Date(),
			TrendLogInterval: 0,
			isTemparatureFaultSetRelays: 1,
			blowerSpeed: 0,
			blowerCorrection: AppConstants.NA,
		},
	});

	//#region  Temp Watch method
	useEffect(() => {
		const subscription = generalWatch(value => {
			console.log('General form values changed:', value);
		});
		return () => {
			subscription.unsubscribe();
		};
	}, [generalWatch]);
	//#endregion
	const {
		control: csControl,
		handleSubmit: csHandleSubmit,
		formState: { errors: csErrors },
		setValue: csSetValue,
		watch: csWatch,
		clearErrors: csClearErrors,
		trigger: csTrigger,
		setError: csSetError,
	} = useForm<ChannelsAndSensorsData>({
		resolver: yupResolver(ChannelAndSensorsSchema as any),
		mode: 'onChange',
		defaultValues: {
			FlowFaultDelay: 30,
			Alarm1Configuration: 0,
			Alarm2Configuration: 0,
			GeneralFaultConfiguration: 0,
			AuxFaultConfiguration: 0,
			AlarmMode: 0,
			Referenceflow1: 0,
			Referenceflow2: 0,
			FlowFaultThreshold: 0,
			FlowFaultThresholdValue: 15,
		},
	});

	const {
		control: addressControl,
		handleSubmit: addressHandleSubmit,
		formState: { errors: addressErrors },
		setValue: addressSetValue,
		watch: addressWatch,
		clearErrors: addressClearErrors,
		trigger: addressTrigger,
	} = useForm<AddressChangeData>({
		resolver: yupResolver(AddressChangeSchema as any),
		defaultValues: {
			newAddressD1: -1,
			newAddressD2: -1,
		},
	});

	//#region  Initialization

	async function OnPageAppeared() {
		deviceParameters.current = new DeviceParametersModel();
	}

	async function initializeAsync() {
		await startTimerForTimeout();
		setIsAddSparepartVisible(false);
		setSelectedObscurationUnit(ObscurationUnit.Alarm);
		if (route.params && route.params.selectedItem != null) {
			const deviceData = route.params.selectedItem as DeviceModel;
			setSelectedDevice(deviceData);
			if (deviceData.deviceStatusStr !== t('Unknown')) {
				showLoadingIndicator(t('PasswordAuthenticated'));
				await delay(500);
			}
			if (deviceData.deviceConfig === Configuration.Extended) {
				setIsEnabledConfig(true);
				setIsSyncEnabled(true);
			} else if (
				deviceData.deviceMacAddress !== t('Not Connected yet') &&
				!deviceData.isDeviceConnected
			) {
				setIsEnabledConfig(false);
				setIsSyncEnabled(false);
				setIsChannel1Visible(true);
				//TODO : OPACITY change for UI
				let deviceParams = await dispatch(
					fetchDeviceParameter({
						dataSource,
						deviceId: deviceData.deviceId,
					}),
				).unwrap();

				AssignDeviceParameters(deviceParams);
				if (deviceParams.channels !== deviceData.channels) {
					let tempDeviceParams = {
						...deviceParams,
						channels: deviceData.channels,
					} as DeviceParametersModel;
					const obj = await dispatch(
						updateExistingDeviceParameter({
							dataSource,
							deviceId: tempDeviceParams.deviceId,
							updates: tempDeviceParams,
						}),
					);
				}
			} else {
				setIsEnabledConfig(false);
				setIsSyncEnabled(false);
			}
			if (deviceData.deviceConfig === Configuration.OutOfTheBox) {
				setIsRealConfigOutOfBox(true);
			} else {
				setIsRealConfigOutOfBox(false);
			}
			var isFirmwareHigher =
				deviceData.firmwareVersion !== null &&
				deviceData.firmwareVersion !== '' &&
				deviceData.firmwareVersion.length < 1
					? false
					: parseInt(deviceData.firmwareVersion.split('.')[0]) >= 4;
			setIsGPIVisible(isFirmwareHigher);
			setDeviceConfig(t(getConfigurationDescription(deviceData.deviceConfig)));

			if (deviceData !== null) {
				if (
					deviceData.listOfChannels !== null &&
					deviceData.listOfChannels.length === 2
				) {
					setIsChannel(2);
					setIsChannel2Available(true);
				} else {
					setIsChannel(1);
					setIsChannel2Available(false);
				}
				if (deviceData.isDeviceConnected) {
					setBluetoothImage('PanelConnected.png');
					setTextColorChange('#1791E4');
				}

				if (
					route.params &&
					route.params.connectedDevice !== undefined &&
					route.params.connectedDevice !== null
				) {
					ConnectedDeviceobj.current = route.params
						.connectedDevice as BluetoothDevice;
					var isFirmwareHigher = await GetDeviceFirmware();
					await GetGPIParametersFromDevice();
					await GetGeneralParametersFromDevice();
					await GetChannelSensorsfromDevice();

					if (deviceData.isDeviceConnected) {
						let tempDeviceParameter = deviceParameters.current;
						tempDeviceParameter.deviceId = deviceData.deviceId;
						tempDeviceParameter.deviceName = deviceData.deviceName;
						tempDeviceParameter.channels = deviceData.channels;
						tempDeviceParameter.deviceType =
							deviceData.deviceType ===
							getDeviceTypeDescription(DeviceType.eIntelligent)
								? DeviceType.eIntelligent
								: DeviceType.eStandAlone;
						deviceParameters.current = tempDeviceParameter;

						const result = await dispatch(
							addNewDeviceParameter({
								dataSource,
								deviceParameter: tempDeviceParameter,
							}),
						);
					}
					const isQrVisible =
						deviceData.isDeviceConnected &&
						deviceData.isManualPairingCompleted &&
						IsGPIVisible; // use isFirmwareHigher if IsGPIVisible is not rendered
					setIsQRScannerVisible(isQrVisible);
					if (deviceData !== null && !deviceData.isConfigDataFetched) {
						setSelectedDevice({
							isConfigDataFetched: true,
						});
						const result = await dispatch(
							updateExistingDevice({
								dataSource,
								deviceId: selectedDeviceRef.current.deviceId,
								updates: {
									isConfigDataFetched: true,
								},
							}),
						);
					}
				}

				if (
					deviceData.isDeviceConnected === false &&
					route.params &&
					(route.params.connectedDevice === undefined ||
						route.params.connectedDevice === null)
				) {
					setBluetoothImage('PanelDisconnected.png');
					setOfflineMode(true);
					setIsSyncEnabled(false);
				}
			}
		}

		hideLoadingIndicator();
		setSelectedObscurationUnit(ObscurationUnit.Alarm);
		// Clean up timer when component unmounts
		return () => {
			if (timeoutTimerRef.current) {
				clearTimeout(timeoutTimerRef.current);
			}
		};
	}

	async function GetDeviceFirmware(): Promise<boolean> {
		let retvalue = false;
		if (
			selectedDeviceRef.current?.firmwareVersion !== '' &&
			selectedDeviceRef.current.firmwareVersion.length > 0
		) {
			retvalue = selectedDeviceRef.current?.deviceName
				? parseInt(selectedDeviceRef.current.firmwareVersion.split('.')[0]) >= 4
				: false;
		} else {
			if (ConnectedDeviceobj.current !== null) {
				const deviceFirmware =
					await faastflexBluetoothCommunicator.GetFirmwareVersion();

				var majorVersion =
					deviceFirmware.firmwareVersion !== '' &&
					deviceFirmware.firmwareVersion.length > 0
						? parseInt(deviceFirmware.firmwareVersion.split('.')[0])
						: 0;
				if (majorVersion > 0) {
					if (selectedDeviceRef.current != null) {
						setSelectedDevice({
							firmwareVersion: deviceFirmware.firmwareVersion,
						});
					}
					dispatch(
						updateExistingDevice({
							dataSource,
							deviceId: selectedDeviceRef.current.deviceId,
							updates: {
								firmwareVersion: deviceFirmware.firmwareVersion,
							},
						}),
					);
					retvalue = majorVersion >= 4;
				}
			}
		}
		return retvalue;
	}

	//#endregion
	//#region Assign Device Parameters
	function AssignDeviceParameters(deviceParams: DeviceParametersModel) {
		//#region C# Implementation
		selectedInstallationDateRef.current = deviceParams.installationDateTime;
		setSelectedInstallationTimeSpan(deviceParams.installationDateTime);
		const tempRelay = deviceParams.temperatureFaultRelay;

		const fanspeed = deviceParams.blowerSpeed;
		const alarm1c =
			selectedDeviceRef.current.deviceCountryCode ===
			getCountryDescription(Country.CHINA)
				? LatchedMode.eLatched
				: deviceParams.alarmLatched;
		const alarm2c =
			selectedDeviceRef.current.deviceCountryCode ===
			getCountryDescription(Country.CHINA)
				? LatchedMode.eLatched
				: deviceParams.alarm2Latched;
		const generalfaultc = deviceParams.generalFaultLatched;
		const auxfaultc = deviceParams.auxFaultLatched;
		const alamm = deviceParams.deviceAlarmMode;

		setSelectedObscurationUnit(ObscurationUnit.Alarm);
		//#endregion

		//#region General Parameters

		generalClearErrors();
		generalSetValue('selectedDate', deviceParams.installationDateTime);
		generalSetValue('selectedTime', deviceParams.installationDateTime);
		generalSetValue('TrendLogInterval', deviceParams.trendLogDisabled);
		generalSetValue(
			'isTemparatureFaultSetRelays',
			deviceParams.temperatureFaultRelay === RelayAlert.eSet
				? 1
				: deviceParams.temperatureFaultRelay === RelayAlert.eUnset
				? 0
				: 2,
		);

		setGpiInputState(
			deviceParams.gpInputState === ExternalInputMode.eUnbalanced_Open_or_Short
				? 1
				: deviceParams.gpInputState ===
				  ExternalInputMode.eBalanced_Open_or_Short_eol
				? 0
				: 1,
		);
		setGpiNormalState(deviceParams.externalInputNormalState);
		setUnbalancedEventTriggered(deviceParams.unbalancedEventTriggered);
		setEventTriggerOnClose(deviceParams.externalTriggerOnClosed);
		setEventTriggerOnOpen(deviceParams.externalTriggerOnOpen);

		if (
			fanspeed === FanSpeedLevel.eLevel_1 ||
			fanspeed === FanSpeedLevel.eLevel_2 ||
			fanspeed === FanSpeedLevel.eLevel_3 ||
			fanspeed === FanSpeedLevel.eLevel_4 ||
			fanspeed === FanSpeedLevel.eLevel_5 ||
			fanspeed === FanSpeedLevel.eLevel_6
		) {
			generalSetValue('blowerSpeed', 0);
		} else {
			generalSetValue('blowerSpeed', 1);
		}
		generalSetValue('blowerCorrection', deviceParams.blowerCorrection);

		//#endregion

		//#region Channel and Sensors Parameters
		csClearErrors();
		csSetValue('FlowFaultDelay', deviceParams.flowFaultDelay);
		//TODO: Enable Alarm1 and Alarm2 configuration if it can be configured from BT APP
		// if (alarm1c === LatchedMode.eLatched) {
		// 	csSetValue('Alarm1Configuration', 0);
		// } else if (alarm1c === LatchedMode.eUnlatched) {
		// 	csSetValue('Alarm1Configuration', 1);
		// }
		// if (alarm2c === LatchedMode.eLatched) {
		// 	csSetValue('Alarm2Configuration', 0);
		// } else if (alarm2c === LatchedMode.eUnlatched) {
		// 	csSetValue('Alarm2Configuration', 1);
		// }
		if (generalfaultc === LatchedMode.eLatched) {
			csSetValue('GeneralFaultConfiguration', 0);
		} else if (generalfaultc === LatchedMode.eUnlatched) {
			csSetValue('GeneralFaultConfiguration', 1);
		}
		if (auxfaultc === LatchedMode.eLatched) {
			csSetValue('AuxFaultConfiguration', 0);
		} else if (auxfaultc === LatchedMode.eUnlatched) {
			csSetValue('AuxFaultConfiguration', 1);
		}
		if (alamm === AlarmMode.eUp_InstantFire) {
			csSetValue('AlarmMode', 0);
		} else if (alamm === AlarmMode.eDown_Cumulative) {
			csSetValue('AlarmMode', 1);
		}
		csSetValue('Referenceflow1', deviceParams.referenceFlowCh1);
		csSetValue('FlowFaultThresholdValue', deviceParams.flowFaultThresholdCh1);
		csSetValue(
			'FlowFaultThreshold',
			deviceParams.flowFaultThresholdCh1 === 15 ? 0 : 1,
		);
		csSetValue('Referenceflow2', deviceParams.referenceFlowCh2);
		//#endregion
	}
	//#endregion

	//#region Sync Parameters
	async function SyncCommandAsync() {
		let syncAnswer = true;
		if (!IsRealConfigOutOfBox) {
			syncAnswer = await confirmAlert(
				t('ResetDeviceConfirmation'),
				t('Reset Device'),
				t('Yes_UpperCase'),
				t('cancel'),
			);
		}
		if (syncAnswer) {
			await getDeviceConfig();
			if (isGeneralParameterVisible) {
				await GetGPIParametersFromDevice();
				await GetGeneralParametersFromDevice();
			} else {
				await GetChannelSensorsfromDevice();
			}
		}
	}
	async function getDeviceConfig() {
		let deviceConfig =
			await faastflexBluetoothCommunicator.GetDeviceConfiguration(
				DeviceType.eIntelligent,
			);
		if (isNotAllowedCommandError(deviceConfig.error)) {
			//Handle Error
		}
		setDeviceConfig(t(getConfigurationDescription(deviceConfig.devconfig)));
		if (deviceConfig.devconfig === Configuration.Extended) {
			setIsEnabledConfig(true);
		} else {
			setIsEnabledConfig(false);
		}
		if (deviceConfig.devconfig === Configuration.OutOfTheBox) {
			setIsRealConfigOutOfBox(true);
		} else {
			setIsRealConfigOutOfBox(false);
		}
	}
	//#endregion

	//#region Timer
	async function startTimerForTimeout() {
		// Clear any existing timer first
		if (timeoutTimerRef.current) {
			clearTimeout(timeoutTimerRef.current);
		}
		timeoutTimerRef.current = setTimeout(() => {
			setShowTimeOutScreen();
		}, 30 * 60 * 1000); // 30 minutes
	}
	function setShowTimeOutScreen() {
		setShowTimeoutPopup(true);
	}

	function handleCloseTimeoutMessage() {
		setShowTimeoutPopup(false);
	}
	//#endregion

	//#region Get Device Params

	function isNotAllowedCommandError(error: ErrorCode): boolean {
		return error === ErrorCode.eGCL_NOT_ALLOWED_COMMAND;
	}

	async function GetGPIParametersFromDevice() {
		try {
			if (
				selectedDeviceRef.current?.isDeviceConnected &&
				(await GetDeviceFirmware())
			) {
				showLoadingIndicator(t('LoadingGeneralDeviceParam'));
				if (IsRealConfigOutOfBox) {
					setGpiInputState(0);
					setUnbalancedEventTriggered(ExternalInputAction.eResetAlarmAndFault);
					setGpiNormalState(ExternalInputNormalState.eOpen);

					deviceParameters.current = {
						...deviceParameters.current,
						GPInputState: ExternalInputMode.eUnbalanced_Open_or_Short,
						ExternalInputNormalState: ExternalInputNormalState.eOpen,
						UnbalancedEventTriggered: ExternalInputAction.eResetAlarmAndFault,
					} as DeviceParametersModel;
					return;
				}
				var deviceGPIParams = new DeviceGPIParams();
				let gpiFetchResult =
					await faastflexBluetoothCommunicator.GetDeviceGPIParams();
				if (gpiFetchResult && gpiFetchResult.error !== ErrorCode.eOK) {
					console.log('Retrying to fetch GPI Parameters from device...');
					await delay(500);
					gpiFetchResult =
						await faastflexBluetoothCommunicator.GetDeviceGPIParams();
				}
				if (gpiFetchResult) {
					deviceGPIParams = {
						...deviceGPIParams,
						...gpiFetchResult.gpiParams,
					};
				}
				if (deviceGPIParams && gpiFetchResult.error === ErrorCode.eOK) {
					setIsGPIEnabledConfig(true);

					setGpiInputState(
						deviceGPIParams.GPIExternalInput ===
							ExternalInputMode.eUnbalanced_Open_or_Short
							? 0
							: deviceGPIParams.GPIExternalInput ===
							  ExternalInputMode.eBalanced_Open_or_Short_eol
							? 1
							: 0,
					);
					const gpiState =
						deviceGPIParams.GPIExternalInput ===
						ExternalInputMode.eUnbalanced_Open_or_Short
							? false
							: deviceGPIParams.GPIExternalInput ===
							  ExternalInputMode.eBalanced_Open_or_Short_eol
							? true
							: false;
					deviceParameters.current = {
						...deviceParameters.current,
						gpInputState: deviceGPIParams.GPIExternalInput,
						gpiState: gpiState,
					};
					if (
						deviceGPIParams.GPIExternalInput ==
						ExternalInputMode.eUnbalanced_Open_or_Short
					) {
						setGpiInputState(0);
						setGpiNormalState(deviceGPIParams.UnSupervisedNormalState);
						setUnbalancedEventTriggered(
							deviceGPIParams.UnSupervisedEventTriggered,
						);
					} else if (
						deviceGPIParams.GPIExternalInput ==
						ExternalInputMode.eBalanced_Open_or_Short_eol
					) {
						setGpiInputState(1);
						setEventTriggerOnClose(
							deviceGPIParams.SupervisedExternalTriggerOnClosed,
						);
						setEventTriggerOnOpen(
							deviceGPIParams.SupervisedExternalTriggerOnOpen,
						);
					}
					deviceParameters.current = {
						...deviceParameters.current,
						externalInputNormalState: deviceGPIParams.UnSupervisedNormalState,
						unbalancedEventTriggered:
							deviceGPIParams.UnSupervisedEventTriggered,
						externalTriggerOnClosed:
							deviceGPIParams.SupervisedExternalTriggerOnClosed,
						externalTriggerOnOpen:
							deviceGPIParams.SupervisedExternalTriggerOnOpen,
					};
				} else {
					Toast.show({
						type: 'error',
						text1: t(
							'Unable to fetch GPI Input data from the device, Please check and retry',
						),
						position: 'bottom',
					});
					setIsGPIEnabledConfig(false);
				}
			}
		} catch (error) {
			Toast.show({
				type: 'error',
				text1: t(
					'Unable to fetch GPI Input data from the device, Please check and retry',
				),
				position: 'bottom',
			});
			setIsGPIEnabledConfig(false);
		}
	}

	async function GetGeneralParametersFromDevice() {
		if (selectedDeviceRef.current?.isDeviceConnected) {
			//TODO: Loading indicator fetching general parameters from the device
			//TODO : Translate all text
			var result =
				await faastflexBluetoothCommunicator.GetFFIDeviceGeneralParams();
			var generalParamsData = result?.generalParams;

			var deviceOrientation =
				getDeviceOrientationDescription(generalParamsData?.DeviceOrientation) ||
				'';
			generalSetValue('Orientation', deviceOrientation);
			setDeviceOrientation(deviceOrientation);
			if (isNotAllowedCommandError(result.error)) {
				setShowTimeOutScreen();
				return;
			} else {
				setSelectedDevice({
					deviceOrientation: deviceOrientation,
				});
			}

			if (isNotAllowedCommandError(result.error)) {
				setShowTimeOutScreen();
				return;
			} else {
				if (generalParamsData?.DeviceDateTime) {
					const deviceDateTime = new Date(generalParamsData.DeviceDateTime);
					const installationDate = new Date(
						deviceDateTime.getFullYear(),
						deviceDateTime.getMonth(),
						deviceDateTime.getDate(),
						deviceDateTime.getHours(),
						deviceDateTime.getMinutes(),
						deviceDateTime.getSeconds(),
					);
					generalSetValue('selectedDate', installationDate);
					generalSetValue('selectedTime', installationDate);
					deviceParameters.current = {
						...deviceParameters.current,
						installationDate: installationDate,
						installationDateTime: installationDate,
					} as DeviceParametersModel;
				}
			}

			var trendLogDisabled = generalParamsData?.Trendlog;
			if (isNotAllowedCommandError(result.error)) {
				setShowTimeOutScreen();
				return;
			} else {
				generalSetValue('TrendLogInterval', trendLogDisabled, {
					shouldValidate: true,
				});
				deviceParameters.current = {
					...deviceParameters.current,
					trendLogDisabled: trendLogDisabled,
				} as DeviceParametersModel;
			}

			var tempRelay = generalParamsData?.TempRelay;
			if (isNotAllowedCommandError(result.error)) {
				setShowTimeOutScreen();
				return;
			} else {
				deviceParameters.current = {
					...deviceParameters.current,
					temperatureFaultRelay: tempRelay,
				} as DeviceParametersModel;
				var value = tempRelay == RelayAlert.eSet ? 0 : 1;
				generalSetValue('isTemparatureFaultSetRelays', value);
			}

			var blwrSpeed = generalParamsData?.BlowerSpeedLevel;
			if (isNotAllowedCommandError(result.error)) {
				setShowTimeOutScreen();
				return;
			} else {
				deviceParameters.current = {
					...deviceParameters.current,
					blowerSpeed: blwrSpeed,
				} as DeviceParametersModel;
				if (blwrSpeed == FanSpeedLevel.eLevel_2) {
					generalSetValue('blowerSpeed', 0);
				} else if (blwrSpeed == FanSpeedLevel.eLevel_4) {
					generalSetValue('blowerSpeed', 1);
				} else {
					generalSetValue('blowerSpeed', 1);
				}
			}

			var blowerCorrection = generalParamsData?.BlowerSpeedCorrection;
			const blowerCorrectionMin =
				getFanPWMPercCorrectionDescription(blowerCorrection);
			if (isNotAllowedCommandError(result.error)) {
				setShowTimeOutScreen();
				return;
			} else {
				generalSetValue('blowerCorrection', blowerCorrectionMin);
				deviceParameters.current = {
					...deviceParameters.current,
					blowerCorrection: blowerCorrectionMin,
				} as DeviceParametersModel;
			}

			generalTrigger();
			hideLoadingIndicator();
		}
	}

	async function GetChannelSensorsfromDevice() {
		showLoadingIndicator(t('LoadingChannelsAndSensorsDetails'));
		if (selectedDeviceRef.current?.isDeviceConnected) {
			var result =
				await faastflexBluetoothCommunicator.GetFFIDeviceChannelsAndSensorsParams();
			var channelAndSensorsData = result?.channelAndSensorParams;
			setIsChannel1Visible(true);
			setIsChannel2Visible(false);

			var selectedFlowFaultDelay =
				parseInt(channelAndSensorsData?.flowFaultDelay) || 0;
			if (isNotAllowedCommandError(result.error)) {
				setShowTimeOutScreen();
				return;
			} else {
				csSetValue('FlowFaultDelay', selectedFlowFaultDelay, {
					shouldValidate: true,
				});
				deviceParameters.current = {
					...deviceParameters.current,
					flowFaultDelay: selectedFlowFaultDelay,
				} as DeviceParametersModel;
			}

			//TODO: Enable Alarm1 and Alarm2 configuration if it can be configured from BT APP
			// var alarm1Latched = channelAndSensorsData?.alarmLatched;
			// if (isNotAllowedCommandError(result.error)) {
			// 	setShowTimeOutScreen();
			// 	return;
			// } else {
			// 	if (
			// 		selectedDevice.deviceCountryCode ===
			// 		getCountryDescription(Country.CHINA)
			// 	) {
			// 		alarm1Latched = LatchedMode.eLatched;
			// 		setIsChineseDevice(true);
			// 	} else {
			// 		setIsChineseDevice(false);
			// 		// continue with the fetched value
			// 	}
			// 	deviceParameters.current = {
			// 		...deviceParameters.current,
			// 		alarmLatched: alarm1Latched,
			// 	} as DeviceParametersModel;
			// 	var value = alarm1Latched == LatchedMode.eLatched ? 0 : 1;
			// 	csSetValue('Alarm1Configuration', value);
			// }

			// var alarm2Latched = channelAndSensorsData?.alarm2Latched;
			// if (isNotAllowedCommandError(result.error)) {
			// 	setShowTimeOutScreen();
			// 	return;
			// } else {
			// 	if (
			// 		selectedDeviceRef.current?.deviceCountryCode ===
			// 		getCountryDescription(Country.CHINA)
			// 	) {
			// 		alarm1Latched = LatchedMode.eLatched;
			// 	} else {
			// 		// continue with the fetched value
			// 	}
			// 	deviceParameters.current = {
			// 		...deviceParameters.current,
			// 		alarm2Latched: alarm2Latched,
			// 	} as DeviceParametersModel;
			// 	var value = alarm2Latched == LatchedMode.eLatched ? 0 : 1;
			// 	csSetValue('Alarm2Configuration', value);
			// }

			var generalfaultLatched = channelAndSensorsData?.generalFaultLatched;
			if (isNotAllowedCommandError(result.error)) {
				setShowTimeOutScreen();
				return;
			} else {
				deviceParameters.current = {
					...deviceParameters.current,
					generalFaultLatched: generalfaultLatched,
				} as DeviceParametersModel;
				var value = generalfaultLatched == LatchedMode.eLatched ? 0 : 1;
				csSetValue('GeneralFaultConfiguration', value);
			}

			var auxfaultLatched = channelAndSensorsData?.auxFaultLatched;
			if (isNotAllowedCommandError(result.error)) {
				setShowTimeOutScreen();
				return;
			} else {
				deviceParameters.current = {
					...deviceParameters.current,
					auxFaultLatched: auxfaultLatched,
				} as DeviceParametersModel;
				var value = auxfaultLatched == LatchedMode.eLatched ? 0 : 1;
				csSetValue('AuxFaultConfiguration', value);
			}

			// var alarmMode = channelAndSensorsData?.alarmMode;
			// if (isNotAllowedCommandError(result.error)) {
			//     setShowTimeOutScreen();
			//     return;
			// }
			// else {

			//     deviceParameters.current = { ...deviceParameters.current, deviceAlarmMode: alarmMode } as DeviceParametersModel;
			//     var value = alarmMode == AlarmMode.eUp_InstantFire ? 0 : 1;
			//     csSetValue('AlarmMode', value);
			// }

			var flowFaultThreshold: number =
				channelAndSensorsData?.ch1FlowFaultThreshold;
			if (isNotAllowedCommandError(result.error)) {
				setShowTimeOutScreen();
				return;
			} else {
				var type = flowFaultThreshold <= 21 ? 0 : 1;
				var value = type === 0 ? 15 : flowFaultThreshold;
				deviceParameters.current = {
					...deviceParameters.current,
					flowFaultThresholdCh1: value,
				} as DeviceParametersModel;
				csSetValue('FlowFaultThreshold', type);
				csSetValue('FlowFaultThresholdValue', value);
			}

			var selectedReferenceFlowCh1: number =
				channelAndSensorsData?.ch1RefAirflow;
			if (isNotAllowedCommandError(result.error)) {
				setShowTimeOutScreen();
				return;
			} else {
				deviceParameters.current = {
					...deviceParameters.current,
					referenceFlowCh1: selectedReferenceFlowCh1,
				} as DeviceParametersModel;
				csSetValue('Referenceflow1', selectedReferenceFlowCh1);
			}
			var selectedReferenceFlowCh2: number =
				channelAndSensorsData?.ch2RefAirflow;
			if (isNotAllowedCommandError(result.error)) {
				setShowTimeOutScreen();
				return;
			} else {
				deviceParameters.current = {
					...deviceParameters.current,
					referenceFlowCh2: selectedReferenceFlowCh2,
				} as DeviceParametersModel;
				csSetValue('Referenceflow2', selectedReferenceFlowCh2);
			}
			csTrigger();
			hideLoadingIndicator();
		}
	}
	//#endregion

	//#region Save Params to Device
	const onSaveParamsPressed = () => {
		saveParametersToDevice();
	};
	async function saveParametersToDevice(isFromTabSelection: boolean = false) {
		try {
			if (
				ConnectedDeviceobj.current !== null &&
				selectedDeviceRef.current?.isDeviceConnected
			) {
				ClearGeneralParamsSaveFailedErrors();
				ClearChannelsandSensorsSaveFailedErrors();
				var generalparameterCount = 0;
				var channelAndSensorParamCount = 0;

				if (isGeneralParameterVisible) {
					var isGeneralParamsValid = await ValidateGeneralParams('');
					if (isGeneralParamsValid) {
						const resultCount = isGeneralParametersChanged();

						//TODO Translate
						const shouldSave =
							selectedDevice?.deviceMacAddress !== 'Not Connected yet' &&
							!selectedDevice.isDeviceConnected
								? false
								: resultCount.hasChanges
								? await confirmAlert(
										stringFormat(
											t('SaveGeneralParameterconfirmation'),
											resultCount.count.toString(),
										),
										t('SaveGeneral'),
										t('save'),
										t('cancel'),
								  )
								: false;

						if (shouldSave) {
							showLoadingIndicator(t('SyncingDeviceParams'));
							if (ConnectedDeviceobj.current !== null) {
								generalParams = [];
								retryGeneralParams = [];
								const selectedDate = generalWatch('selectedDate');
								const selectedTime = generalWatch('selectedTime');
								if (selectedDate !== null) {
									const installDate = new Date(
										selectedDate.getFullYear(),
										selectedDate.getMonth(),
										selectedDate.getDate(),
										selectedTime.getHours(),
										selectedTime.getMinutes(),
										selectedTime.getSeconds(),
									);
									selectedInstallationDateRef.current = installDate;
									if (
										deviceParameters.current.installationDate?.getTime() !==
										installDate.getTime()
									) {
										generalParams.push(FF_DateTime);
									}
								}

								if (IsEnabledConfig) {
									const trendLogInterval = generalWatch('TrendLogInterval');
									if (
										deviceParameters.current.trendLogDisabled !==
										trendLogInterval
									) {
										generalParams.push(FF_TrendLogDisabled);
									}
									const isTemparatureFaultSetRelays = generalWatch(
										'isTemparatureFaultSetRelays',
									);
									var tempRelay =
										isTemparatureFaultSetRelays === 0
											? RelayAlert.eSet
											: RelayAlert.eUnset;
									setTempFaultRelay(tempRelay);
									if (
										deviceParameters.current.temperatureFaultRelay !== tempRelay
									) {
										//&& tempRelay !== RelayAlert.eUnknown
										generalParams.push(FF_TemperatureFaultRelay);
									}

									if (IsGPIVisible && IsGPIEnabledConfig) {
										if (gpiInputState) {
											if (
												deviceParameters.current.gpInputState !==
												ExternalInputMode.eBalanced_Open_or_Short_eol
											) {
												generalParams.push(FF_GPIInputStateSupervised);
											}
											if (
												deviceParameters.current.externalTriggerOnOpen !==
												eventTriggerOnOpen
											) {
												generalParams.push(FF_ExternalTriggerOnOpen);
											}
											if (
												deviceParameters.current.externalTriggerOnClosed !==
												eventTriggerOnClose
											) {
												generalParams.push(FF_ExternalTriggerOnClosed);
											}
										} else {
											if (
												deviceParameters.current.gpInputState !==
												ExternalInputMode.eUnbalanced_Open_or_Short
											) {
												generalParams.push(FF_GPIInputStateUnSupervised);
											}
											if (
												deviceParameters.current.externalInputNormalState !==
												gpiNormalState
											) {
												generalParams.push(FF_ExternalInputNormalState);
											}
											if (
												deviceParameters.current.unbalancedEventTriggered !==
												unbalancedEventTriggered
											) {
												generalParams.push(FF_UnbalancedEventTriggered);
											}
										}
									}
									const blowerCorrection = generalWatch('blowerSpeed');
									var tempFanSpeed =
										blowerCorrection === 0
											? FanSpeedLevel.eLevel_2
											: FanSpeedLevel.eLevel_4;
									if (deviceParameters.current.blowerSpeed !== tempFanSpeed) {
										//TODO && tempFanSpeed !== FanSpeedLevel.eUnknown
										generalParams.push(FF_BlowerSpeed);
									}
								}
								if (generalParams === null || generalParams.length <= 0) {
									hideLoadingIndicator();
									Toast.show({
										type: 'info',
										text2: t('nodatachanged'),
										position: 'bottom',
									});
									return;
								}

								const results: boolean[] = [];
								for (const paramName of generalParams) {
									const success = await saveGeneralParametersToDevice(
										paramName,
									);
									results.push(success);

									if (!success) {
										retryGeneralParams.push(paramName);
									}

									await delay(100);
								}
								await delay(100);
								if (retryGeneralParams.length > 0) {
									const retryResults: boolean[] = [];
									const stillretryGeneralParams: string[] = [];

									for (const paramName of retryGeneralParams) {
										console.log(`[SaveParams] Retrying: ${paramName}`);
										const success = await saveGeneralParametersToDevice(
											paramName,
										);
										retryResults.push(success);

										if (!success) {
											stillretryGeneralParams.push(paramName);
										}

										await delay(100);
									}
									hideLoadingIndicator();

									if (stillretryGeneralParams.length === 0) {
										generalClearErrors();
										Toast.show({
											type: 'success',
											text2: t('SyncingDeviceParamsSuccess'),
											position: 'bottom',
										});
									} else {
										Toast.show({
											type: 'error',
											text2: t('SyncingDeviceGeneralParamsFailed'),
											position: 'bottom',
										});
									}
								} else {
									hideLoadingIndicator();
									generalClearErrors();
									Toast.show({
										type: 'success',
										text2: t('SyncingDeviceParamsSuccess'),
										position: 'bottom',
									});
								}
							}
						}
						if (isFromTabSelection) {
							setIsGeneralParameterVisible(false);
							setIsChannelsAndSensorsVisible(true);
						}
					}
					setImportConfiginProgress(false);
				} else if (isChannelsAndSensorsVisible) {
					var isVaidChannels = await ValidateChannelAndSensorParams('');
					if (isVaidChannels) {
						const resultCount = isChannelSensorParametersChanged();

						//TODO Translate
						const shouldSave =
							selectedDevice?.deviceMacAddress !== 'Not Connected yet' &&
							!selectedDevice.isDeviceConnected
								? false
								: resultCount.hasChanges
								? await confirmAlert(
										stringFormat(
											t('Savechannelsensorconfirmation'),
											resultCount.count.toString(),
										),
										t('Savechannelsensor'),
										t('save'),
										t('cancel'),
								  )
								: false;

						if (shouldSave) {
							showLoadingIndicator(t('SyncingDeviceParams'));
							if (ConnectedDeviceobj.current !== null) {
								channelsAndSensorsParams = [];
								retryChannelsAndSensorsParams = [];

								const flowFaultDelay = csWatch('FlowFaultDelay');
								if (
									deviceParameters.current.flowFaultDelay !== flowFaultDelay
								) {
									channelsAndSensorsParams.push(FF_FlowFaultDelay);
								}

								//TODO: Enable Alarm1 and Alarm2 configuration if it can be configured from BT APP
								// const alarm1Config = csWatch('Alarm1Configuration');
								// var tempAlarmLatchMode =
								// 	alarm1Config === 0
								// 		? LatchedMode.eLatched
								// 		: LatchedMode.eUnlatched;
								// setAlarmLatchMode(tempAlarmLatchMode);
								// if (deviceParameters.current.alarmLatched !== tempAlarmLatchMode) {
								// 	//TODO && tempAlarmLatchMode !== LatchedMode.eUnknown
								// 	channelsAndSensorsParams.push(FF_Alarm1Latched);
								// }
								// if (IsChannel2Available) {
								// 	const alarm2Config = csWatch('Alarm2Configuration');
								// 	var tempPreAlarmLatchMode =
								// 		alarm2Config === 0
								// 			? LatchedMode.eLatched
								// 			: LatchedMode.eUnlatched;
								// 	setAlarmLatchMode(tempPreAlarmLatchMode);
								// 	if (
								// 		deviceParameters.current.alarm2Latched !==
								// 		tempPreAlarmLatchMode
								// 	) {
								// 		//TODO && tempPreAlarmLatchMode !== LatchedMode.eUnknown
								// 		channelsAndSensorsParams.push(FF_Alarm2Latched);
								// 	}
								// }

								const genfaultConfig = csWatch('GeneralFaultConfiguration');
								var tempGenFaultLatchMode =
									genfaultConfig === 0
										? LatchedMode.eLatched
										: LatchedMode.eUnlatched;
								setFaultLatchMode(tempGenFaultLatchMode);
								if (
									deviceParameters.current.faultLatched !==
									tempGenFaultLatchMode
								) {
									//TODO && tempFaultLatchMode !== LatchedMode.eUnknown
									channelsAndSensorsParams.push(FF_GeneralFaultLatched);
								}

								const auxfaultConfig = csWatch('AuxFaultConfiguration');
								var tempAuxFaultLatchMode =
									auxfaultConfig === 0
										? LatchedMode.eLatched
										: LatchedMode.eUnlatched;
								setFaultLatchMode(tempAuxFaultLatchMode);
								if (
									deviceParameters.current.faultLatched !==
									tempAuxFaultLatchMode
								) {
									//TODO && tempFaultLatchMode !== LatchedMode.eUnknown
									channelsAndSensorsParams.push(FF_AuxFaultLatched);
								}

								// const alarmMode = csWatch('AlarmMode');
								// var tempFFAlarmMode = alarmMode === 0 ? AlarmMode.eUp_InstantFire : alarmMode === 1 ? AlarmMode.eDown_Cumulative : AlarmMode.eUnknown;
								// setFFAlarmMode(tempFFAlarmMode);
								// if (deviceParameters.current.deviceAlarmMode !== tempFFAlarmMode && tempFFAlarmMode !== AlarmMode.eUnknown) {
								//     channelsAndSensorsParams.push(FF_AlarmMode);
								// }
								const FlowFaultThreshold = csWatch('FlowFaultThresholdValue');
								if (
									deviceParameters.current.flowFaultThresholdCh1 !==
									FlowFaultThreshold
								) {
									channelsAndSensorsParams.push(FF_FlowFaultThreshold);
								}

								if (
									channelsAndSensorsParams === null ||
									channelsAndSensorsParams.length <= 0
								) {
									hideLoadingIndicator();
									Toast.show({
										type: 'info',
										text2: t('nodatachanged'),
										position: 'bottom',
									});
									return;
								}

								const results: boolean[] = [];
								for (const paramName of channelsAndSensorsParams) {
									const success = await SaveChannelsAndSensorsToDevice(
										paramName,
									);
									results.push(success);

									if (!success) {
										retryChannelsAndSensorsParams.push(paramName);
									}

									// Small delay between operations for device processing
									await delay(100);
								}
								//  const result = await Promise.all(generalParams);

								await delay(100);

								if (retryChannelsAndSensorsParams.length > 0) {
									const retryResults: boolean[] = [];
									const stillretryChannelsAndSensorsParams: string[] = [];

									for (const paramName of retryChannelsAndSensorsParams) {
										console.log(`[SaveParams] Retrying: ${paramName}`);
										const success = await SaveChannelsAndSensorsToDevice(
											paramName,
										);
										retryResults.push(success);

										if (!success) {
											stillretryChannelsAndSensorsParams.push(paramName);
										}

										await delay(100);
									}
									hideLoadingIndicator();

									if (stillretryChannelsAndSensorsParams.length === 0) {
										generalClearErrors();
										Toast.show({
											type: 'success',
											text2: t('SyncingDeviceParamsSuccess'),
											position: 'bottom',
										});
									} else {
										Toast.show({
											type: 'error',
											text2: t('SyncingChannelsAndSensorsDataFailed'),
											position: 'bottom',
										});
									}
								} else {
									hideLoadingIndicator();
									generalClearErrors();
									Toast.show({
										type: 'success',
										text2: t('SyncingDeviceParamsSuccess'),
										position: 'bottom',
									});
								}
							}
						}
					}
					if (isFromTabSelection) {
						setIsGeneralParameterVisible(true);
						setIsChannelsAndSensorsVisible(false);
					}
				} else if (isSensorAddressVisible) {
					setIsSensorAddressVisible(false);
					setIsGeneralParameterVisible(true);
					setIsChannelsAndSensorsVisible(false);
				}
				deviceParameters.current = {
					...deviceParameters.current,
					deviceId: selectedDevice.deviceId,
					deviceName: selectedDevice.deviceName,
					channels: selectedDevice.channels,
				} as DeviceParametersModel;

				await dispatch(
					updateExistingDeviceParameter({
						dataSource,
						deviceId: selectedDevice.deviceId,
						updates: deviceParameters.current,
					}),
				);
			} else if (selectedDeviceRef.current?.isDeviceConnected === false) {
				if (isGeneralParameterVisible) {
					setIsGeneralParameterVisible(false);
					setIsChannelsAndSensorsVisible(true);
				} else {
					setIsGeneralParameterVisible(true);
					setIsChannelsAndSensorsVisible(false);
				}
			} else {
				Toast.show({
					type: 'success',
					text2: t('PlsConnectDevice'),
					position: 'bottom',
				});
			}
		} catch (error) {
			hideLoadingIndicator();
		}
	}

	async function saveGeneralParametersToDevice(
		paramName: string,
	): Promise<boolean> {
		try {
			switch (paramName) {
				case FF_DateTime:
					const dateTimeL = selectedInstallationDateRef.current;
					const year = dateTimeL.getFullYear() % 100;
					const month = dateTimeL.getMonth() + 1;
					const day = dateTimeL.getDate();
					const hours = dateTimeL.getHours();
					const minutes = dateTimeL.getMinutes();
					const seconds = dateTimeL.getSeconds();
					const dateTime =
						await faastflexBluetoothCommunicator.SetDatetimeofDevice(
							year,
							month,
							day,
							hours,
							minutes,
							seconds,
						);
					if (dateTime.isUpdated) {
						deviceParameters.current = {
							...deviceParameters.current,
							installationDate: selectedInstallationDateRef.current,
							installationDateTime: new Date(
								selectedInstallationTimeSpan.getHours(),
								selectedInstallationTimeSpan.getMinutes(),
								0,
							),
						} as DeviceParametersModel;
						return true;
					} else {
						setDeviceDateSaveFailed(true);
						if (dateTime.error === ErrorCode.eGCL_NOT_ALLOWED_COMMAND) {
							setShowTimeOutScreen();
						}
						return false;
					}

				case FF_TrendLogDisabled:
					const trendLogInterval = generalWatch('TrendLogInterval');
					const trendLogIntervalSeconds = trendLogInterval * 60;
					const trendLogMSB = (trendLogIntervalSeconds >> 8) & 0xff;
					const trendLogLSB = trendLogIntervalSeconds & 0xff;

					//const trendLogMSB = x % 256;
					//const trendLogLSB = Math.floor(x / 256);

					const trendlogResult =
						await faastflexBluetoothCommunicator.SetFFITrendlogDisabled(
							trendLogLSB,
							trendLogMSB,
						);
					if (trendlogResult.isUpdated) {
						deviceParameters.current = {
							...deviceParameters.current,
							trendLogDisabled: trendLogInterval,
						} as DeviceParametersModel;
						return true;
					} else {
						setTrendLogIntervalSaveFailed(true);
						if (trendlogResult.error === ErrorCode.eGCL_NOT_ALLOWED_COMMAND) {
							setShowTimeOutScreen();
						}
						return false;
					}

				case FF_TemperatureFaultRelay:
					const tempFaultRelay =
						generalWatch('isTemparatureFaultSetRelays') === 0
							? RelayAlert.eSet
							: RelayAlert.eUnset;
					const temperatureFaultRelayResult =
						await faastflexBluetoothCommunicator.SetTempFaultSetRelay(
							tempFaultRelay,
						);
					if (temperatureFaultRelayResult.isUpdated) {
						deviceParameters.current = {
							...deviceParameters.current,
							temperatureFaultRelay: tempFaultRelay,
						} as DeviceParametersModel;
						return true;
					} else {
						setTempFaultSetsRelaysSaveFailed(true);
						if (
							temperatureFaultRelayResult.error ===
							ErrorCode.eGCL_NOT_ALLOWED_COMMAND
						) {
							setShowTimeOutScreen();
						}
						return false;
					}

				case FF_GPIInputStateSupervised:
					const inputSupervised =
						await faastflexBluetoothCommunicator.SetExternalInput(
							ExternalInputMode.eBalanced_Open_or_Short_eol,
						);
					if (inputSupervised.isUpdated) {
						deviceParameters.current = {
							...deviceParameters.current,
							gpInputState: ExternalInputMode.eBalanced_Open_or_Short_eol,
							gpiState: true,
						} as DeviceParametersModel;
						return true;
					} else {
						setGPISaveFailed(true);
						if (inputSupervised.error === ErrorCode.eGCL_NOT_ALLOWED_COMMAND) {
							setShowTimeOutScreen();
						}
						return false;
					}

				case FF_ExternalTriggerOnOpen:
					// const eventTriggerOpened = generalWatch('eventTriggerOnOpen');
					const externalTriggerOnOpen =
						await faastflexBluetoothCommunicator.SetExternalTriggredOpen(
							eventTriggerOnOpen,
						);
					if (externalTriggerOnOpen.isUpdated) {
						deviceParameters.current = {
							...deviceParameters.current,
							externalTriggerOnOpen: eventTriggerOnOpen,
						} as DeviceParametersModel;
						return true;
					} else {
						setGPISaveFailed(true);
						if (
							externalTriggerOnOpen.error === ErrorCode.eGCL_NOT_ALLOWED_COMMAND
						) {
							setShowTimeOutScreen();
						}
						return false;
					}

				case FF_ExternalTriggerOnClosed:
					// const eventTriggeredOnClose = generalWatch('eventTriggerOnClose');
					const tempEventTriggeredOnClose =
						await faastflexBluetoothCommunicator.SetExternalTriggredClosed(
							eventTriggerOnClose,
						);
					if (tempEventTriggeredOnClose.isUpdated) {
						deviceParameters.current = {
							...deviceParameters.current,
							externalTriggerOnClosed: eventTriggerOnClose,
						} as DeviceParametersModel;
						return true;
					} else {
						setGPISaveFailed(true);
						if (
							tempEventTriggeredOnClose.error ===
							ErrorCode.eGCL_NOT_ALLOWED_COMMAND
						) {
							setShowTimeOutScreen();
						}
						return false;
					}

				case FF_GPIInputStateUnSupervised:
					const inputUnSupervised =
						await faastflexBluetoothCommunicator.SetExternalInput(
							ExternalInputMode.eUnbalanced_Open_or_Short,
						);
					if (inputUnSupervised.isUpdated) {
						deviceParameters.current = {
							...deviceParameters.current,
							gpInputState: ExternalInputMode.eUnbalanced_Open_or_Short,
							gpiState: true,
						} as DeviceParametersModel;
						return true;
					} else {
						setGPISaveFailed(true);
						if (
							inputUnSupervised.error === ErrorCode.eGCL_NOT_ALLOWED_COMMAND
						) {
							setShowTimeOutScreen();
						}
						return false;
					}

				case FF_ExternalInputNormalState:
					//const SelectedGPINormalState = generalWatch('gpiNormalState');
					const externalInputNormalState =
						await faastflexBluetoothCommunicator.SetExternalUnbalancedNormalState(
							gpiNormalState,
						);
					if (externalInputNormalState.isUpdated) {
						deviceParameters.current = {
							...deviceParameters.current,
							externalInputNormalState: gpiNormalState,
						} as DeviceParametersModel;
						return true;
					} else {
						setGPISaveFailed(true);
						if (
							externalInputNormalState.error ===
							ErrorCode.eGCL_NOT_ALLOWED_COMMAND
						) {
							setShowTimeOutScreen();
						}
						return false;
					}
				case FF_UnbalancedEventTriggered:
					//const unbalancedEventTriggered = generalWatch('unbalancedEventTriggered');
					const tempUnbalancedEventTriggered =
						await faastflexBluetoothCommunicator.SetExternalTriggredUnbalanced(
							unbalancedEventTriggered,
						);
					if (tempUnbalancedEventTriggered.isUpdated) {
						deviceParameters.current = {
							...deviceParameters.current,
							unbalancedEventTriggered: unbalancedEventTriggered,
						} as DeviceParametersModel;
						return true;
					} else {
						setGPISaveFailed(true);
						if (
							tempUnbalancedEventTriggered.error ===
							ErrorCode.eGCL_NOT_ALLOWED_COMMAND
						) {
							setShowTimeOutScreen();
						}
						return false;
					}

				case FF_BlowerSpeed:
					const blowerCorrection =
						generalWatch('blowerSpeed') === 0
							? FanSpeedLevel.eLevel_2
							: FanSpeedLevel.eLevel_4;
					const blowerSpeed =
						await faastflexBluetoothCommunicator.SetBlowerSpeed(
							blowerCorrection,
						);
					if (blowerSpeed.isUpdated) {
						deviceParameters.current = {
							...deviceParameters.current,
							blowerSpeed: blowerCorrection,
						} as DeviceParametersModel;
						return true;
					} else {
						setAspiratorSpeedSaveFailed(true);
						if (blowerSpeed.error === ErrorCode.eGCL_NOT_ALLOWED_COMMAND) {
							setShowTimeOutScreen();
						}
						return false;
					}
				default:
					return false;
			}
		} catch (error) {
			return false;
		}
	}

	async function SaveChannelsAndSensorsToDevice(
		paramName: string,
	): Promise<boolean> {
		try {
			switch (paramName) {
				case FF_FlowFaultDelay:
					const flowFaultDelay = csWatch('FlowFaultDelay');
					const flowFaultDelayResult =
						await faastflexBluetoothCommunicator.SetFlowFaultDelay(
							flowFaultDelay,
						);
					if (flowFaultDelayResult.isUpdated) {
						deviceParameters.current = {
							...deviceParameters.current,
							flowFaultDelay: flowFaultDelay,
						} as DeviceParametersModel;
						return true;
					} else {
						setFlowFaultDelaySaveFailed(true);
						if (
							flowFaultDelayResult.error === ErrorCode.eGCL_NOT_ALLOWED_COMMAND
						) {
							setShowTimeOutScreen();
						}
						return false;
					}

				//TODO: Enable Alarm1 and Alarm2 configuration if it can be configured from BT APP
				// case FF_Alarm1Latched:
				// 	const alarm1Config =
				// 		csWatch('Alarm1Configuration') === 0
				// 			? LatchedMode.eLatched
				// 			: LatchedMode.eUnlatched;
				// 	const alarm1LatchedResult =
				// 		await faastflexBluetoothCommunicator.FFI_SetAlarmLatched(
				// 			alarm1Config,
				// 			Channel.Channel1,
				// 		);
				// 	if (alarm1LatchedResult.isUpdated) {
				// 		deviceParameters.current = {
				// 			...deviceParameters.current,
				// 			alarmLatched: alarm1Config,
				// 		} as DeviceParametersModel;
				// 		return true;
				// 	} else {
				// 		setAlarm1ConfigSaveFailed(true);
				// 		if (
				// 			alarm1LatchedResult.error === ErrorCode.eGCL_NOT_ALLOWED_COMMAND
				// 		) {
				// 			setShowTimeOutScreen();
				// 		}
				// 		return false;
				// 	}

				// case FF_Alarm2Latched:
				// 	const alarm2Config =
				// 		csWatch('Alarm2Configuration') === 0
				// 			? LatchedMode.eLatched
				// 			: LatchedMode.eUnlatched;
				// 	const alarm2LatchedResult =
				// 		await faastflexBluetoothCommunicator.FFI_SetAlarmLatched(
				// 			alarm2Config,
				// 			Channel.Channel2,
				// 		);
				// 	if (alarm2LatchedResult.isUpdated) {
				// 		deviceParameters.current = {
				// 			...deviceParameters.current,
				// 			alarmLatched: alarm2Config,
				// 		} as DeviceParametersModel;
				// 		return true;
				// 	} else {
				// 		setAlarm2ConfigSaveFailed(true);
				// 		if (
				// 			alarm2LatchedResult.error === ErrorCode.eGCL_NOT_ALLOWED_COMMAND
				// 		) {
				// 			setShowTimeOutScreen();
				// 		}
				// 		return false;
				// 	}

				case FF_GeneralFaultLatched:
					const generalFault =
						csWatch('GeneralFaultConfiguration') === 0
							? LatchedMode.eLatched
							: LatchedMode.eUnlatched;
					const generalFaultResult =
						await faastflexBluetoothCommunicator.FFI_SetGeneralFaultLatched(
							generalFault,
						);
					if (generalFaultResult.isUpdated) {
						deviceParameters.current = {
							...deviceParameters.current,
							faultLatched: generalFault,
						} as DeviceParametersModel;
						return true;
					} else {
						setGeneralFaultConfigSaveFailed(true);
						if (
							generalFaultResult.error === ErrorCode.eGCL_NOT_ALLOWED_COMMAND
						) {
							setShowTimeOutScreen();
						}
						return false;
					}

				case FF_AuxFaultLatched:
					const auxFault =
						csWatch('AuxFaultConfiguration') === 0
							? LatchedMode.eLatched
							: LatchedMode.eUnlatched;
					const auxFaultResult =
						await faastflexBluetoothCommunicator.FFI_SetAuxFaultLatched(
							auxFault,
						);
					if (auxFaultResult.isUpdated) {
						deviceParameters.current = {
							...deviceParameters.current,
							faultLatched: auxFault,
						} as DeviceParametersModel;
						return true;
					} else {
						setGeneralFaultConfigSaveFailed(true);
						if (auxFaultResult.error === ErrorCode.eGCL_NOT_ALLOWED_COMMAND) {
							setShowTimeOutScreen();
						}
						return false;
					}

				// case FF_AlarmMode:
				//     const alarmMode = csWatch('AlarmMode') === 0 ? AlarmMode.eUp_InstantFire : AlarmMode.eDown_Cumulative;
				//     const alarmModeResult = await faastflexBluetoothCommunicator.SetAlarmMode(alarmMode);
				//     if (alarmModeResult.isUpdated) {
				//         deviceParameters.current = { ...deviceParameters.current, deviceAlarmMode: alarmMode } as DeviceParametersModel;
				//         return true;
				//     }
				//     else {
				//         setAlarmModeSaveFailed(true);
				//         if (alarmModeResult.error === ErrorCode.eGCL_NOT_ALLOWED_COMMAND) {
				//             setShowTimeOutScreen();
				//         }
				//         return false;
				//     }

				case FF_FlowFaultThreshold:
					const flowFaultThreshold: number = csWatch(
						'FlowFaultThresholdValue',
					) as number;
					const flowFault = flowFaultThreshold < 21 ? 128 : flowFaultThreshold;
					const flowFaultThreshold1Result =
						await faastflexBluetoothCommunicator.SetFFIFlowFaultThreshold(
							flowFault,
						);
					if (flowFaultThreshold1Result.isUpdated) {
						deviceParameters.current = {
							...deviceParameters.current,
							flowFaultThresholdCh1: flowFaultThreshold,
						} as DeviceParametersModel;
						return true;
					} else {
						setFlowFaultThresholdSaveFailed(true);
						if (
							flowFaultThreshold1Result.error ===
							ErrorCode.eGCL_NOT_ALLOWED_COMMAND
						) {
							setShowTimeOutScreen();
						}
						return false;
					}
				default:
					return false;
			}
		} catch (error) {
			console.log('Error in saving general parameters', error);
			return false;
		}
	}

	const isGeneralParametersChanged = (): {
		hasChanges: boolean;
		count: number;
	} => {
		let hasChanges = false;
		let generalparameterCount = 0;
		var deviceTime = deviceParameters.current.installationDate.toTimeString();
		var selectedTime = generalWatch('selectedTime').toTimeString();

		if (
			!!selectedDevice?.firmwareVersion &&
			parseInt(selectedDevice?.firmwareVersion?.split('.')[0] || '0') >= 4
		) {
			const extinputmode = gpiInputState === 1;
			const isSupervised = extinputmode;

			if (deviceParameters.current.gpiState !== extinputmode) {
				generalparameterCount++;
			}

			if (isSupervised) {
				//Check supervised input changes
				generalparameterCount +=
					deviceParameters.current.externalTriggerOnOpen !==
						eventTriggerOnOpen &&
					deviceParameters.current.externalTriggerOnOpen !==
						ExternalInputAction.eUnknown
						? 1
						: 0;
				generalparameterCount +=
					deviceParameters.current.externalTriggerOnClosed !==
						eventTriggerOnClose &&
					deviceParameters.current.externalTriggerOnClosed !==
						ExternalInputAction.eUnknown
						? 1
						: 0;
			} else {
				//Check unsupervised input changes
				generalparameterCount +=
					deviceParameters.current.unbalancedEventTriggered !==
						unbalancedEventTriggered &&
					deviceParameters.current.unbalancedEventTriggered !==
						ExternalInputAction.eUnknown
						? 1
						: 0;
				generalparameterCount +=
					deviceParameters.current.externalInputNormalState !==
						gpiNormalState &&
					deviceParameters.current.externalInputNormalState !==
						ExternalInputNormalState.eUnknown
						? 1
						: 0;
			}
		}

		const temprelay = deviceParameters.current.temperatureFaultRelay;
		let deviceSelectedTempfaultRelay = false;
		let deviceSelectedTempfaultRelay1 = false;

		if (temprelay === RelayAlert.eSet) {
			deviceSelectedTempfaultRelay = true;
			deviceSelectedTempfaultRelay1 = false;
		} else if (temprelay === RelayAlert.eUnset) {
			deviceSelectedTempfaultRelay = false;
			deviceSelectedTempfaultRelay1 = true;
		}

		// Blower Speed check
		const blowerspeed = deviceParameters.current.blowerSpeed;
		let deviceSelectedBlowerSpeed = 0;

		if (blowerspeed === FanSpeedLevel.eLevel_2) {
			deviceSelectedBlowerSpeed = 0;
		} else if (blowerspeed === FanSpeedLevel.eLevel_4) {
			deviceSelectedBlowerSpeed = 1;
		} else {
			deviceSelectedBlowerSpeed = 1;
		}
		if (
			deviceParameters.current.installationDate.toDateString() !==
			generalWatch('selectedDate').toDateString()
		) {
			++generalparameterCount;
		}
		if (deviceTime !== selectedTime) {
			++generalparameterCount;
		}
		if (
			deviceParameters.current.trendLogDisabled !==
			generalWatch('TrendLogInterval')
		) {
			++generalparameterCount;
		}
		if (
			deviceSelectedTempfaultRelay !==
				(generalWatch('isTemparatureFaultSetRelays') === 0) ||
			deviceSelectedTempfaultRelay1 !==
				(generalWatch('isTemparatureFaultSetRelays') === 1)
		) {
			++generalparameterCount;
		}

		if (deviceSelectedBlowerSpeed !== generalWatch('blowerSpeed')) {
			++generalparameterCount;
		}
		hasChanges = generalparameterCount > 0;
		return { hasChanges, count: generalparameterCount };
	};

	const isChannelSensorParametersChanged = (): {
		hasChanges: boolean;
		count: number;
	} => {
		let hasChanges = false;
		let channelsensorparameterCount = 0;

		// Check each general parameter for changes
		const alarm1FormValue = deviceParameters.current.alarmLatched;
		const alarm2FormValue = deviceParameters.current.alarm2Latched;
		const generalFaultFormValue = deviceParameters.current.generalFaultLatched;
		const auxFaultFormValue = deviceParameters.current.auxFaultLatched;
		// const alarmModeFormValue = deviceParameters.current.deviceAlarmMode;

		const alarm1lac = alarm1FormValue === LatchedMode.eLatched ? 0 : 1;
		const alarm2lac = alarm2FormValue === LatchedMode.eLatched ? 0 : 1;
		const genfaultlac = generalFaultFormValue === LatchedMode.eLatched ? 0 : 1;
		const auxfaultlac = auxFaultFormValue === LatchedMode.eLatched ? 0 : 1;
		// const ffAlarmMode = alarmModeFormValue === AlarmMode.eUp_InstantFire ? 0 : 1;

		if (deviceParameters.current.flowFaultDelay !== csWatch('FlowFaultDelay')) {
			++channelsensorparameterCount;
		}
		//TODO: Enable Alarm1 and Alarm2 configuration if it can be configured from BT APP
		// if (alarm1lac !== csWatch('Alarm1Configuration')) {
		// 	++channelsensorparameterCount;
		// }
		// if (IsChannel2Available && alarm2lac !== csWatch('Alarm2Configuration')) {
		// 	++channelsensorparameterCount;
		// }
		if (genfaultlac !== csWatch('GeneralFaultConfiguration')) {
			++channelsensorparameterCount;
		}
		if (auxfaultlac !== csWatch('AuxFaultConfiguration')) {
			++channelsensorparameterCount;
		}
		// if (ffAlarmMode !== csWatch('AlarmMode')) {
		//     ++channelsensorparameterCount;
		// }
		if (
			deviceParameters.current.flowFaultThresholdCh1 !==
			csWatch('FlowFaultThresholdValue')
		) {
			++channelsensorparameterCount;
		}

		hasChanges = channelsensorparameterCount > 0;
		return { hasChanges, count: channelsensorparameterCount };
	};

	async function ValidateGeneralParams(
		validationOption: string,
	): Promise<boolean> {
		switch (validationOption) {
			case 'TrendLogInterval':
				return await generalTrigger('TrendLogInterval');
			default:
				return await generalTrigger('TrendLogInterval');
		}
	}

	async function ValidateChannelAndSensorParams(
		validationOption: string,
	): Promise<boolean> {
		switch (validationOption) {
			case 'FlowFaultDelay':
				return await csTrigger('FlowFaultDelay');
			case 'FlowFaultThreshold':
				return await csTrigger('FlowFaultThreshold');
			default:
				if (IsChannel2Available) {
					// Validate all channel fields
					return Promise.all([
						csTrigger('FlowFaultDelay'),
						csTrigger('FlowFaultThreshold'),
						csTrigger('Referenceflow1'),
						csTrigger('Referenceflow2'),
					]).then(results => results.every(Boolean));
				} else {
					return Promise.all([
						csTrigger('FlowFaultDelay'),
						csTrigger('FlowFaultThreshold'),
						csTrigger('Referenceflow1'),
					]).then(results => results.every(Boolean));
				}
		}
	}

	function ClearGeneralParamsSaveFailedErrors() {
		setDeviceDateSaveFailed(false);
		setTrendLogIntervalSaveFailed(false);
		setTempFaultSetsRelaysSaveFailed(false);
		setGPISaveFailed(false);
		setAspiratorSpeedSaveFailed(false);
	}
	function ClearChannelsandSensorsSaveFailedErrors() {
		setFlowFaultDelaySaveFailed(false);
		setAlarm1ConfigSaveFailed(false);
		setAlarm2ConfigSaveFailed(false);
		setGeneralFaultConfigSaveFailed(false);
		setAuxFaultConfigSaveFailed(false);
		setAlarmModeSaveFailed(false);
		setFlowFaultThresholdSaveFailed(false);
	}

	//#endregion

	//#region Back Handler
	async function handleBackPress(): Promise<void> {
		if (selectedDevice.isDeviceConnected) {
			let tempDeviceParameter = deviceParameters.current;
			tempDeviceParameter.deviceId = selectedDevice.deviceId;
			tempDeviceParameter.deviceName = selectedDevice.deviceName;
			tempDeviceParameter.channels = selectedDevice.channels;
			deviceParameters.current = {
				...deviceParameters.current,
				deviceId: selectedDevice.deviceId,
				deviceName: selectedDevice.deviceName,
				channels: selectedDevice.channels,
			} as DeviceParametersModel;

			await dispatch(
				addNewDeviceParameter({
					dataSource,
					deviceParameter: tempDeviceParameter,
				}),
			);
			const userConfirmed = await confirmAlert(
				t('ExitDeviceParametersConfirmation'),
				t('ExitDeviceParameters'),
				t('Exit'),
				t('cancel'),
			);
			if (userConfirmed) {
				navigation.goBack();
			}
		} else {
			navigation.goBack();
		}
	}
	//#endregion

	//#region Spare part change

	// Header and step information
	const [ASP_HeaderStatusColor, setASP_HeaderStatusColor] =
		useState<string>('#8CB55A');
	const [ASP_StepCount, setASP_StepCount] = useState<number>(1);
	const [ASP_StepName, setASP_StepName] = useState<string>('');
	const [ASP_StepDescription, setASP_StepDescription] = useState<string>('');
	const [ASP_StepImage, setASP_StepImage] = useState<ReactElement>();

	// Visibility controls for UI components
	const [IsASPCompensationVisible, setIsASPCompensationVisible] =
		useState<boolean>(false);
	const [IsASPprocedureCompleteVisible, setIsASPprocedureCompleteVisible] =
		useState<boolean>(false);
	const [IsASPDeviceStatusVisible, setIsASPDeviceStatusVisible] =
		useState<boolean>(true);
	const [IsASPDeviceStatusLabelVisible, setIsASPDeviceStatusLabelVisible] =
		useState<boolean>(true);
	const [IsASPDoneButtonVisible, setIsASPDoneButtonVisible] =
		useState<boolean>(false);
	const [IsASPScanQRButtonVisible, setIsASPScanQRButtonVisible] =
		useState<boolean>(false);

	// Device status information
	const [ASP_DeviceStatus, setASP_DeviceStatus] = useState<string>('');
	const [ASP_DeviceStatusImage, setASP_DeviceStatusImage] =
		useState<ReactElement>(<PassIcon height={30} width={30} />);

	// UI control states
	const [IsASPProgressVisible, setIsASPProgressVisible] =
		useState<boolean>(false);
	const [IsASPNextButtonVisible, setIsASPNextButtonVisible] =
		useState<boolean>(true);
	const [IsASPNextButtonEnabled, setIsASPNextButtonEnabled] =
		useState<boolean>(true);
	const [IsASPRetryButtonVisible, setIsASPRetryButtonVisible] =
		useState<boolean>(false);
	const [aspDeviceStatusProgress, setAspDeviceStatusProgress] =
		useState<number>(0);
	const [IsASPBackButtonVisible, setIsASPBackButtonVisible] =
		useState<boolean>(false);
	const [isQRScannerModalVisible, setIsQRScannerModalVisible] =
		useState<boolean>(false);
	const [ASP_COMPENSATIONVALUE, setASP_COMPENSATIONVALUE] =
		useState<string>('');
	const progressTimerRef = useRef<CustomTimer | null>(null);
	const totalTimeRef = useRef<number>(0);
	async function StartAspiratorSparePartChange(): Promise<void> {
		setIsAddSparepartVisible(true);
		setASP_HeaderStatusColor('#8CB55A');
		setASP_StepCount(1);
		setASP_StepName(t('txtOPENDEVICECOVER'));
		setASP_StepDescription(t('msgOpenMainCover'));
		setASP_StepImage(<AspiratorCoverRemoval />);
		setIsASPCompensationVisible(false);
		setIsASPprocedureCompleteVisible(false);
		setIsASPDeviceStatusVisible(true);
		setIsASPDeviceStatusLabelVisible(true);
		setIsASPDoneButtonVisible(false);
		setIsASPScanQRButtonVisible(false);
		await StartWaitModeStep();
	}
	async function StartWaitModeStep(): Promise<void> {
		const waitModeResult = (await CheckDeviceStatus(false)) as boolean;
		if (waitModeResult) {
			setASP_DeviceStatus(t('txtMainCoverOpened'));
			setASP_DeviceStatusImage(<PassIcon height={30} width={30} />);
			setIsASPProgressVisible(false);
			setIsASPNextButtonVisible(true);
			setIsASPNextButtonEnabled(true);
			setIsASPRetryButtonVisible(false);
		} else {
			setASP_DeviceStatus(t('txtOpenMainCover'));
			setASP_DeviceStatusImage(<PassIcon height={30} width={30} />);
			setIsASPProgressVisible(true);
			setIsASPNextButtonVisible(false);
			setIsASPNextButtonEnabled(true);
			setIsASPRetryButtonVisible(false);
			StartWaitModeTimer();
		}
	}
	function StartWaitModeTimer(isWaitMode: boolean = true): void {
		if (progressTimerRef.current != null) {
			progressTimerRef.current.stop();
		}
		if (isWaitMode) {
			progressTimerRef.current = new CustomTimer(1000, CheckWaitModeProgress);
			totalTimeRef.current = 10;
		} else {
			progressTimerRef.current = new CustomTimer(
				1000,
				CheckServiceModeProgress,
			);
			totalTimeRef.current = 60;
		}
		setAspDeviceStatusProgress(0);
		progressTimerRef.current.start();
	}
	function CheckWaitModeProgress(): void {
		totalTimeRef.current -= 1;
		const a = (10 - totalTimeRef.current) / 10;
		setAspDeviceStatusProgress(((10 - totalTimeRef.current) / 10) * 100);
		if (totalTimeRef.current === 5 || totalTimeRef.current === 0) {
			CheckDeviceStatus(false).then((isWaitmode: boolean) => {
				if (isWaitmode) {
					setASP_DeviceStatusImage(<PassIcon height={30} width={30} />);
					setIsASPProgressVisible(false);
					setIsASPNextButtonVisible(true);
					setIsASPNextButtonEnabled(true);
					if (progressTimerRef.current) {
						progressTimerRef.current.stop();
					}
				} else if (totalTimeRef.current <= 0) {
					if (progressTimerRef.current) {
						progressTimerRef.current?.stop();
					}
					EnableWaitModeStepRetry();
				}
			});
		}
	}
	function CheckServiceModeProgress(): void {
		totalTimeRef.current -= 1;
		const a = (60 - totalTimeRef.current) / 60;
		setAspDeviceStatusProgress(((60 - totalTimeRef.current) / 60) * 100);
		if (
			totalTimeRef.current === 30 ||
			totalTimeRef.current === 15 ||
			totalTimeRef.current === 5 ||
			totalTimeRef.current === 0
		) {
			CheckDeviceStatus(true).then((isWaitmode: boolean) => {
				if (isWaitmode) {
					setASP_DeviceStatusImage(<PassIcon height={30} width={30} />);
					setIsASPProgressVisible(false);
					setIsASPNextButtonVisible(true);
					setIsASPNextButtonEnabled(true);
					if (progressTimerRef.current) {
						progressTimerRef.current.stop();
					}
				} else if (totalTimeRef.current === 0) {
					if (progressTimerRef.current) {
						progressTimerRef.current.stop();
					}
					EnableServiceModeStepRetry();
				}
			});
		}
	}
	function EnableWaitModeStepRetry(): void {
		setASP_DeviceStatus(t('txtMainCoverNotOpened'));
		setASP_DeviceStatusImage(<FailIcon height={30} width={30} />);
		setIsASPNextButtonVisible(false);
		setIsASPRetryButtonVisible(true);
	}

	function EnableServiceModeStepRetry(): void {
		setASP_DeviceStatusImage(<FailIcon height={30} width={30} />);
		setIsASPNextButtonVisible(false);
		setIsASPRetryButtonVisible(true);
	}

	async function CheckDeviceStatus(
		isServiceModeCheck: boolean,
	): Promise<boolean> {
		try {
			const deviceModeResult =
				await faastflexBluetoothCommunicator.GetDeviceMode();
			const deviceMode = deviceModeResult.deviceMode;
			if (isServiceModeCheck) {
				return deviceMode === DeviceStatus.MAIN_FSM_SERVICE;
			} else {
				return (
					deviceMode === DeviceStatus.MAIN_FSM_WAIT ||
					deviceMode === DeviceStatus.MAIN_FSM_SERVICE
				);
			}
		} catch (error) {
			console.error('Error checking device status:', error);
			return false;
		}
	}
	async function ASP_NextCommandAsync(): Promise<void> {
		if (ASP_StepCount === 1) {
			await InitializeServiceModeStep();
		} else if (ASP_StepCount === 2) {
			await StartScanQRStep();
		} else if (ASP_StepCount === 3) {
			await SendCompensationValueToDevice();
		}
	}
	async function InitializeServiceModeStep(): Promise<void> {
		setASP_HeaderStatusColor('#F9D311');
		setASP_StepCount(2);
		setASP_StepName(t('lblSERVICEMODE'));
		setASP_StepDescription(t('msgWaitForDeviceServiceMode'));
		setASP_DeviceStatus(t('txtDeviceInServiceMode'));
		setASP_StepImage(<AspiratorChange />);
		setIsASPCompensationVisible(false);
		setIsASPprocedureCompleteVisible(false);
		setIsASPDeviceStatusVisible(true);
		setIsASPDeviceStatusLabelVisible(true);
		setIsASPNextButtonVisible(true);
		setIsASPNextButtonEnabled(false);
		setIsASPDoneButtonVisible(false);
		setIsASPScanQRButtonVisible(false);
		await StartServiceModeStep();
	}
	async function StartServiceModeStep(): Promise<void> {
		const isServiceMode = await CheckDeviceStatus(true);

		if (isServiceMode) {
			setASP_DeviceStatusImage(<PassIcon height={30} width={30} />);
			setIsASPProgressVisible(false);
			setIsASPNextButtonEnabled(true);
			setIsASPRetryButtonVisible(false);
			setIsASPNextButtonVisible(true);
		} else {
			setASP_DeviceStatusImage(<PassIcon height={30} width={30} />);
			setIsASPProgressVisible(true);
			setIsASPNextButtonEnabled(false);
			setIsASPRetryButtonVisible(false);
			setIsASPNextButtonVisible(true);
			StartWaitModeTimer(false);
		}
	}
	async function ASP_RetryCommand(): Promise<void> {
		if (ASP_StepCount === 1) {
			await StartWaitModeStep();
		} else if (ASP_StepCount === 2) {
			await StartServiceModeStep();
		}
	}
	async function ASP_CancelCommandAsync(): Promise<void> {
		let isServiceMode = false;
		if (ASP_StepCount >= 2) {
			isServiceMode = await CheckDeviceStatus(true);
		}
		Alert.alert(
			t('lblCancelProcess'),
			t('msgCancelSparepartProcess'),
			[
				{
					text: t('cancel'),
					style: 'cancel',
				},
				{
					text: t('Yes_UpperCase'),
					onPress: async () => {
						if (isServiceMode) {
							await NavigateToHome();
						} else {
							setIsAddSparepartVisible(false);
						}
					},
				},
			],
			{ cancelable: false },
		);
	}
	async function checkCameraPermission(): Promise<boolean> {
		try {
			const permission =
				Platform.OS === 'ios'
					? PERMISSIONS.IOS.CAMERA
					: PERMISSIONS.ANDROID.CAMERA;

			const result = await check(permission);

			switch (result) {
				case RESULTS.GRANTED:
					return true;

				case RESULTS.DENIED:
					const requestResult = await request(permission);
					return requestResult === RESULTS.GRANTED;

				case RESULTS.LIMITED:
					return true;

				case RESULTS.BLOCKED:
					Alert.alert(
						'Camera Permission Required',
						'Camera permission is required for QR scanning. Please enable it in your device settings.',
						[
							{
								text: 'Cancel',
								style: 'cancel',
							},
							{
								text: 'Open Settings',
								onPress: () => {
									// Open device settings
									Linking.openSettings();
								},
							},
						],
					);
					return false;

				case RESULTS.UNAVAILABLE:
					// This feature is not available on this device
					Alert.alert(
						'Feature Not Available',
						'Camera is not available on this device.',
					);
					return false;

				default:
					return false;
			}
		} catch (error) {
			console.error('Error checking camera permission:', error);
			return false;
		}
	}

	async function ASP_ScanQRCommandAsync(): Promise<void> {
		try {
			let hasPermission = false;
			if (Platform.OS === 'ios') {
				hasPermission = true;
			} else {
				hasPermission = await checkCameraPermission();
			}
			if (hasPermission) {
				setIsQRScannerModalVisible(true);
			}
		} catch (error) {}
	}
	async function ASP_DoneCommandAsync(): Promise<void> {
		setIsASPBackButtonVisible(true);
		setIsAddSparepartVisible(false);
		await NavigateToHome();
	}

	async function NavigateToHome(): Promise<void> {
		navigation.dispatch(StackActions.pop(2));
	}

	async function StartScanQRStep(): Promise<void> {
		setASP_HeaderStatusColor('#F9D311');
		setASP_StepCount(3);
		setASP_StepName(t('lblSCANTHEQR'));
		setASP_StepDescription(t('msgScanQRLaser'));
		setASP_DeviceStatus('');
		setASP_StepImage(<AspiratorQR />);

		setIsASPCompensationVisible(false);
		setIsASPprocedureCompleteVisible(false);
		setIsASPDeviceStatusVisible(false);
		setIsASPNextButtonVisible(false);
		setIsASPDoneButtonVisible(false);
		setIsASPScanQRButtonVisible(true);
		setIsASPRetryButtonVisible(false);
	}
	async function SendCompensationValueToDevice(): Promise<void> {
		const correctionVal = GetFanPWMPercCorrection(ASP_COMPENSATIONVALUE);
		if (correctionVal === FanPWMPercCorrection.eUnknown) {
			Alert.alert('', t('aspiratorSparePartErr'), [{ text: t('Ok') }]);
			return;
		}

		try {
			const result =
				await faastflexBluetoothCommunicator.SetBlowerSpeedCorrection(
					correctionVal,
				);

			if (result && result.error === ErrorCode.eOK) {
				setASP_HeaderStatusColor('#F9D311');
				setASP_StepCount(4);
				setASP_StepName(t('lblCloseTheCover'));
				setASP_StepDescription(t('msgCloseAspiratorAndDeviceCover'));
				setASP_DeviceStatus(t('txtProcedureCompleted'));
				setASP_StepImage(<AspiratorCover />);
				setASP_DeviceStatusImage(<PassIcon height={30} width={30} />);
				setIsASPDeviceStatusVisible(true);
				setIsASPCompensationVisible(false);
				setIsASPprocedureCompleteVisible(true);
				setIsASPNextButtonVisible(false);
				setIsASPDoneButtonVisible(true);
				setIsASPScanQRButtonVisible(false);
				setIsASPRetryButtonVisible(false);
				setIsASPDeviceStatusLabelVisible(true);
				setIsASPBackButtonVisible(false);
			} else {
				Alert.alert('', t('aspiratorSparePartReqNotComplete'), [
					{ text: t('Ok') },
				]);
			}
		} catch (error) {
			console.error('Error sending compensation value:', error);
			Alert.alert('', t('aspiratorSparePartReqNotComplete'), [
				{ text: t('Ok') },
			]);
		}
	}

	function GetFanPWMPercCorrection(s: string): FanPWMPercCorrection {
		try {
			switch (s) {
				case '-6':
					return FanPWMPercCorrection.eMinusSix;
				case '-5':
					return FanPWMPercCorrection.eMinusFive;
				case '-4':
					return FanPWMPercCorrection.eMinusFour;
				case '-3':
					return FanPWMPercCorrection.eMinusThree;
				case '-2':
					return FanPWMPercCorrection.eMinusTwo;
				case '-1':
					return FanPWMPercCorrection.eMinusOne;
				case '0':
					return FanPWMPercCorrection.eZero;
				case '+1':
					return FanPWMPercCorrection.ePlusOne;
				case '+2':
					return FanPWMPercCorrection.ePlusTwo;
				case '+3':
					return FanPWMPercCorrection.ePlusThree;
				case '+4':
					return FanPWMPercCorrection.ePlusFour;
				case '+5':
					return FanPWMPercCorrection.ePlusFive;
				case '+6':
					return FanPWMPercCorrection.ePlusSix;
				default:
					console.error('Invalid fan PWM percentage correction value', s);
					return FanPWMPercCorrection.eUnknown;
			}
		} catch (error) {
			console.error('Error in GetFanPWMPercCorrection', error);
			return FanPWMPercCorrection.eUnknown;
		}
	}

	const closeQRScanner = () => {
		setIsQRScannerModalVisible(false);
	};

	async function handleQRScanner(result: string): Promise<void> {
		try {
			setIsQRScannerModalVisible(false);
			handleQRScanResult(result);
		} catch (error) {
			console.error('QR scanning error:', error);
			Alert.alert('', t('aspiratorSparePartErr'), [{ text: t('Ok') }]);
		}
	}
	async function handleQRScanResult(result: string): Promise<void> {
		try {
			if (result) {
				let validationCheck = false;
				let compVal = 'NA';
				const range = [
					'-6',
					'-5',
					'-4',
					'-3',
					'-2',
					'-1',
					'0',
					'+1',
					'+2',
					'+3',
					'+4',
					'+5',
					'+6',
				];
				const val =
					result && result.length >= 2
						? result.substring(result.length - 2)
						: 'NA';

				validationCheck = range.includes(val);
				compVal = validationCheck ? val : 'NA';

				if (validationCheck) {
					setASP_HeaderStatusColor('#F9D311');
					setASP_StepCount(3);
					setASP_StepName(t('lblSCANTHEQR'));
					setASP_StepDescription(t('msgScanQRLaser'));
					setASP_DeviceStatus(t('txtQRScanned'));
					setASP_DeviceStatusImage(<PassIcon height={30} width={30} />);
					setASP_StepImage(<AspiratorQR />);
					setIsASPDeviceStatusVisible(true);
					setIsASPCompensationVisible(true);
					setIsASPprocedureCompleteVisible(false);
					setIsASPDeviceStatusLabelVisible(true);
					setIsASPNextButtonVisible(true);
					setIsASPDoneButtonVisible(false);
					setIsASPScanQRButtonVisible(false);
					setIsASPRetryButtonVisible(false);
					setASP_COMPENSATIONVALUE(compVal);
				} else {
					setASP_HeaderStatusColor('#F9D311');
					setASP_StepCount(3);
					setASP_StepName(t('lblSCANTHEQR'));
					setASP_StepDescription(t('msgScanQRLaser'));
					setASP_DeviceStatus('');
					setASP_StepImage(<General />);
					setIsASPDeviceStatusVisible(true);
					setIsASPCompensationVisible(true);
					setIsASPprocedureCompleteVisible(false);
					setIsASPNextButtonVisible(false);
					setIsASPDoneButtonVisible(false);
					setIsASPScanQRButtonVisible(true);
					setIsASPRetryButtonVisible(false);
					setIsASPDeviceStatusLabelVisible(false);
					setASP_COMPENSATIONVALUE(compVal);
				}
			}
		} catch (error) {
			console.error('QR scanning error:', error);
			Alert.alert('', t('aspiratorSparePartErr'), [{ text: t('Ok') }]);
		}
	}

	const renderAspiratorSparePartChange = () => {
		return (
			<Modal
				animationType='fade'
				visible={IsAddSparepartVisible}
				onRequestClose={() => true}>
				<SafeAreaProvider>
					<View style={{ flex: 1, flexDirection: 'column' }}>
						{/*Header*/}
						<SafeAreaContextView edges={['top']} style={styles.safeHeader}>
							<View
								style={[
									styles.headerSection,
									{
										backgroundColor: '#000',
										alignItems: 'center',
									},
								]}>
								<View
									style={{
										flexDirection: 'row',
										alignItems: 'center',
										paddingHorizontal: 10,
										height: '100%',
										backgroundColor: '#000',
									}}>
									{IsASPBackButtonVisible && (
										<TouchableOpacity
											onPress={() => ASP_CancelCommandAsync()}
											style={{
												height: '100%',
												padding: 0,
												margin: 0,
												justifyContent: 'center',
											}}>
											<LeftArrowWhite height={30} width={30} />
										</TouchableOpacity>
									)}
									<View style={[{ flex: 2 }]}>
										<Text
											style={{
												color: '#fff',
												fontSize: 18,
												fontWeight: 'bold',
												textAlign: 'center',
											}}>
											{t('lblAddBlowerSparePart')}
										</Text>
									</View>
								</View>
							</View>
						</SafeAreaContextView>

						<View
							style={{
								height: '30%',
								backgroundColor: '#ffffff',
								flex: 1,
							}}>
							<View
								style={{
									height: 6,
									backgroundColor: ASP_HeaderStatusColor,
								}}
							/>
							<View
								style={{
									padding: 20,
									alignItems: 'flex-start',
									justifyContent: 'center',
									backgroundColor: '#E7E7E7',
								}}>
								<Text style={{ textAlign: 'left' }}>
									<Text
										style={{
											fontWeight: 'bold',
											fontSize: 16,
										}}>
										{t('lblStep')}{' '}
									</Text>
									<Text
										style={{
											fontWeight: 'bold',
											fontSize: 16,
										}}>
										{ASP_StepCount}
									</Text>
									<Text
										style={{
											fontWeight: 'bold',
											fontSize: 16,
										}}>
										{' '}
										-{' '}
									</Text>
									<Text style={{ fontSize: 16 }}>{ASP_StepName}</Text>
								</Text>
							</View>

							<View
								style={{
									padding: 20,
									alignItems: 'center',
									justifyContent: 'center',
									flex: 1,
								}}>
								<Text
									style={{
										fontSize: 15,
										color: '#000',
										textAlign: 'left',
										marginBottom: 10,
									}}>
									{ASP_StepDescription}
								</Text>
								<View
									style={{
										alignItems: 'center',
										justifyContent: 'center',
										marginBottom: 10,
										flex: 1,
									}}>
									<View
										style={{
											width: '100%',
											height: '100%',
											alignItems: 'center',
											justifyContent: 'center',
											minHeight: 200,
										}}>
										{ASP_StepImage}
									</View>
								</View>

								{/* Compensation Value (conditionally visible) */}
								{IsASPCompensationVisible && (
									<Text
										style={{
											fontSize: 15,
											color: '#000',
											textAlign: 'center',
											marginBottom: 10,
										}}>
										<Text>{t('txtCOMPENSATIONVALUE')}</Text>
										<Text>:</Text>
										<Text>{ASP_COMPENSATIONVALUE}</Text>
									</Text>
								)}

								{/* Completion Note (conditionally visible) */}
								{IsASPprocedureCompleteVisible && (
									<Text
										style={{
											fontSize: 15,
											color: '#000',
											textAlign: 'center',
											marginBottom: 10,
										}}>
										{t('noteAddSparePartProcedureComplete')}
									</Text>
								)}
							</View>

							<View
								style={{
									padding: 20,
									alignItems: 'center',
									justifyContent: 'center',
									backgroundColor: '#EFF8FF',
								}}>
								<View
									style={{
										flexDirection: 'row',
										alignItems: 'center',
										justifyContent: 'center',
									}}>
									<Text
										style={{
											fontSize: 15,
											color: '#000',
											textAlign: 'center',
											marginBottom: 10,
										}}>
										{ASP_DeviceStatus}
									</Text>
									{ASP_DeviceStatusImage}
								</View>
								{!IsASPDeviceStatusLabelVisible && (
									<Text
										style={{
											fontSize: 15,
											fontWeight: 'bold',
											color: '#1791E4',
											textAlign: 'center',
											marginTop: 10,
											marginBottom: 10,
										}}>
										{' '}
										{t('msgCheckIfTheCompensationValueIsMatching')}
									</Text>
								)}
							</View>

							{IsASPProgressVisible && (
								<CustomProgressBar percentage={aspDeviceStatusProgress} />
							)}
						</View>

						<View style={{ padding: 20 }}>
							<View style={styles.buttonGrid}>
								{!IsASPDoneButtonVisible && (
									<View style={styles.buttonGridColumn}>
										<TouchableOpacity
											style={[styles.cancelButton]}
											onPress={ASP_CancelCommandAsync}>
											<Text style={styles.cancelButtonText}>{t('cancel')}</Text>
										</TouchableOpacity>
									</View>
								)}

								<View style={styles.buttonGridColumn}>
									{IsASPNextButtonVisible && (
										<TouchableOpacity
											style={[
												styles.actionButton,
												!IsASPNextButtonEnabled && styles.disabledButton,
											]}
											onPress={ASP_NextCommandAsync}
											disabled={!IsASPNextButtonEnabled}>
											<Text style={styles.actionButtonText}>
												{t('Next_UpperCase')}
											</Text>
										</TouchableOpacity>
									)}

									{IsASPScanQRButtonVisible && (
										<TouchableOpacity
											style={styles.actionButton}
											onPress={ASP_ScanQRCommandAsync}>
											<Text style={styles.actionButtonText}>{t('qrscan')}</Text>
										</TouchableOpacity>
									)}

									{IsASPRetryButtonVisible && (
										<TouchableOpacity
											style={styles.actionButton}
											onPress={ASP_RetryCommand}>
											<Text style={[styles.actionButtonText, styles.boldText]}>
												{t('Retry_UpperCase')}
											</Text>
										</TouchableOpacity>
									)}
								</View>
							</View>

							{IsASPDoneButtonVisible && (
								<TouchableOpacity
									style={styles.doneButton}
									onPress={ASP_DoneCommandAsync}>
									<Text style={styles.actionButtonText}>{t('done')}</Text>
								</TouchableOpacity>
							)}
						</View>
						<Modal
							visible={isQRScannerModalVisible}
							animationType='slide'
							presentationStyle='fullScreen'
							onRequestClose={closeQRScanner}>
							<QRScanner
								scannerTitle={t('qrAlign')}
								cancelButtonText={t('cancel')}
								onScannerCancelled={closeQRScanner}
								onCodeScanned={handleQRScanner}
							/>
						</Modal>
					</View>
				</SafeAreaProvider>
			</Modal>
		);
	};
	//#endregion

	//#region Password Change

	const showChangePasscodeModal = () => {
		setPasswordModalVisible(true);
	};

	const ChangePasswordCommand = async (password: string) => {
		try {
			if (password && password.length === 6) {
				setPasswordModalVisible(false);
				showLoadingIndicator('');
				if (
					ConnectedDeviceobj.current !== null &&
					ConnectedDeviceobj.current !== undefined
				) {
					const passwordChangeAnswer =
						await faastflexBluetoothCommunicator.ChangeDevicePassword(password);
					await delay(500);
					hideLoadingIndicator();
					if (passwordChangeAnswer.isChanged) {
						Toast.show({
							type: 'success',
							text1: t('PasswordChangeSuccessMsg'),
							position: 'bottom',
						});
					} else {
						Toast.show({
							type: 'error',
							text1: t('PasswordChangeErrorMsg'),
							position: 'bottom',
						});
					}
				}
			}
		} catch (error) {
			hideLoadingIndicator();
			Toast.show({
				type: 'error',
				text1: t('PasswordChangeErrorMsg'),
				position: 'bottom',
			});
		}
	};

	const CancelNewPasswordAsync = () => {
		setPasswordModalVisible(false);
	};

	//#endregion

	//#region Render General Parameter

	const renderGeneralParameter = () => {
		const setGPITypeDefaults = (gpiState: number) => {
			if (gpiState === 1) {
				setGpiNormalState(ExternalInputNormalState.eShort);
				setUnbalancedEventTriggered(ExternalInputAction.eResetAlarmAndFault);
			}
			if (gpiState === 0) {
				setEventTriggerOnClose(ExternalInputAction.eResetAlarmAndFault);
				setEventTriggerOnOpen(ExternalInputAction.eResetAlarmAndFault);
			}
			setGpiInputState(gpiState);
		};
		return (
			<SafeAreaView style={{ flex: 1 }}>
				<ScrollView>
					<View
						style={[styles.container, { opacity: offlineMode ? 0.6 : 1 }]}
						pointerEvents={offlineMode ? 'none' : 'auto'}>
						{IsRealConfigOutOfBox && (
							<View
								style={[
									styles.section,
									{
										flexDirection: 'row',
										alignItems: 'center',
										marginBottom: 15,
									},
								]}>
								<FailIcon height={20} width={20} />
								<Text
									style={{
										fontSize: 17,
										fontWeight: '600',
										color: 'red',
									}}>
									{t('realConfigOutOfBoxErrorMessage')}
								</Text>
							</View>
						)}
						{/* Trend Log Inrterval */}
						<View style={styles.section}>
							{/* Heading */}
							<View
								style={{
									paddingVertical: 10,
									borderBottomWidth: 1,
									borderColor: '#e0e0e0',
									marginBottom: 10,
								}}>
								<Text style={{ fontSize: 17, fontWeight: '600' }}>
									{t('GeneralParams')}
								</Text>
							</View>

							<View
								style={{
									flexDirection: 'row',
									alignItems: 'center',
									marginBottom: 5,
								}}>
								<Text style={styles.GeneralParameterradioTitle}>
									{t('realconfig')} :{' '}
								</Text>
								<Text>{RealConfiguration}</Text>
							</View>

							<TouchableOpacity
								style={styles.actionButton}
								onPress={() => ChangeAddressCommand()}>
								<Text style={[styles.actionButtonText, styles.boldText]}>
									{t('lblAddressChange')}
								</Text>
							</TouchableOpacity>

							{/* Password */}
							<View style={{ marginVertical: 0, marginBottom: 5 }}>
								<Text
									style={[
										styles.GeneralParameterradioTitle,
										{ marginBottom: 5 },
									]}>
									{t('password')}
								</Text>
								<Text style={styles.passwordChangeBox}>{t('TapToChange')}</Text>
								<TouchableOpacity onPress={() => showChangePasscodeModal()}>
									<Text
										style={{
											color: '#1791E4',
											fontSize: 12,
										}}>
										{t('TapToChange')}
									</Text>
								</TouchableOpacity>
							</View>

							{/* Orientation */}
							<Controller
								name='Orientation'
								control={generalControl}
								render={({ field: { onChange, value } }) => (
									<TextInputField
										name={t('orientation')}
										control={generalControl}
										placeholder='Upright Orientation'
										title={t('orientation')}
										isRequired={true}
										errorMessage={generalErrors.Orientation?.message}
										isDisable={true}
										value={value}
										onChangeText={onChange}
									/>
								)}
							/>

							{/* Date Time */}
							<Controller
								name='selectedDate'
								control={generalControl}
								render={({
									field: { onChange: onDateChange, value: dateValue },
								}) => (
									<Controller
										name='selectedTime'
										control={generalControl}
										render={({
											field: { onChange: onTimeChange, value: timeValue },
										}) => (
											<View style={{ marginVertical: 0 }}>
												<Text
													style={[
														styles.GeneralParameterradioTitle,
														{ marginBottom: 0 },
													]}>
													{t('DeviceDate')}
												</Text>
												<DateTime
													selectedDate={dateValue}
													setSelectedDate={onDateChange}
													selectedTime={timeValue}
													setSelectedTime={onTimeChange}
												/>
												{(generalErrors.selectedDate ||
													generalErrors.selectedTime) && (
													<Text
														style={{
															color: 'red',
															fontSize: 12,
														}}>
														{generalErrors.selectedDate?.message ||
															generalErrors.selectedTime?.message}
													</Text>
												)}
												{deviceDateSaveFailed && (
													<Text
														style={{
															color: '#ff5252',
															fontSize: 12,
															marginTop: 4,
														}}>
														{t('ChangesNotSavedErrMsg')}
													</Text>
												)}
											</View>
										)}
									/>
								)}
							/>

							<View style={{ marginVertical: 0 }}>
								<CustomInput
									name='TrendLogInterval'
									control={generalControl}
									placeholder=''
									title={t('TrendLogInterval')}
									isRequired={true}
									errorMessage={generalErrors.TrendLogInterval?.message}
									belowText={t('TrendLogIntervalRangeInfo')}
									minValue={1}
									maxValue={240}
									unit={t('minutes')}
									keyboardType='numeric'
									maxLength={3}
								/>
								{trendLogIntervalSaveFailed && (
									<Text
										style={{
											color: '#ff5252',
											fontSize: 12,
											marginTop: 4,
										}}>
										{t('ChangesNotSavedErrMsg')}
									</Text>
								)}
							</View>

							<Text style={styles.GeneralParameterradioTitle}>
								{t('TemperatureFaultSetsRelays')}
							</Text>
							<Controller
								name='isTemparatureFaultSetRelays'
								control={generalControl}
								render={({ field: { onChange, value } }) => (
									<View style={styles.GeneralParameterradioContainer}>
										<View style={styles.radiospacebetween}>
											<RadioButton
												option={{
													id: 0,
													text: t('Yes'),
												}}
												isSelected={value === 0}
												onOptionChange={onChange}
											/>
										</View>
										<View style={styles.radiospacebetween}>
											<RadioButton
												option={{
													id: 1,
													text: t('no'),
												}}
												isSelected={value === 1}
												onOptionChange={onChange}
											/>
										</View>
										{tempFaultSetsRelaysSaveFailed && (
											<Text
												style={{
													color: '#ff5252',
													fontSize: 12,
													marginTop: 4,
												}}>
												{t('ChangesNotSavedErrMsg')}
											</Text>
										)}
									</View>
								)}
							/>
						</View>

						{/* GPI Input */}
						{IsGPIVisible && (
							<View
								style={[
									styles.section,
									{
										opacity: IsGPIEnabledConfig ? 1 : 0.5,
										paddingBottom: 10,
									},
								]}
								pointerEvents={IsGPIEnabledConfig ? 'auto' : 'none'}>
								<View
									style={{
										paddingVertical: 10,
										marginBottom: 0,
										flexDirection: 'row',
										justifyContent: 'space-between',
										alignItems: 'center',
									}}>
									<Text style={styles.sectionTitle}>{t('GPIInput')}</Text>
									<TouchableOpacity
										onPress={() => GetGPIParametersFromDevice()}>
										<SyncBlue height={20} width={20} />
									</TouchableOpacity>
								</View>

								<Text style={styles.dropdownLabel}>{t('State')}</Text>

								<View style={styles.radioContainer}>
									<View style={styles.radiospacebetween}>
										<RadioButton
											option={{
												id: 1,
												text: t('lblSupervised'),
											}}
											isSelected={gpiInputState === 1}
											onOptionChange={(value: any) => setGPITypeDefaults(value)}
										/>
									</View>
									<View style={styles.radiospacebetween}>
										<RadioButton
											option={{
												id: 0,
												text: t('lblUnSupervised'),
											}}
											isSelected={gpiInputState === 0}
											onOptionChange={(value: any) => setGPITypeDefaults(value)}
										/>
									</View>
								</View>

								{gpiInputState === 1 ? (
									<View style={styles.dropdownSection}>
										<Text style={styles.dropdownLabel}>
											{t('EventTriggeredOnClose')}
										</Text>
										<RNPickerSelect
											onValueChange={selectedValue => {
												if (selectedValue !== null) {
													setEventTriggerOnClose(selectedValue);
												}
											}}
											items={getExternalInputActionItems()}
											value={eventTriggerOnClose}
											style={pickerSelectStyles}
											useNativeAndroidPickerStyle={false}
											Icon={() => <DropDownIcon height={20} width={20} />}
										/>
										<Text style={styles.dropdownLabel}>
											{t('EventTriggeredOnOpen')}
										</Text>
										<RNPickerSelect
											onValueChange={selectedValue => {
												if (selectedValue !== null) {
													setEventTriggerOnOpen(selectedValue);
												}
											}}
											items={getExternalInputActionItems()}
											value={eventTriggerOnOpen}
											style={pickerSelectStyles}
											useNativeAndroidPickerStyle={false}
											Icon={() => <DropDownIcon height={20} width={20} />}
										/>
									</View>
								) : (
									<View style={styles.dropdownSection}>
										<Text style={styles.dropdownLabel}>
											{t('GPINormalState')}
										</Text>
										<RNPickerSelect
											onValueChange={selectedValue => {
												if (selectedValue !== null) {
													setGpiNormalState(selectedValue);
												}
											}}
											items={getExternalInputNormalStateItems()}
											value={gpiNormalState}
											style={pickerSelectStyles}
											useNativeAndroidPickerStyle={false}
											Icon={() => <DropDownIcon height={20} width={20} />}
										/>
										<Text style={[styles.dropdownLabel, { paddingTop: 5 }]}>
											{t('unbalancedaction')}
										</Text>
										<RNPickerSelect
											onValueChange={selectedValue => {
												if (selectedValue !== null) {
													setUnbalancedEventTriggered(selectedValue);
												}
											}}
											items={getExternalInputActionItems()}
											value={unbalancedEventTriggered}
											style={pickerSelectStyles}
											useNativeAndroidPickerStyle={false}
											Icon={() => <DropDownIcon height={20} width={20} />}
										/>
									</View>
								)}
								{gpiSaveFailed && (
									<Text
										style={{
											color: '#ff5252',
											fontSize: 12,
											marginTop: 4,
										}}>
										{t('ChangesNotSavedErrMsg')}
									</Text>
								)}
							</View>
						)}

						{/* Aspirator Speed */}
						<View style={styles.section}>
							<View
								style={{
									paddingVertical: 10,
									borderBottomWidth: 1,
									borderColor: '#e0e0e0',
									marginBottom: 10,
									flexDirection: 'row',
									justifyContent: 'space-between',
									alignItems: 'center',
								}}>
								<Text style={{ fontSize: 16, fontWeight: '600' }}>
									{t('Blower')}
								</Text>
								<TouchableOpacity
									onPress={() => StartAspiratorSparePartChange()}>
									<Text
										style={{
											color: '#1791E4',
											fontSize: 12,
										}}>
										{t('lblAddSparePart')}
									</Text>
								</TouchableOpacity>
							</View>
							<Text style={styles.radioTitle}>{t('Speed')}</Text>
							<Controller
								name='blowerSpeed'
								control={generalControl}
								render={({ field: { onChange, value } }) => (
									<View style={styles.radioContainer}>
										<View style={styles.radiospacebetween}>
											<RadioButton
												option={{
													id: 0,
													text: t('Low'),
												}}
												isSelected={value === 0}
												onOptionChange={onChange}
											/>
										</View>
										<View style={styles.radiospacebetween}>
											<RadioButton
												option={{
													id: 1,
													text: t('High'),
												}}
												isSelected={value === 1}
												onOptionChange={onChange}
											/>
										</View>
									</View>
								)}
							/>

							<CustomInput
								name='blowerCorrection'
								control={generalControl}
								placeholder=''
								title={t('BlowerCorrection')}
								isRequired={false}
								errorMessage={generalErrors.blowerCorrection?.message}
								belowText={t('BlowerCorrectionRange')}
								minValue={-6}
								maxValue={6}
								unit=''
								keyboardType='numeric'
								maxLength={3}
								isDisable={true}
								customOpacity={0.5}
							/>

							{aspiratorSpeedSaveFailed && (
								<Text
									style={{
										color: '#ff5252',
										fontSize: 12,
										marginTop: 4,
									}}>
									{t('ChangesNotSavedErrMsg')}
								</Text>
							)}
						</View>
					</View>
				</ScrollView>

				{/* Password Modal */}
				{isPasswordModalVisible && (
					<PasswordModal
						onClose={() => {
							CancelNewPasswordAsync();
						}}
						password={password}
						setPassword={ChangePasswordCommand}
						maximumLength={6}
					/>
				)}
			</SafeAreaView>
		);
	};
	//#endregion

	//#region Channel and sensors region
	const renderChannelsandSensors = () => {
		return (
			<SafeAreaView style={{ flex: 1 }}>
				<ScrollView style={{ flex: 1 }}>
					<View
						style={[styles.container, { opacity: offlineMode ? 0.6 : 1 }]}
						pointerEvents={offlineMode ? 'none' : 'auto'}>
						{/* Temperature Fault Sets Relays */}
						<View style={styles.section}>
							<Text style={styles.ActionCongigsectionTitle}>
								{t('ActionConfiguration')}
							</Text>

							<View style={{ marginVertical: 0 }}>
								<CustomInput
									name='FlowFaultDelay'
									control={csControl}
									placeholder='Enter Flow Fault Delay'
									title={t('FlowFaultDelay')}
									isRequired={true}
									errorMessage={csErrors.FlowFaultDelay?.message}
									belowText={t('max250secondsRange')}
									minValue={1}
									maxValue={250}
									unit={t('seconds')}
									keyboardType='numeric'
									maxLength={3}
								/>
								{flowFaultDelaySaveFailed && (
									<Text
										style={{
											color: '#ff5252',
											fontSize: 12,
											marginTop: 4,
										}}>
										{t('ChangesNotSavedErrMsg')}
									</Text>
								)}
							</View>

							<Text style={styles.radioTitle}>
								{t('lblGeneralFaultConfig')}
							</Text>
							<Controller
								name='GeneralFaultConfiguration'
								control={csControl}
								render={({ field: { onChange, value } }) => (
									<View style={styles.radioContainer}>
										<View style={styles.radiospacebetween}>
											<RadioButton
												option={{
													id: 0,
													text: t('Latched'),
												}}
												isSelected={value === 0}
												onOptionChange={onChange}
											/>
										</View>
										<View style={styles.radiospacebetween}>
											<RadioButton
												option={{
													id: 1,
													text: t('Unlatched'),
												}}
												isSelected={value === 1}
												onOptionChange={onChange}
											/>
										</View>
										{generalFaultConfigSaveFailed && (
											<Text
												style={{
													color: '#ff5252',
													fontSize: 12,
													marginTop: 4,
												}}>
												{t('ChangesNotSavedErrMsg')}
											</Text>
										)}
									</View>
								)}
							/>
							<Text style={styles.radioTitle}>{t('lblAuxFaultConfig')}</Text>
							<Controller
								name='AuxFaultConfiguration'
								control={csControl}
								render={({ field: { onChange, value } }) => (
									<View style={styles.radioContainer}>
										<View style={styles.radiospacebetween}>
											<RadioButton
												option={{
													id: 0,
													text: t('Latched'),
												}}
												isSelected={value === 0}
												onOptionChange={onChange}
											/>
										</View>
										<View style={styles.radiospacebetween}>
											<RadioButton
												option={{
													id: 1,
													text: t('Unlatched'),
												}}
												isSelected={value === 1}
												onOptionChange={onChange}
											/>
										</View>
										{auxFaultConfigSaveFailed && (
											<Text
												style={{
													color: '#ff5252',
													fontSize: 12,
													marginTop: 4,
												}}>
												{t('ChangesNotSavedErrMsg')}
											</Text>
										)}
									</View>
								)}
							/>
							{/* <Text style={styles.radioTitle}>{t('AlarmMode')}</Text>
                            <Controller
                                name="AlarmMode"
                                control={csControl}
                                render={({ field: { onChange, value } }) => (
                                    <View style={[styles.radioContainer, { borderBottomWidth: 0 }]}>
                                        <View style={styles.radiospacebetween}>
                                            <RadioButton
                                                option={{ id: 0, text: t('Instant') }}
                                                isSelected={value === 0}
                                                onOptionChange={onChange}
                                            />
                                        </View>
                                        <View style={styles.radiospacebetween}>
                                            <RadioButton
                                                option={{ id: 1, text: t('Cumulative') }}
                                                isSelected={value === 1}
                                                onOptionChange={onChange}
                                            />
                                        </View>
                                        {alarmModeSaveFailed && (
                                            <Text style={{ color: '#ff5252', fontSize: 12, marginTop: 4 }}>
                                                {t('ChangesNotSavedErrMsg')}
                                            </Text>
                                        )}
                                    </View>
                                )}
                            /> */}
						</View>

						<View style={[styles.section]}>
							{IsChannel2Available === false ? (
								<Text style={styles.sectionTitle}>{t('Channel1')}</Text>
							) : (
								<View
									style={{
										flexDirection: 'row',
										justifyContent: 'space-between',
										borderRadius: 10,
										marginBottom: 10,
									}}>
									<TouchableOpacity
										onPress={() => {
											setIsChannel(1);
										}}
										style={[
											isChannel === 1
												? {
														borderBottomWidth: 6,
														borderColor: commonColors.backgroundColor_Blue,
												  }
												: {},
											{
												flex: 1,
												alignItems: 'center',
												justifyContent: 'center',
												paddingVertical: 15,
											},
										]}>
										<Text style={styles.sectionTitleHeading}>
											{t('Channel1')}
										</Text>
									</TouchableOpacity>
									<View
										style={{
											width: 1,
											backgroundColor: 'gray',
											marginVertical: 10,
										}}
									/>
									<TouchableOpacity
										onPress={() => {
											setIsChannel(2);
										}}
										style={[
											isChannel === 2
												? {
														borderBottomWidth: 6,
														borderColor: commonColors.backgroundColor_Blue,
												  }
												: {},
											{
												flex: 1,
												alignItems: 'center',
												justifyContent: 'center',
												paddingVertical: 15,
											},
										]}>
										<Text style={styles.sectionTitleHeading}>
											{t('Channel2')}
										</Text>
									</TouchableOpacity>
								</View>
							)}
							<View>
								{isChannel === 1 ? (
									<View>
										{/* <Text style={[styles.radioTitle, { marginTop: 10 }]}>
											{t('AlarmConfiguration')}
										</Text>
										<Controller
											key='Alarm1Configuration'
											name='Alarm1Configuration'
											control={csControl}
											render={({ field: { onChange, value } }) => (
												<View
													style={[
														styles.radioContainer,
														{
															borderBottomWidth: 0,
															marginBottom: 20,
														},
													]}>
													<View style={styles.radiospacebetween}>
														<RadioButton
															option={{
																id: 0,
																text: t('Latched'),
															}}
															isSelected={value === 0}
															onOptionChange={onChange}
														/>
													</View>
													{!isChineseDevice && (
														<View style={styles.radiospacebetween}>
															<RadioButton
																option={{
																	id: 1,
																	text: t('Unlatched'),
																}}
																isSelected={value === 1}
																onOptionChange={onChange}
															/>
														</View>
													)}
													{alarm1ConfigSaveFailed && (
														<Text
															style={{
																color: '#ff5252',
																fontSize: 12,
																marginTop: 4,
															}}>
															{t('ChangesNotSavedErrMsg')}
														</Text>
													)}
												</View>
											)}
										/> */}

										{/* Reference Flow */}
										<View style={{ marginBottom: 10 }}>
											<View
												style={{
													flexDirection: 'row',
													justifyContent: 'space-between',
												}}>
												<Text>{t('ReferenceFlow')}</Text>
												<TouchableOpacity
													onPress={() => {
														handleNormalizeParameters();
													}}>
													<Text
														style={{
															color: '#1791E4',
														}}>
														{t('NormalizeParameters')}
													</Text>
												</TouchableOpacity>
											</View>
											<Controller
												key='Referenceflow1'
												name='Referenceflow1'
												control={csControl}
												render={({ field: { value } }) => (
													<View style={styles.fixedFieldWrapper}>
														<Text style={styles.fixedFieldInput}>
															{value !== undefined && value !== null
																? value.toString()
																: '0'}
														</Text>
														<Text style={styles.fixedFieldRightText}>
															{t('litPerMin')}
														</Text>
													</View>
												)}
											/>
										</View>
									</View>
								) : (
									<View>
										{/* <Text style={[styles.radioTitle, { marginTop: 10 }]}>
											{t('AlarmConfiguration')}
										</Text>
										<Controller
											key='Alarm2Configuration'
											name='Alarm2Configuration'
											control={csControl}
											render={({ field: { onChange, value } }) => (
												<View
													style={[
														styles.radioContainer,
														{
															borderBottomWidth: 0,
															marginBottom: 20,
														},
													]}>
													<View style={styles.radiospacebetween}>
														<RadioButton
															option={{
																id: 0,
																text: t('Latched'),
															}}
															isSelected={value === 0}
															onOptionChange={onChange}
														/>
													</View>
													{!isChineseDevice && (
														<View style={styles.radiospacebetween}>
															<RadioButton
																option={{
																	id: 1,
																	text: t('Unlatched'),
																}}
																isSelected={value === 1}
																onOptionChange={onChange}
															/>
														</View>
													)}
													{alarm2ConfigSaveFailed && (
														<Text
															style={{
																color: '#ff5252',
																fontSize: 12,
																marginTop: 4,
															}}>
															{t('ChangesNotSavedErrMsg')}
														</Text>
													)}
												</View>
											)}
										/> */}

										{/* Reference Flow 2 */}
										<View style={{ marginBottom: 10 }}>
											<View
												style={{
													flexDirection: 'row',
													justifyContent: 'space-between',
												}}>
												<Text>{t('ReferenceFlow')}</Text>
												<TouchableOpacity
													onPress={() => {
														handleNormalizeParameters();
													}}>
													<Text
														style={{
															color: '#1791E4',
														}}>
														{t('NormalizeParameters')}
													</Text>
												</TouchableOpacity>
											</View>
											<Controller
												key='Referenceflow2'
												name='Referenceflow2'
												control={csControl}
												render={({ field: { value } }) => (
													<View style={styles.fixedFieldWrapper}>
														<Text style={styles.fixedFieldInput}>
															{value !== undefined && value !== null
																? value.toString()
																: '0'}
														</Text>
														<Text style={styles.fixedFieldRightText}>
															{t('litPerMin')}
														</Text>
													</View>
												)}
											/>
										</View>
									</View>
								)}

								<View
									style={{
										flexDirection: 'row',
										flex: 1,
										borderColor: '#ccc',
										borderBottomWidth: 1,
										marginBottom: 10,
									}}
								/>

								<Text style={[styles.radioTitle]}>
									<Text>{t('FlowFaultThreshold')}</Text>
									{t('percentInBrackets')}
								</Text>
								<Controller
									key='FlowFaultThreshold'
									name='FlowFaultThreshold'
									control={csControl}
									render={({ field: { onChange, value } }) => (
										<View
											style={[styles.radioContainer, { borderBottomWidth: 0 }]}>
											<View style={styles.radiospacebetween}>
												<RadioButton
													option={{
														id: 0,
														text: t('lblen54Limit'),
													}}
													isSelected={value === 0}
													onOptionChange={() => {
														onChange(0);
														csSetValue('FlowFaultThresholdValue', 15);
													}}
												/>
											</View>
											<View style={styles.radiospacebetween}>
												<RadioButton
													option={{
														id: 1,
														text: t('lblotherLimit'),
													}}
													isSelected={value === 1}
													onOptionChange={() => {
														onChange(1);
														csSetValue('FlowFaultThresholdValue', 21);
													}}
												/>
											</View>
										</View>
									)}
								/>
								<View style={{ marginTop: 0 }}>
									<Controller
										key='FlowFaultThresholdValue'
										name='FlowFaultThresholdValue'
										control={csControl}
										render={({ field: { onChange, value } }) => (
											<>
												{csWatch('FlowFaultThreshold') === 1 ? (
													<IncrementDecrement
														label=''
														value={csWatch('FlowFaultThresholdValue')}
														setValue={newValue => {
															csSetValue('FlowFaultThresholdValue', newValue);
														}}
														min={21}
														max={80}
														belowText={t('FlowFaultThresholdRange')}
														isDisabled={false}
													/>
												) : (
													<View
														style={{
															borderWidth: 1,
															padding: 15,
															backgroundColor: '#f0f0f0',
															borderColor: '#d3d3d3',
															marginBottom: 10,
														}}>
														<Text
															style={{
																color: commonColors.textColor_Grey,
																fontSize: 18,
															}}>
															{t('msgEN54CompliantLimits')}
														</Text>
													</View>
												)}
											</>
										)}
									/>

									{flowFaultThresholdSaveFailed && (
										<Text
											style={{
												color: '#ff5252',
												fontSize: 12,
												marginTop: 2,
												marginBottom: 10,
											}}>
											{t('ChangesNotSavedErrMsg')}
										</Text>
									)}
								</View>
							</View>
						</View>
					</View>
				</ScrollView>
			</SafeAreaView>
		);
	};
	//#endregion

	//#region Render Sensor Address
	const tenthsRange1 = Array.from({ length: 16 }, (_, i) => i);
	const unitsRange1 = Array.from({ length: 10 }, (_, i) => i);

	const tenthsRange2 = Array.from({ length: 16 }, (_, i) => i);
	const unitsRange2 = Array.from({ length: 10 }, (_, i) => i);

	const [tenthsValueD1, setTenthsValueD1] = useState<number>(-1);
	const [unitsValueD1, setUnitsValueD1] = useState<number>(-1);
	const [newAddressD1, setNewAddressD1] = useState<string>(AppConstants.NA);

	const [detector1CurrentAddress, setDetector1CurrentAddress] =
		useState<string>(AppConstants.NA);

	const [tenthsValueD2, setTenthsValueD2] = useState<number>(-1);
	const [unitsValueD2, setUnitsValueD2] = useState<number>(-1);
	const [newAddressD2, setNewAddressD2] = useState<string>(AppConstants.NA);
	const [detector2CurrentAddress, setDetector2CurrentAddress] =
		useState<string>(AppConstants.NA);

	const [isD1CheckboxSelected, setIsD1CheckboxSelected] =
		useState<boolean>(false);
	const [isD2CheckboxSelected, setIsD2CheckboxSelected] =
		useState<boolean>(false);

	const [isModuleAvailable, setIsModuleAvailable] = useState<boolean>(true);

	const [addressChangeLoadingIndicator, setAddressChangeLoadingIndicator] =
		useState<boolean>(false);
	const [
		addressChangeLoadingIndicatorMessage,
		setAddressChangeLoadingIndicatorMessage,
	] = useState<string>('');

	// Define your custom range here

	const handleValueChangeD1 = (value: number, type: number) => {
		if (value >= 0) {
			let newTenths = tenthsValueD1;
			let newUnits = unitsValueD1;

			if (type === 1) {
				newTenths = value;
				setTenthsValueD1(value);
			} else if (type === 2) {
				newUnits = value;
				setUnitsValueD1(value);
			}

			const newAddress =
				(newTenths !== -1 ? newTenths * 10 : 0) +
				(newUnits !== -1 ? newUnits : 0);
			setNewAddressD1(newAddress.toString());
		}
	};

	const handleValueChangeD2 = (value: number, type: number) => {
		if (value >= 0) {
			let newTenths = tenthsValueD2;
			let newUnits = unitsValueD2;

			if (type === 1) {
				newTenths = value;
				setTenthsValueD2(value);
			} else if (type === 2) {
				newUnits = value;
				setUnitsValueD2(value);
			}

			const newAddress =
				(newTenths !== -1 ? newTenths * 10 : 0) +
				(newUnits !== -1 ? newUnits : 0);
			setNewAddressD2(newAddress.toString());
		}
	};

	const clearDetectorSelection = (detectorNumber: number) => {
		if (detectorNumber === 1) {
			setNewAddressD1(AppConstants.NA);
			// setIsD1CheckboxSelected(false);
		} else if (detectorNumber === 2) {
			setNewAddressD2(AppConstants.NA);
			// setIsD2CheckboxSelected(false);
		}
	};

	const selectDetectorNum = (num: number) => {
		setDetectorNum(num);
	};

	async function ChangeAddressCommand(
		isFromButton: boolean = true,
	): Promise<void> {
		setIsSensorAddressVisible(isFromButton);
		clearDetectorSelection(1);
		clearDetectorSelection(2);
		selectDetectorNum(1);
		if (isFromButton) {
			hideLoadingIndicator();
			setAddressChangeLoadingIndicator(false);
			setAddressChangeLoadingIndicatorMessage('');
			await FetchCurrentAddressCommand();
		}
	}

	async function AddressChange_CancelCommandAsync(): Promise<void> {
		Alert.alert(
			t('lblCancelProcess'),
			t('msgAddressChangeBackConfirmation'),
			[
				{
					text: t('cancel'),
					style: 'cancel',
				},
				{
					text: t('Yes_UpperCase'),
					onPress: async () => {
						ChangeAddressCommand(false);
					},
				},
			],
			{ cancelable: false },
		);
	}

	async function AddressSyncToDeviceCommand(): Promise<void> {
		try {
			setAddressChangeLoadingIndicator(true);
			setAddressChangeLoadingIndicatorMessage(t('msgSettingAddressToDevice'));
			if (isD1CheckboxSelected) {
				const address1 = 255;
				await setAddressToDevice(Channel.Channel1, address1);
			} else {
				if (
					newAddressD1 !== null &&
					newAddressD1 !== undefined &&
					newAddressD1 !== AppConstants.NA
				) {
					console.log('New Address D1:', newAddressD1);
					const address1 = parseInt(newAddressD1, 0);
					await setAddressToDevice(Channel.Channel1, address1);
				}
			}
			if (IsChannel2Available) {
				await delay(500);
				if (isD2CheckboxSelected) {
					const address2 = 255;
					await setAddressToDevice(Channel.Channel2, address2);
				} else {
					if (
						newAddressD2 !== null &&
						newAddressD2 !== undefined &&
						newAddressD2 !== AppConstants.NA
					) {
						console.log('New Address D2:', newAddressD2);
						const address2 = parseInt(newAddressD2, 0);
						await setAddressToDevice(Channel.Channel2, address2);
					}
				}
			}
			// Verify channel address set by fetching again
			await delay(4000);
			//setIsModuleAvailable(true);
			let Address1Matched = false;
			let Address2Matched = false;
			const sensor1AddressCheck =
				await faastflexBluetoothCommunicator.GetFFISensorAddress(
					Channel.Channel1,
				);
			console.log(
				'Sensor 1 Address Result After Setting Address:',
				sensor1AddressCheck,
			);
			if (
				sensor1AddressCheck !== null &&
				sensor1AddressCheck !== undefined &&
				sensor1AddressCheck.error === ErrorCode.eOK
			) {
				if (sensor1AddressCheck.address === 254) {
					Address1Matched = false;
					setDetector1CurrentAddress('NA');
				} else {
					if (isD1CheckboxSelected) {
						setDetector1CurrentAddress(sensor1AddressCheck.address.toString());
						Address1Matched = true;
					} else if (sensor1AddressCheck.address.toString() === newAddressD1) {
						setDetector1CurrentAddress(sensor1AddressCheck.address.toString());
						Address1Matched = true;
					} else {
						Address1Matched = false;
					}
				}
			}
			if (IsChannel2Available) {
				await delay(5000);
				const sensor2AddressCheck =
					await faastflexBluetoothCommunicator.GetFFISensorAddress(
						Channel.Channel2,
					);
				if (
					sensor2AddressCheck !== null &&
					sensor2AddressCheck !== undefined &&
					sensor2AddressCheck.error === ErrorCode.eOK
				) {
					if (sensor2AddressCheck.address === 254) {
						Address2Matched = false;
						setDetector2CurrentAddress('NA');
					} else {
						if (isD2CheckboxSelected) {
							setDetector2CurrentAddress(
								sensor2AddressCheck.address.toString(),
							);
							Address2Matched = true;
						} else if (
							sensor2AddressCheck.address.toString() === newAddressD2
						) {
							setDetector2CurrentAddress(
								sensor2AddressCheck.address.toString(),
							);
							Address2Matched = true;
						} else {
							Address2Matched = false;
						}
					}
				}
			}

			//TODO: Check if toast is shown , if not then check how to show toast on modal

			if (Address1Matched && Address2Matched) {
				Toast.show({
					type: 'success',
					text2: t('msgAddressSetSuccessfully'),
					position: 'bottom',
				});
			} else {
				Toast.show({
					type: 'error',
					text2: t('msgAddressSetFailed'),
					position: 'bottom',
				});
			}

			await delay(500);
			setAddressChangeLoadingIndicator(false);
		} catch (error) {
			setAddressChangeLoadingIndicator(false);
		}
	}

	async function setAddressToDevice(
		channelNumber: Channel,
		address: number,
	): Promise<void> {
		const setResult = await faastflexBluetoothCommunicator.SetFFISensorAddress(
			channelNumber,
			address,
		);
		if (setResult.error === ErrorCode.eOK && setResult.isUpdated) {
			Toast.show({
				type: 'success',
				text2: t('msgAddressSetSuccessfully'),
				position: 'bottom',
			});
		} else {
			Toast.show({
				type: 'error',
				text2: t('msgAddressSetFailed'),
				position: 'bottom',
			});
		}
	}

	async function FetchCurrentAddressCommand(): Promise<void> {
		try {
			setAddressChangeLoadingIndicator(true);
			setAddressChangeLoadingIndicatorMessage(t('msgFetchingCurrentAddress'));
			setIsModuleAvailable(true);
			const sensor1AddressResult =
				await faastflexBluetoothCommunicator.GetFFISensorAddress(
					Channel.Channel1,
				);
			console.log('Sensor 1 Address Result:', sensor1AddressResult);
			if (
				sensor1AddressResult !== null &&
				sensor1AddressResult !== undefined &&
				sensor1AddressResult.error === ErrorCode.eOK
			) {
				if (sensor1AddressResult.address === 254) {
					setIsModuleAvailable(false);
					setDetector1CurrentAddress('NA');
				} else {
					setDetector1CurrentAddress(sensor1AddressResult.address.toString());
				}
			}
			if (IsChannel2Available) {
				await delay(500);
				const sensor2AddressResult =
					await faastflexBluetoothCommunicator.GetFFISensorAddress(
						Channel.Channel2,
					);
				console.log('Sensor 2 Address Result:', sensor2AddressResult);
				if (
					sensor2AddressResult !== null &&
					sensor2AddressResult !== undefined &&
					sensor2AddressResult.error === ErrorCode.eOK
				) {
					if (sensor2AddressResult.address === 254) {
						setIsModuleAvailable(false);
						setDetector2CurrentAddress('NA');
					} else {
						setDetector2CurrentAddress(sensor2AddressResult.address.toString());
					}
				}
			}
			await delay(500);
			console.log('module available:', isModuleAvailable);
			setAddressChangeLoadingIndicator(false);
		} catch (error) {
			setAddressChangeLoadingIndicator(false);
		}
	}

	async function setDetector1KnobAddress(): Promise<void> {
		const newCheckboxState1 = !isD1CheckboxSelected;
		setIsD1CheckboxSelected(newCheckboxState1);
		setNewAddressD1(AppConstants.NA);
		// Clear selection when checkbox is being checked (not unchecked)
		// if(!newCheckboxState){
		//     clearDetectorSelection(1);
		// }
	}
	async function setDetector2KnobAddress(): Promise<void> {
		const newCheckboxState2 = !isD2CheckboxSelected;
		setIsD2CheckboxSelected(newCheckboxState2);
		setNewAddressD2(AppConstants.NA);
		// if(!newCheckboxState){
		//     clearDetectorSelection(2);
		// }
	}

	const renderSensorAddress = () => {
		hideLoadingIndicator();
		return (
			<Modal
				animationType='fade'
				visible={isSensorAddressVisible}
				onRequestClose={() => AddressChange_CancelCommandAsync}>
				<View style={{ flex: 1, flexDirection: 'column' }}>
					{/*Header*/}
					<SafeAreaContextView edges={['top']} style={styles.safeHeader}>
						<View
							style={[
								styles.headerSection,
								{
									backgroundColor: '#000',
									alignItems: 'center',
								},
							]}>
							<View
								style={{
									flexDirection: 'row',
									alignItems: 'center',
									paddingHorizontal: 10,
									height: '100%',
									backgroundColor: '#000',
								}}>
								<TouchableOpacity
									onPress={() => AddressChange_CancelCommandAsync()}
									style={{
										height: '100%',
										padding: 0,
										margin: 0,
										justifyContent: 'center',
									}}>
									<LeftArrowWhite height={30} width={30} />
								</TouchableOpacity>
								<View style={[{ flex: 2 }]}>
									<Text
										style={{
											color: '#fff',
											fontSize: 18,
											fontWeight: 'bold',
											textAlign: 'center',
										}}>
										{t('lblAddressChange')}
									</Text>
								</View>
							</View>
						</View>
					</SafeAreaContextView>

					<ScrollView contentContainerStyle={{ flexGrow: 1 }}>
						<View style={styles.container}>
							{/* Trend Log Inrterval */}
							<View style={[styles.section, { flex: 1, marginBottom: 0 }]}>
								<Text style={styles.sectionTitleHeading}>
									{t('lblSelectDetector')}
								</Text>
								{IsChannel2Available === false ? (
									<Text style={styles.sectionTitle}>{t('lblDetector1')}</Text>
								) : (
									<View
										style={{
											flexDirection: 'row',
											justifyContent: 'space-between',
											borderRadius: 10,
											marginBottom: 10,
										}}>
										<TouchableOpacity
											onPress={() => {
												selectDetectorNum(1);
											}}
											style={[
												detectorNum === 1
													? {
															borderBottomWidth: 6,
															borderColor: commonColors.backgroundColor_Blue,
													  }
													: {},
												{
													flex: 1,
													alignItems: 'center',
													justifyContent: 'center',
													paddingVertical: 15,
												},
											]}>
											<Text style={styles.sectionTitleHeading}>
												{t('lblDetector1')}
											</Text>
										</TouchableOpacity>
										<View
											style={{
												width: 1,
												backgroundColor: 'gray',
												marginVertical: 10,
											}}
										/>
										<TouchableOpacity
											onPress={() => {
												selectDetectorNum(2);
											}}
											style={[
												detectorNum === 2
													? {
															borderBottomWidth: 6,
															borderColor: commonColors.backgroundColor_Blue,
													  }
													: {},
												{
													flex: 1,
													alignItems: 'center',
													justifyContent: 'center',
													paddingVertical: 15,
												},
											]}>
											<Text style={styles.sectionTitleHeading}>
												{t('lblDetector2')}
											</Text>
										</TouchableOpacity>
									</View>
								)}

								{detectorNum === 1 ? (
									<View>
										<View style={{ marginVertical: 0 }}>
											<Text style={styles.sectionTitle}>
												{t('lblCurrentAddress')}
											</Text>
											<View
												style={[
													{
														borderWidth: 2,
														borderColor: commonColors.textColor_Grey,
														borderRadius: 2,
														padding: 10,
														marginBottom: 10,
													},
												]}>
												<Text>{detector1CurrentAddress}</Text>
											</View>
										</View>

										{false && (
											<>
												<View
													style={{
														alignItems: 'flex-start',
														marginTop: 20,
														marginBottom: 5,
														flexDirection: 'column',
													}}>
													<Text
														style={{
															alignItems: 'flex-start',
															fontWeight: 'bold',
														}}>
														{t('lblTenths')}
													</Text>
												</View>
												<HorizontalScrollPicker
													list={tenthsRange1}
													selectedNumber={tenthsValueD1}
													onSelectItem={value => handleValueChangeD1(value, 1)}
													clearSelection={false}
												/>

												<View
													style={{
														alignItems: 'flex-start',
														marginTop: 20,
														marginBottom: 5,
														flexDirection: 'column',
													}}>
													<Text
														style={{
															alignItems: 'flex-start',
															fontWeight: 'bold',
														}}>
														{t('lblUnits')}
													</Text>
												</View>

												<HorizontalScrollPicker
													list={unitsRange1}
													selectedNumber={unitsValueD1}
													onSelectItem={value => handleValueChangeD1(value, 2)}
													clearSelection={false}
												/>

												<View
													style={{
														alignItems: 'center',
														marginTop: 20,
													}}></View>
											</>
										)}

										<View
											style={{
												marginVertical: 20,
												opacity: isD1CheckboxSelected ? 0.5 : 1,
											}}
											pointerEvents={isD1CheckboxSelected ? 'none' : 'auto'}>
											<View
												style={{
													alignItems: 'center',
													marginTop: 20,
													marginBottom: 20,
													flexDirection: 'row',
													justifyContent: 'space-between',
												}}>
												<Text
													style={[
														styles.sectionTitleHeading,
														{ fontSize: 18 },
													]}>
													{t('lblSelectNewAddress')}
												</Text>
												{/* <TouchableOpacity onPress={() => clearDetectorSelection(1)} style={{ padding:0,margin:0, justifyContent:'center', paddingRight:10 }}>
                <ResetBlue height={24} width={24} />
                </TouchableOpacity> */}
											</View>
											<TextInput
												style={styles.addressInput}
												onChangeText={text => {
													// Remove any non-numeric characters
													const numericValue = text.replace(/[^0-9]/g, '');

													if (numericValue === '') {
														setNewAddressD1(AppConstants.NA);
													} else {
														const value = parseInt(numericValue, 10);
														// Enforce 0-159 range
														if (value >= 0 && value <= 159) {
															setNewAddressD1(value.toString());
														} else if (value > 159) {
															// If value exceeds 159, set to 159
															setNewAddressD1('159');
														}
													}
												}}
												value={
													newAddressD1 !== AppConstants.NA ? newAddressD1 : ''
												}
												placeholder={AppConstants.NA}
												placeholderTextColor={commonColors.textColor_Grey}
												keyboardType='numeric'
												maxLength={3}
											/>
											<Text style={styles.belowText}>
												{stringFormat(t('newAddressRangeInfoMsg'), '0', '159')}
											</Text>
										</View>

										<View
											style={[
												styles.checkboxContainer,
												{
													opacity: isModuleAvailable ? 1 : 0.5,
												},
											]}
											pointerEvents={isModuleAvailable ? 'auto' : 'none'}>
											<TouchableOpacity
												onPress={() => setDetector1KnobAddress()}
												style={{
													flexDirection: 'row',
													alignItems: 'center',
												}}>
												<CheckBox
													value={isD1CheckboxSelected}
													tintColors={{
														true: '#1791E4',
														false: '#9D9D9D',
													}}
													style={styles.checkbox}
												/>
												<Text style={styles.checkboxLabel}>
													{t('lblUseRotarySwitch')}
												</Text>
											</TouchableOpacity>
										</View>

										<Text
											style={[
												styles.belowText,
												{ marginTop: 0, fontSize: 14 },
											]}>
											{t('msgUseRotarySwitch')}
										</Text>

										{!isModuleAvailable && (
											<Text
												style={{
													color: 'red',
													fontSize: 12,
													marginTop: 10,
												}}>
												{t('msgModuleNotDetected')}
											</Text>
										)}

										<View
											style={{
												alignItems: 'center',
												marginTop: 20,
											}}></View>
									</View>
								) : (
									<View>
										{/* Detector 2*/}
										<View style={{ marginVertical: 0 }}>
											<Text style={styles.sectionTitle}>
												{t('lblCurrentAddress')}
											</Text>
											<View
												style={[
													{
														borderWidth: 2,
														borderColor: commonColors.textColor_Grey,
														borderRadius: 2,
														padding: 10,
														marginBottom: 10,
													},
												]}>
												<Text>{detector2CurrentAddress}</Text>
											</View>
										</View>

										{false && (
											<>
												<View
													style={{
														alignItems: 'flex-start',
														marginTop: 20,
														marginBottom: 5,
														flexDirection: 'column',
													}}>
													<Text
														style={{
															alignItems: 'flex-start',
															fontWeight: 'bold',
														}}>
														{t('lblTenths')}
													</Text>
												</View>
												<HorizontalScrollPicker
													list={tenthsRange2}
													selectedNumber={tenthsValueD2}
													onSelectItem={value => handleValueChangeD2(value, 1)}
													clearSelection={false}
												/>

												<View
													style={{
														alignItems: 'flex-start',
														marginTop: 20,
														marginBottom: 5,
														flexDirection: 'column',
													}}>
													<Text
														style={{
															alignItems: 'flex-start',
															fontWeight: 'bold',
														}}>
														{t('lblUnits')}
													</Text>
												</View>

												<HorizontalScrollPicker
													list={unitsRange2}
													selectedNumber={unitsValueD2}
													onSelectItem={value => handleValueChangeD2(value, 2)}
													clearSelection={false}
												/>

												<View
													style={{
														alignItems: 'center',
														marginTop: 20,
													}}></View>
											</>
										)}

										<View
											style={{
												marginVertical: 20,
												opacity: isD2CheckboxSelected ? 0.5 : 1,
											}}
											pointerEvents={isD2CheckboxSelected ? 'none' : 'auto'}>
											<View
												style={{
													alignItems: 'center',
													marginTop: 20,
													marginBottom: 20,
													flexDirection: 'row',
													justifyContent: 'space-between',
												}}>
												<Text
													style={[
														styles.sectionTitleHeading,
														{ fontSize: 18 },
													]}>
													{t('lblSelectNewAddress')}
												</Text>
												{/* <TouchableOpacity onPress={() => clearDetectorSelection(2)} style={{ padding:0,margin:0, justifyContent:'center', paddingRight:10 }}>
                <ResetBlue height={24} width={24} />
                </TouchableOpacity> */}
											</View>
											<TextInput
												style={styles.addressInput}
												onChangeText={text => {
													// Remove any non-numeric characters
													const numericValue = text.replace(/[^0-9]/g, '');

													if (numericValue === '') {
														setNewAddressD2(AppConstants.NA);
													} else {
														const value = parseInt(numericValue, 10);
														// Enforce 0-159 range
														if (value >= 0 && value <= 159) {
															setNewAddressD2(value.toString());
														} else if (value > 159) {
															// If value exceeds 159, set to 159
															setNewAddressD2('159');
														}
													}
												}}
												value={
													newAddressD2 !== AppConstants.NA ? newAddressD2 : ''
												}
												placeholder={AppConstants.NA}
												placeholderTextColor={commonColors.textColor_Grey}
												keyboardType='numeric'
												maxLength={3}
											/>
											<Text style={styles.belowText}>
												{stringFormat(t('newAddressRangeInfoMsg'), '0', '159')}
											</Text>
										</View>

										<View
											style={[
												styles.checkboxContainer,
												{
													opacity: isModuleAvailable ? 1 : 0.5,
												},
											]}
											pointerEvents={isModuleAvailable ? 'auto' : 'none'}>
											<TouchableOpacity
												onPress={() => setDetector2KnobAddress()}
												style={{
													flexDirection: 'row',
													alignItems: 'center',
												}}>
												<CheckBox
													value={isD2CheckboxSelected}
													tintColors={{
														true: '#1791E4',
														false: '#9D9D9D',
													}}
													style={styles.checkbox}
												/>
												<Text style={styles.checkboxLabel}>
													{t('lblUseRotarySwitch')}
												</Text>
											</TouchableOpacity>
										</View>

										<Text
											style={[
												styles.belowText,
												{ marginTop: 0, fontSize: 14 },
											]}>
											{t('msgUseRotarySwitch')}
										</Text>

										{!isModuleAvailable && (
											<Text
												style={{
													color: 'red',
													fontSize: 12,
													marginTop: 10,
												}}>
												{t('msgModuleNotDetected')}
											</Text>
										)}

										<View
											style={{
												alignItems: 'center',
												marginTop: 20,
											}}></View>
									</View>
								)}
							</View>
						</View>
					</ScrollView>

					<View style={{ padding: 16 }}>
						<TouchableOpacity
							style={[styles.doneButton]}
							onPress={AddressSyncToDeviceCommand}>
							<Text style={styles.actionButtonText}>
								{t('saveandconfigure')}
							</Text>
						</TouchableOpacity>
					</View>

					<ModalLoadingIndicator
						visible={addressChangeLoadingIndicator}
						message={addressChangeLoadingIndicatorMessage}
					/>
				</View>
			</Modal>
		);
	};
	//#endregion

	//#region  More Options and Normalization
	const handleNormalizeParameters = () => {
		normalizeParameters();
	};
	async function normalizeParameters() {
		var doWeNeedBothChannelsNormalized = true;
		if (IsChannel2Available)
			doWeNeedBothChannelsNormalized = await confirmAlert(
				t('msgNormalizebothchannels'),
				t('lblNOTE'),
				t('ok'),
				t('cancel'),
			);
		if (doWeNeedBothChannelsNormalized) {
			showLoadingIndicator(t('SendingNormalizedCommand'));
			var isNormalized =
				await faastflexBluetoothCommunicator.SetNormalizedCommand();
			hideLoadingIndicator();
			if (isNormalized.isReset) {
				showLoadingIndicator(t('NormalizationInProgressMsg'));
				await delay(60000);
				hideLoadingIndicator();
				Toast.show({
					type: 'info',
					text2: t('NormalizationCompleteMsg'),
					position: 'bottom',
				});
			} else {
				Toast.show({
					type: 'error',
					text2: t('NormalizedCommandError'),
					position: 'bottom',
				});
			}
		}
	}
	//#endregion

	//#region Tab Press Handler
	function handleGeneralParametersPress() {
		if (isGeneralParameterVisible) return;
		saveParametersToDevice(true);
	}

	function handleChannelAndSensorsPress() {
		if (isChannelsAndSensorsVisible) return;
		saveParametersToDevice(true);
		setIsChannel2Available(selectedDeviceRef.current.channels > 1);
	}

	//#endregion

	const renderFooter = () => {
		return (
			<View>
				<View
					style={[styles.buttonFooter, { opacity: offlineMode ? 0.5 : 1 }]}
					pointerEvents={offlineMode ? 'none' : 'auto'}>
					<SingleButtonFooter
						buttonText={t('saveandconfigure')}
						onButtonPress={onSaveParamsPressed}
						buttonDisabled={false}
						buttonStyle={{ backgroundColor: '#1791E4' }}
						buttonTextStyle={{ color: '#fff' }}
					/>
				</View>
				<View style={styles.footer}>
					<ImageButtonSVG
						svgComponent={<GeneralEnabled />}
						disabledSvgComponent={<General />}
						disabled={!isGeneralParameterVisible}
						svgHeight={30}
						svgWidth={30}
						text='General'
						onPress={() => {
							handleGeneralParametersPress();
						}}
						style={styles.button}
						textStyle={
							isGeneralParameterVisible
								? styles.buttonTextBlue
								: styles.buttonText
						}></ImageButtonSVG>

					<ImageButtonSVG
						svgComponent={<DashboardEnabled />}
						disabledSvgComponent={<Dashboard />}
						disabled={!isChannelsAndSensorsVisible}
						svgHeight={30}
						svgWidth={30}
						text={t('ChannelandSensors')}
						onPress={() => {
							handleChannelAndSensorsPress();
						}}
						style={styles.button}
						textStyle={
							isChannelsAndSensorsVisible
								? styles.buttonTextBlue
								: styles.buttonText
						}></ImageButtonSVG>
				</View>
			</View>
		);
	};

	function getPanelImage(image: string): ReactElement {
		if (image === 'PanelConnected.png') {
			return <BluetoothConnected height={30} width={30} />;
		} else if (image === 'PanelNotConnected.png') {
			return <BluetoothDisabled height={30} width={30} />;
		} else {
			return <BluetoothDisabled height={30} width={30} />;
		}
	}

	return (
		<View style={styles.mainContainer}>
			{/* Header - 10% of height */}
			<SafeAreaContextView edges={['top']} style={styles.safeHeader}>
				<View
					style={[
						styles.headerSection,
						{
							backgroundColor: '#000',
							alignItems: 'center',
						},
					]}>
					<View
						style={{
							flexDirection: 'row',
							alignItems: 'center',
							paddingHorizontal: 10,
							height: '100%',
						}}>
						<TouchableOpacity
							onPress={() => handleBackPress()}
							style={{
								height: '100%',
								padding: 0,
								margin: 0,
								justifyContent: 'center',
							}}>
							<LeftArrowWhite height={30} width={30} />
						</TouchableOpacity>

						<View style={[{ flex: 2 }]}>
							<Text
								style={{
									color: '#fff',
									fontSize: 18,
									fontWeight: 'bold',
									textAlign: 'center',
								}}>
								Device Parameters
							</Text>
						</View>

						{getPanelImage(BluetoothImage)}

						<TouchableOpacity
							disabled={!IsSyncEnabled}
							onPress={() => SyncCommandAsync()}
							style={{
								height: '100%',
								paddingHorizontal: 15,
								margin: 0,
								justifyContent: 'center',
								opacity: IsSyncEnabled ? 1 : 0.5,
							}}>
							<SyncWhite height={24} width={24} />
						</TouchableOpacity>

						<DropdownMenu
							triggerText=''
							menuOptions={[
								...(offlineMode
									? []
									: [
											{
												label: t('ImportConfiguration'),
												onSelect: handleImport,
											},
									  ]),
								{
									label: t('ExportConfiguration'),
									onSelect: exportDeviceParameters,
								},
							]}
							triggerTextStyle={styles.buttonText}
						/>
					</View>
				</View>
			</SafeAreaContextView>

			<View style={styles.contentSection}>
				<MenuProvider>
					<View style={{ flex: 1 }}>
						{/* Main content area - conditionally render based on active screen */}
						{isGeneralParameterVisible && renderGeneralParameter()}
						{isChannelsAndSensorsVisible && renderChannelsandSensors()}

						{!isGeneralParameterVisible &&
							!isChannelsAndSensorsVisible &&
							!isSensorAddressVisible && (
								<View>{/* Items when both screens are false */}</View>
							)}
					</View>
				</MenuProvider>
			</View>

			{/* Footer */}
			<View style={styles.footerSection}>{renderFooter()}</View>
			<TimeoutPopup
				isVisible={showTimeoutPopup}
				onClose={handleCloseTimeoutMessage}
			/>
			{IsAddSparepartVisible && renderAspiratorSparePartChange()}
			{isSensorAddressVisible && renderSensorAddress()}
		</View>
	);
}
const styles = StyleSheet.create({
	//#region Main Content Styles
	mainContainer: {
		flex: 1,
		backgroundColor: '#f5f5f5',
	},
	headerSection: {
		backgroundColor: '#000',
		height: 56,
		width: '100%',
	},
	safeHeader: {
		backgroundColor: '#000',
	},
	contentSection: {
		flex: 1,
		width: '100%',
	},
	footerSection: {
		width: '100%',
		backgroundColor: '#ffffff',
	},
	//#endregion

	footer: {
		backgroundColor: '#ffffffff',
		borderTopWidth: 1,
		borderTopColor: '#e0e0e0',
		flexDirection: 'row',
		justifyContent: 'space-around',
		alignItems: 'center',
	},
	button: {
		marginTop: 5,
		backgroundColor: '#ffffff',
	},
	buttonText: {
		color: '#000000',
		fontSize: 14,
		textAlign: 'center',
	},
	buttonTextBlue: {
		color: '#1792E5',
		fontSize: 14,
		textAlign: 'center',
	},

	container: {
		flex: 1,
		marginHorizontal: 14,
		marginTop: 10,
	},
	header: {
		fontSize: 20,
		fontWeight: 'bold',
		marginBottom: 20,
	},
	section: {
		backgroundColor: '#fff',
		borderRadius: 5,
		paddingHorizontal: 16,
		paddingTop: 16,
		marginBottom: 16,
		borderWidth: 1,
		borderColor: '#e0e0e0',
		elevation: 5,
	},
	sectionTitle: {
		fontSize: 16,
		fontWeight: '600',
		marginBottom: 10,
		paddingBottom: 10,
		borderBottomColor: '#e0e0e0',
	},
	GeneralParameterradioContainer: {
		flexDirection: 'row',
		justifyContent: 'flex-start',
		alignItems: 'center',
		marginVertical: 8,
		paddingBottom: 10,
	},
	radioContainer: {
		flexDirection: 'row',
		justifyContent: 'flex-start',
		alignItems: 'center',
		marginVertical: 8,
		paddingBottom: 5,
		borderBottomWidth: 1,
		borderBottomColor: '#e0e0e0',
	},
	GeneralParameterradioTitle: {
		color: commonColors.textColor_Black,
		fontSize: 15,
		fontWeight: '500',
	},
	radioTitle: {
		fontSize: 15,
		fontWeight: '400',
		marginBottom: 5,
	},
	radiospacebetween: {
		flex: 1,
	},
	radioField: {
		marginTop: 10,
		borderBottomWidth: 1,
		borderBottomColor: '#e0e0e0',
	},
	buttonFooter: {
		borderTopWidth: 1,
		borderTopColor: '#e0e0e0',
		backgroundColor: '#fff',
	},
	dropdownSection: {
		marginTop: 5,
	},
	dropdownLabel: {
		color: commonColors.textColor_Black,
		fontSize: 15,
		fontWeight: '500',
		paddingBottom: 5,
	},
	dropdownButton: {
		flexDirection: 'row',
		alignItems: 'center',
		justifyContent: 'space-between',
		marginBottom: 10,
		height: commonSizes.textBoxHeight_L,
		borderColor: commonColors.textBoxBorderColor,
		borderWidth: commonSizes.textBoXBorderWidthXS,
		borderRadius: commonSizes.cornerRadius,
		paddingHorizontal: commonSizes.paddingM_Percent,
		marginTop: commonSizes.heightS_Pixel,
	},
	dropdownText: {
		flex: 1,
		fontSize: 15,
		color: '#000',
	},
	dropdownIcon: {
		width: 15,
		height: 15,
		marginRight: 10,
	},

	sectionTitleHeading: {
		fontSize: 16,
		fontWeight: '600',
	},
	ActionCongigsectionTitle: {
		fontSize: 16,
		fontWeight: '600',
		marginBottom: 15,
		paddingBottom: 10,
		borderBottomWidth: 1,
		borderBottomColor: '#e0e0e0',
	},
	incrementContainer: {
		flexDirection: 'row',
		alignItems: 'center',
		marginVertical: 8,
		borderWidth: 1,
		borderColor: '#e0e0e0',
	},
	incrementButton: {
		width: 30,
		height: 30,
		justifyContent: 'center',
		alignItems: 'center',
		borderWidth: 1,
		borderColor: '#e0e0e0',
		borderRadius: 5,
	},
	incrementButtonText: {
		fontSize: 18,
		fontWeight: 'bold',
	},
	incrementValueContainer: {
		flex: 1,
		justifyContent: 'center',
		alignItems: 'center',
	},
	incrementValue: {
		fontSize: 16,
	},

	//#region Aspitoror Spare Part Change Modal

	// Add to your existing styles object

	buttonGrid: {
		flexDirection: 'row',
		justifyContent: 'space-between',
		marginBottom: 10,
	},
	buttonGridColumn: {
		flex: 1,
		paddingHorizontal: 5,
	},
	cancelButton: {
		backgroundColor: 'white',
		paddingVertical: 12,
		paddingHorizontal: 10,
		borderRadius: 5,
		borderWidth: 1,
		borderColor: '#1791E4',
		alignItems: 'center',
		justifyContent: 'center',
	},
	cancelButtonText: {
		color: '#1791E4',
		fontSize: 16,
	},
	actionButton: {
		backgroundColor: '#1791E4',
		paddingVertical: 12,
		paddingHorizontal: 10,
		borderRadius: 5,
		alignItems: 'center',
		justifyContent: 'center',
	},
	disabledButton: {
		opacity: 0.5,
	},
	actionButtonText: {
		color: 'white',
		fontSize: 16,
	},
	boldText: {
		fontWeight: 'bold',
	},
	doneButton: {
		backgroundColor: '#1791E4',
		paddingVertical: 12,
		paddingHorizontal: 10,
		borderRadius: 5,
		alignItems: 'center',
		justifyContent: 'center',
		marginTop: 5,
	},
	stepImage: {
		width: 200,
		height: 150,
		resizeMode: 'contain',
		marginBottom: 15,
	},
	checkboxContainer: {
		flexDirection: 'row',
		alignItems: 'center',
		marginVertical: 10,
		paddingBottom: 10,
	},
	checkbox: {
		marginRight: 10,
	},
	checkboxLabel: {
		fontSize: 15,
		color: commonColors.textColor_Black,
		flex: 1,
	},
	addressInput: {
		height: 45,
		borderWidth: 2,
		borderColor: commonColors.textColor_Grey,
		borderRadius: 4,
		paddingHorizontal: 15,
		fontSize: 16,
		color: commonColors.textColor_Black,
		backgroundColor: '#fff',
		marginBottom: 5,
	},
	belowText: {
		fontSize: 12,
		color: commonColors.textColor_Grey,
		marginTop: 5,
	},
	//#endregion

	//#region Password change Styles
	passwordChangeBox: {
		height: commonSizes.textBoxHeight_L,
		borderColor: commonColors.textBoxBorderColor,
		borderWidth: commonSizes.textBoXBorderWidthXS,
		borderRadius: commonSizes.cornerRadius,
		paddingHorizontal: commonSizes.paddingM_Percent,
		color: commonColors.textColor_Grey,
		fontSize: commonSizes.textSizeM,
		textAlignVertical: 'center',
	},
	//#endregion
	fixedFieldWrapper: {
		flexDirection: 'row',
		alignItems: 'center',
		justifyContent: 'space-between',
		height: commonSizes.textBoxHeight_L,
		borderColor: commonColors.textBoxBorderColor,
		borderWidth: commonSizes.textBoXBorderWidthXS,
		borderRadius: commonSizes.cornerRadius,
		paddingHorizontal: commonSizes.paddingM_Percent,
		color: commonColors.textColor_Grey,
		fontSize: commonSizes.textSizeM,
		marginTop: commonSizes.heightS_Pixel,
		opacity: 0.7,
	},
	fixedFieldInput: {
		flex: 1,
		padding: 10,
		color: '#495057',
		fontSize: 16,
	},
	fixedFieldRightText: {
		fontSize: 14,
		color: 'rgba(100,100,100,0.5)',
	},
});

const pickerSelectStyles = {
	inputIOS: {
		fontSize: 15,
		padding: 10,
		borderWidth: 1,
		borderColor: '#9D9D9D',
		borderRadius: 4,
		color: '#000',
		paddingHorizontal: 20,
		backgroundColor: '#fff',
		margin: 0,
	},
	inputAndroid: {
		fontSize: 15,
		padding: 10,
		borderWidth: 1,
		borderColor: '#9D9D9D',
		borderRadius: 2,
		color: '#000',
		paddingHorizontal: 20,
		backgroundColor: '#fff',
		margin: 0,
	},
	iconContainer: {
		top: 12,
		right: 12,
	},
};
