import React, { useEffect, useRef, useState } from 'react';
import {
	View,
	StyleSheet,
	ScrollView,
	Text,
	TouchableOpacity,
	Image,
	BackHandler,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useForm, Controller } from 'react-hook-form';
import { yupResolver } from '@hookform/resolvers/yup';
import * as Yup from 'yup';
import { commonColors, commonSizes } from '@styles/base';
import RNPickerSelect from 'react-native-picker-select';
import DropDownIcon from '@assets/images/DropDownIcon.svg';
import { RadioButtonGroup } from '@components/RadioButton';
import TextInputField from '@components/textInputField';
import DoubleButtonFooter from '@components/doubleButtonFooter';
import { DeviceModel } from '@ff_model/deviceModel';
import { useAppDispatch } from '@global/hooks';
import { useDatabase } from '@global/DatabaseContext';
import {
	addNewDevice,
	fetchDeviceById,
	updateExistingDevice,
} from '@ff_redux/deviceRedux/devicesThunk';
import { useTranslation } from 'react-i18next';
import LeftArrowWhite from '@assets/images/LeftArrowWhite.svg';
import { AppConstants } from '@global/GlobalConstants/globalConstants';

const maxLength = 50;

// Define Yup validation schema
const deviceSchema = Yup.object().shape({
	deviceName: Yup.string()
		.required('Device Name is required')
		.max(maxLength, 'Device name cannot exceed 50 characters')
		.matches(/^[a-zA-Z0-9 _-]*$/, 'Device name contains Invalid Character'),
	pipeConfiguration: Yup.string().required('Pipe Configuration is required'),
	deviceLocation: Yup.string()
		.required('Device Location is required')
		.max(maxLength, 'Device Location cannot exceed 50 characters')
		.matches(/^[a-zA-Z0-9 _-]*$/, 'Device location contains Invalid Character'),
	channels: Yup.number().required('Select Channel'),
	pipeLength: Yup.number()
		.typeError('Pipe length must be a number')
		.optional()
		.positive('Pipe Length should not be negative and empty')
		.min(0, 'Total Pipe length should be from 0 - 160.0 meter')
		.max(160, 'Total Pipe length should be from 0 - 160.0 meter'),
	minTransportTime: Yup.number()
		.typeError('Minimum Transport Time must be a number')
		.optional()
		.positive('Minimum Transport time should not be negative and empty')
		.min(0, 'Transport time should be from 0-120 seconds')
		.max(120, 'Transport time should be from 0-120 seconds'),
	maxTransportTime: Yup.number()
		.typeError('Maximum Transport Time must be a number')
		.optional()
		.positive('Maximum Transport time should not be negative and empty')
		.min(0, 'Maximum Transport time should be from 0-120 seconds')
		.max(120, 'Maximum Transport time should be from 0-120 seconds'),
});

export default function CreateOrEditDeviceScreen({ route, navigation }: any) {
	const dispatch = useAppDispatch();
	const { dataSource } = useDatabase();
	const { t } = useTranslation();

	const pipeConfigurations = ['I', 'U', 'M', '2U'];
	const radiobuttonOptions = [
		{ label: '01', value: 1 },
		{ label: '02', value: 2 },
	];
	const [NewPaneltitle, setNewPaneltitle] = useState<string>(t('addnewdevice'));
	const [EditedDevice, setEditedDevice] = useState<DeviceModel>(
		new DeviceModel(),
	);
	const [IsEnabledChannel, setIsEnabledChannel] = useState<boolean>(true);
	const editedDeviceRef = useRef<DeviceModel>(new DeviceModel());
	const isNewDeviceRef = useRef<boolean>(true);
	const isFromProjectHomeRef = useRef<boolean>(true);
	const deviceId = useRef<number>(0);
	const projectId = useRef<number>(0);
	const {
		control,
		handleSubmit,
		reset,
		clearErrors,
		setValue,
		formState: { errors },
	} = useForm<DeviceModel>({
		resolver: yupResolver(deviceSchema) as any,
		defaultValues: {
			deviceName: '',
			deviceLocation: '',
			pipeConfiguration: '',
			pipeLength: 0,
			channels: 0,
			minTransportTime: 0,
			maxTransportTime: 0,
		},
		mode: 'onChange',
	});

	function getDefaultPipeConfiguration(configuration: string): string {
		if (!editedDeviceRef.current?.pipeConfiguration) return '';

		// Find the matching pipe configuration or return empty string
		return pipeConfigurations.find(config => config === configuration) || '';
	}

	//#region  On Screen Appeared
	useEffect(() => {
		console.log('Route params:', route.params);
		InitializeAsync();
	}, []);

	useEffect(() => {
		const unsubscribe = navigation.addListener('focus', () => {
			OnPageAppeared();
		});
		return unsubscribe;
	}, [navigation]);
	//#endregion

	//#region Prevent Device Back Functionality
	useEffect(() => {
		const backHandler = BackHandler.addEventListener(
			'hardwareBackPress',
			() => {
				return true; // Return true to prevent default back behavior
			},
		);

		return () => backHandler.remove();
	}, []);

	//iOS
	useEffect(() => {
		navigation.setOptions({
			gestureEnabled: false, // Disable swipe back gesture
		});
	}, [navigation]);
	//#endregion

	async function OnPageAppeared() {
		// Any actions needed when the page appears can be added here
	}
	async function InitializeAsync() {
		if (
			route.params !== null &&
			route.params !== undefined &&
			route.params.isFromProjectHome !== null
		) {
			const isFromProjectHome = route.params.isFromProjectHome as boolean;
			isFromProjectHomeRef.current = isFromProjectHome;
		}
		if (
			route.params !== null &&
			route.params !== undefined &&
			route.params.isNewDevice !== null
		) {
			const isNewDevice = route.params.isNewDevice as boolean;
			isNewDeviceRef.current = isNewDevice;
			if (isNewDevice) {
				setNewPaneltitle(t('addnewdevice'));
				clearErrors();
				setValue('deviceName', '');
				setValue('deviceLocation', '');
				setValue('pipeConfiguration', getDefaultPipeConfiguration('I'));
				setValue('channels', 1);
				setValue('pipeLength', 0);
				setValue('minTransportTime', 0);
				setValue('maxTransportTime', 0);
			} else {
				setNewPaneltitle(t('editdev'));
				if (
					route.params !== null &&
					route.params !== undefined &&
					route.params.device !== null
				) {
					let device = route.params.device as DeviceModel;
					setEditedDevice(device);
					editedDeviceRef.current = device;
					deviceId.current = device.deviceId;
					const deviceResult = await dispatch(
						fetchDeviceById({
							dataSource,
							deviceId: editedDeviceRef.current.deviceId,
						}),
					).unwrap();
					if (deviceResult !== null && deviceResult !== undefined) {
						if (deviceResult.channels !== editedDeviceRef.current.channels) {
							const tempDevice = {
								...editedDeviceRef.current,
								channels: deviceResult.channels,
							};
							setEditedDevice(tempDevice);
							editedDeviceRef.current = tempDevice;
						}

						clearErrors();
						setValue('deviceName', editedDeviceRef.current.deviceName);
						setValue('deviceLocation', editedDeviceRef.current.deviceLocation);
						setValue(
							'pipeConfiguration',
							getDefaultPipeConfiguration(
								editedDeviceRef.current.pipeConfiguration,
							),
						);
						setValue('channels', editedDeviceRef.current.channels);
						setValue('pipeLength', editedDeviceRef.current.pipeLength);
						setValue(
							'minTransportTime',
							editedDeviceRef.current.minTransportTime,
						);
						setValue(
							'maxTransportTime',
							editedDeviceRef.current.maxTransportTime,
						);
						if (
							editedDeviceRef.current.deviceMacAddress !==
							AppConstants.NotYetConnected
						) {
							setIsEnabledChannel(false);
						}
					}
				}
			}
		}
		if (
			route.params !== null &&
			route.params !== undefined &&
			route.params.projectId !== null
		) {
			projectId.current = route.params.projectId as number;
		}
	}

	const handleCancel = () => {
		navigation.goBack();
	};

	let _allowDeviceCreation = true;
	async function CreatePanelCommand(data: DeviceModel) {
		try {
			if (_allowDeviceCreation) {
				_allowDeviceCreation = false;
				let isValid = true;
				if (isValid) {
					if (isNewDeviceRef.current) {
						let newDevice = new DeviceModel();
						newDevice.projectId = projectId.current;
						newDevice.deviceName = data.deviceName;
						newDevice.deviceLocation = data.deviceLocation;
						newDevice.pipeConfiguration = data.pipeConfiguration;
						newDevice.channels = data.channels;
						newDevice.pipeLength = data.pipeLength ?? 0;
						newDevice.minTransportTime = data.minTransportTime ?? 0;
						newDevice.maxTransportTime = data.maxTransportTime ?? 0;
						newDevice.isConfigDataFetched = false;

						await dispatch(addNewDevice({ dataSource, device: newDevice }));
					} else {
						let updatedDevice = { ...editedDeviceRef.current };
						updatedDevice.projectId = projectId.current;
						updatedDevice.deviceName = data.deviceName;
						updatedDevice.deviceLocation = data.deviceLocation;
						updatedDevice.pipeConfiguration = data.pipeConfiguration;
						updatedDevice.channels = data.channels;
						updatedDevice.pipeLength = data.pipeLength ?? 0;
						updatedDevice.minTransportTime = data.minTransportTime ?? 0;
						updatedDevice.maxTransportTime = data.maxTransportTime ?? 0;
						updatedDevice.deviceId = deviceId.current;
						await dispatch(
							updateExistingDevice({
								dataSource,
								deviceId: updatedDevice.deviceId,
								updates: updatedDevice,
							}),
						);
					}
					if (isFromProjectHomeRef.current) {
						navigation.replace(AppConstants.DeviceListScreen, {
							projectId: projectId.current,
						});
					} else {
						navigation.goBack();
					}
				} else {
					_allowDeviceCreation = true;
				}
			}
		} catch (error) {
			_allowDeviceCreation = true;
		}
	}

	const BackButtonCommand = () => {
		navigation.goBack();
	};

	const renderHeader = () => {
		return (
			<SafeAreaView edges={['top']} style={styles.safeHeader}>
				<View
					style={[
						styles.headerSection,
						{
							backgroundColor: '#000',
							alignItems: 'center',
						},
					]}>
					<View
						style={{
							flexDirection: 'row',
							alignItems: 'center',
							paddingHorizontal: 10,
							height: '100%',
							backgroundColor: '#000',
						}}>
						<TouchableOpacity
							onPress={() => BackButtonCommand()}
							style={{
								height: '100%',
								padding: 0,
								margin: 0,
								justifyContent: 'center',
							}}>
							<LeftArrowWhite height={30} width={30} />
						</TouchableOpacity>

						<View style={[{ flex: 2 }]}>
							<Text
								style={{
									color: '#fff',
									fontSize: 18,
									fontWeight: 'bold',
									textAlign: 'center',
								}}>
								{NewPaneltitle}
							</Text>
						</View>
					</View>
				</View>
			</SafeAreaView>
		);
	};

	return (
		<View style={styles.container}>
			{renderHeader()}

			<ScrollView
				contentContainerStyle={styles.scrollContainer}
				showsVerticalScrollIndicator={true}>
				<TextInputField
					name='deviceName'
					control={control}
					placeholder={t('Enterdevicename')}
					title={t('devicename')}
					isRequired={true}
					errorMessage={errors.deviceName?.message}
					maxChar={maxLength}
				/>
				<TextInputField
					name='deviceLocation'
					control={control}
					placeholder={t('Enterdevicelocation')}
					title={t('DeviceLoaction')}
					isRequired={true}
					errorMessage={errors.deviceLocation?.message}
					maxChar={maxLength}
				/>
				<Text style={styles.fieldTitle}>{t('PipeConfiguration')}</Text>
				<Controller
					control={control}
					name='pipeConfiguration'
					render={({ field: { onChange, value } }) => (
						<RNPickerSelect
							value={value}
							onValueChange={onChange}
							useNativeAndroidPickerStyle={false}
							placeholder={{
								label: t('SelectPipeConfiguration'),
								value: null,
							}}
							style={{
								inputIOS: {
									height: commonSizes.textBoxHeight_L,
									width: '100%',
									color: commonColors.textColor_Black,
									fontSize: commonSizes.textSizeM,
									paddingLeft: commonSizes.paddingL_Percent,
								},
								inputAndroid: {
									height: commonSizes.textBoxHeight_L,
									width: '100%',
									color: commonColors.textColor_Black,
									fontSize: commonSizes.textSizeM,
									paddingLeft: commonSizes.paddingL_Percent,
								},
								inputIOSContainer: {
									borderWidth: commonSizes.textBoXBorderWidthXS,
									borderColor: commonColors.textBoxBorderColor,
									borderRadius: commonSizes.cornerRadius,
									marginBottom: commonSizes.heightS_Pixel,
								},
								inputAndroidContainer: {
									borderWidth: commonSizes.textBoXBorderWidthXS,
									borderColor: commonColors.textBoxBorderColor,
									borderRadius: commonSizes.cornerRadius,
									marginBottom: commonSizes.heightS_Pixel,
								},
							}}
							items={[
								{ label: 'I', value: 'I' },
								{ label: 'U', value: 'U' },
								{ label: 'M', value: 'M' },
								{ label: '2U', value: '2U' },
							]}
							Icon={() => {
								return (
									<View style={styles.DropdownImageContainer}>
										<DropDownIcon />
									</View>
								);
							}}
						/>
					)}
				/>
				<Text style={styles.fieldTitle}>{t('channels')}</Text>
				<Controller
					control={control}
					name='channels'
					render={({ field: { onChange, value } }) => (
						<>
							<RadioButtonGroup
								options={radiobuttonOptions}
								value={value}
								onChange={onChange}
								isRequired={true}
								errorMessage={errors.channels?.message}
								disabled={!IsEnabledChannel}
							/>
							{errors.channels && (
								<Text style={styles.errorText}>{errors.channels.message}</Text>
							)}
						</>
					)}
				/>
				<TextInputField
					name='pipeLength'
					control={control}
					placeholder='0'
					title={t('PipeLength')}
					errorMessage={errors.pipeLength?.message}
					maxChar={maxLength}
				/>
				<TextInputField
					name='minTransportTime'
					control={control}
					placeholder='0'
					title={t('minTransportTime')}
					errorMessage={errors.minTransportTime?.message}
					maxChar={maxLength}
				/>
				<TextInputField
					name='maxTransportTime'
					control={control}
					placeholder='0'
					title={t('maxTransportTime')}
					errorMessage={errors.maxTransportTime?.message}
					maxChar={maxLength}
				/>
			</ScrollView>
			<View
				style={{
					borderTopColor: commonColors.lineColor,
					borderTopWidth: commonSizes.lineThicknessS,
					backgroundColor: commonColors.backgroundColor_White,
				}}>
				<View style={{ marginHorizontal: '2%' }}>
					<DoubleButtonFooter
						leftButtonText={t('cancel')}
						rightButtonText={t('createdev')}
						onLeftButtonPress={() => handleCancel()}
						onRightButtonPress={handleSubmit(CreatePanelCommand)}
					/>
				</View>
			</View>
		</View>
	);
}

const styles = StyleSheet.create({
	container: {
		flex: 1,
		justifyContent: 'space-evenly',
		backgroundColor: commonColors.backgroundColor_White,
	},
	fieldTitle: {
		color: commonColors.textColor_Black,
		fontSize: commonSizes.textSizeL,
		fontWeight: '500',
	},
	scrollContainer: {
		flexGrow: 1,
		paddingHorizontal: commonSizes.paddingXL_Percent,
		paddingTop: commonSizes.paddingXL_Percent,
		gap: '2%',
	},
	DropdownImageContainer: {
		width: commonSizes.iconWidthM_Pixel,
		height: commonSizes.iconHeightM_Pixel,
		marginEnd: commonSizes.widthXS_Pixel,
		marginVertical: commonSizes.widthM_Pixel,
		alignItems: 'center',
	},
	errorText: {
		color: 'red',
	},
	headerSection: {
		height: 56,
		width: '100%',
	},
	safeHeader: {
		backgroundColor: '#000',
	},
});
