import React, { ReactElement, useEffect, useRef, useState } from 'react';
import {
	View,
	StyleSheet,
	SafeAreaView,
	ScrollView,
	Text,
	TextInput,
	TouchableOpacity,
	Image,
	Alert,
	Modal,
	Platform,
	Linking,
	BackHandler,
} from 'react-native';
import {
	SafeAreaProvider,
	SafeAreaView as SafeAreaContextView,
} from 'react-native-safe-area-context';
import { MenuProvider } from 'react-native-popup-menu';
import { check, request, PERMISSIONS, RESULTS } from 'react-native-permissions';
import * as yup from 'yup';
import { yupResolver } from '@hookform/resolvers/yup';
import { Controller, useForm } from 'react-hook-form';
import DropDown from '@ff_controllers/dropdown.tsx';
import SingleButtonFooter from '@components/singleButtonFooter';
import RadioButton from '@components/RadioButton';
import TextInputField from '@ff_controllers/textInputField.tsx';
import DateTime from '@ff_controllers/dateTime.tsx';
import CustomInput from '@ff_controllers/customInputField.tsx';
import PasswordModal from '@ff_controllers/passwordModal.tsx';
import { commonColors, commonSizes } from '@styles/base';
import dropdownIcon from '@assets/images/DropDownIcon.svg';
import IncrementDecrement from '@ff_controllers/incrementAndDecrement.tsx';
import TimeoutPopup from '@ff_controllers/timeoutPopup.tsx';
import { ObscurationUnit } from '@faastflex/faastflexEnum/obscurationUnit.ts';
import { useDatabase } from '../../../global/DatabaseContext.tsx';
import { useAppDispatch } from '../../../global/hooks.ts';
import {
	addNewDeviceParameter,
	updateExistingDeviceParameter,
	fetchDeviceParameter,
} from '@ff_redux/deviceParameterRedux/deviceParameterThunk.ts';

import { DeviceModel } from '@ff_model/deviceModel.ts';
import { delay } from '@ff_utils/timeDelay.ts';
//import { TimeSpan } from '@ff_utils/timeSpan.ts';
import {
	AlarmLevel,
	AlarmMode,
	Channel,
	Configuration,
	Country,
	DeviceStatus,
	DeviceType,
	ErrorCode,
	ExternalInputAction,
	ExternalInputMode,
	ExternalInputNormalState,
	FanPWMPercCorrection,
	FanSpeedLevel,
	getConfigurationDescription,
	getCountryDescription,
	getDeviceOrientationDescription,
	getDeviceTypeDescription,
	getExternalInputActionDescription,
	getExternalInputNormalStateDescription,
	getFanPWMPercCorrectionDescription,
	LatchedMode,
	PreAlarmLevel,
	RelayAlert,
} from '@faastflexCommands/commandEnum.ts';
import { DeviceGPIParams } from '@faastflexCommands/common_objects.ts';
import faastflexBluetoothCommunicator from '@faastflexCommunicator/faastflexBluetoothCommunicator.ts';
import { DeviceParametersModel } from '@ff_model/deviceParametersModel.ts';
import { confirmAlert } from '@ff_utils/confirmAlert.ts';
import DropdownMenu from '@ff_controllers/dropdownController.tsx';
import { useLoading } from '../../../global/GlobalContext/LoadingContext.tsx';
import Toast from 'react-native-toast-message';
import RNPickerSelect from 'react-native-picker-select';
import { updateExistingDevice } from '../redux/deviceRedux/devicesThunk';

import RNFS from 'react-native-fs';
import { pick } from '@react-native-documents/picker';
import {
	decryptAndParseConfigFile,
	encryptAndSerializeConfigFile,
} from '@ff_utils/fileDecryption';
// import { examineFileContent, testJustDecryption, testDecryptionBasics } from '../../@ff_utils/debugDecryption';
import { BluetoothDevice } from 'bleCommunicator/bleService.ts';
import { useTranslation } from 'react-i18next';
import QRScanner from '@components/QRScanner.tsx';
import CustomProgressBar from '@ff_controllers/customProgressBar.tsx';
import LeftArrowWhite from '@assets/images/LeftArrowWhite.svg';
import Dashboard from '@assets/images/Dashboard.svg';
import DashboardEnabled from '@assets/images/DashboardEnabled.svg';
import General from '@assets/images/General.svg';
import GeneralEnabled from '@assets/images/GeneralEnabled.svg';
import ImageButtonSVG from '@ff_controllers/imageButtonSVG.tsx';
import AspiratorQR from '@assets/images/AspiratorQR.svg';
import AspiratorChange from '@assets/images/AspiratorChange.svg';
import AspiratorCover from '@assets/images/AspiratorCover.svg';
import AspiratorCoverRemoval from '@assets/images/AspiratorCoverRemoval.svg';
import PassIcon from '@assets/images/Pass.svg';
import FailIcon from '@assets/images/Fail.svg';
import { CustomTimer } from '@ff_utils/customTimer.ts';
import BluetoothConnected from '@assets/images/BluetoothConnected.svg';
import BluetoothDisabled from '@assets/images/BluetoothDisabled.svg';
import SyncWhite from '@assets/images/SyncWhite.svg';
import SyncBlue from '@assets/images/SyncBlue.svg';
import stringFormat from '@ff_utils/stringFormat.ts';
import DropDownIcon from '@assets/images/DropDownIcon.svg';
import { AppConstants } from '@global/GlobalConstants/globalConstants.ts';
import useSyncedState from '@global/Hooks/useSyncedState.ts';
import {
	convertValueToObscurationUnit,
	convertBackObscurationUnitToValue,
} from '@faastflex/converters/obscurationUnitConverter.ts';
import { StackActions, useNavigation } from '@react-navigation/native';
import { el } from 'date-fns/locale';
import Share from 'react-native-share';

//#region Constants
const FF_DateTime = 'DateTime';
const FF_TrendLogDisabled = 'TrendLogDisabled';
const FF_TemperatureFaultRelay = 'TemperatureFaultRelay';
const FF_LowPowerFaultRelay = 'LowPowerFaultRelay';
const FF_GPIInputStateSupervised = 'GPIInputStateSupervised';
const FF_ExternalTriggerOnOpen = 'ExternalTriggerOnOpen';
const FF_ExternalTriggerOnClosed = 'ExternalTriggerOnClosed';
const FF_GPIInputStateUnSupervised = 'GPIInputStateUnSupervised';
const FF_ExternalInputNormalState = 'ExternalInputNormalState';
const FF_UnbalancedEventTriggered = 'UnbalancedEventTriggered';
const FF_BlowerSpeed = 'BlowerSpeed';
const FF_ActionDelay = 'PreAlarmDelay';
const FF_AlarmDelay = 'AlarmDelay';
const FF_FlowFaultDelay = 'FlowFaultDelay';
const FF_AlarmLatched = 'AlarmLatched';
const FF_ActionLatched = 'PreAlarmLatched';
const FF_FaultLatched = 'FaultLatched';
const FF_AlarmMode = 'AlarmMode';
const FF_Channel1AlarmLevel = 'Channel1AlarmLevel';
const FF_Channel1ActionLevel = 'Channel1PreAlarmLevel';
const FF_FlowFaultThreshold1 = 'FlowFaultThreshold1';
const FF_Channel2AlarmLevel = 'Channel2AlarmLevel';
const FF_Channel2ActionLevel = 'Channel2PreAlarmLevel';
const FF_FlowFaultThreshold2 = 'FlowFaultThreshold2';

const GPI_Open = 'Open';
const GPI_Short = 'Short';
const GPI_None = 'None';
const GPI_RestAlarmsAndFault = 'Rest Alarms and Fault';
const GPI_PerformDisableAction = 'Perform Disable Action';
const GPI_TriggerExtFault = 'Trigger Ext. Fault';
const GPI_ResetDevice = 'Reset Device';
//#endregion
interface GeneralParametersData {
	Orientation: string;
	selectedDate: Date;
	selectedTime: Date;
	TrendLogInterval: number;
	isTemparatureFaultSetRelays: number;
	isLowPowerFaultSetRelays: number;
	blowerSpeed: number;
	blowerCorrection: string;
}

const GeneralSchema = yup.object().shape({
	TrendLogInterval: yup
		.number()
		.required('Trend Log Interval is required')
		.typeError('Trend Log Interval is Required')
		.integer('Trend Log Interval must be an integer')
		.min(0, 'Trend Log Interval must be between 0 and 240 seconds')
		.max(240, 'Trend Log Interval must be between 0 and 240 seconds'),
});

interface ChannelsAndSensorsData {
	ActionDelay: number;
	AlarmDelay: number;
	FlowFaultDelay: number;
	AlarmConfiguration: number;
	ActionConfiguration: number;
	FaultConfiguration: number;
	AlarmMode: number;
	ActionLevel1: number;
	AlarmLevel1: number;
	Referenceflow1: number;
	FlowFaultThreshold1: number;
	FlowFaultThreshold1Value: number;
	ActionLevel2?: number;
	AlarmLevel2?: number;
	Referenceflow2?: number;
	FlowFaultThreshold2?: number;
	FlowFaultThreshold2Value: number;
}

const ChannelAndSensorsSchema = yup.object().shape({
	ActionDelay: yup
		.number()
		.required('Action Delay is required')
		.typeError('Action Delay is Required')
		.integer('Action Delay must be an integer')
		.min(0, 'Action Delay must be between 0 and 240 seconds')
		.max(240, 'Action Delay must be between 0 and 240 seconds'),
	AlarmDelay: yup
		.number()
		.required('Alarm Delay is required')
		.typeError('Alarm Delay must Required')
		.integer('Alarm Delay must be an integer')
		.min(0, 'Alarm Delay must be between 0 and 240 seconds')
		.max(240, 'Alarm Delay must be between 0 and 240 seconds'),
	FlowFaultDelay: yup
		.number()
		.required('Flow Fault Delay is required')
		.typeError('Flow Fault Delay must Requird')
		.integer('Flow Fault Delay must be an integer')
		.min(0, 'Flow Fault Delay must be between 0 and 240 seconds')
		.max(240, 'Flow Fault Delay must be between 0 and 240 seconds'),
	ActionLevel1: yup
		.number()
		.required('Action Level is required')
		.min(0, 'Value Should be any integer between 0 and 8')
		.max(8, 'Value Should be any integer between 0 and 8'),
	AlarmLevel1: yup
		.number()
		.required('Alarm Level is required')
		.min(0, 'Value Should be any integer between 0 and 9')
		.max(9, 'Value Should be any integer between 0 and 9'),
	Referenceflow1: yup.number().required('Reference Flow is required'),
	FlowFaultThreshold1: yup
		.number()
		.required('Flow Fault Threshold is required'),
	FlowFaultThreshold1Value: yup
		.number()
		.required('Use EN54 Limit is required')
		.min(0, 'Value Should be any integer between 10 and 80')
		.max(80, 'Value Should be any integer between 10 and 80'),
	ActionLevel2: yup.number().when([], (fields, schema, context: any) => {
		return context && context.IsChannel2Available
			? schema
					.required('Action Level is required')
					.min(0, 'Value Should be any integer between 0 and 8')
					.max(8, 'Value Should be any integer between 0 and 8')
			: schema.notRequired();
	}),
	AlarmLevel2: yup.number().when([], (fields, schema, context: any) => {
		return context && context.IsChannel2Available
			? schema
					.required('Alarm Level is required')
					.min(0, 'Value Should be any integer between 0 and 9')
					.max(9, 'Value Should be any integer between 0 and 9')
			: schema.notRequired();
	}),
	Referenceflow2: yup.number().when([], (fields, schema, context: any) => {
		return context && context.IsChannel2Available
			? schema.required('Reference Flow is required')
			: schema.notRequired();
	}),
	FlowFaultThreshold2: yup.number().when([], (fields, schema, context: any) => {
		return context && context.IsChannel2Available
			? schema.required('Flow Fault Threshold is required')
			: schema.notRequired();
	}),
	FlowFaultThreshold2Value: yup
		.number()
		.when([], (fields, schema, context: any) => {
			return context && context.IsChannel2Available
				? schema
						.required('Flow Fault Threshold is required')
						.min(0, 'Value Should be any integer between 10 and 80')
						.max(80, 'Value Should be any integer between 10 and 80')
				: schema.notRequired();
		}),
});
export default function DeviceParameterScreen({ route, navigation }: any) {
	//#region Export DeviceParametersModel to Downloads folder
	const exportDeviceParameters = async () => {
		try {
			// Use the encryption function to create encrypted XML data
			const encryptedData = encryptAndSerializeConfigFile(
				deviceParameters.current,
			);

			const fileName = `DeviceParameters_${Date.now()}.sfc`;
			// Write to app's downloads directory
			const directoryPath =
				Platform.OS === 'ios'
					? RNFS.DocumentDirectoryPath
					: RNFS.DownloadDirectoryPath;
			const filePath = `${directoryPath}/${fileName}`;

			// Write the encrypted data as base64 to the file
			await RNFS.writeFile(filePath, encryptedData, 'base64');

			const answer = await confirmAlert(
				stringFormat(t('DeviceExportedAndShareConfirmation'), filePath),
				t('lblExported'),
				t('Share'),
				t('Cancel_PascalCase'),
			);
			if (answer) {
				try {
					const shareOptions = {
						title: fileName,
						url: Platform.OS === 'ios' ? filePath : `file://${filePath}`,
						type: 'text/plain',
						filename: fileName,
						failOnCancel: false,
					};
					await Share.open(shareOptions)
						.then(res => {
							console.log('Share result:', res);
							Toast.show({
								type: 'success',
								text1: stringFormat(t('DeviceExported'), filePath),
								text2: fileName,
								position: 'bottom',
							});
						})
						.catch(error => {
							console.log('Share error:', error);
							if (
								error.message &&
								error.message.includes('User did not share')
							) {
								console.log('User cancelled share');
							} else {
								Alert.alert(t('warning'), t('msgPleaseTryAgain'), [
									{ text: t('ok') },
								]);
							}
						});
				} catch (error) {
					Alert.alert(t('warning'), t('msgPleaseTryAgain'), [
						{ text: t('ok') },
					]);
				}
			}
		} catch (error: any) {
			Alert.alert(t('warning'), t('msgPleaseTryAgain'), [{ text: t('ok') }]);
		}
	};
	//#endregion

	//#region Map XML data to DeviceParametersModel
	function mapXmlDataToDeviceParameters(
		deviceParams: DeviceParametersModel,
		xmlData: any,
		isOlderConfig: boolean,
	) {
		try {
			if (isOlderConfig) {
				// Handle date/time properties
				if (xmlData.InstallationDate) {
					const dateValue =
						xmlData.InstallationDateTime || xmlData.installationDateTime;
					const parsedDate = new Date(dateValue);

					// Check if date is default/invalid date (0001-01-01T00:00:00)
					if (
						parsedDate.getFullYear() === 1 ||
						parsedDate.getTime() === 0 ||
						isNaN(parsedDate.getTime())
					) {
						deviceParams.installationDateTime = new Date();
						deviceParams.installationDate = new Date();
					} else {
						deviceParams.installationDateTime = parsedDate;
						deviceParams.installationDate = parsedDate;
					}
				}
				// Handle numeric properties
				if (xmlData.TrendLogDisabled !== undefined)
					deviceParams.trendLogDisabled = Number(xmlData.TrendLogDisabled);
				if (xmlData.ActionDelay !== undefined)
					deviceParams.actionDelay = Number(xmlData.ActionDelay);
				if (xmlData.AlarmDelay !== undefined)
					deviceParams.alarmDelay = Number(xmlData.AlarmDelay);
				if (xmlData.FlowFaultDelay !== undefined)
					deviceParams.flowFaultDelay = Number(xmlData.FlowFaultDelay);
				if (xmlData.BlowerCorrection !== undefined)
					deviceParams.blowerCorrection = String(xmlData.BlowerCorrection);

				// Handle enum properties
				if (xmlData.TemperatureFaultRelay !== undefined) {
					deviceParams.temperatureFaultRelay =
						xmlData.TemperatureFaultRelay === 'eSet'
							? RelayAlert.eSet
							: xmlData.TemperatureFaultRelay === 'eUnset'
							? RelayAlert.eUnset
							: RelayAlert.eUnknown;
				}
				if (xmlData.LowPowerFaultRelay !== undefined) {
					deviceParams.lowPowerFaultRelay =
						xmlData.LowPowerFaultRelay === 'eSet'
							? RelayAlert.eSet
							: xmlData.LowPowerFaultRelay === 'eUnset'
							? RelayAlert.eUnset
							: RelayAlert.eUnknown;
				}
				if (xmlData.BlowerSpeed !== undefined) {
					if (
						xmlData.BlowerSpeed === 'eLevel_1' ||
						xmlData.BlowerSpeed === 'eLevel_2' ||
						xmlData.BlowerSpeed === 'eLevel_3' ||
						xmlData.BlowerSpeed === 'eLevel_4' ||
						xmlData.BlowerSpeed === 'eLevel_5' ||
						xmlData.BlowerSpeed === 'eLevel_6'
					) {
						deviceParams.blowerSpeed = 0;
					} else if (
						xmlData.BlowerSpeed === 'eLevel_7' ||
						xmlData.BlowerSpeed === 'eLevel_8' ||
						xmlData.BlowerSpeed === 'eLevel_9' ||
						xmlData.BlowerSpeed === 'eLevel_10'
					) {
						deviceParams.blowerSpeed = 1;
					} else {
						deviceParams.blowerSpeed = 1;
					}
				}

				if (xmlData.AlarmLateched !== undefined) {
					deviceParams.alarmLatched =
						xmlData.AlarmLateched === 'eLatched'
							? LatchedMode.eLatched
							: xmlData.AlarmLateched === 'eUnlatched'
							? LatchedMode.eUnlatched
							: LatchedMode.eUnknown;
				}
				if (xmlData.ActionLateched !== undefined) {
					deviceParams.actionLatched =
						xmlData.ActionLateched === 'eLatched'
							? LatchedMode.eLatched
							: xmlData.ActionLateched === 'eUnlatched'
							? LatchedMode.eUnlatched
							: LatchedMode.eUnknown;
				}
				if (xmlData.FaultLateched !== undefined) {
					deviceParams.faultLatched =
						xmlData.FaultLateched === 'eLatched'
							? LatchedMode.eLatched
							: xmlData.FaultLateched === 'eUnlatched'
							? LatchedMode.eUnlatched
							: LatchedMode.eUnknown;
				}
				if (xmlData.DeviceAlarmMode !== undefined) {
					deviceParams.deviceAlarmMode =
						xmlData.DeviceAlarmMode === 'eDown_Cumulative'
							? AlarmMode.eDown_Cumulative
							: xmlData.DeviceAlarmMode === 'eUp_InstantFire'
							? AlarmMode.eUp_InstantFire
							: AlarmMode.eUnknown;
				}

				// Handle channel properties
				if (xmlData.Channel1ActionLevel !== undefined)
					deviceParams.channel1ActionLevel = Number(
						xmlData.Channel1ActionLevel,
					);
				if (xmlData.Channel1AlarmLevel !== undefined)
					deviceParams.channel1AlarmLevel = Number(xmlData.Channel1AlarmLevel);
				if (xmlData.FlowFaultThresholdCh1 !== undefined)
					deviceParams.flowFaultThresholdCh1 = Number(
						xmlData.FlowFaultThresholdCh1,
					);
				if (xmlData.ReferenceFlowCh1 !== undefined)
					deviceParams.referenceFlowCh1 = Number(xmlData.ReferenceFlowCh1);

				if (xmlData.Channel2ActionLevel !== undefined)
					deviceParams.channel2ActionLevel = Number(
						xmlData.Channel2ActionLevel,
					);
				if (xmlData.Channel2AlarmLevel !== undefined)
					deviceParams.channel2AlarmLevel = Number(xmlData.Channel2AlarmLevel);
				if (xmlData.FlowFaultThresholdCh2 !== undefined)
					deviceParams.flowFaultThresholdCh2 = Number(
						xmlData.FlowFaultThresholdCh2,
					);
				if (xmlData.ReferenceFlowCh2 !== undefined)
					deviceParams.referenceFlowCh2 = Number(xmlData.ReferenceFlowCh2);

				// Handle GPI properties
				if (xmlData.GPInputState !== undefined) {
					deviceParams.gpInputState =
						xmlData.GPInputState === 'eUnbalanced_open_or_short'
							? ExternalInputMode.eUnbalanced_Open_or_Short
							: xmlData.GPInputState === 'eBalanced_open_or_short_or_eol'
							? ExternalInputMode.eBalanced_Open_or_Short_eol
							: ExternalInputMode.eUnknown;
				}
				if (xmlData.ExternalInputNormalState !== undefined) {
					if (xmlData.ExternalInputNormalState === 'eOpen') {
						deviceParams.externalInputNormalState =
							ExternalInputNormalState.eOpen;
					} else if (xmlData.ExternalInputNormalState === 'eShort') {
						deviceParams.externalInputNormalState =
							ExternalInputNormalState.eShort;
					} else {
						deviceParams.externalInputNormalState =
							ExternalInputNormalState.eUnknown;
					}
				}

				if (xmlData.UnbalancedEventTriggered !== undefined) {
					if (xmlData.UnbalancedEventTriggered === 'eNone') {
						deviceParams.unbalancedEventTriggered = ExternalInputAction.eNone;
					} else if (
						xmlData.UnbalancedEventTriggered === 'ePerformADisableAction'
					) {
						deviceParams.unbalancedEventTriggered =
							ExternalInputAction.ePerformADisableAction;
					} else if (
						xmlData.UnbalancedEventTriggered === 'eResetAlarmAndFault'
					) {
						deviceParams.unbalancedEventTriggered =
							ExternalInputAction.eResetAlarmAndFault;
					} else if (xmlData.UnbalancedEventTriggered === 'eResetDevice') {
						deviceParams.unbalancedEventTriggered =
							ExternalInputAction.eResetDevice;
					} else if (xmlData.UnbalancedEventTriggered === 'eTriggerExtFault') {
						deviceParams.unbalancedEventTriggered =
							ExternalInputAction.eTriggerExtFault;
					} else {
						deviceParams.unbalancedEventTriggered =
							ExternalInputAction.eUnknown;
					}
				}

				if (xmlData.ExternalTriggerOnClosed !== undefined) {
					if (xmlData.ExternalTriggerOnClosed === 'eNone') {
						deviceParams.externalTriggerOnClosed = ExternalInputAction.eNone;
					} else if (
						xmlData.ExternalTriggerOnClosed === 'ePerformADisableAction'
					) {
						deviceParams.externalTriggerOnClosed =
							ExternalInputAction.ePerformADisableAction;
					} else if (
						xmlData.ExternalTriggerOnClosed === 'eResetAlarmAndFault'
					) {
						deviceParams.externalTriggerOnClosed =
							ExternalInputAction.eResetAlarmAndFault;
					} else if (xmlData.ExternalTriggerOnClosed === 'eResetDevice') {
						deviceParams.externalTriggerOnClosed =
							ExternalInputAction.eResetDevice;
					} else if (xmlData.ExternalTriggerOnClosed === 'eTriggerExtFault') {
						deviceParams.externalTriggerOnClosed =
							ExternalInputAction.eTriggerExtFault;
					} else {
						deviceParams.externalTriggerOnClosed = ExternalInputAction.eUnknown;
					}
				}

				if (xmlData.ExternalTriggerOnOpen !== undefined) {
					if (xmlData.ExternalTriggerOnOpen === 'eNone') {
						deviceParams.externalTriggerOnOpen = ExternalInputAction.eNone;
					} else if (
						xmlData.ExternalTriggerOnOpen === 'ePerformADisableAction'
					) {
						deviceParams.externalTriggerOnOpen =
							ExternalInputAction.ePerformADisableAction;
					} else if (xmlData.ExternalTriggerOnOpen === 'eResetAlarmAndFault') {
						deviceParams.externalTriggerOnOpen =
							ExternalInputAction.eResetAlarmAndFault;
					} else if (xmlData.ExternalTriggerOnOpen === 'eResetDevice') {
						deviceParams.externalTriggerOnOpen =
							ExternalInputAction.eResetDevice;
					} else if (xmlData.ExternalTriggerOnOpen === 'eTriggerExtFault') {
						deviceParams.externalTriggerOnOpen =
							ExternalInputAction.eTriggerExtFault;
					} else {
						deviceParams.externalTriggerOnOpen = ExternalInputAction.eUnknown;
					}
				}

				// Handle boolean properties
				if (xmlData.GPIState !== undefined) {
					deviceParams.gpiState =
						xmlData.GPInputState === 'eBalanced_open_or_short_or_eol'
							? true
							: xmlData.GPInputState === 'eUnbalanced_open_or_short'
							? false
							: false;
				}

				// Handle device identification properties
				if (xmlData.DeviceId) deviceParams.deviceId = xmlData.DeviceId;
				if (xmlData.DeviceName) deviceParams.deviceName = xmlData.DeviceName;
				if (xmlData.Channels !== undefined)
					deviceParams.channels = Number(xmlData.Channels);
			} else {
				// Handle date/time properties
				if (xmlData.installationDateTime) {
					const dateValue = xmlData.installationDateTime;
					deviceParams.installationDateTime = new Date(dateValue);
					deviceParams.installationDate = new Date(dateValue);
				}
				// Handle numeric properties
				if (xmlData.trendLogDisabled !== undefined)
					deviceParams.trendLogDisabled = Number(xmlData.trendLogDisabled);
				if (xmlData.actionDelay !== undefined)
					deviceParams.actionDelay = Number(xmlData.actionDelay);
				if (xmlData.alarmDelay !== undefined)
					deviceParams.alarmDelay = Number(xmlData.alarmDelay);
				if (xmlData.flowFaultDelay !== undefined)
					deviceParams.flowFaultDelay = Number(xmlData.flowFaultDelay);
				if (xmlData.blowerCorrection !== undefined)
					deviceParams.blowerCorrection = String(xmlData.blowerCorrection);

				// Handle enum properties
				if (xmlData.temperatureFaultRelay !== undefined)
					deviceParams.temperatureFaultRelay = Number(
						xmlData.temperatureFaultRelay,
					);
				if (xmlData.lowPowerFaultRelay !== undefined)
					deviceParams.lowPowerFaultRelay = Number(xmlData.lowPowerFaultRelay);
				if (xmlData.blowerSpeed !== undefined)
					deviceParams.blowerSpeed = Number(xmlData.blowerSpeed);
				if (xmlData.alarmLatched !== undefined)
					deviceParams.alarmLatched = Number(xmlData.alarmLatched);
				if (xmlData.actionLatched !== undefined)
					deviceParams.actionLatched = Number(xmlData.actionLatched);
				if (xmlData.faultLatched !== undefined)
					deviceParams.faultLatched = Number(xmlData.faultLatched);
				if (xmlData.deviceAlarmMode !== undefined)
					deviceParams.deviceAlarmMode = Number(xmlData.deviceAlarmMode);

				// Handle channel properties
				if (xmlData.channel1ActionLevel !== undefined)
					deviceParams.channel1ActionLevel = Number(
						xmlData.channel1ActionLevel,
					);
				if (xmlData.channel1AlarmLevel !== undefined)
					deviceParams.channel1AlarmLevel = Number(xmlData.channel1AlarmLevel);
				if (xmlData.flowFaultThresholdCh1 !== undefined)
					deviceParams.flowFaultThresholdCh1 = Number(
						xmlData.flowFaultThresholdCh1,
					);
				if (xmlData.referenceFlowCh1 !== undefined)
					deviceParams.referenceFlowCh1 = Number(xmlData.referenceFlowCh1);

				if (xmlData.channel2ActionLevel !== undefined)
					deviceParams.channel2ActionLevel = Number(
						xmlData.channel2ActionLevel,
					);
				if (xmlData.channel2AlarmLevel !== undefined)
					deviceParams.channel2AlarmLevel = Number(xmlData.channel2AlarmLevel);
				if (xmlData.flowFaultThresholdCh2 !== undefined)
					deviceParams.flowFaultThresholdCh2 = Number(
						xmlData.flowFaultThresholdCh2,
					);
				if (xmlData.referenceFlowCh2 !== undefined)
					deviceParams.referenceFlowCh2 = Number(xmlData.referenceFlowCh2);

				// Handle GPI properties
				if (xmlData.gpInputState !== undefined)
					deviceParams.gpInputState = Number(xmlData.gpInputState);
				if (xmlData.externalInputNormalState !== undefined)
					deviceParams.externalInputNormalState = Number(
						xmlData.externalInputNormalState,
					);
				if (xmlData.unbalancedEventTriggered !== undefined)
					deviceParams.unbalancedEventTriggered = Number(
						xmlData.unbalancedEventTriggered,
					);
				if (xmlData.externalTriggerOnClosed !== undefined)
					deviceParams.externalTriggerOnClosed = Number(
						xmlData.externalTriggerOnClosed,
					);
				if (xmlData.externalTriggerOnOpen !== undefined)
					deviceParams.externalTriggerOnOpen = Number(
						xmlData.externalTriggerOnOpen,
					);

				// Handle boolean properties
				if (xmlData.gpiState !== undefined)
					deviceParams.gpiState = Boolean(xmlData.gpiState);

				// Handle device identification properties
				if (xmlData.deviceId) deviceParams.deviceId = xmlData.deviceId;
				if (xmlData.deviceName) deviceParams.deviceName = xmlData.deviceName;
				if (xmlData.channels !== undefined)
					deviceParams.channels = Number(xmlData.channels);

				//Handle Intelligent Device specific parameters
				if (xmlData.alarm2Latched !== undefined)
					deviceParams.alarm2Latched = Number(xmlData.alarm2Latched);
				if (xmlData.auxFaultLatched !== undefined)
					deviceParams.auxFaultLatched = Number(xmlData.auxFaultLatched);
				if (xmlData.generalFaultLatched !== undefined)
					deviceParams.generalFaultLatched = Number(
						xmlData.generalFaultLatched,
					);
			}

			console.log('Mapped XML data to device parameters successfully');
			console.log('Filled Data is ', deviceParams);
		} catch (error) {
			console.error('Error mapping XML data to device parameters:', error);
			throw new Error('Failed to map configuration data');
		}
	}

	//#endregion

	//#region Import DeviceParametersModel from Downloads folder
	const filePickerInProgressRef = useRef<boolean>(false);
	const handleImport = async () => {
		if (filePickerInProgressRef.current) {
			console.log('File picker already in progress, ignoring new request');
			return;
		}
		try {
			filePickerInProgressRef.current = true;
			const res = await pick({
				type: [
					Platform.OS === 'ios'
						? 'public.data' // iOS: Accept all file types
						: '*/*',
				],
				llowMultiSelection: false,
				mode: 'open',
				copyTo: 'cachesDirectory',
			});
			console.log('array', res);

			await Promise.all(
				res.map(async file => {
					console.log('Selected file:', file.uri);

					try {
						const fileName = file.name || '';

						let filePath = file.uri;
						if (Platform.OS === 'ios') {
							filePath = decodeURIComponent(file.uri.replace('file://', ''));
						} else {
							filePath = file.uri;
						}

						let fileContent: string;

						// For encrypted files, read as base64 since they contain binary data
						console.log('Reading encrypted .sfc file as base64...');
						fileContent = await RNFS.readFile(filePath, 'base64');

						let parsed;

						console.log('Processing encrypted .sfc file...');
						try {
							parsed = await decryptAndParseConfigFile(fileContent, fileName);
							console.log('Full pipeline worked! Parsed result:', parsed);
						} catch (parseError) {
							console.log('XML parsing failed:', parseError);
							throw parseError;
						}
						console.log('Decrypted and parsed .sfc file:', parsed);
						Toast.show({
							type: 'success',
							text1: 'Encrypted File Decrypted',
							text2: 'Successfully decrypted configuration file from old app',
							position: 'bottom',
						});

						let channels = 0;
						if (parsed.channels) {
							channels = Number(parsed.channels);
						} else if (parsed.Channels) {
							channels = Number(parsed.Channels);
						}

						if (channels !== deviceParameters.current.channels) {
							Alert.alert('Error', t('Channel Mismatch'), [{ text: 'ok' }]);
							return;
						}
						let isOlderConfig = false;
						if (parsed.deviceType !== undefined) {
							const importedDeviceType = Number(parsed.deviceType);
							const currentDeviceType = deviceParameters.current.deviceType;
							isOlderConfig = false;
							if (importedDeviceType !== currentDeviceType) {
								Alert.alert('Error', t('Device Type Mismatch'), [
									{ text: 'ok' },
								]);
								return;
							}
						} else {
							isOlderConfig = true;
							parsed.deviceType = DeviceType.eStandAlone;
						}

						const importedParams = new DeviceParametersModel();
						// Handle different data structures based on source
						mapXmlDataToDeviceParameters(importedParams, parsed, isOlderConfig);

						console.log('Imported device parameters:', importedParams);

						// Validate and assign imported values to form
						AssignImportedValuesToYup(importedParams);

						Toast.show({
							type: 'success',
							text1: 'Import Successful',
							text2: `Configuration imported successfully from ${fileName}`,
							position: 'bottom',
						});
					} catch (parseError) {
						console.error('Error parsing file:', parseError);
						Toast.show({
							type: 'error',
							text1: 'Import Failed',
							text2:
								parseError instanceof Error
									? parseError.message
									: 'Could not parse the selected file',
							position: 'bottom',
						});
					}
				}),
			);
		} catch (err) {
			console.log('File picker error:', err);
			Toast.show({
				type: 'error',
				text1: 'File Selection Failed',
				text2: 'Could not select or read the file',
				position: 'bottom',
			});
		} finally {
			filePickerInProgressRef.current = false;
		}
	};
	//#endregion

	//#region
	async function AssignImportedValuesToYup(
		deviceParams: DeviceParametersModel,
	) {
		//#region General Parameters
		if (deviceParams !== null && deviceParams !== undefined) {
			const alarmc =
				selectedDeviceRef.current.deviceCountryCode ===
				getCountryDescription(Country.CHINA)
					? LatchedMode.eLatched
					: deviceParams.alarmLatched;
			const fanspeed = deviceParams.blowerSpeed;
			const actc = deviceParams.actionLatched;
			const faultc = deviceParams.faultLatched;
			const alamm = deviceParams.deviceAlarmMode;
			generalClearErrors();
			generalSetValue('selectedDate', deviceParams.installationDateTime);
			generalSetValue('selectedTime', deviceParams.installationDateTime);
			generalSetValue('TrendLogInterval', deviceParams.trendLogDisabled);
			generalSetValue(
				'isTemparatureFaultSetRelays',
				deviceParams.temperatureFaultRelay === 0
					? 1
					: deviceParams.temperatureFaultRelay === 1
					? 0
					: 2,
			);
			generalSetValue(
				'isLowPowerFaultSetRelays',
				deviceParams.lowPowerFaultRelay === 0
					? 1
					: deviceParams.lowPowerFaultRelay === 1
					? 0
					: 2,
			);

			if (IsGPIVisible && IsGPIEnabledConfig) {
				setGpiInputState(deviceParams.gpiState === true ? 1 : 0);
				setGpiNormalState(deviceParams.externalInputNormalState);
				setUnbalancedEventTriggered(deviceParams.unbalancedEventTriggered);
				setEventTriggerOnClose(deviceParams.externalTriggerOnClosed);
				setEventTriggerOnOpen(deviceParams.externalTriggerOnOpen);
			}

			if (fanspeed === 0) {
				generalSetValue('blowerSpeed', 0);
			} else if (fanspeed === 1) {
				generalSetValue('blowerSpeed', 1);
			} else {
				generalSetValue('blowerSpeed', 1);
			}
			generalSetValue('blowerCorrection', deviceParams.blowerCorrection);

			//#endregion

			//#region Channel and Sensors Parameters
			csClearErrors();
			csSetValue('ActionDelay', deviceParams.actionDelay);
			csSetValue('AlarmDelay', deviceParams.alarmDelay);
			csSetValue('FlowFaultDelay', deviceParams.flowFaultDelay);
			if (alarmc === LatchedMode.eLatched) {
				csSetValue('AlarmConfiguration', 0);
			} else if (alarmc === LatchedMode.eUnlatched) {
				csSetValue('AlarmConfiguration', 1);
			}
			if (actc === LatchedMode.eLatched) {
				csSetValue('ActionConfiguration', 0);
			} else if (actc === LatchedMode.eUnlatched) {
				csSetValue('ActionConfiguration', 1);
			}
			if (faultc === LatchedMode.eLatched) {
				csSetValue('FaultConfiguration', 0);
			} else if (faultc === LatchedMode.eUnlatched) {
				csSetValue('FaultConfiguration', 1);
			}
			if (alamm === AlarmMode.eUp_InstantFire) {
				csSetValue('AlarmMode', 0);
			} else if (alamm === AlarmMode.eDown_Cumulative) {
				csSetValue('AlarmMode', 1);
			}
			csSetValue('ActionLevel1', deviceParams.channel1ActionLevel);
			csSetValue('AlarmLevel1', deviceParams.channel1AlarmLevel);
			csSetValue('Referenceflow1', deviceParams.referenceFlowCh1);
			csSetValue(
				'FlowFaultThreshold1Value',
				deviceParams.flowFaultThresholdCh1,
			);
			csSetValue(
				'FlowFaultThreshold1',
				deviceParams.flowFaultThresholdCh1 === 15 ? 0 : 1,
			);
			csSetValue('ActionLevel2', deviceParams.channel2ActionLevel);
			csSetValue('AlarmLevel2', deviceParams.channel2AlarmLevel);
			csSetValue('Referenceflow2', deviceParams.referenceFlowCh2);
			csSetValue(
				'FlowFaultThreshold2Value',
				deviceParams.flowFaultThresholdCh2,
			);
			csSetValue(
				'FlowFaultThreshold2',
				deviceParams.flowFaultThresholdCh2 === 15 ? 0 : 1,
			);
			//#endregion
		}
	}
	//#endregion

	//#region
	function FetchValuesFromYup(): DeviceParametersModel {
		let devParams = new DeviceParametersModel();

		const selectedDate = generalWatch('selectedDate');
		const selectedTime = generalWatch('selectedTime');
		if (selectedDate !== null) {
			const installDate = new Date(
				selectedDate.getFullYear(),
				selectedDate.getMonth(),
				selectedDate.getDate(),
				selectedTime.getHours(),
				selectedTime.getMinutes(),
				selectedTime.getSeconds(),
			);
			devParams.installationDate = installDate;
		}

		const trendLogInterval = generalWatch('TrendLogInterval');
		devParams.trendLogDisabled = trendLogInterval;

		const isTemparatureFaultSetRelays = generalWatch(
			'isTemparatureFaultSetRelays',
		);
		devParams.temperatureFaultRelay = isTemparatureFaultSetRelays;

		const isLowPowerFaultSetRelays = generalWatch('isLowPowerFaultSetRelays');

		devParams.lowPowerFaultRelay = isLowPowerFaultSetRelays;

		if (IsGPIVisible && IsGPIEnabledConfig) {
			devParams.gpiState = gpiInputState === 1;
			devParams.externalInputNormalState = gpiNormalState;
			devParams.unbalancedEventTriggered = unbalancedEventTriggered;
			devParams.externalTriggerOnClosed = eventTriggerOnClose;
			devParams.externalTriggerOnOpen = eventTriggerOnOpen;
		}
		const blowerSpeed = generalWatch('blowerSpeed');
		devParams.blowerSpeed = blowerSpeed;
		const blowerCorrection = generalWatch('blowerCorrection');
		devParams.blowerCorrection = blowerCorrection;

		const actionDelay = csWatch('ActionDelay');
		devParams.actionDelay = actionDelay;

		const alarmDelay = csWatch('AlarmDelay');
		devParams.alarmDelay = alarmDelay;

		const flowFaultDelay = csWatch('FlowFaultDelay');
		devParams.flowFaultDelay = flowFaultDelay;

		const alarmConfig = csWatch('AlarmConfiguration');
		devParams.alarmLatched = alarmConfig;

		const actionConfig = csWatch('ActionConfiguration');
		devParams.actionLatched = actionConfig;

		const faultConfig = csWatch('FaultConfiguration');
		devParams.faultLatched = faultConfig;

		const alarmMode = csWatch('AlarmMode');
		devParams.deviceAlarmMode = alarmMode;

		const ActionLevel1 = csWatch('ActionLevel1');
		devParams.channel1ActionLevel = ActionLevel1;

		const AlarmLevel1 = csWatch('AlarmLevel1');
		devParams.channel1AlarmLevel = AlarmLevel1;

		const FlowFaultThreshold1 = csWatch('FlowFaultThreshold1Value');
		devParams.flowFaultThresholdCh1 = FlowFaultThreshold1;

		const ActionLevel2 = csWatch('ActionLevel2');
		devParams.channel2ActionLevel = ActionLevel2 ?? 0;

		const AlarmLevel2 = csWatch('AlarmLevel2');
		devParams.channel2AlarmLevel = AlarmLevel2 ?? 0;

		const FlowFaultThreshold2 = csWatch('FlowFaultThreshold2Value');
		devParams.flowFaultThresholdCh2 = FlowFaultThreshold2;

		return devParams;
	}
	//#endregion
	//#region Properties

	//Database
	const dispatch = useAppDispatch();
	const { dataSource } = useDatabase();
	const { t } = useTranslation();

	const [isChannel, setIsChannel] = useState(2);
	const { showLoadingIndicator, hideLoadingIndicator } = useLoading();
	// Current active field for dropdown
	const [currentField, setCurrentField] = useState<string>('');
	const [isGPIDropDownModalVisible, setGPIDropDownModalVisible] =
		useState<boolean>(false);
	const [tempSelectedItem, setTempSelectedItem] = useState<string | null>(null);
	const [password, setPassword] = useState<string>('');
	const [isPasswordModalVisible, setPasswordModalVisible] = useState(false);
	const [RealConfiguration, setRealConfiguration] =
		useState<string>('Extented');
	const [showTimeoutPopup, setShowTimeoutPopup] = useState(false);
	const timeoutTimerRef = React.useRef<NodeJS.Timeout | null>(null);
	const [isGeneralParameterVisible, setIsGeneralParameterVisible] =
		useState<boolean>(true);
	const [isChannelsAndSensorsVisible, setIsChannelsAndSensorsVisible] =
		useState<boolean>(false);
	const [IsQRScannerVisible, setIsQRScannerVisible] = useState<boolean>(false);

	const [IsAddSparepartVisible, setIsAddSparepartVisible] = useState(false);
	const [selectedObscurationUnit, setSelectedObscurationUnit] =
		useState<ObscurationUnit>(ObscurationUnit.Alarm);
	const [selectedDevice, setSelectedDevice, selectedDeviceRef] =
		useSyncedState<DeviceModel>(new DeviceModel());
	const [IsEnabledConfig, setIsEnabledConfig] = useState<boolean>(false);
	const [IsSyncEnabled, setIsSyncEnabled] = useState<boolean>(false);
	const [IsRealConfigOutOfBox, setIsRealConfigOutOfBox] =
		useState<boolean>(false);
	const [isChannel1Visible, setIsChannel1Visible] = useState<boolean>(false);
	const [isChannel2Visible, setIsChannel2Visible] = useState<boolean>(false);
	const [IsGPIVisible, setIsGPIVisible] = useState<boolean>(false);
	const [DeviceConfig, setDeviceConfig] = useState<string>('Default');
	const [IsChannel2Available, setIsChannel2Available] =
		useState<boolean>(false);
	const [GPIInputState1, setGPIInputState1] = useState<boolean>(true);
	const [
		IsUnbalancedEventtriggeredlistVisible,
		setIsUnbalancedEventtriggeredlistVisible,
	] = useState<boolean>(false);
	const [IsEventtriggeredOpenlistVisible, setIsEventtriggeredOpenlistVisible] =
		useState<boolean>(false);
	const [IsGPIEnabledConfig, setIsGPIEnabledConfig] = useState<boolean>(false);
	const [deviceOrientation, setDeviceOrientation] = useState<string>('');
	const selectedInstallationDateRef = useRef<Date>(new Date());
	const [selectedInstallationTimeSpan, setSelectedInstallationTimeSpan] =
		useState<Date>(new Date());
	const [SelectedTimeoutDisabled, setSelectedTimeoutDisabled] =
		useState<number>(0);
	const [SelectedTrendDisabled, setSelectedTrendDisabled] = useState<number>(0);
	const [tempRelay, setTempRelay] = useState<RelayAlert>(RelayAlert.eUnknown);
	const [SelectedTempfaultRelay, setSelectedTempfaultRelay] =
		useState<boolean>(false);
	const [SelectedTempfaultRelay1, setSelectedTempfaultRelay1] =
		useState<boolean>(false);
	const [lowrelay, setLowRelay] = useState<RelayAlert>(RelayAlert.eUnknown);
	const [SelectedLowPowerfaultRelay, setSelectedLowPowerfaultRelay] =
		useState<boolean>(false);
	const [SelectedLowPowerfaultRelay1, setSelectedLowPowerfaultRelay1] =
		useState<boolean>(false);
	const [blowerspeed, setBlowerSpeed] = useState<FanSpeedLevel>(
		FanSpeedLevel.eUnknown,
	);
	const [SelectedBlowerSpeed, setSelectedBlowerSpeed] =
		useState<boolean>(false);
	const [SelectedBlowerSpeed1, setSelectedBlowerSpeed1] =
		useState<boolean>(false);
	const [SelectedBlowerCorrection, setSelectedBlowerCorrection] =
		useState<string>(AppConstants.NA);
	const [SelectedActionDelay, setSelectedActionDelay] = useState<number>(0);
	const [selectedAlarmDelay, setSelectedAlarmDelay] = useState<number>(0);
	const [SelectedFlowFaultDelay, setSelectedFlowFaultDelay] =
		useState<number>(0);
	const [SelectedAlarmConfig, setSelectedAlarmConfig] =
		useState<boolean>(false);
	const [SelectedAlarmConfig1, setSelectedAlarmConfig1] =
		useState<boolean>(false);
	const [alamc, setAlarmC] = useState<LatchedMode>(LatchedMode.eUnknown);
	const [faultc, setFaultC] = useState<LatchedMode>(LatchedMode.eUnknown);
	const [actc, setActC] = useState<LatchedMode>(LatchedMode.eUnknown);
	const [alamm, setAlarmM] = useState<AlarmMode>(AlarmMode.eUnknown);
	const [SelectedActionConfig, setSelectedActionConfig] =
		useState<boolean>(false);
	const [SelectedActionConfig1, setSelectedActionConfig1] =
		useState<boolean>(false);
	const [SelectedFaultConfig, setSelectedFaultConfig] =
		useState<boolean>(false);
	const [SelectedFaultConfig1, setSelectedFaultConfig1] =
		useState<boolean>(false);
	const [SelectedAlarmMode, setSelectedAlarmMode] = useState<boolean>(false);
	const [SelectedAlarmMode1, setSelectedAlarmMode1] = useState<boolean>(false);
	const [SelectedChannel1ActionLevel, setSelectedChannel1ActionLevel] =
		useState<number>(0);
	const [SelectedChannel1AlarmLevel, setSelectedChannel1AlarmLevel] =
		useState<number>(0);
	const [SelectedFlowFaultThresholdCh1, setSelectedFlowFaultThresholdCh1] =
		useState<number>(0);
	const [IsEn54Standard1, setIsEn54Standard1] = useState<boolean>(false);
	const [TempFlowfault1, setTempFlowfault1] = useState<number>(0);
	const [IsOtherStandard1, setIsOtherStandard1] = useState<boolean>(false);
	const [SelectedReferenceFlowCh1, setSelectedReferenceFlowCh1] =
		useState<number>(0);
	const [SelectedChannel2ActionLevel, setSelectedChannel2ActionLevel] =
		useState<number>(0);
	const [SelectedChannel2AlarmLevel, setSelectedChannel2AlarmLevel] =
		useState<number>(0);
	const [SelectedFlowFaultThresholdCh2, setSelectedFlowFaultThresholdCh2] =
		useState<number>(0);
	const [IsEn54Standard2, setIsEn54Standard2] = useState<boolean>(false);
	const [TempFlowfault2, setTempFlowfault2] = useState<number>(0);
	const [IsOtherStandard2, setIsOtherStandard2] = useState<boolean>(false);
	const [SelectedReferenceFlowCh2, setSelectedReferenceFlowCh2] =
		useState<number>(0);
	const [BluetoothImage, setBluetoothImage] = useState<string>(
		'PanelDisconnected.png',
	);
	const [TextColorChange, setTextColorChange] = useState<string>('#1791E4');
	let generalParams: string[] = [];
	let retryGeneralParams: string[] = [];

	const [tempFaultRelay, setTempFaultRelay] = useState<RelayAlert>(
		RelayAlert.eUnknown,
	);
	const [lowpowerFaultRelay, setLowpowerFaultRelay] = useState<RelayAlert>(
		RelayAlert.eUnknown,
	);
	const [importConfiginProgress, setImportConfiginProgress] =
		useState<boolean>(false);
	let channelsAndSensorsParams: string[] = [];
	let retryChannelsAndSensorsParams: string[] = [];
	const [alarmLatchMode, setAlarmLatchMode] = useState<LatchedMode>(
		LatchedMode.eUnknown,
	);
	const [preAlarmLatchMode, setPreAlarmLatchMode] = useState<LatchedMode>(
		LatchedMode.eUnknown,
	);
	const [faultLatchMode, setFaultLatchMode] = useState<LatchedMode>(
		LatchedMode.eUnknown,
	);
	const [ffAlarmMode, setFFAlarmMode] = useState<AlarmMode>(AlarmMode.eUnknown);
	const ConnectedDeviceobj = useRef<BluetoothDevice | null>();
	const deviceParameters = useRef<DeviceParametersModel>(
		new DeviceParametersModel(),
	);
	const [offlineMode, setOfflineMode] = useState<boolean>(false);
	const [isChineseDevice, setIsChineseDevice] = useState<boolean>(false);

	// Add these useState hooks in your component
	const [gpiInputState, setGpiInputState] = useState<number>(1);
	const [gpiNormalState, setGpiNormalState] =
		useState<ExternalInputNormalState>(ExternalInputNormalState.eShort);
	const [unbalancedEventTriggered, setUnbalancedEventTriggered] =
		useState<ExternalInputAction>(ExternalInputAction.eResetAlarmAndFault);
	const [eventTriggerOnClose, setEventTriggerOnClose] =
		useState<ExternalInputAction>(ExternalInputAction.eResetAlarmAndFault);
	const [eventTriggerOnOpen, setEventTriggerOnOpen] =
		useState<ExternalInputAction>(ExternalInputAction.eResetAlarmAndFault);

	function getExternalInputActionItems(): Array<{
		label: string;
		value: ExternalInputAction;
	}> {
		return [
			{
				label: getExternalInputActionDescription(ExternalInputAction.eNone),
				value: ExternalInputAction.eNone,
			},
			{
				label: getExternalInputActionDescription(
					ExternalInputAction.eResetDevice,
				),
				value: ExternalInputAction.eResetDevice,
			},
			{
				label: getExternalInputActionDescription(
					ExternalInputAction.eTriggerExtFault,
				),
				value: ExternalInputAction.eTriggerExtFault,
			},
			{
				label: getExternalInputActionDescription(
					ExternalInputAction.ePerformADisableAction,
				),
				value: ExternalInputAction.ePerformADisableAction,
			},
			{
				label: getExternalInputActionDescription(
					ExternalInputAction.eResetAlarmAndFault,
				),
				value: ExternalInputAction.eResetAlarmAndFault,
			},
		];
	}

	function getExternalInputNormalStateItems(): Array<{
		label: string;
		value: ExternalInputNormalState;
	}> {
		return [
			{
				label: getExternalInputNormalStateDescription(
					ExternalInputNormalState.eOpen,
				),
				value: ExternalInputNormalState.eOpen,
			},
			{
				label: getExternalInputNormalStateDescription(
					ExternalInputNormalState.eShort,
				),
				value: ExternalInputNormalState.eShort,
			},
		];
	}

	//#region Save Failed Message

	// General parameters save failure flags
	const [deviceDateSaveFailed, setDeviceDateSaveFailed] =
		useState<boolean>(false);
	const [disableTimeoutSaveFailed, setDisableTimeoutSaveFailed] =
		useState<boolean>(false);
	const [trendLogIntervalSaveFailed, setTrendLogIntervalSaveFailed] =
		useState<boolean>(false);
	const [tempFaultSetsRelaysSaveFailed, setTempFaultSetsRelaysSaveFailed] =
		useState<boolean>(false);
	const [
		lowPowerFaultSetsRelaysSaveFailed,
		setLowPowerFaultSetsRelaysSaveFailed,
	] = useState<boolean>(false);
	const [gpiSaveFailed, setGPISaveFailed] = useState<boolean>(false);
	const [aspiratorSpeedSaveFailed, setAspiratorSpeedSaveFailed] =
		useState<boolean>(false);

	// Channels and sensors save failure flags
	const [actionDelaySaveFailed, setActionDelaySaveFailed] =
		useState<boolean>(false);
	const [alarmDelaySaveFailed, setAlarmDelaySaveFailed] =
		useState<boolean>(false);
	const [flowFaultDelaySaveFailed, setFlowFaultDelaySaveFailed] =
		useState<boolean>(false);
	const [alarmConfigSaveFailed, setAlarmConfigSaveFailed] =
		useState<boolean>(false);
	const [actionConfigSaveFailed, setActionConfigSaveFailed] =
		useState<boolean>(false);
	const [faultConfigSaveFailed, setFaultConfigSaveFailed] =
		useState<boolean>(false);
	const [alarmModeSaveFailed, setAlarmModeSaveFailed] =
		useState<boolean>(false);

	// Channel 1 specific save failure flags
	const [ch1ActionLevelSaveFailed, setCh1ActionLevelSaveFailed] =
		useState<boolean>(false);
	const [ch1AlarmLevelSaveFailed, setCh1AlarmLevelSaveFailed] =
		useState<boolean>(false);
	const [ch1FlowFaultThresholdSaveFailed, setCh1FlowFaultThresholdSaveFailed] =
		useState<boolean>(false);

	// Channel 2 specific save failure flags
	const [ch2ActionLevelSaveFailed, setCh2ActionLevelSaveFailed] =
		useState<boolean>(false);
	const [ch2AlarmLevelSaveFailed, setCh2AlarmLevelSaveFailed] =
		useState<boolean>(false);
	const [ch2FlowFaultThresholdSaveFailed, setCh2FlowFaultThresholdSaveFailed] =
		useState<boolean>(false);
	//#endregion

	//#endregion
	//#region  On Screen Appeared
	useEffect(() => {
		console.log('Route params:', route.params);
		initializeAsync();
	}, []);

	useEffect(() => {
		const unsubscribe = navigation.addListener('focus', () => {
			OnPageAppeared();
		});
		return unsubscribe;
	}, [navigation]);
	//#endregion
	//#region Prevent Device Back Functionality
	useEffect(() => {
		const backHandler = BackHandler.addEventListener(
			'hardwareBackPress',
			() => {
				return true; // Return true to prevent default back behavior
			},
		);

		return () => backHandler.remove();
	}, []);

	//iOS
	useEffect(() => {
		navigation.setOptions({
			gestureEnabled: false, // Disable swipe back gesture
		});
	}, [navigation]);
	//#endregion

	const {
		control: generalControl,
		handleSubmit: generalHandleSubmit,
		formState: { errors: generalErrors },
		setValue: generalSetValue,
		watch: generalWatch,
		clearErrors: generalClearErrors,
		trigger: generalTrigger,
	} = useForm<GeneralParametersData>({
		resolver: yupResolver(GeneralSchema as any),
		mode: 'onChange',
		defaultValues: {
			Orientation: '',
			selectedDate: new Date(),
			selectedTime: new Date(),
			TrendLogInterval: 0,
			isTemparatureFaultSetRelays: 1,
			isLowPowerFaultSetRelays: 1,
			blowerSpeed: 0,
			blowerCorrection: AppConstants.NA,
		},
	});

	//#region  Temp Watch method
	useEffect(() => {
		const subscription = generalWatch(value => {
			console.log('General form values changed:', value);
		});
		return () => {
			subscription.unsubscribe();
		};
	}, [generalWatch]);
	//#endregion
	const {
		control: csControl,
		handleSubmit: csHandleSubmit,
		formState: { errors: csErrors },
		setValue: csSetValue,
		watch: csWatch,
		clearErrors: csClearErrors,
		trigger: csTrigger,
		setError: csSetError,
	} = useForm<ChannelsAndSensorsData>({
		resolver: yupResolver(ChannelAndSensorsSchema as any),
		mode: 'onChange',
		defaultValues: {
			ActionDelay: 0,
			AlarmDelay: 0,
			FlowFaultDelay: 30,
			AlarmConfiguration: 0,
			ActionConfiguration: 0,
			FaultConfiguration: 0,
			AlarmMode: 0,
			ActionLevel1: 0,
			AlarmLevel1: 0,
			Referenceflow1: 0,
			FlowFaultThreshold1: 0,
			FlowFaultThreshold1Value: 15,
			ActionLevel2: 0,
			AlarmLevel2: 0,
			Referenceflow2: 0,
			FlowFaultThreshold2: 0,
			FlowFaultThreshold2Value: 15,
		},
	});

	//#region  Initialization

	async function OnPageAppeared() {
		deviceParameters.current = new DeviceParametersModel();
	}

	async function initializeAsync() {
		await startTimerForTimeout();
		setIsAddSparepartVisible(false);
		setSelectedObscurationUnit(ObscurationUnit.Alarm);
		if (route.params && route.params.selectedItem != null) {
			const deviceData = route.params.selectedItem as DeviceModel;
			setSelectedDevice(deviceData);
			if (deviceData.deviceStatusStr !== t('Unknown')) {
				showLoadingIndicator(t('PasswordAuthenticated'));
				await delay(500);
			}
			if (deviceData.deviceConfig === Configuration.Extended) {
				setIsEnabledConfig(true);
				setIsSyncEnabled(true);
			} else if (
				deviceData.deviceMacAddress !== t('Not Connected yet') &&
				!deviceData.isDeviceConnected
			) {
				setIsEnabledConfig(false);
				setIsSyncEnabled(false);
				setIsChannel1Visible(true);
				//TODO : OPACITY change for UI
				let deviceParams = await dispatch(
					fetchDeviceParameter({
						dataSource,
						deviceId: deviceData.deviceId,
					}),
				).unwrap();

				AssignDeviceParameters(deviceParams);
				if (deviceParams.channels !== deviceData.channels) {
					let tempDeviceParams = {
						...deviceParams,
						channels: deviceData.channels,
					} as DeviceParametersModel;
					const obj = await dispatch(
						updateExistingDeviceParameter({
							dataSource,
							deviceId: tempDeviceParams.deviceId,
							updates: tempDeviceParams,
						}),
					);
				}
			} else {
				setIsEnabledConfig(false);
				setIsSyncEnabled(false);
			}
			if (deviceData.deviceConfig === Configuration.OutOfTheBox) {
				setIsRealConfigOutOfBox(true);
			} else {
				setIsRealConfigOutOfBox(false);
			}
			var isFirmwareHigher =
				deviceData.firmwareVersion !== null &&
				deviceData.firmwareVersion !== '' &&
				deviceData.firmwareVersion.length < 1
					? false
					: parseInt(deviceData.firmwareVersion.split('.')[0]) >= 4;
			setIsGPIVisible(isFirmwareHigher);
			setDeviceConfig(t(getConfigurationDescription(deviceData.deviceConfig)));

			if (deviceData !== null) {
				if (
					deviceData.listOfChannels !== null &&
					deviceData.listOfChannels.length === 2
				) {
					setIsChannel(2);
					setIsChannel2Available(true);
				} else {
					setIsChannel(1);
					setIsChannel2Available(false);
				}
				if (deviceData.isDeviceConnected) {
					setBluetoothImage('PanelConnected.png');
					setTextColorChange('#1791E4');
				}

				if (
					route.params &&
					route.params.connectedDevice !== undefined &&
					route.params.connectedDevice !== null
				) {
					ConnectedDeviceobj.current = route.params
						.connectedDevice as BluetoothDevice;
					var isFirmwareHigher = await GetDeviceFirmware();
					await GetGPIParametersFromDevice();
					await GetGeneralParametersFromDevice();
					await GetChannelSensorsfromDevice();

					if (deviceData.isDeviceConnected) {
						let tempDeviceParameter = deviceParameters.current;
						tempDeviceParameter.deviceId = deviceData.deviceId;
						tempDeviceParameter.deviceName = deviceData.deviceName;
						tempDeviceParameter.channels = deviceData.channels;
						tempDeviceParameter.deviceType =
							deviceData.deviceType ===
							getDeviceTypeDescription(DeviceType.eIntelligent)
								? DeviceType.eIntelligent
								: DeviceType.eStandAlone;
						deviceParameters.current = tempDeviceParameter;

						const result = await dispatch(
							addNewDeviceParameter({
								dataSource,
								deviceParameter: tempDeviceParameter,
							}),
						);
					}
					const isQrVisible =
						deviceData.isDeviceConnected &&
						deviceData.isManualPairingCompleted &&
						IsGPIVisible; // use isFirmwareHigher if IsGPIVisible is not rendered
					setIsQRScannerVisible(isQrVisible);
					if (deviceData !== null && !deviceData.isConfigDataFetched) {
						setSelectedDevice({
							isConfigDataFetched: true,
						});
						const result = await dispatch(
							updateExistingDevice({
								dataSource,
								deviceId: selectedDeviceRef.current.deviceId,
								updates: {
									isConfigDataFetched: true,
								},
							}),
						);
					}
				}

				if (
					deviceData.isDeviceConnected === false &&
					route.params &&
					(route.params.connectedDevice === undefined ||
						route.params.connectedDevice === null)
				) {
					setBluetoothImage('PanelDisconnected.png');
					setOfflineMode(true);
					setIsSyncEnabled(false);
				}
			}
		}

		hideLoadingIndicator();
		setSelectedObscurationUnit(ObscurationUnit.Alarm);
		// Clean up timer when component unmounts
		return () => {
			if (timeoutTimerRef.current) {
				clearTimeout(timeoutTimerRef.current);
			}
		};
	}

	async function GetDeviceFirmware(): Promise<boolean> {
		let retvalue = false;
		if (
			selectedDeviceRef.current?.firmwareVersion !== '' &&
			selectedDeviceRef.current.firmwareVersion.length > 0
		) {
			retvalue = selectedDeviceRef.current?.deviceName
				? parseInt(selectedDeviceRef.current.firmwareVersion.split('.')[0]) >= 4
				: false;
		} else {
			if (ConnectedDeviceobj.current !== null) {
				const deviceFirmware =
					await faastflexBluetoothCommunicator.GetFirmwareVersion();

				var majorVersion =
					deviceFirmware.firmwareVersion !== '' &&
					deviceFirmware.firmwareVersion.length > 0
						? parseInt(deviceFirmware.firmwareVersion.split('.')[0])
						: 0;
				if (majorVersion > 0) {
					if (selectedDeviceRef.current != null) {
						setSelectedDevice({
							firmwareVersion: deviceFirmware.firmwareVersion,
						});
					}
					dispatch(
						updateExistingDevice({
							dataSource,
							deviceId: selectedDeviceRef.current.deviceId,
							updates: {
								firmwareVersion: deviceFirmware.firmwareVersion,
							},
						}),
					);
					retvalue = majorVersion >= 4;
				}
			}
		}
		return retvalue;
	}

	//#endregion
	//#region Assign Device Parameters
	function AssignDeviceParameters(deviceParams: DeviceParametersModel) {
		//#region C# Implementation
		selectedInstallationDateRef.current = deviceParams.installationDateTime;
		setSelectedInstallationTimeSpan(deviceParams.installationDateTime);
		setSelectedTimeoutDisabled(deviceParams.timeOutDisabled);
		setSelectedTrendDisabled(deviceParams.trendLogDisabled);
		const tempRelay = deviceParams.temperatureFaultRelay;
		if (tempRelay === RelayAlert.eSet) {
			setSelectedTempfaultRelay(true);
			setSelectedTempfaultRelay1(false);
		} else if (tempRelay === RelayAlert.eUnset) {
			setSelectedTempfaultRelay(false);
			setSelectedTempfaultRelay1(true);
		} else {
			setSelectedTempfaultRelay(false);
			setSelectedTempfaultRelay1(false);
		}
		const lowrelay = deviceParams.lowPowerFaultRelay;
		if (lowrelay === RelayAlert.eSet) {
			setSelectedLowPowerfaultRelay(true);
			setSelectedLowPowerfaultRelay1(false);
		} else if (lowrelay === RelayAlert.eUnset) {
			setSelectedLowPowerfaultRelay(false);
			setSelectedLowPowerfaultRelay1(true);
		} else {
			setSelectedLowPowerfaultRelay(false);
			setSelectedLowPowerfaultRelay1(false);
		}

		const fanspeed = deviceParams.blowerSpeed;
		if (
			fanspeed === FanSpeedLevel.eLevel_1 ||
			fanspeed === FanSpeedLevel.eLevel_2 ||
			fanspeed === FanSpeedLevel.eLevel_3 ||
			fanspeed === FanSpeedLevel.eLevel_4 ||
			fanspeed === FanSpeedLevel.eLevel_5 ||
			fanspeed === FanSpeedLevel.eLevel_6
		) {
			setSelectedBlowerSpeed(true);
			setSelectedBlowerSpeed1(false);
		} else {
			setSelectedBlowerSpeed(false);
			setSelectedBlowerSpeed1(true);
		}
		setSelectedBlowerCorrection(deviceParams.blowerCorrection);

		setSelectedActionDelay(deviceParams.actionDelay);
		setSelectedAlarmDelay(deviceParams.alarmDelay);
		setSelectedFlowFaultDelay(deviceParams.flowFaultDelay);
		const alarmc =
			selectedDeviceRef.current.deviceCountryCode ===
			getCountryDescription(Country.CHINA)
				? LatchedMode.eLatched
				: deviceParams.alarmLatched;
		if (alarmc === LatchedMode.eLatched) {
			setSelectedAlarmConfig(true);
			setSelectedAlarmConfig1(false);
		} else if (alarmc === LatchedMode.eUnlatched) {
			setSelectedAlarmConfig(false);
			setSelectedAlarmConfig1(true);
		}
		const actc = deviceParams.actionLatched;
		if (actc === LatchedMode.eLatched) {
			setSelectedActionConfig(true);
			setSelectedActionConfig1(false);
		} else if (actc === LatchedMode.eUnlatched) {
			setSelectedActionConfig(false);
			setSelectedActionConfig1(true);
		}
		const faultc = deviceParams.faultLatched;
		if (faultc === LatchedMode.eLatched) {
			setSelectedFaultConfig(true);
			setSelectedFaultConfig1(false);
		} else if (faultc === LatchedMode.eUnlatched) {
			setSelectedFaultConfig(false);
			setSelectedFaultConfig1(true);
		}
		const alamm = deviceParams.deviceAlarmMode;
		if (alamm === AlarmMode.eUp_InstantFire) {
			setSelectedAlarmMode(true);
			setSelectedAlarmMode1(false);
		} else if (alamm === AlarmMode.eDown_Cumulative) {
			setSelectedAlarmMode(false);
			setSelectedAlarmMode1(true);
		}

		setSelectedChannel1ActionLevel(deviceParams.channel1ActionLevel);
		setSelectedChannel1AlarmLevel(deviceParams.channel1AlarmLevel);
		setSelectedFlowFaultThresholdCh1(deviceParams.flowFaultThresholdCh1);
		setIsEn54Standard1(
			deviceParams.flowFaultThresholdCh1 === 15 ? true : false,
		);
		setTempFlowfault1(deviceParams.flowFaultThresholdCh1);
		setIsOtherStandard1(
			deviceParams.flowFaultThresholdCh1 === 15 ? false : true,
		);
		setSelectedReferenceFlowCh1(deviceParams.referenceFlowCh1);

		setSelectedChannel2ActionLevel(deviceParams.channel2ActionLevel);
		setSelectedChannel2AlarmLevel(deviceParams.channel2AlarmLevel);
		setSelectedFlowFaultThresholdCh2(deviceParams.flowFaultThresholdCh2);
		setIsEn54Standard2(
			deviceParams.flowFaultThresholdCh2 === 15 ? true : false,
		);
		setTempFlowfault2(deviceParams.flowFaultThresholdCh2);
		setIsOtherStandard2(
			deviceParams.flowFaultThresholdCh2 === 15 ? false : true,
		);
		setSelectedReferenceFlowCh2(deviceParams.referenceFlowCh2);
		setSelectedObscurationUnit(ObscurationUnit.Alarm);
		//#endregion

		//#region General Parameters

		generalClearErrors();
		generalSetValue('selectedDate', deviceParams.installationDateTime);
		generalSetValue('selectedTime', deviceParams.installationDateTime);
		generalSetValue('TrendLogInterval', deviceParams.trendLogDisabled);
		generalSetValue(
			'isTemparatureFaultSetRelays',
			deviceParams.temperatureFaultRelay === RelayAlert.eSet
				? 1
				: deviceParams.temperatureFaultRelay === RelayAlert.eUnset
				? 0
				: 2,
		);
		generalSetValue(
			'isLowPowerFaultSetRelays',
			deviceParams.lowPowerFaultRelay === RelayAlert.eSet
				? 1
				: deviceParams.lowPowerFaultRelay === RelayAlert.eUnset
				? 0
				: 2,
		);

		setGpiInputState(
			deviceParams.gpInputState === ExternalInputMode.eUnbalanced_Open_or_Short
				? 1
				: deviceParams.gpInputState ===
				  ExternalInputMode.eBalanced_Open_or_Short_eol
				? 0
				: 1,
		);
		setGpiNormalState(deviceParams.externalInputNormalState);
		setUnbalancedEventTriggered(deviceParams.unbalancedEventTriggered);
		setEventTriggerOnClose(deviceParams.externalTriggerOnClosed);
		setEventTriggerOnOpen(deviceParams.externalTriggerOnOpen);

		if (fanspeed === 0) {
			generalSetValue('blowerSpeed', 0);
		} else if (fanspeed === 1) {
			generalSetValue('blowerSpeed', 1);
		} else {
			generalSetValue('blowerSpeed', 1);
		}

		generalSetValue('blowerCorrection', deviceParams.blowerCorrection);

		//#endregion

		//#region Channel and Sensors Parameters
		csClearErrors();
		csSetValue('ActionDelay', deviceParams.actionDelay);
		csSetValue('AlarmDelay', deviceParams.alarmDelay);
		csSetValue('FlowFaultDelay', deviceParams.flowFaultDelay);
		if (alarmc === LatchedMode.eLatched) {
			csSetValue('AlarmConfiguration', 0);
		} else if (alarmc === LatchedMode.eUnlatched) {
			csSetValue('AlarmConfiguration', 1);
		}
		if (actc === LatchedMode.eLatched) {
			csSetValue('ActionConfiguration', 0);
		} else if (actc === LatchedMode.eUnlatched) {
			csSetValue('ActionConfiguration', 1);
		}
		if (faultc === LatchedMode.eLatched) {
			csSetValue('FaultConfiguration', 0);
		} else if (faultc === LatchedMode.eUnlatched) {
			csSetValue('FaultConfiguration', 1);
		}
		if (alamm === AlarmMode.eUp_InstantFire) {
			csSetValue('AlarmMode', 1);
		} else if (alamm === AlarmMode.eDown_Cumulative) {
			csSetValue('AlarmMode', 2);
		}
		csSetValue('ActionLevel1', deviceParams.channel1ActionLevel);
		csSetValue('AlarmLevel1', deviceParams.channel1AlarmLevel);
		csSetValue('Referenceflow1', deviceParams.referenceFlowCh1);
		csSetValue('FlowFaultThreshold1Value', deviceParams.flowFaultThresholdCh1);
		csSetValue(
			'FlowFaultThreshold1',
			deviceParams.flowFaultThresholdCh1 === 15 ? 0 : 1,
		);
		csSetValue('ActionLevel2', deviceParams.channel2ActionLevel);
		csSetValue('AlarmLevel2', deviceParams.channel2AlarmLevel);
		csSetValue('Referenceflow2', deviceParams.referenceFlowCh2);
		csSetValue('FlowFaultThreshold2Value', deviceParams.flowFaultThresholdCh2);
		csSetValue(
			'FlowFaultThreshold2',
			deviceParams.flowFaultThresholdCh2 === 15 ? 0 : 1,
		);
		//#endregion
	}
	//#endregion

	//#region Sync Parameters
	async function SyncCommandAsync() {
		let syncAnswer = true;
		if (!IsRealConfigOutOfBox) {
			syncAnswer = await confirmAlert(
				t('ResetDeviceConfirmation'),
				t('Reset Device'),
				t('Yes_UpperCase'),
				t('cancel'),
			);
		}
		if (syncAnswer) {
			await getDeviceConfig();
			if (isGeneralParameterVisible) {
				await GetGPIParametersFromDevice();
				await GetGeneralParametersFromDevice();
			} else {
				await GetChannelSensorsfromDevice();
			}
		}
	}
	async function getDeviceConfig() {
		let deviceConfig =
			await faastflexBluetoothCommunicator.GetDeviceConfiguration(
				DeviceType.eStandAlone,
			);
		if (isNotAllowedCommandError(deviceConfig.error)) {
			//Handle Error
		}
		setDeviceConfig(t(getConfigurationDescription(deviceConfig.devconfig)));
		if (deviceConfig.devconfig === Configuration.Extended) {
			setIsEnabledConfig(true);
		} else {
			setIsEnabledConfig(false);
		}
		if (deviceConfig.devconfig === Configuration.OutOfTheBox) {
			setIsRealConfigOutOfBox(true);
		} else {
			setIsRealConfigOutOfBox(false);
		}
	}
	//#endregion

	//#region Timer
	async function startTimerForTimeout() {
		// Clear any existing timer first
		if (timeoutTimerRef.current) {
			clearTimeout(timeoutTimerRef.current);
		}
		timeoutTimerRef.current = setTimeout(() => {
			setShowTimeOutScreen();
		}, 30 * 60 * 1000); // 30 minutes
	}
	function setShowTimeOutScreen() {
		setShowTimeoutPopup(true);
	}

	function handleCloseTimeoutMessage() {
		setShowTimeoutPopup(false);
	}
	//#endregion

	//#region Get Device Params

	function isNotAllowedCommandError(error: ErrorCode): boolean {
		return error === ErrorCode.eGCL_NOT_ALLOWED_COMMAND;
	}

	async function GetGPIParametersFromDevice() {
		try {
			if (
				selectedDeviceRef.current?.isDeviceConnected &&
				(await GetDeviceFirmware())
			) {
				showLoadingIndicator(t('LoadingGeneralDeviceParam'));
				if (IsRealConfigOutOfBox) {
					setGpiInputState(0);
					setUnbalancedEventTriggered(ExternalInputAction.eResetAlarmAndFault);
					setGpiNormalState(ExternalInputNormalState.eOpen);

					deviceParameters.current = {
						...deviceParameters.current,
						GPInputState: ExternalInputMode.eUnbalanced_Open_or_Short,
						ExternalInputNormalState: ExternalInputNormalState.eOpen,
						UnbalancedEventTriggered: ExternalInputAction.eResetAlarmAndFault,
					} as DeviceParametersModel;
					return;
				}
				var deviceGPIParams = new DeviceGPIParams();
				let gpiFetchResult =
					await faastflexBluetoothCommunicator.GetDeviceGPIParams();
				if (gpiFetchResult && gpiFetchResult.error !== ErrorCode.eOK) {
					console.log('Retrying to fetch GPI Parameters from device...');
					await delay(500);
					gpiFetchResult =
						await faastflexBluetoothCommunicator.GetDeviceGPIParams();
				}
				if (gpiFetchResult) {
					deviceGPIParams = {
						...deviceGPIParams,
						...gpiFetchResult.gpiParams,
					};
				}
				if (deviceGPIParams && gpiFetchResult.error === ErrorCode.eOK) {
					setIsGPIEnabledConfig(true);

					setGpiInputState(
						deviceGPIParams.GPIExternalInput ===
							ExternalInputMode.eUnbalanced_Open_or_Short
							? 0
							: deviceGPIParams.GPIExternalInput ===
							  ExternalInputMode.eBalanced_Open_or_Short_eol
							? 1
							: 0,
					);
					const gpiState =
						deviceGPIParams.GPIExternalInput ===
						ExternalInputMode.eUnbalanced_Open_or_Short
							? false
							: deviceGPIParams.GPIExternalInput ===
							  ExternalInputMode.eBalanced_Open_or_Short_eol
							? true
							: false;
					deviceParameters.current = {
						...deviceParameters.current,
						gpInputState: deviceGPIParams.GPIExternalInput,
						gpiState: gpiState,
					};
					if (
						deviceGPIParams.GPIExternalInput ==
						ExternalInputMode.eUnbalanced_Open_or_Short
					) {
						setGpiInputState(0);
						setGpiNormalState(deviceGPIParams.UnSupervisedNormalState);
						setUnbalancedEventTriggered(
							deviceGPIParams.UnSupervisedEventTriggered,
						);
					} else if (
						deviceGPIParams.GPIExternalInput ==
						ExternalInputMode.eBalanced_Open_or_Short_eol
					) {
						setGpiInputState(1);
						setEventTriggerOnClose(
							deviceGPIParams.SupervisedExternalTriggerOnClosed,
						);
						setEventTriggerOnOpen(
							deviceGPIParams.SupervisedExternalTriggerOnOpen,
						);
					}
					deviceParameters.current = {
						...deviceParameters.current,
						externalInputNormalState: deviceGPIParams.UnSupervisedNormalState,
						unbalancedEventTriggered:
							deviceGPIParams.UnSupervisedEventTriggered,
						externalTriggerOnClosed:
							deviceGPIParams.SupervisedExternalTriggerOnClosed,
						externalTriggerOnOpen:
							deviceGPIParams.SupervisedExternalTriggerOnOpen,
					};
				} else {
					Toast.show({
						type: 'error',
						text1: t(
							'Unable to fetch GPI Input data from the device, Please check and retry',
						),
						position: 'bottom',
					});
					setIsGPIEnabledConfig(false);
				}
			}
		} catch (error) {
			Toast.show({
				type: 'error',
				text1: t(
					'Unable to fetch GPI Input data from the device, Please check and retry',
				),
				position: 'bottom',
			});
			setIsGPIEnabledConfig(false);
		}
	}

	async function GetGeneralParametersFromDevice() {
		if (selectedDeviceRef.current?.isDeviceConnected) {
			//TODO: Loading indicator fetching general parameters from the device
			//TODO : Translate all text
			var result =
				await faastflexBluetoothCommunicator.GetDeviceGeneralParams();
			var generalParamsData = result?.generalParams;

			var deviceOrientation =
				getDeviceOrientationDescription(generalParamsData?.DeviceOrientation) ||
				'';
			generalSetValue('Orientation', deviceOrientation);
			setDeviceOrientation(deviceOrientation);
			if (isNotAllowedCommandError(result.error)) {
				setShowTimeOutScreen();
				return;
			} else {
				setSelectedDevice({
					deviceOrientation: deviceOrientation,
				});
			}

			if (isNotAllowedCommandError(result.error)) {
				setShowTimeOutScreen();
				return;
			} else {
				if (generalParamsData?.DeviceDateTime) {
					const deviceDateTime = new Date(generalParamsData.DeviceDateTime);
					const installationDate = new Date(
						deviceDateTime.getFullYear(),
						deviceDateTime.getMonth(),
						deviceDateTime.getDate(),
						deviceDateTime.getHours(),
						deviceDateTime.getMinutes(),
						deviceDateTime.getSeconds(),
					);
					generalSetValue('selectedDate', installationDate);
					generalSetValue('selectedTime', installationDate);
					deviceParameters.current = {
						...deviceParameters.current,
						installationDate: installationDate,
						installationDateTime: installationDate,
					} as DeviceParametersModel;
				}
			}

			// var timeOutDisabled = generalParamsData?.DisableTimeout || 0;
			// if(isNotAllowedCommandError(result.error)){
			//     setShowTimeOutScreen();
			//     return;
			// }
			// else{
			//     setSelectedTimeoutDisabled(timeOutDisabled);
			//     setDeviceParameters(prevParams => ({
			//         ...prevParams,
			//         timeOutDisabled: timeOutDisabled,
			//     }));

			// }

			var trendLogDisabled = generalParamsData?.Trendlog;
			if (isNotAllowedCommandError(result.error)) {
				setShowTimeOutScreen();
				return;
			} else {
				generalSetValue('TrendLogInterval', trendLogDisabled, {
					shouldValidate: true,
				});
				setSelectedTrendDisabled(trendLogDisabled);
				deviceParameters.current = {
					...deviceParameters.current,
					trendLogDisabled: trendLogDisabled,
				} as DeviceParametersModel;
			}

			var tempRelay = generalParamsData?.TempRelay;
			setTempRelay(tempRelay);
			if (isNotAllowedCommandError(result.error)) {
				setShowTimeOutScreen();
				return;
			} else {
				deviceParameters.current = {
					...deviceParameters.current,
					temperatureFaultRelay: tempRelay,
				} as DeviceParametersModel;
				var value = tempRelay == RelayAlert.eSet ? 0 : 1;
				generalSetValue('isTemparatureFaultSetRelays', value);
				if (tempRelay == RelayAlert.eSet) {
					setSelectedTempfaultRelay(true);
					setSelectedTempfaultRelay1(false);
				} else if (tempRelay == RelayAlert.eUnset) {
					setSelectedTempfaultRelay1(true);
					setSelectedTempfaultRelay(false);
				} else {
					setSelectedTempfaultRelay(false);
					setSelectedTempfaultRelay1(false);
				}
			}

			var lowRelay = generalParamsData?.LowPowerRelay;
			setLowRelay(lowRelay);
			if (isNotAllowedCommandError(result.error)) {
				setShowTimeOutScreen();
				return;
			} else {
				deviceParameters.current = {
					...deviceParameters.current,
					lowPowerFaultRelay: lowRelay,
				} as DeviceParametersModel;
				var value = lowRelay == RelayAlert.eSet ? 0 : 1;
				generalSetValue('isLowPowerFaultSetRelays', value);
				if (lowRelay == RelayAlert.eSet) {
					setSelectedLowPowerfaultRelay(true);
					setSelectedLowPowerfaultRelay1(false);
				} else if (lowRelay == RelayAlert.eUnset) {
					setSelectedLowPowerfaultRelay1(true);
					setSelectedLowPowerfaultRelay(false);
				} else {
					setSelectedLowPowerfaultRelay(false);
					setSelectedLowPowerfaultRelay1(false);
				}
			}

			var blwrSpeed = generalParamsData?.BlowerSpeedLevel;
			setBlowerSpeed(blwrSpeed);
			if (isNotAllowedCommandError(result.error)) {
				setShowTimeOutScreen();
				return;
			} else {
				deviceParameters.current = {
					...deviceParameters.current,
					blowerSpeed: blwrSpeed,
				} as DeviceParametersModel;

				if (
					blwrSpeed == FanSpeedLevel.eLevel_1 ||
					blwrSpeed == FanSpeedLevel.eLevel_2 ||
					blwrSpeed == FanSpeedLevel.eLevel_3 ||
					blwrSpeed == FanSpeedLevel.eLevel_4 ||
					blwrSpeed == FanSpeedLevel.eLevel_5 ||
					blwrSpeed == FanSpeedLevel.eLevel_6
				) {
					generalSetValue('blowerSpeed', 0);
				} else {
					generalSetValue('blowerSpeed', 1);
				}
			}

			var blowerCorrection = generalParamsData?.BlowerSpeedCorrection;
			const blowerCorrectionMin =
				getFanPWMPercCorrectionDescription(blowerCorrection);
			if (isNotAllowedCommandError(result.error)) {
				setShowTimeOutScreen();
				return;
			} else {
				generalSetValue('blowerCorrection', blowerCorrectionMin);
				deviceParameters.current = {
					...deviceParameters.current,
					blowerCorrection: blowerCorrectionMin,
				} as DeviceParametersModel;
			}

			generalTrigger();
			hideLoadingIndicator();
		}
	}

	async function GetChannelSensorsfromDevice() {
		showLoadingIndicator(t('LoadingChannelsAndSensorsDetails'));
		if (selectedDeviceRef.current?.isDeviceConnected) {
			var result =
				await faastflexBluetoothCommunicator.GetDeviceChannelsAndSensorsParams();
			var channelAndSensorsData = result?.channelAndSensorParams;
			setIsChannel1Visible(true);
			setIsChannel2Visible(false);

			var selectedActionDelay =
				parseInt(channelAndSensorsData?.actionDelay) || 0;
			if (isNotAllowedCommandError(result.error)) {
				setShowTimeOutScreen();
				return;
			} else {
				csSetValue('ActionDelay', selectedActionDelay, {
					shouldValidate: true,
				});
				deviceParameters.current = {
					...deviceParameters.current,
					actionDelay: selectedActionDelay,
				} as DeviceParametersModel;
				setSelectedActionDelay(selectedActionDelay);
			}

			var selectedAlarmDelay = parseInt(channelAndSensorsData?.alarmDelay) || 0;
			if (isNotAllowedCommandError(result.error)) {
				setShowTimeOutScreen();
				return;
			} else {
				csSetValue('AlarmDelay', selectedAlarmDelay, {
					shouldValidate: true,
				});
				deviceParameters.current = {
					...deviceParameters.current,
					alarmDelay: selectedAlarmDelay,
				} as DeviceParametersModel;
				setSelectedAlarmDelay(selectedAlarmDelay);
			}

			var selectedFlowFaultDelay =
				parseInt(channelAndSensorsData?.flowFaultDelay) || 0;
			if (isNotAllowedCommandError(result.error)) {
				setShowTimeOutScreen();
				return;
			} else {
				csSetValue('FlowFaultDelay', selectedFlowFaultDelay, {
					shouldValidate: true,
				});
				deviceParameters.current = {
					...deviceParameters.current,
					flowFaultDelay: selectedFlowFaultDelay,
				} as DeviceParametersModel;
				setSelectedFlowFaultDelay(selectedFlowFaultDelay);
			}

			var alarmLatched = channelAndSensorsData?.alarmLatched;
			setAlarmC(alarmLatched);
			if (isNotAllowedCommandError(result.error)) {
				setShowTimeOutScreen();
				return;
			} else {
				if (
					selectedDeviceRef.current.deviceCountryCode ===
					getCountryDescription(Country.CHINA)
				) {
					setIsChineseDevice(true);
					setAlarmC(LatchedMode.eLatched);
					alarmLatched = LatchedMode.eLatched;
				} else {
					setIsChineseDevice(false);
				}
				deviceParameters.current = {
					...deviceParameters.current,
					alarmLatched: alarmLatched,
				} as DeviceParametersModel;
				var value = alarmLatched == LatchedMode.eLatched ? 0 : 1;
				csSetValue('AlarmConfiguration', value);
				if (alarmLatched == LatchedMode.eLatched) {
					setSelectedAlarmConfig(true);
					setSelectedAlarmConfig1(false);
				} else if (alarmLatched == LatchedMode.eUnlatched) {
					setSelectedAlarmConfig(false);
					setSelectedAlarmConfig1(true);
				}
			}

			var actionLatched = channelAndSensorsData?.preAlarmLatched;
			setActC(actionLatched);
			if (isNotAllowedCommandError(result.error)) {
				setShowTimeOutScreen();
				return;
			} else {
				deviceParameters.current = {
					...deviceParameters.current,
					actionLatched: actionLatched,
				} as DeviceParametersModel;
				var value = actionLatched == LatchedMode.eLatched ? 0 : 1;
				csSetValue('ActionConfiguration', value);
				if (actionLatched == LatchedMode.eLatched) {
					setSelectedActionConfig(true);
					setSelectedActionConfig1(false);
				} else if (actionLatched == LatchedMode.eUnlatched) {
					setSelectedActionConfig(false);
					setSelectedActionConfig1(true);
				}
			}

			var faultLatched = channelAndSensorsData?.faultLatched;
			setFaultC(faultLatched);
			if (isNotAllowedCommandError(result.error)) {
				setShowTimeOutScreen();
				return;
			} else {
				deviceParameters.current = {
					...deviceParameters.current,
					faultLatched: faultLatched,
				} as DeviceParametersModel;
				var value = faultLatched == LatchedMode.eLatched ? 0 : 1;
				csSetValue('FaultConfiguration', value);
				if (faultLatched == LatchedMode.eLatched) {
					setSelectedFaultConfig(true);
					setSelectedFaultConfig1(false);
				} else if (faultLatched == LatchedMode.eUnlatched) {
					setSelectedFaultConfig(false);
					setSelectedFaultConfig1(true);
				}
			}

			var alarmMode = channelAndSensorsData?.alarmMode;
			setAlarmM(alarmMode);
			if (isNotAllowedCommandError(result.error)) {
				setShowTimeOutScreen();
				return;
			} else {
				deviceParameters.current = {
					...deviceParameters.current,
					deviceAlarmMode: alarmMode,
				} as DeviceParametersModel;
				var value = alarmMode == AlarmMode.eUp_InstantFire ? 0 : 1;
				csSetValue('AlarmMode', value);
				if (alarmMode == AlarmMode.eUp_InstantFire) {
					setSelectedAlarmMode(true);
					setSelectedAlarmMode1(false);
				} else if (alarmMode == AlarmMode.eDown_Cumulative) {
					setSelectedAlarmMode(false);
					setSelectedAlarmMode1(true);
				}
			}

			var channel1ActionLevel: number = channelAndSensorsData?.ch1PreAlarmLevel;
			if (isNotAllowedCommandError(result.error)) {
				setShowTimeOutScreen();
				return;
			} else {
				deviceParameters.current = {
					...deviceParameters.current,
					channel1ActionLevel: channel1ActionLevel,
				} as DeviceParametersModel;
				csSetValue('ActionLevel1', channel1ActionLevel);
				setSelectedChannel1ActionLevel(channel1ActionLevel);
			}

			var channel1AlarmLevel: number = channelAndSensorsData?.ch1AlarmLevel;
			if (isNotAllowedCommandError(result.error)) {
				setShowTimeOutScreen();
				return;
			} else {
				deviceParameters.current = {
					...deviceParameters.current,
					channel1AlarmLevel: channel1AlarmLevel,
				} as DeviceParametersModel;
				csSetValue('AlarmLevel1', channel1AlarmLevel);
				setSelectedChannel1AlarmLevel(channel1AlarmLevel);
			}

			var flowFaultThresholdCh1: number =
				channelAndSensorsData?.ch1FlowFaultThreshold;
			if (isNotAllowedCommandError(result.error)) {
				setShowTimeOutScreen();
				return;
			} else {
				var type = flowFaultThresholdCh1 <= 15 ? 0 : 1;
				var value = type === 0 ? 15 : flowFaultThresholdCh1;
				deviceParameters.current = {
					...deviceParameters.current,
					flowFaultThresholdCh1: value,
				} as DeviceParametersModel;
				csSetValue('FlowFaultThreshold1', type);
				csSetValue('FlowFaultThreshold1Value', value);
				setSelectedFlowFaultThresholdCh1(flowFaultThresholdCh1);
				setIsEn54Standard1(flowFaultThresholdCh1 <= 15);
				setTempFlowfault1(flowFaultThresholdCh1);
				setIsOtherStandard1(flowFaultThresholdCh1 > 15);
			}

			var selectedReferenceFlowCh1: number =
				channelAndSensorsData?.ch1RefAirflow;
			if (isNotAllowedCommandError(result.error)) {
				setShowTimeOutScreen();
				return;
			} else {
				deviceParameters.current = {
					...deviceParameters.current,
					referenceFlowCh1: selectedReferenceFlowCh1,
				} as DeviceParametersModel;
				csSetValue('Referenceflow1', selectedReferenceFlowCh1);
			}

			var channel2ActionLevel: number = channelAndSensorsData?.ch2PreAlarmLevel;
			if (isNotAllowedCommandError(result.error)) {
				setShowTimeOutScreen();
				return;
			} else {
				deviceParameters.current = {
					...deviceParameters.current,
					channel2ActionLevel: channel2ActionLevel,
				} as DeviceParametersModel;
				csSetValue('ActionLevel2', channel2ActionLevel);
				setSelectedChannel2ActionLevel(channel2ActionLevel);
			}

			var channel2AlarmLevel: number = channelAndSensorsData?.ch2AlarmLevel;
			if (isNotAllowedCommandError(result.error)) {
				setShowTimeOutScreen();
				return;
			} else {
				deviceParameters.current = {
					...deviceParameters.current,
					channel2AlarmLevel: channel2AlarmLevel,
				} as DeviceParametersModel;
				csSetValue('AlarmLevel2', channel2AlarmLevel);
				setSelectedChannel2AlarmLevel(channel2AlarmLevel);
			}

			var flowFaultThresholdCh2: number =
				channelAndSensorsData?.ch2FlowFaultThreshold;
			if (isNotAllowedCommandError(result.error)) {
				setShowTimeOutScreen();
				return;
			} else {
				var type = flowFaultThresholdCh2 <= 15 ? 0 : 1;
				var value = type === 0 ? 15 : flowFaultThresholdCh2;
				deviceParameters.current = {
					...deviceParameters.current,
					flowFaultThresholdCh2: value,
				} as DeviceParametersModel;
				csSetValue('FlowFaultThreshold2', type);
				csSetValue('FlowFaultThreshold2Value', value);
				setSelectedFlowFaultThresholdCh2(flowFaultThresholdCh2);
				setIsEn54Standard2(flowFaultThresholdCh2 <= 15);
				setTempFlowfault2(flowFaultThresholdCh2);
				setIsOtherStandard2(flowFaultThresholdCh2 > 15);
			}
			var selectedReferenceFlowCh2: number =
				channelAndSensorsData?.ch2RefAirflow;
			if (isNotAllowedCommandError(result.error)) {
				setShowTimeOutScreen();
				return;
			} else {
				deviceParameters.current = {
					...deviceParameters.current,
					referenceFlowCh2: selectedReferenceFlowCh2,
				} as DeviceParametersModel;
				csSetValue('Referenceflow2', selectedReferenceFlowCh2);
			}
			csTrigger();
			hideLoadingIndicator();
		}
	}
	//#endregion

	//#region Save Params to Device
	const onSaveParamsPressed = () => {
		saveParametersToDevice();
	};
	async function saveParametersToDevice(isFromTabSelection: boolean = false) {
		try {
			if (
				ConnectedDeviceobj.current !== null &&
				selectedDeviceRef.current?.isDeviceConnected
			) {
				ClearGeneralParamsSaveFailedErrors();
				ClearChannelsandSensorsSaveFailedErrors();
				var generalparameterCount = 0;
				var channelAndSensorParamCount = 0;

				if (isGeneralParameterVisible) {
					var isGeneralParamsValid = await ValidateGeneralParams('');
					if (isGeneralParamsValid) {
						const resultCount = isGeneralParametersChanged();

						//TODO Translate
						const shouldSave =
							selectedDevice?.deviceMacAddress !== 'Not Connected yet' &&
							!selectedDevice.isDeviceConnected
								? false
								: resultCount.hasChanges
								? await confirmAlert(
										stringFormat(
											t('SaveGeneralParameterconfirmation'),
											resultCount.count.toString(),
										),
										t('SaveGeneral'),
										t('save'),
										t('cancel'),
								  )
								: false;

						if (shouldSave) {
							showLoadingIndicator(t('SyncingDeviceParams'));
							if (ConnectedDeviceobj.current !== null) {
								generalParams = [];
								retryGeneralParams = [];

								const selectedDate = generalWatch('selectedDate');
								const selectedTime = generalWatch('selectedTime');
								if (selectedDate !== null) {
									const installDate = new Date(
										selectedDate.getFullYear(),
										selectedDate.getMonth(),
										selectedDate.getDate(),
										selectedTime.getHours(),
										selectedTime.getMinutes(),
										selectedTime.getSeconds(),
									);
									selectedInstallationDateRef.current = installDate;
									if (
										deviceParameters.current.installationDate?.getTime() !==
										installDate.getTime()
									) {
										generalParams.push(FF_DateTime);
									}
								}

								if (IsEnabledConfig) {
									const trendLogInterval = generalWatch('TrendLogInterval');
									if (
										deviceParameters.current.trendLogDisabled !==
										trendLogInterval
									) {
										generalParams.push(FF_TrendLogDisabled);
									}
									const isTemparatureFaultSetRelays = generalWatch(
										'isTemparatureFaultSetRelays',
									);
									var tempRelay =
										isTemparatureFaultSetRelays === 0
											? RelayAlert.eSet
											: RelayAlert.eUnset;
									setTempFaultRelay(tempRelay);
									if (
										deviceParameters.current.temperatureFaultRelay !== tempRelay
									) {
										//&& tempRelay !== RelayAlert.eUnknown
										generalParams.push(FF_TemperatureFaultRelay);
									}
									const isLowPowerFaultSetRelays = generalWatch(
										'isLowPowerFaultSetRelays',
									);
									var lowPowerRelay =
										isLowPowerFaultSetRelays === 0
											? RelayAlert.eSet
											: RelayAlert.eUnset;
									setLowpowerFaultRelay(lowPowerRelay);
									if (
										deviceParameters.current.lowPowerFaultRelay !==
										lowPowerRelay
									) {
										//TODO && lowPowerRelay !== RelayAlert.eUnknown
										generalParams.push(FF_LowPowerFaultRelay);
									}

									if (IsGPIVisible && IsGPIEnabledConfig) {
										if (gpiInputState) {
											if (
												deviceParameters.current.gpInputState !==
												ExternalInputMode.eBalanced_Open_or_Short_eol
											) {
												generalParams.push(FF_GPIInputStateSupervised);
											}
											if (
												deviceParameters.current.externalTriggerOnOpen !==
												eventTriggerOnOpen
											) {
												generalParams.push(FF_ExternalTriggerOnOpen);
											}
											if (
												deviceParameters.current.externalTriggerOnClosed !==
												eventTriggerOnClose
											) {
												generalParams.push(FF_ExternalTriggerOnClosed);
											}
										} else {
											if (
												deviceParameters.current.gpInputState !==
												ExternalInputMode.eUnbalanced_Open_or_Short
											) {
												generalParams.push(FF_GPIInputStateUnSupervised);
											}
											if (
												deviceParameters.current.externalInputNormalState !==
												gpiNormalState
											) {
												generalParams.push(FF_ExternalInputNormalState);
											}
											if (
												deviceParameters.current.unbalancedEventTriggered !==
												unbalancedEventTriggered
											) {
												generalParams.push(FF_UnbalancedEventTriggered);
											}
										}
									}
									const blowerCorrection = generalWatch('blowerSpeed');
									var tempFanSpeed =
										blowerCorrection === 0
											? FanSpeedLevel.eLevel_5
											: FanSpeedLevel.eLevel_10;
									if (deviceParameters.current.blowerSpeed !== tempFanSpeed) {
										//TODO && tempFanSpeed !== FanSpeedLevel.eUnknown
										generalParams.push(FF_BlowerSpeed);
									}
								}
								if (generalParams === null || generalParams.length <= 0) {
									hideLoadingIndicator();
									Toast.show({
										type: 'info',
										text2: t('nodatachanged'),
										position: 'bottom',
									});
									return;
								}
								const results: boolean[] = [];
								for (const paramName of generalParams) {
									const success = await saveGeneralParametersToDevice(
										paramName,
									);
									results.push(success);

									if (!success) {
										retryGeneralParams.push(paramName);
									}
									await delay(100);
								}
								await delay(100);

								if (retryGeneralParams.length > 0) {
									const retryResults: boolean[] = [];
									const stillretryGeneralParams: string[] = [];

									for (const paramName of retryGeneralParams) {
										console.log(`[SaveParams] Retrying: ${paramName}`);
										const success = await saveGeneralParametersToDevice(
											paramName,
										);
										retryResults.push(success);

										if (!success) {
											stillretryGeneralParams.push(paramName);
										}

										await delay(100);
									}
									hideLoadingIndicator();

									if (stillretryGeneralParams.length === 0) {
										generalClearErrors();
										Toast.show({
											type: 'success',
											text2: t('SyncingDeviceParamsSuccess'),
											position: 'bottom',
										});
									} else {
										Toast.show({
											type: 'error',
											text2: t('SyncingDeviceGeneralParamsFailed'),
											position: 'bottom',
										});
									}
								} else {
									hideLoadingIndicator();
									generalClearErrors();
									Toast.show({
										type: 'success',
										text2: t('SyncingDeviceParamsSuccess'),
										position: 'bottom',
									});
								}
							}
						}
						if (isFromTabSelection) {
							setIsGeneralParameterVisible(false);
							setIsChannelsAndSensorsVisible(true);
						}
					}
					setImportConfiginProgress(false);
				} else {
					var isVaidChannels = await ValidateChannelAndSensorParams('');
					if (isVaidChannels) {
						const resultCount = isChannelSensorParametersChanged();

						//TODO Translate
						const shouldSave =
							selectedDevice?.deviceMacAddress !== 'Not Connected yet' &&
							!selectedDevice.isDeviceConnected
								? false
								: resultCount.hasChanges
								? await confirmAlert(
										stringFormat(
											t('Savechannelsensorconfirmation'),
											resultCount.count.toString(),
										),
										t('Savechannelsensor'),
										t('save'),
										t('cancel'),
								  )
								: false;

						if (shouldSave) {
							showLoadingIndicator(t('SyncingDeviceParams'));
							if (ConnectedDeviceobj.current !== null) {
								channelsAndSensorsParams = [];
								retryChannelsAndSensorsParams = [];

								const actionDelay = csWatch('ActionDelay');
								if (deviceParameters.current.actionDelay !== actionDelay) {
									channelsAndSensorsParams.push(FF_ActionDelay);
								}
								const alarmDelay = csWatch('AlarmDelay');
								if (deviceParameters.current.alarmDelay !== alarmDelay) {
									channelsAndSensorsParams.push(FF_AlarmDelay);
								}
								const flowFaultDelay = csWatch('FlowFaultDelay');
								if (
									deviceParameters.current.flowFaultDelay !== flowFaultDelay
								) {
									channelsAndSensorsParams.push(FF_FlowFaultDelay);
								}
								const alarmConfig = csWatch('AlarmConfiguration');
								var tempAlarmLatchMode =
									alarmConfig === 0
										? LatchedMode.eLatched
										: LatchedMode.eUnlatched;
								setAlarmLatchMode(tempAlarmLatchMode);
								if (
									deviceParameters.current.alarmLatched !== tempAlarmLatchMode
								) {
									//TODO && tempAlarmLatchMode !== LatchedMode.eUnknown
									channelsAndSensorsParams.push(FF_AlarmLatched);
								}
								const actionConfig = csWatch('ActionConfiguration');
								var tempPreAlarmLatchMode =
									actionConfig === 0
										? LatchedMode.eLatched
										: LatchedMode.eUnlatched;
								setAlarmLatchMode(tempPreAlarmLatchMode);
								if (
									deviceParameters.current.actionLatched !==
									tempPreAlarmLatchMode
								) {
									//TODO && tempPreAlarmLatchMode !== LatchedMode.eUnknown
									channelsAndSensorsParams.push(FF_ActionLatched);
								}
								const faultConfig = csWatch('FaultConfiguration');
								var tempFaultLatchMode =
									faultConfig === 0
										? LatchedMode.eLatched
										: LatchedMode.eUnlatched;
								setFaultLatchMode(tempFaultLatchMode);
								if (
									deviceParameters.current.faultLatched !== tempFaultLatchMode
								) {
									//TODO && tempFaultLatchMode !== LatchedMode.eUnknown
									channelsAndSensorsParams.push(FF_FaultLatched);
								}
								const alarmMode = csWatch('AlarmMode');
								var tempFFAlarmMode =
									alarmMode === 0
										? AlarmMode.eUp_InstantFire
										: alarmMode === 1
										? AlarmMode.eDown_Cumulative
										: AlarmMode.eUnknown;
								setFFAlarmMode(tempFFAlarmMode);
								if (
									deviceParameters.current.deviceAlarmMode !==
										tempFFAlarmMode &&
									tempFFAlarmMode !== AlarmMode.eUnknown
								) {
									channelsAndSensorsParams.push(FF_AlarmMode);
								}
								const ActionLevel1 = csWatch('ActionLevel1');
								if (
									deviceParameters.current.channel1ActionLevel !== ActionLevel1
								) {
									channelsAndSensorsParams.push(FF_Channel1ActionLevel);
								}
								const AlarmLevel1 = csWatch('AlarmLevel1');
								if (
									deviceParameters.current.channel1AlarmLevel !== AlarmLevel1
								) {
									channelsAndSensorsParams.push(FF_Channel1AlarmLevel);
								}
								const FlowFaultThreshold1 = csWatch('FlowFaultThreshold1Value');
								if (
									deviceParameters.current.flowFaultThresholdCh1 !==
									FlowFaultThreshold1
								) {
									channelsAndSensorsParams.push(FF_FlowFaultThreshold1);
								}
								if (IsChannel2Available) {
									const ActionLevel2 = csWatch('ActionLevel2');
									if (
										deviceParameters.current.channel2ActionLevel !==
										ActionLevel2
									) {
										channelsAndSensorsParams.push(FF_Channel2ActionLevel);
									}
									const AlarmLevel2 = csWatch('AlarmLevel2');
									if (
										deviceParameters.current.channel2AlarmLevel !== AlarmLevel2
									) {
										channelsAndSensorsParams.push(FF_Channel2AlarmLevel);
									}
									const FlowFaultThreshold2 = csWatch(
										'FlowFaultThreshold2Value',
									);
									if (
										deviceParameters.current.flowFaultThresholdCh2 !==
										FlowFaultThreshold2
									) {
										channelsAndSensorsParams.push(FF_FlowFaultThreshold2);
									}
								}

								if (
									channelsAndSensorsParams === null ||
									channelsAndSensorsParams.length <= 0
								) {
									hideLoadingIndicator();
									Toast.show({
										type: 'info',
										text2: t('nodatachanged'),
										position: 'bottom',
									});
									return;
								}

								const results: boolean[] = [];
								for (const paramName of channelsAndSensorsParams) {
									const success = await SaveChannelsAndSensorsToDevice(
										paramName,
									);
									results.push(success);

									if (!success) {
										retryChannelsAndSensorsParams.push(paramName);
									}

									// Small delay between operations for device processing
									await delay(100);
								}
								//  const result = await Promise.all(generalParams);

								await delay(100);

								if (retryChannelsAndSensorsParams.length > 0) {
									const retryResults: boolean[] = [];
									const stillretryChannelsAndSensorsParams: string[] = [];

									for (const paramName of retryChannelsAndSensorsParams) {
										console.log(`[SaveParams] Retrying: ${paramName}`);
										const success = await SaveChannelsAndSensorsToDevice(
											paramName,
										);
										retryResults.push(success);

										if (!success) {
											stillretryChannelsAndSensorsParams.push(paramName);
										}

										await delay(100);
									}
									hideLoadingIndicator();

									if (stillretryChannelsAndSensorsParams.length === 0) {
										generalClearErrors();
										Toast.show({
											type: 'success',
											text2: t('SyncingDeviceParamsSuccess'),
											position: 'bottom',
										});
									} else {
										Toast.show({
											type: 'error',
											text2: t('SyncingChannelsAndSensorsDataFailed'),
											position: 'bottom',
										});
									}
								} else {
									hideLoadingIndicator();
									generalClearErrors();
									Toast.show({
										type: 'success',
										text2: t('SyncingDeviceParamsSuccess'),
										position: 'bottom',
									});
								}
							}
						}
					}
					if (isFromTabSelection) {
						setIsGeneralParameterVisible(true);
						setIsChannelsAndSensorsVisible(false);
					}
				}
				deviceParameters.current = {
					...deviceParameters.current,
					deviceId: selectedDevice.deviceId,
					deviceName: selectedDevice.deviceName,
					channels: selectedDevice.channels,
				} as DeviceParametersModel;

				await dispatch(
					updateExistingDeviceParameter({
						dataSource,
						deviceId: selectedDevice.deviceId,
						updates: deviceParameters.current,
					}),
				);
			} else if (selectedDeviceRef.current?.isDeviceConnected === false) {
				if (isGeneralParameterVisible) {
					setIsGeneralParameterVisible(false);
					setIsChannelsAndSensorsVisible(true);
				} else {
					setIsGeneralParameterVisible(true);
					setIsChannelsAndSensorsVisible(false);
				}
			} else {
				Toast.show({
					type: 'success',
					text2: t('PlsConnectDevice'),
					position: 'bottom',
				});
			}
		} catch (error) {
			hideLoadingIndicator();
		}
	}

	async function saveGeneralParametersToDevice(
		paramName: string,
	): Promise<boolean> {
		try {
			switch (paramName) {
				case FF_DateTime:
					const dateTimeL = selectedInstallationDateRef.current;
					const year = dateTimeL.getFullYear() % 100;
					const month = dateTimeL.getMonth() + 1;
					const day = dateTimeL.getDate();
					const hours = dateTimeL.getHours();
					const minutes = dateTimeL.getMinutes();
					const seconds = dateTimeL.getSeconds();
					const dateTime =
						await faastflexBluetoothCommunicator.SetDatetimeofDevice(
							year,
							month,
							day,
							hours,
							minutes,
							seconds,
						);
					if (dateTime.isUpdated) {
						deviceParameters.current = {
							...deviceParameters.current,
							installationDate: selectedInstallationDateRef.current,
							installationDateTime: new Date(
								selectedInstallationTimeSpan.getHours(),
								selectedInstallationTimeSpan.getMinutes(),
								0,
							),
						} as DeviceParametersModel;
						return true;
					} else {
						setDeviceDateSaveFailed(true);
						if (dateTime.error === ErrorCode.eGCL_NOT_ALLOWED_COMMAND) {
							setShowTimeOutScreen();
						}
						return false;
					}

				case FF_TrendLogDisabled:
					const trendLogInterval = generalWatch('TrendLogInterval');
					const trendlogResult =
						await faastflexBluetoothCommunicator.SetTrendlogDisabled(
							trendLogInterval,
						);
					if (trendlogResult.isUpdated) {
						deviceParameters.current = {
							...deviceParameters.current,
							trendLogDisabled: trendLogInterval,
						} as DeviceParametersModel;
						return true;
					} else {
						setTrendLogIntervalSaveFailed(true);
						if (trendlogResult.error === ErrorCode.eGCL_NOT_ALLOWED_COMMAND) {
							setShowTimeOutScreen();
						}
						return false;
					}

				case FF_TemperatureFaultRelay:
					const tempFaultRelay =
						generalWatch('isTemparatureFaultSetRelays') === 0
							? RelayAlert.eSet
							: RelayAlert.eUnset;
					const temperatureFaultRelayResult =
						await faastflexBluetoothCommunicator.SetTempFaultSetRelay(
							tempFaultRelay,
						);
					if (temperatureFaultRelayResult.isUpdated) {
						deviceParameters.current = {
							...deviceParameters.current,
							temperatureFaultRelay: tempFaultRelay,
						} as DeviceParametersModel;
						return true;
					} else {
						setTempFaultSetsRelaysSaveFailed(true);
						if (
							temperatureFaultRelayResult.error ===
							ErrorCode.eGCL_NOT_ALLOWED_COMMAND
						) {
							setShowTimeOutScreen();
						}
						return false;
					}

				case FF_LowPowerFaultRelay:
					const lowpowerFaultRelay =
						generalWatch('isLowPowerFaultSetRelays') === 0
							? RelayAlert.eSet
							: RelayAlert.eUnset;
					const lowPowerFaultRelayResult =
						await faastflexBluetoothCommunicator.SetLowPowerFaultSetRelay(
							lowpowerFaultRelay,
						);
					if (lowPowerFaultRelayResult.isUpdated) {
						deviceParameters.current = {
							...deviceParameters.current,
							lowPowerFaultRelay: lowpowerFaultRelay,
						} as DeviceParametersModel;
						return true;
					} else {
						setLowPowerFaultSetsRelaysSaveFailed(true);
						if (
							lowPowerFaultRelayResult.error ===
							ErrorCode.eGCL_NOT_ALLOWED_COMMAND
						) {
							setShowTimeOutScreen();
						}
						return false;
					}

				case FF_GPIInputStateSupervised:
					const inputSupervised =
						await faastflexBluetoothCommunicator.SetExternalInput(
							ExternalInputMode.eBalanced_Open_or_Short_eol,
						);
					if (inputSupervised.isUpdated) {
						deviceParameters.current = {
							...deviceParameters.current,
							gpInputState: ExternalInputMode.eBalanced_Open_or_Short_eol,
							gpiState: true,
						} as DeviceParametersModel;
						return true;
					} else {
						setGPISaveFailed(true);
						if (inputSupervised.error === ErrorCode.eGCL_NOT_ALLOWED_COMMAND) {
							setShowTimeOutScreen();
						}
						return false;
					}

				case FF_ExternalTriggerOnOpen:
					const externalTriggerOnOpen =
						await faastflexBluetoothCommunicator.SetExternalTriggredOpen(
							eventTriggerOnOpen,
						);
					if (externalTriggerOnOpen.isUpdated) {
						deviceParameters.current = {
							...deviceParameters.current,
							externalTriggerOnOpen: eventTriggerOnOpen,
						} as DeviceParametersModel;
						return true;
					} else {
						setGPISaveFailed(true);
						if (
							externalTriggerOnOpen.error === ErrorCode.eGCL_NOT_ALLOWED_COMMAND
						) {
							setShowTimeOutScreen();
						}
						return false;
					}

				case FF_ExternalTriggerOnClosed:
					const tempEventTriggeredOnClose =
						await faastflexBluetoothCommunicator.SetExternalTriggredClosed(
							eventTriggerOnClose,
						);
					if (tempEventTriggeredOnClose.isUpdated) {
						deviceParameters.current = {
							...deviceParameters.current,
							externalTriggerOnClosed: eventTriggerOnClose,
						} as DeviceParametersModel;
						return true;
					} else {
						setGPISaveFailed(true);
						if (
							tempEventTriggeredOnClose.error ===
							ErrorCode.eGCL_NOT_ALLOWED_COMMAND
						) {
							setShowTimeOutScreen();
						}
						return false;
					}

				case FF_GPIInputStateUnSupervised:
					const inputUnSupervised =
						await faastflexBluetoothCommunicator.SetExternalInput(
							ExternalInputMode.eUnbalanced_Open_or_Short,
						);
					if (inputUnSupervised.isUpdated) {
						deviceParameters.current = {
							...deviceParameters.current,
							gpInputState: ExternalInputMode.eUnbalanced_Open_or_Short,
							gpiState: false,
						} as DeviceParametersModel;
						return true;
					} else {
						setGPISaveFailed(true);
						if (
							inputUnSupervised.error === ErrorCode.eGCL_NOT_ALLOWED_COMMAND
						) {
							setShowTimeOutScreen();
						}
						return false;
					}

				case FF_ExternalInputNormalState:
					const externalInputNormalState =
						await faastflexBluetoothCommunicator.SetExternalUnbalancedNormalState(
							gpiNormalState,
						);
					if (externalInputNormalState.isUpdated) {
						deviceParameters.current = {
							...deviceParameters.current,
							externalInputNormalState: gpiNormalState,
						} as DeviceParametersModel;
						return true;
					} else {
						setGPISaveFailed(true);
						if (
							externalInputNormalState.error ===
							ErrorCode.eGCL_NOT_ALLOWED_COMMAND
						) {
							setShowTimeOutScreen();
						}
						return false;
					}

				case FF_UnbalancedEventTriggered:
					const tempUnbalancedEventTriggered =
						await faastflexBluetoothCommunicator.SetExternalTriggredUnbalanced(
							unbalancedEventTriggered,
						);
					if (tempUnbalancedEventTriggered.isUpdated) {
						deviceParameters.current = {
							...deviceParameters.current,
							unbalancedEventTriggered: unbalancedEventTriggered,
						} as DeviceParametersModel;
						return true;
					} else {
						setGPISaveFailed(true);
						if (
							tempUnbalancedEventTriggered.error ===
							ErrorCode.eGCL_NOT_ALLOWED_COMMAND
						) {
							setShowTimeOutScreen();
						}
						return false;
					}

				case FF_BlowerSpeed:
					const blowerCorrection =
						generalWatch('blowerSpeed') === 0
							? FanSpeedLevel.eLevel_5
							: FanSpeedLevel.eLevel_10;
					const blowerSpeed =
						await faastflexBluetoothCommunicator.SetBlowerSpeed(
							blowerCorrection,
						);
					if (blowerSpeed.isUpdated) {
						deviceParameters.current = {
							...deviceParameters.current,
							blowerSpeed: blowerCorrection,
						} as DeviceParametersModel;
						return true;
					} else {
						setAspiratorSpeedSaveFailed(true);
						if (blowerSpeed.error === ErrorCode.eGCL_NOT_ALLOWED_COMMAND) {
							setShowTimeOutScreen();
						}
						return false;
					}

				default:
					return false;
			}
		} catch (error) {
			return false;
		}
	}

	async function SaveChannelsAndSensorsToDevice(
		paramName: string,
	): Promise<boolean> {
		try {
			switch (paramName) {
				case FF_ActionDelay:
					const actionDelay = csWatch('ActionDelay');
					const preAlarmResult =
						await faastflexBluetoothCommunicator.SetPreAlarmDelay(actionDelay);
					if (preAlarmResult.isUpdated) {
						deviceParameters.current = {
							...deviceParameters.current,
							actionDelay: actionDelay,
						} as DeviceParametersModel;
						return true;
					} else {
						setActionDelaySaveFailed(true);
						if (preAlarmResult.error === ErrorCode.eGCL_NOT_ALLOWED_COMMAND) {
							setShowTimeOutScreen();
						}
						return false;
					}
				case FF_AlarmDelay:
					const alarmDelay = csWatch('AlarmDelay');
					const alarmDelayResult =
						await faastflexBluetoothCommunicator.SetAlarmDelay(alarmDelay);
					if (alarmDelayResult.isUpdated) {
						deviceParameters.current = {
							...deviceParameters.current,
							alarmDelay: alarmDelay,
						} as DeviceParametersModel;
						return true;
					} else {
						setAlarmDelaySaveFailed(true);
						if (alarmDelayResult.error === ErrorCode.eGCL_NOT_ALLOWED_COMMAND) {
							setShowTimeOutScreen();
						}
						return false;
					}

				case FF_FlowFaultDelay:
					const flowFaultDelay = csWatch('FlowFaultDelay');
					const flowFaultDelayResult =
						await faastflexBluetoothCommunicator.SetFlowFaultDelay(
							flowFaultDelay,
						);
					if (flowFaultDelayResult.isUpdated) {
						deviceParameters.current = {
							...deviceParameters.current,
							flowFaultDelay: flowFaultDelay,
						} as DeviceParametersModel;
						return true;
					} else {
						setFlowFaultDelaySaveFailed(true);
						if (
							flowFaultDelayResult.error === ErrorCode.eGCL_NOT_ALLOWED_COMMAND
						) {
							setShowTimeOutScreen();
						}
						return false;
					}

				case FF_AlarmLatched:
					const alarmConfig =
						csWatch('AlarmConfiguration') === 0
							? LatchedMode.eLatched
							: LatchedMode.eUnlatched;
					const alarmLatchedResult =
						await faastflexBluetoothCommunicator.SetAlarmLatched(alarmConfig);
					if (alarmLatchedResult.isUpdated) {
						deviceParameters.current = {
							...deviceParameters.current,
							alarmLatched: alarmConfig,
						} as DeviceParametersModel;
						return true;
					} else {
						setAlarmConfigSaveFailed(true);
						if (
							alarmLatchedResult.error === ErrorCode.eGCL_NOT_ALLOWED_COMMAND
						) {
							setShowTimeOutScreen();
						}
						return false;
					}

				case FF_ActionLatched:
					const actionConfig =
						csWatch('ActionConfiguration') === 0
							? LatchedMode.eLatched
							: LatchedMode.eUnlatched;
					const preAlarmLatchedResult =
						await faastflexBluetoothCommunicator.SetPreAlarmLatched(
							actionConfig,
						);
					if (preAlarmLatchedResult.isUpdated) {
						deviceParameters.current = {
							...deviceParameters.current,
							actionLatched: actionConfig,
						} as DeviceParametersModel;
						return true;
					} else {
						setActionConfigSaveFailed(true);
						if (
							preAlarmLatchedResult.error === ErrorCode.eGCL_NOT_ALLOWED_COMMAND
						) {
							setShowTimeOutScreen();
						}
						return false;
					}

				case FF_FaultLatched:
					const faultConfig =
						csWatch('FaultConfiguration') === 0
							? LatchedMode.eLatched
							: LatchedMode.eUnlatched;
					const faultLatchedResult =
						await faastflexBluetoothCommunicator.SetFaultLatched(faultConfig);
					if (faultLatchedResult.isUpdated) {
						deviceParameters.current = {
							...deviceParameters.current,
							faultLatched: faultConfig,
						} as DeviceParametersModel;
						return true;
					} else {
						setFaultConfigSaveFailed(true);
						if (
							faultLatchedResult.error === ErrorCode.eGCL_NOT_ALLOWED_COMMAND
						) {
							setShowTimeOutScreen();
						}
						return false;
					}

				case FF_AlarmMode:
					const alarmMode =
						csWatch('AlarmMode') === 0
							? AlarmMode.eUp_InstantFire
							: AlarmMode.eDown_Cumulative;
					const alarmModeResult =
						await faastflexBluetoothCommunicator.SetAlarmMode(alarmMode);
					if (alarmModeResult.isUpdated) {
						deviceParameters.current = {
							...deviceParameters.current,
							deviceAlarmMode: alarmMode,
						} as DeviceParametersModel;
						return true;
					} else {
						setAlarmModeSaveFailed(true);
						if (alarmModeResult.error === ErrorCode.eGCL_NOT_ALLOWED_COMMAND) {
							setShowTimeOutScreen();
						}
						return false;
					}

				case FF_Channel1AlarmLevel:
					const alarmLevel1: AlarmLevel = csWatch('AlarmLevel1') as AlarmLevel;
					const channnel1AlarmResult =
						await faastflexBluetoothCommunicator.SetChannelAlarmLevel(
							Channel.Channel1,
							alarmLevel1,
						);
					if (channnel1AlarmResult.isUpdated) {
						deviceParameters.current = {
							...deviceParameters.current,
							channel1AlarmLevel: alarmLevel1,
						} as DeviceParametersModel;
						return true;
					} else {
						setCh1AlarmLevelSaveFailed(true);
						if (
							channnel1AlarmResult.error === ErrorCode.eGCL_NOT_ALLOWED_COMMAND
						) {
							setShowTimeOutScreen();
						}
						return false;
					}

				case FF_Channel1ActionLevel:
					const actionLevel1: PreAlarmLevel = csWatch(
						'ActionLevel1',
					) as PreAlarmLevel;
					const channnel1ActionResult =
						await faastflexBluetoothCommunicator.SetChannelPreAlarmLevel(
							Channel.Channel1,
							actionLevel1,
						);
					if (channnel1ActionResult.isUpdated) {
						deviceParameters.current = {
							...deviceParameters.current,
							channel1ActionLevel: actionLevel1,
						} as DeviceParametersModel;
						return true;
					} else {
						setCh1ActionLevelSaveFailed(true);
						if (
							channnel1ActionResult.error === ErrorCode.eGCL_NOT_ALLOWED_COMMAND
						) {
							setShowTimeOutScreen();
						}
						return false;
					}

				case FF_FlowFaultThreshold1:
					const flowFaultThreshold1: number = csWatch(
						'FlowFaultThreshold1Value',
					) as number;
					const flowFaultThreshold1Result =
						await faastflexBluetoothCommunicator.SetFlowFaultThreshold(
							Channel.Channel1,
							flowFaultThreshold1,
						);
					if (flowFaultThreshold1Result.isUpdated) {
						deviceParameters.current = {
							...deviceParameters.current,
							flowFaultThresholdCh1: flowFaultThreshold1,
						} as DeviceParametersModel;
						return true;
					} else {
						setCh1FlowFaultThresholdSaveFailed(true);
						if (
							flowFaultThreshold1Result.error ===
							ErrorCode.eGCL_NOT_ALLOWED_COMMAND
						) {
							setShowTimeOutScreen();
						}
						return false;
					}

				case FF_Channel2AlarmLevel:
					const alarmLevel2: AlarmLevel = csWatch('AlarmLevel2') as AlarmLevel;
					const channnel2AlarmResult =
						await faastflexBluetoothCommunicator.SetChannelAlarmLevel(
							Channel.Channel2,
							alarmLevel2,
						);
					if (channnel2AlarmResult.isUpdated) {
						deviceParameters.current = {
							...deviceParameters.current,
							channel2AlarmLevel: alarmLevel2,
						} as DeviceParametersModel;
						return true;
					} else {
						setCh2AlarmLevelSaveFailed(true);
						if (
							channnel2AlarmResult.error === ErrorCode.eGCL_NOT_ALLOWED_COMMAND
						) {
							setShowTimeOutScreen();
						}
						return false;
					}

				case FF_Channel2ActionLevel:
					const actionLevel2: PreAlarmLevel = csWatch(
						'ActionLevel2',
					) as PreAlarmLevel;
					const channnel2ActionResult =
						await faastflexBluetoothCommunicator.SetChannelPreAlarmLevel(
							Channel.Channel2,
							actionLevel2,
						);
					if (channnel2ActionResult.isUpdated) {
						deviceParameters.current = {
							...deviceParameters.current,
							channel2ActionLevel: actionLevel2,
						} as DeviceParametersModel;
						return true;
					} else {
						setCh2ActionLevelSaveFailed(true);
						if (
							channnel2ActionResult.error === ErrorCode.eGCL_NOT_ALLOWED_COMMAND
						) {
							setShowTimeOutScreen();
						}
						return false;
					}
				case FF_FlowFaultThreshold2:
					const flowFaultThreshold2: number = csWatch(
						'FlowFaultThreshold2Value',
					) as number;
					const flowFaultThreshold2Result =
						await faastflexBluetoothCommunicator.SetFlowFaultThreshold(
							Channel.Channel2,
							flowFaultThreshold2,
						);
					if (flowFaultThreshold2Result.isUpdated) {
						deviceParameters.current = {
							...deviceParameters.current,
							flowFaultThresholdCh2: flowFaultThreshold2,
						} as DeviceParametersModel;
						return true;
					} else {
						setCh2FlowFaultThresholdSaveFailed(true);
						if (
							flowFaultThreshold2Result.error ===
							ErrorCode.eGCL_NOT_ALLOWED_COMMAND
						) {
							setShowTimeOutScreen();
						}
						return false;
					}
				default:
					return false;
			}
		} catch (error) {
			return false;
		}
	}

	const isGeneralParametersChanged = (): {
		hasChanges: boolean;
		count: number;
	} => {
		let hasChanges = false;
		let generalparameterCount = 0;
		var deviceTime = deviceParameters.current.installationDate.toTimeString();
		var selectedTime = generalWatch('selectedTime').toTimeString();

		if (
			!!selectedDevice?.firmwareVersion &&
			parseInt(selectedDevice?.firmwareVersion?.split('.')[0] || '0') >= 4
		) {
			const extinputmode = gpiInputState === 1;
			const isSupervised = extinputmode;

			if (deviceParameters.current.gpiState !== extinputmode) {
				generalparameterCount++;
			}

			if (isSupervised) {
				//Check supervised input changes
				generalparameterCount +=
					deviceParameters.current.externalTriggerOnOpen !==
						eventTriggerOnOpen &&
					deviceParameters.current.externalTriggerOnOpen !==
						ExternalInputAction.eUnknown
						? 1
						: 0;
				generalparameterCount +=
					deviceParameters.current.externalTriggerOnClosed !==
						eventTriggerOnClose &&
					deviceParameters.current.externalTriggerOnClosed !==
						ExternalInputAction.eUnknown
						? 1
						: 0;
			} else {
				//Check unsupervised input changes
				generalparameterCount +=
					deviceParameters.current.unbalancedEventTriggered !==
						unbalancedEventTriggered &&
					deviceParameters.current.unbalancedEventTriggered !==
						ExternalInputAction.eUnknown
						? 1
						: 0;
				generalparameterCount +=
					deviceParameters.current.externalInputNormalState !==
						gpiNormalState &&
					deviceParameters.current.externalInputNormalState !==
						ExternalInputNormalState.eUnknown
						? 1
						: 0;
			}
		}

		const temprelay = deviceParameters.current.temperatureFaultRelay;
		let deviceSelectedTempfaultRelay = false;
		let deviceSelectedTempfaultRelay1 = false;

		if (temprelay === RelayAlert.eSet) {
			deviceSelectedTempfaultRelay = true;
			deviceSelectedTempfaultRelay1 = false;
		} else if (temprelay === RelayAlert.eUnset) {
			deviceSelectedTempfaultRelay = false;
			deviceSelectedTempfaultRelay1 = true;
		}

		// Low Power Fault Relay check
		const lowrelay = deviceParameters.current.lowPowerFaultRelay;
		let deviceSelectedLowPowerfaultRelay = false;
		let deviceSelectedLowPowerfaultRelay1 = false;

		if (lowrelay === RelayAlert.eSet) {
			deviceSelectedLowPowerfaultRelay = true;
			deviceSelectedLowPowerfaultRelay1 = false;
		} else if (lowrelay === RelayAlert.eUnset) {
			deviceSelectedLowPowerfaultRelay = false;
			deviceSelectedLowPowerfaultRelay1 = true;
		}

		// Blower Speed check
		const blowerspeed = deviceParameters.current.blowerSpeed;
		let deviceSelectedBlowerSpeed = 0;

		if (
			blowerspeed === FanSpeedLevel.eLevel_1 ||
			blowerspeed === FanSpeedLevel.eLevel_2 ||
			blowerspeed === FanSpeedLevel.eLevel_3 ||
			blowerspeed === FanSpeedLevel.eLevel_4 ||
			blowerspeed === FanSpeedLevel.eLevel_5 ||
			blowerspeed === FanSpeedLevel.eLevel_6
		) {
			deviceSelectedBlowerSpeed = 0;
		} else {
			deviceSelectedBlowerSpeed = 1;
		}
		if (
			deviceParameters.current.installationDate.toDateString() !==
			generalWatch('selectedDate').toDateString()
		) {
			++generalparameterCount;
		}
		if (deviceTime !== selectedTime) {
			++generalparameterCount;
		}
		if (
			deviceParameters.current.trendLogDisabled !==
			generalWatch('TrendLogInterval')
		) {
			++generalparameterCount;
		}
		if (
			deviceSelectedTempfaultRelay !==
				(generalWatch('isTemparatureFaultSetRelays') === 0) ||
			deviceSelectedTempfaultRelay1 !==
				(generalWatch('isTemparatureFaultSetRelays') === 1)
		) {
			++generalparameterCount;
		}
		if (
			deviceSelectedLowPowerfaultRelay !==
				(generalWatch('isLowPowerFaultSetRelays') === 0) ||
			deviceSelectedLowPowerfaultRelay1 !==
				(generalWatch('isLowPowerFaultSetRelays') === 1)
		) {
			++generalparameterCount;
		}
		if (deviceSelectedBlowerSpeed !== generalWatch('blowerSpeed')) {
			++generalparameterCount;
		}
		hasChanges = generalparameterCount > 0;
		return { hasChanges, count: generalparameterCount };
	};

	const isChannelSensorParametersChanged = (): {
		hasChanges: boolean;
		count: number;
	} => {
		let hasChanges = false;
		let channelsensorparameterCount = 0;

		// Check each general parameter for changes
		const alamlac = deviceParameters.current.alarmLatched;
		let deviceSelectedAlarmConfig = false;
		let deviceSelectedAlarmConfig1 = false;

		if (alamlac === LatchedMode.eLatched) {
			deviceSelectedAlarmConfig = true;
			deviceSelectedAlarmConfig1 = false;
		} else if (alamlac === LatchedMode.eUnlatched) {
			deviceSelectedAlarmConfig = false;
			deviceSelectedAlarmConfig1 = true;
		}

		const actc = deviceParameters.current.actionLatched;
		let deviceSelectedActionConfig = false;
		let deviceSelectedActionConfig1 = false;
		if (actc == LatchedMode.eLatched) {
			deviceSelectedActionConfig = true;
			deviceSelectedActionConfig1 = false;
		} else if (actc == LatchedMode.eUnlatched) {
			deviceSelectedActionConfig = false;
			deviceSelectedActionConfig1 = true;
		}

		var faultc = deviceParameters.current.faultLatched;
		let deviceSelectedFaultConfig = false;
		let deviceSelectedFaultConfig1 = false;
		if (faultc == LatchedMode.eLatched) {
			deviceSelectedFaultConfig = true;
			deviceSelectedFaultConfig1 = false;
		} else if (faultc == LatchedMode.eUnlatched) {
			deviceSelectedFaultConfig = false;
			deviceSelectedFaultConfig1 = true;
		}

		var alamm = deviceParameters.current.deviceAlarmMode;
		let deviceSelectedAlarmMode = false;
		let deviceSelectedAlarmMode1 = false;
		if (alamm == AlarmMode.eUp_InstantFire) {
			deviceSelectedAlarmMode = true;
			deviceSelectedAlarmMode1 = false;
		} else if (alamm == AlarmMode.eDown_Cumulative) {
			deviceSelectedAlarmMode = false;
			deviceSelectedAlarmMode1 = true;
		}

		if (deviceParameters.current.actionDelay !== csWatch('ActionDelay')) {
			++channelsensorparameterCount;
		}
		if (deviceParameters.current.alarmDelay !== csWatch('AlarmDelay')) {
			++channelsensorparameterCount;
		}
		if (deviceParameters.current.flowFaultDelay !== csWatch('FlowFaultDelay')) {
			++channelsensorparameterCount;
		}
		if (
			deviceSelectedAlarmConfig !== (csWatch('AlarmConfiguration') === 0) ||
			deviceSelectedAlarmConfig1 !== (csWatch('AlarmConfiguration') === 1)
		) {
			++channelsensorparameterCount;
		}
		if (
			deviceSelectedActionConfig !== (csWatch('ActionConfiguration') === 0) ||
			deviceSelectedActionConfig1 !== (csWatch('ActionConfiguration') === 1)
		) {
			++channelsensorparameterCount;
		}
		if (
			deviceSelectedFaultConfig !== (csWatch('FaultConfiguration') === 0) ||
			deviceSelectedFaultConfig1 !== (csWatch('FaultConfiguration') === 1)
		) {
			++channelsensorparameterCount;
		}
		if (
			deviceSelectedAlarmMode !== (csWatch('AlarmMode') === 0) ||
			deviceSelectedAlarmMode1 !== (csWatch('AlarmMode') === 1)
		) {
			++channelsensorparameterCount;
		}
		if (
			deviceParameters.current.channel1AlarmLevel !== csWatch('AlarmLevel1')
		) {
			++channelsensorparameterCount;
		}
		if (
			deviceParameters.current.channel1ActionLevel !== csWatch('ActionLevel1')
		) {
			++channelsensorparameterCount;
		}
		if (
			deviceParameters.current.flowFaultThresholdCh1 !==
			csWatch('FlowFaultThreshold1Value')
		) {
			++channelsensorparameterCount;
		}
		if (IsChannel2Available) {
			if (
				deviceParameters.current.channel2AlarmLevel !== csWatch('AlarmLevel2')
			) {
				++channelsensorparameterCount;
			}
			if (
				deviceParameters.current.channel2ActionLevel !== csWatch('ActionLevel2')
			) {
				++channelsensorparameterCount;
			}
			if (
				deviceParameters.current.flowFaultThresholdCh2 !==
				csWatch('FlowFaultThreshold2Value')
			) {
				++channelsensorparameterCount;
			}
		}
		hasChanges = channelsensorparameterCount > 0;
		return { hasChanges, count: channelsensorparameterCount };
	};

	async function ValidateGeneralParams(
		validationOption: string,
	): Promise<boolean> {
		switch (validationOption) {
			case 'TrendLogInterval':
				return await generalTrigger('TrendLogInterval');
			default:
				return await generalTrigger('TrendLogInterval');
		}
	}

	async function ValidateChannelAndSensorParams(
		validationOption: string,
	): Promise<boolean> {
		switch (validationOption) {
			case 'ActionDelay':
				return await csTrigger('ActionDelay');
			case 'AlarmDelay':
				return await csTrigger('AlarmDelay');
			case 'FlowFaultDelay':
				return await csTrigger('FlowFaultDelay');
			case 'FlowFaultThresholdCh1':
				return await csTrigger('FlowFaultThreshold1');
			case 'FlowFaultThresholdCh2':
				return await csTrigger('FlowFaultThreshold2');
			case 'Channel1AlarmLevel':
				return await csTrigger('AlarmLevel1');
			case 'Channel2AlarmLevel':
				return await csTrigger('AlarmLevel2');
			case 'Channel1ActionLevel':
				return await csTrigger('ActionLevel1');
			case 'Channel2ActionLevel':
				return await csTrigger('ActionLevel2');
			default:
				if (IsChannel2Available) {
					csClearErrors(['AlarmLevel1', 'AlarmLevel2']);

					const actionLevel1: number = csWatch('ActionLevel1') ?? 0;
					const alarmLevel1: number = csWatch('AlarmLevel1') ?? 0;
					const actionLevel2: number = csWatch('ActionLevel2') ?? 0;
					const alarmLevel2: number = csWatch('AlarmLevel2') ?? 0;

					if (actionLevel1 > 0 && alarmLevel1 <= actionLevel1) {
						csSetError('AlarmLevel1', {
							type: 'value',
							message: 'Alarm Level must be greater than Action Level',
						});
						return Promise.resolve(false);
					}

					if (actionLevel2 > 0 && alarmLevel2 <= actionLevel2) {
						csSetError('AlarmLevel2', {
							type: 'value',
							message: 'Alarm Level must be greater than Action Level',
						});
						return Promise.resolve(false);
					}
					// Validate all channel fields
					return Promise.all([
						csTrigger('ActionDelay'),
						csTrigger('AlarmDelay'),
						csTrigger('FlowFaultDelay'),
						csTrigger('FlowFaultThreshold1'),
						csTrigger('FlowFaultThreshold2'),
						csTrigger('AlarmLevel1'),
						csTrigger('AlarmLevel2'),
						csTrigger('ActionLevel1'),
						csTrigger('ActionLevel2'),
						csTrigger('Referenceflow1'),
						csTrigger('Referenceflow2'),
					]).then(results => results.every(Boolean));
				} else {
					csClearErrors('AlarmLevel1');

					const actionLevel1: number = csWatch('ActionLevel1') ?? 0;
					const alarmLevel1: number = csWatch('AlarmLevel1') ?? 0;
					if (actionLevel1 > 0 && alarmLevel1 <= actionLevel1) {
						csSetError('AlarmLevel1', {
							type: 'value',
							message: 'Alarm Level must be greater than Action Level',
						});
						return Promise.resolve(false);
					}

					return Promise.all([
						csTrigger('ActionDelay'),
						csTrigger('AlarmDelay'),
						csTrigger('FlowFaultDelay'),
						csTrigger('FlowFaultThreshold1'),
						csTrigger('AlarmLevel1'),
						csTrigger('ActionLevel1'),
						csTrigger('Referenceflow1'),
					]).then(results => results.every(Boolean));
				}
		}
	}

	function ClearGeneralParamsSaveFailedErrors() {
		setDeviceDateSaveFailed(false);
		setDisableTimeoutSaveFailed(false);
		setTrendLogIntervalSaveFailed(false);
		setTempFaultSetsRelaysSaveFailed(false);
		setLowPowerFaultSetsRelaysSaveFailed(false);
		setGPISaveFailed(false);
		setAspiratorSpeedSaveFailed(false);
	}
	function ClearChannelsandSensorsSaveFailedErrors() {
		setActionDelaySaveFailed(false);
		setAlarmDelaySaveFailed(false);
		setFlowFaultDelaySaveFailed(false);
		setAlarmConfigSaveFailed(false);
		setActionConfigSaveFailed(false);
		setFaultConfigSaveFailed(false);
		setAlarmModeSaveFailed(false);
		setCh1AlarmLevelSaveFailed(false);
		setCh1ActionLevelSaveFailed(false);
		setCh1FlowFaultThresholdSaveFailed(false);
		setCh2AlarmLevelSaveFailed(false);
		setCh2ActionLevelSaveFailed(false);
		setCh2FlowFaultThresholdSaveFailed(false);
	}

	//#endregion

	//#region Back Handler
	async function handleBackPress(): Promise<void> {
		if (selectedDevice.isDeviceConnected) {
			let tempDeviceParameter = deviceParameters.current;
			tempDeviceParameter.deviceId = selectedDevice.deviceId;
			tempDeviceParameter.deviceName = selectedDevice.deviceName;
			tempDeviceParameter.channels = selectedDevice.channels;
			deviceParameters.current = {
				...deviceParameters.current,
				deviceId: selectedDevice.deviceId,
				deviceName: selectedDevice.deviceName,
				channels: selectedDevice.channels,
			} as DeviceParametersModel;

			await dispatch(
				addNewDeviceParameter({
					dataSource,
					deviceParameter: tempDeviceParameter,
				}),
			);
			const userConfirmed = await confirmAlert(
				t('ExitDeviceParametersConfirmation'),
				t('ExitDeviceParameters'),
				t('Exit'),
				t('cancel'),
			);
			if (userConfirmed) {
				navigation.goBack();
			}
		} else {
			navigation.goBack();
		}
	}
	//#endregion

	//#region Spare part change

	// Header and step information
	const [ASP_HeaderStatusColor, setASP_HeaderStatusColor] =
		useState<string>('#8CB55A');
	const [ASP_StepCount, setASP_StepCount] = useState<number>(1);
	const [ASP_StepName, setASP_StepName] = useState<string>('');
	const [ASP_StepDescription, setASP_StepDescription] = useState<string>('');
	const [ASP_StepImage, setASP_StepImage] = useState<ReactElement>();

	// Visibility controls for UI components
	const [IsASPCompensationVisible, setIsASPCompensationVisible] =
		useState<boolean>(false);
	const [IsASPprocedureCompleteVisible, setIsASPprocedureCompleteVisible] =
		useState<boolean>(false);
	const [IsASPDeviceStatusVisible, setIsASPDeviceStatusVisible] =
		useState<boolean>(true);
	const [IsASPDeviceStatusLabelVisible, setIsASPDeviceStatusLabelVisible] =
		useState<boolean>(true);
	const [IsASPDoneButtonVisible, setIsASPDoneButtonVisible] =
		useState<boolean>(false);
	const [IsASPScanQRButtonVisible, setIsASPScanQRButtonVisible] =
		useState<boolean>(false);

	// Device status information
	const [ASP_DeviceStatus, setASP_DeviceStatus] = useState<string>('');
	const [ASP_DeviceStatusImage, setASP_DeviceStatusImage] =
		useState<ReactElement>(<PassIcon height={30} width={30} />);

	// UI control states
	const [IsASPProgressVisible, setIsASPProgressVisible] =
		useState<boolean>(false);
	const [IsASPNextButtonVisible, setIsASPNextButtonVisible] =
		useState<boolean>(true);
	const [IsASPNextButtonEnabled, setIsASPNextButtonEnabled] =
		useState<boolean>(true);
	const [IsASPRetryButtonVisible, setIsASPRetryButtonVisible] =
		useState<boolean>(false);
	const [aspDeviceStatusProgress, setAspDeviceStatusProgress] =
		useState<number>(0);
	const [IsASPBackButtonVisible, setIsASPBackButtonVisible] =
		useState<boolean>(false);
	const [isQRScannerModalVisible, setIsQRScannerModalVisible] =
		useState<boolean>(false);
	const [ASP_COMPENSATIONVALUE, setASP_COMPENSATIONVALUE] =
		useState<string>('');
	const progressTimerRef = useRef<CustomTimer | null>(null);
	const totalTimeRef = useRef<number>(0);
	async function StartAspiratorSparePartChange(): Promise<void> {
		setIsAddSparepartVisible(true);
		setASP_HeaderStatusColor('#8CB55A');
		setASP_StepCount(1);
		setASP_StepName(t('txtOPENDEVICECOVER'));
		setASP_StepDescription(t('msgOpenMainCover'));
		setASP_StepImage(<AspiratorCoverRemoval />);
		setIsASPCompensationVisible(false);
		setIsASPprocedureCompleteVisible(false);
		setIsASPDeviceStatusVisible(true);
		setIsASPDeviceStatusLabelVisible(true);
		setIsASPDoneButtonVisible(false);
		setIsASPScanQRButtonVisible(false);
		await StartWaitModeStep();
	}
	async function StartWaitModeStep(): Promise<void> {
		const waitModeResult = await CheckDeviceStatus(false);
		if (waitModeResult) {
			setASP_DeviceStatus(t('txtMainCoverOpened'));
			setASP_DeviceStatusImage(<PassIcon height={30} width={30} />);
			setIsASPProgressVisible(false);
			setIsASPNextButtonVisible(true);
			setIsASPNextButtonEnabled(true);
			setIsASPRetryButtonVisible(false);
		} else {
			setASP_DeviceStatus(t('txtOpenMainCover'));
			setASP_DeviceStatusImage(<PassIcon height={30} width={30} />);
			setIsASPProgressVisible(true);
			setIsASPNextButtonVisible(false);
			setIsASPNextButtonEnabled(true);
			setIsASPRetryButtonVisible(false);
			StartWaitModeTimer();
		}
	}
	function StartWaitModeTimer(isWaitMode: boolean = true): void {
		if (progressTimerRef.current != null) {
			progressTimerRef.current.stop();
		}
		if (isWaitMode) {
			progressTimerRef.current = new CustomTimer(1000, CheckWaitModeProgress);
			totalTimeRef.current = 10;
		} else {
			progressTimerRef.current = new CustomTimer(
				1000,
				CheckServiceModeProgress,
			);
			totalTimeRef.current = 60;
		}
		setAspDeviceStatusProgress(0);
		progressTimerRef.current.start();
	}
	function CheckWaitModeProgress(): void {
		totalTimeRef.current -= 1;
		const a = (10 - totalTimeRef.current) / 10;
		setAspDeviceStatusProgress(((10 - totalTimeRef.current) / 10) * 100);
		if (totalTimeRef.current === 5 || totalTimeRef.current === 0) {
			CheckDeviceStatus(false).then((isWaitmode: boolean) => {
				if (isWaitmode) {
					setASP_DeviceStatusImage(<PassIcon height={30} width={30} />);
					setIsASPProgressVisible(false);
					setIsASPNextButtonVisible(true);
					setIsASPNextButtonEnabled(true);
					if (progressTimerRef.current) {
						progressTimerRef.current.stop();
					}
				} else if (totalTimeRef.current <= 0) {
					if (progressTimerRef.current) {
						progressTimerRef.current?.stop();
					}
					EnableWaitModeStepRetry();
				}
			});
		}
	}
	function CheckServiceModeProgress(): void {
		totalTimeRef.current -= 1;
		const a = (60 - totalTimeRef.current) / 60;
		setAspDeviceStatusProgress(((60 - totalTimeRef.current) / 60) * 100);
		if (
			totalTimeRef.current === 30 ||
			totalTimeRef.current === 15 ||
			totalTimeRef.current === 5 ||
			totalTimeRef.current === 0
		) {
			CheckDeviceStatus(true).then((isWaitmode: boolean) => {
				if (isWaitmode) {
					setASP_DeviceStatusImage(<PassIcon height={30} width={30} />);
					setIsASPProgressVisible(false);
					setIsASPNextButtonVisible(true);
					setIsASPNextButtonEnabled(true);
					if (progressTimerRef.current) {
						progressTimerRef.current.stop();
					}
				} else if (totalTimeRef.current === 0) {
					if (progressTimerRef.current) {
						progressTimerRef.current.stop();
					}
					EnableServiceModeStepRetry();
				}
			});
		}
	}
	function EnableWaitModeStepRetry(): void {
		setASP_DeviceStatus(t('txtMainCoverNotOpened'));
		setASP_DeviceStatusImage(<FailIcon height={30} width={30} />);
		setIsASPNextButtonVisible(false);
		setIsASPRetryButtonVisible(true);
	}

	function EnableServiceModeStepRetry(): void {
		setASP_DeviceStatusImage(<FailIcon height={30} width={30} />);
		setIsASPNextButtonVisible(false);
		setIsASPRetryButtonVisible(true);
	}

	async function CheckDeviceStatus(
		isServiceModeCheck: boolean,
	): Promise<boolean> {
		try {
			const deviceModeResult =
				await faastflexBluetoothCommunicator.GetDeviceMode();
			const deviceMode = deviceModeResult.deviceMode;
			if (isServiceModeCheck) {
				return deviceMode === DeviceStatus.MAIN_FSM_SERVICE;
			} else {
				return (
					deviceMode === DeviceStatus.MAIN_FSM_WAIT ||
					deviceMode === DeviceStatus.MAIN_FSM_SERVICE
				);
			}
		} catch (error) {
			console.error('Error checking device status:', error);
			return false;
		}
	}
	async function ASP_NextCommandAsync(): Promise<void> {
		if (ASP_StepCount === 1) {
			await InitializeServiceModeStep();
		} else if (ASP_StepCount === 2) {
			await StartScanQRStep();
		} else if (ASP_StepCount === 3) {
			await SendCompensationValueToDevice();
		}
	}
	async function InitializeServiceModeStep(): Promise<void> {
		setASP_HeaderStatusColor('#F9D311');
		setASP_StepCount(2);
		setASP_StepName(t('lblSERVICEMODE'));
		setASP_StepDescription(t('msgWaitForDeviceServiceMode'));
		setASP_DeviceStatus(t('txtDeviceInServiceMode'));
		setASP_StepImage(<AspiratorChange />);
		setIsASPCompensationVisible(false);
		setIsASPprocedureCompleteVisible(false);
		setIsASPDeviceStatusVisible(true);
		setIsASPDeviceStatusLabelVisible(true);
		setIsASPNextButtonVisible(true);
		setIsASPNextButtonEnabled(false);
		setIsASPDoneButtonVisible(false);
		setIsASPScanQRButtonVisible(false);
		await StartServiceModeStep();
	}
	async function StartServiceModeStep(): Promise<void> {
		const isServiceMode = await CheckDeviceStatus(true);

		if (isServiceMode) {
			setASP_DeviceStatusImage(<PassIcon height={30} width={30} />);
			setIsASPProgressVisible(false);
			setIsASPNextButtonEnabled(true);
			setIsASPRetryButtonVisible(false);
			setIsASPNextButtonVisible(true);
		} else {
			setASP_DeviceStatusImage(<PassIcon height={30} width={30} />);
			setIsASPProgressVisible(true);
			setIsASPNextButtonEnabled(false);
			setIsASPRetryButtonVisible(false);
			setIsASPNextButtonVisible(true);
			StartWaitModeTimer(false);
		}
	}
	async function ASP_RetryCommand(): Promise<void> {
		if (ASP_StepCount === 1) {
			await StartWaitModeStep();
		} else if (ASP_StepCount === 2) {
			await StartServiceModeStep();
		}
	}
	async function ASP_CancelCommandAsync(): Promise<void> {
		let isServiceMode = false;
		if (ASP_StepCount >= 2) {
			isServiceMode = await CheckDeviceStatus(true);
		}
		Alert.alert(
			t('lblCancelProcess'),
			t('msgCancelSparepartProcess'),
			[
				{
					text: t('cancel'),
					style: 'cancel',
				},
				{
					text: t('Yes_UpperCase'),
					onPress: async () => {
						if (isServiceMode) {
							await NavigateToHome();
						} else {
							setIsAddSparepartVisible(false);
						}
					},
				},
			],
			{ cancelable: false },
		);
	}
	async function checkCameraPermission(): Promise<boolean> {
		try {
			const permission =
				Platform.OS === 'ios'
					? PERMISSIONS.IOS.CAMERA
					: PERMISSIONS.ANDROID.CAMERA;

			const result = await check(permission);

			switch (result) {
				case RESULTS.GRANTED:
					return true;

				case RESULTS.DENIED:
					const requestResult = await request(permission);
					return requestResult === RESULTS.GRANTED;

				case RESULTS.LIMITED:
					return true;

				case RESULTS.BLOCKED:
					Alert.alert(
						'Camera Permission Required',
						'Camera permission is required for QR scanning. Please enable it in your device settings.',
						[
							{
								text: 'Cancel',
								style: 'cancel',
							},
							{
								text: 'Open Settings',
								onPress: () => {
									// Open device settings
									Linking.openSettings();
								},
							},
						],
					);
					return false;

				case RESULTS.UNAVAILABLE:
					// This feature is not available on this device
					Alert.alert(
						'Feature Not Available',
						'Camera is not available on this device.',
					);
					return false;

				default:
					return false;
			}
		} catch (error) {
			console.error('Error checking camera permission:', error);
			return false;
		}
	}

	async function ASP_ScanQRCommandAsync(): Promise<void> {
		try {
			let hasPermission = false;
			if (Platform.OS === 'ios') {
				hasPermission = true;
			} else {
				hasPermission = await checkCameraPermission();
			}

			if (hasPermission) {
				setIsQRScannerModalVisible(true);
			}
		} catch (error) {}
	}

	async function ASP_DoneCommandAsync(): Promise<void> {
		setIsASPBackButtonVisible(true);
		setIsAddSparepartVisible(false);
		await NavigateToHome();
	}

	async function NavigateToHome(): Promise<void> {
		navigation.dispatch(StackActions.pop(2));
	}

	async function StartScanQRStep(): Promise<void> {
		setASP_HeaderStatusColor('#F9D311');
		setASP_StepCount(3);
		setASP_StepName(t('lblSCANTHEQR'));
		setASP_StepDescription(t('msgScanQRLaser'));
		setASP_DeviceStatus('');
		setASP_StepImage(<AspiratorQR />);

		setIsASPCompensationVisible(false);
		setIsASPprocedureCompleteVisible(false);
		setIsASPDeviceStatusVisible(false);
		setIsASPNextButtonVisible(false);
		setIsASPDoneButtonVisible(false);
		setIsASPScanQRButtonVisible(true);
		setIsASPRetryButtonVisible(false);
	}
	async function SendCompensationValueToDevice(): Promise<void> {
		const correctionVal = GetFanPWMPercCorrection(ASP_COMPENSATIONVALUE);
		if (correctionVal === FanPWMPercCorrection.eUnknown) {
			Alert.alert('', t('aspiratorSparePartErr'), [{ text: t('Ok') }]);
			return;
		}

		try {
			const result =
				await faastflexBluetoothCommunicator.SetBlowerSpeedCorrection(
					correctionVal,
				);

			if (result && result.error === ErrorCode.eOK) {
				setASP_HeaderStatusColor('#F9D311');
				setASP_StepCount(4);
				setASP_StepName(t('lblCloseTheCover'));
				setASP_StepDescription(t('msgCloseAspiratorAndDeviceCover'));
				setASP_DeviceStatus(t('txtProcedureCompleted'));
				setASP_StepImage(<AspiratorCover />);
				setASP_DeviceStatusImage(<PassIcon height={30} width={30} />);
				setIsASPDeviceStatusVisible(true);
				setIsASPCompensationVisible(false);
				setIsASPprocedureCompleteVisible(true);
				setIsASPNextButtonVisible(false);
				setIsASPDoneButtonVisible(true);
				setIsASPScanQRButtonVisible(false);
				setIsASPRetryButtonVisible(false);
				setIsASPDeviceStatusLabelVisible(true);
				setIsASPBackButtonVisible(false);
			} else {
				Alert.alert('', t('aspiratorSparePartReqNotComplete'), [
					{ text: t('Ok') },
				]);
			}
		} catch (error) {
			console.error('Error sending compensation value:', error);
			Alert.alert('', t('aspiratorSparePartReqNotComplete'), [
				{ text: t('Ok') },
			]);
		}
	}

	function GetFanPWMPercCorrection(s: string): FanPWMPercCorrection {
		try {
			switch (s) {
				case '-6':
					return FanPWMPercCorrection.eMinusSix;
				case '-5':
					return FanPWMPercCorrection.eMinusFive;
				case '-4':
					return FanPWMPercCorrection.eMinusFour;
				case '-3':
					return FanPWMPercCorrection.eMinusThree;
				case '-2':
					return FanPWMPercCorrection.eMinusTwo;
				case '-1':
					return FanPWMPercCorrection.eMinusOne;
				case '0':
					return FanPWMPercCorrection.eZero;
				case '+1':
					return FanPWMPercCorrection.ePlusOne;
				case '+2':
					return FanPWMPercCorrection.ePlusTwo;
				case '+3':
					return FanPWMPercCorrection.ePlusThree;
				case '+4':
					return FanPWMPercCorrection.ePlusFour;
				case '+5':
					return FanPWMPercCorrection.ePlusFive;
				case '+6':
					return FanPWMPercCorrection.ePlusSix;
				default:
					console.error('Invalid fan PWM percentage correction value', s);
					return FanPWMPercCorrection.eUnknown;
			}
		} catch (error) {
			console.error('Error in GetFanPWMPercCorrection', error);
			return FanPWMPercCorrection.eUnknown;
		}
	}

	const closeQRScanner = () => {
		setIsQRScannerModalVisible(false);
	};

	async function handleQRScanner(result: string): Promise<void> {
		try {
			setIsQRScannerModalVisible(false);
			handleQRScanResult(result);
		} catch (error) {
			console.error('QR scanning error:', error);
			Alert.alert('', t('aspiratorSparePartErr'), [{ text: t('Ok') }]);
		}
	}
	async function handleQRScanResult(result: string): Promise<void> {
		try {
			if (result) {
				let validationCheck = false;
				let compVal = 'NA';
				const range = [
					'-6',
					'-5',
					'-4',
					'-3',
					'-2',
					'-1',
					'0',
					'+1',
					'+2',
					'+3',
					'+4',
					'+5',
					'+6',
				];
				const val =
					result && result.length >= 2
						? result.substring(result.length - 2)
						: 'NA';

				validationCheck = range.includes(val);
				compVal = validationCheck ? val : 'NA';

				if (validationCheck) {
					setASP_HeaderStatusColor('#F9D311');
					setASP_StepCount(3);
					setASP_StepName(t('lblSCANTHEQR'));
					setASP_StepDescription(t('msgScanQRLaser'));
					setASP_DeviceStatus(t('txtQRScanned'));
					setASP_DeviceStatusImage(<PassIcon height={30} width={30} />);
					setASP_StepImage(<AspiratorQR />);
					setIsASPDeviceStatusVisible(true);
					setIsASPCompensationVisible(true);
					setIsASPprocedureCompleteVisible(false);
					setIsASPDeviceStatusLabelVisible(true);
					setIsASPNextButtonVisible(true);
					setIsASPDoneButtonVisible(false);
					setIsASPScanQRButtonVisible(false);
					setIsASPRetryButtonVisible(false);
					setASP_COMPENSATIONVALUE(compVal);
				} else {
					setASP_HeaderStatusColor('#F9D311');
					setASP_StepCount(3);
					setASP_StepName(t('lblSCANTHEQR'));
					setASP_StepDescription(t('msgScanQRLaser'));
					setASP_DeviceStatus('');
					setASP_StepImage(<General />);
					setIsASPDeviceStatusVisible(true);
					setIsASPCompensationVisible(true);
					setIsASPprocedureCompleteVisible(false);
					setIsASPNextButtonVisible(false);
					setIsASPDoneButtonVisible(false);
					setIsASPScanQRButtonVisible(true);
					setIsASPRetryButtonVisible(false);
					setIsASPDeviceStatusLabelVisible(false);
					setASP_COMPENSATIONVALUE(compVal);
				}
			}
		} catch (error) {
			console.error('QR scanning error:', error);
			Alert.alert('', t('aspiratorSparePartErr'), [{ text: t('Ok') }]);
		}
	}

	const renderAspiratorSparePartChange = () => {
		return (
			<Modal
				animationType='fade'
				visible={IsAddSparepartVisible}
				onRequestClose={() => true}>
				<SafeAreaProvider>
					<View style={{ flex: 1, flexDirection: 'column' }}>
						{/*Header*/}
						<SafeAreaContextView edges={['top']} style={styles.safeHeader}>
							<View
								style={[
									styles.headerSection,
									{
										backgroundColor: '#000',
										alignItems: 'center',
									},
								]}>
								<View
									style={{
										flexDirection: 'row',
										alignItems: 'center',
										paddingHorizontal: 10,
										height: '100%',
										backgroundColor: '#000',
									}}>
									{IsASPBackButtonVisible && (
										<TouchableOpacity
											onPress={() => ASP_CancelCommandAsync()}
											style={{
												height: '100%',
												padding: 0,
												margin: 0,
												justifyContent: 'center',
											}}>
											<LeftArrowWhite height={30} width={30} />
										</TouchableOpacity>
									)}
									<View style={[{ flex: 2 }]}>
										<Text
											style={{
												color: '#fff',
												fontSize: 18,
												fontWeight: 'bold',
												textAlign: 'center',
											}}>
											{t('lblAddBlowerSparePart')}
										</Text>
									</View>
								</View>
							</View>
						</SafeAreaContextView>
						<View
							style={{
								height: '30%',
								backgroundColor: '#ffffff',
								flex: 1,
							}}>
							<View
								style={{
									height: 6,
									backgroundColor: ASP_HeaderStatusColor,
								}}
							/>
							<View
								style={{
									padding: 20,
									alignItems: 'flex-start',
									justifyContent: 'center',
									backgroundColor: '#E7E7E7',
								}}>
								<Text style={{ textAlign: 'left' }}>
									<Text
										style={{
											fontWeight: 'bold',
											fontSize: 16,
										}}>
										{t('lblStep')}{' '}
									</Text>
									<Text
										style={{
											fontWeight: 'bold',
											fontSize: 16,
										}}>
										{ASP_StepCount}
									</Text>
									<Text
										style={{
											fontWeight: 'bold',
											fontSize: 16,
										}}>
										{' '}
										-{' '}
									</Text>
									<Text style={{ fontSize: 16 }}>{ASP_StepName}</Text>
								</Text>
							</View>

							<View
								style={{
									padding: 20,
									alignItems: 'center',
									justifyContent: 'center',
									flex: 1,
								}}>
								<Text
									style={{
										fontSize: 15,
										color: '#000',
										textAlign: 'left',
										marginBottom: 10,
									}}>
									{ASP_StepDescription}
								</Text>
								<View
									style={{
										alignItems: 'center',
										justifyContent: 'center',
										marginBottom: 10,
										flex: 1,
									}}>
									<View
										style={{
											width: '100%',
											height: '100%',
											alignItems: 'center',
											justifyContent: 'center',
											minHeight: 200,
										}}>
										{ASP_StepImage}
									</View>
								</View>

								{/* Compensation Value (conditionally visible) */}
								{IsASPCompensationVisible && (
									<Text
										style={{
											fontSize: 15,
											color: '#000',
											textAlign: 'center',
											marginBottom: 10,
										}}>
										<Text>{t('txtCOMPENSATIONVALUE')}</Text>
										<Text>:</Text>
										<Text>{ASP_COMPENSATIONVALUE}</Text>
									</Text>
								)}

								{/* Completion Note (conditionally visible) */}
								{IsASPprocedureCompleteVisible && (
									<Text
										style={{
											fontSize: 15,
											color: '#000',
											textAlign: 'center',
											marginBottom: 10,
										}}>
										{t('noteAddSparePartProcedureComplete')}
									</Text>
								)}
							</View>

							<View
								style={{
									padding: 20,
									alignItems: 'center',
									justifyContent: 'center',
									backgroundColor: '#EFF8FF',
								}}>
								<View
									style={{
										flexDirection: 'row',
										alignItems: 'center',
										justifyContent: 'center',
									}}>
									<Text
										style={{
											fontSize: 15,
											color: '#000',
											textAlign: 'center',
											marginBottom: 10,
										}}>
										{ASP_DeviceStatus}
									</Text>
									{ASP_DeviceStatusImage}
								</View>
								{!IsASPDeviceStatusLabelVisible && (
									<Text
										style={{
											fontSize: 15,
											fontWeight: 'bold',
											color: '#1791E4',
											textAlign: 'center',
											marginTop: 10,
											marginBottom: 10,
										}}>
										{' '}
										{t('msgCheckIfTheCompensationValueIsMatching')}
									</Text>
								)}
							</View>

							{IsASPProgressVisible && (
								<CustomProgressBar percentage={aspDeviceStatusProgress} />
							)}
						</View>

						<View style={{ padding: 20 }}>
							<View style={styles.buttonGrid}>
								{!IsASPDoneButtonVisible && (
									<View style={styles.buttonGridColumn}>
										<TouchableOpacity
											style={[styles.cancelButton]}
											onPress={ASP_CancelCommandAsync}>
											<Text style={styles.cancelButtonText}>{t('cancel')}</Text>
										</TouchableOpacity>
									</View>
								)}

								<View style={styles.buttonGridColumn}>
									{IsASPNextButtonVisible && (
										<TouchableOpacity
											style={[
												styles.actionButton,
												!IsASPNextButtonEnabled && styles.disabledButton,
											]}
											onPress={ASP_NextCommandAsync}
											disabled={!IsASPNextButtonEnabled}>
											<Text style={styles.actionButtonText}>
												{t('Next_UpperCase')}
											</Text>
										</TouchableOpacity>
									)}

									{IsASPScanQRButtonVisible && (
										<TouchableOpacity
											style={styles.actionButton}
											onPress={ASP_ScanQRCommandAsync}>
											<Text style={styles.actionButtonText}>{t('qrscan')}</Text>
										</TouchableOpacity>
									)}

									{IsASPRetryButtonVisible && (
										<TouchableOpacity
											style={styles.actionButton}
											onPress={ASP_RetryCommand}>
											<Text style={[styles.actionButtonText, styles.boldText]}>
												{t('Retry_UpperCase')}
											</Text>
										</TouchableOpacity>
									)}
								</View>
							</View>

							{IsASPDoneButtonVisible && (
								<TouchableOpacity
									style={styles.doneButton}
									onPress={ASP_DoneCommandAsync}>
									<Text style={styles.actionButtonText}>{t('done')}</Text>
								</TouchableOpacity>
							)}
						</View>
						<Modal
							visible={isQRScannerModalVisible}
							animationType='slide'
							presentationStyle='fullScreen'
							onRequestClose={closeQRScanner}>
							<QRScanner
								scannerTitle={t('qrAlign')}
								cancelButtonText={t('cancel')}
								onScannerCancelled={closeQRScanner}
								onCodeScanned={handleQRScanner}
							/>
						</Modal>
					</View>
				</SafeAreaProvider>
			</Modal>
		);
	};
	//#endregion

	//#region Password Change

	const showChangePasscodeModal = () => {
		setPasswordModalVisible(true);
	};

	const ChangePasswordCommand = async (password: string) => {
		try {
			if (password && password.length === 6) {
				setPasswordModalVisible(false);
				showLoadingIndicator('');
				if (
					ConnectedDeviceobj.current !== null &&
					ConnectedDeviceobj.current !== undefined
				) {
					const passwordChangeAnswer =
						await faastflexBluetoothCommunicator.ChangeDevicePassword(password);
					await delay(500);
					hideLoadingIndicator();
					if (passwordChangeAnswer.isChanged) {
						Toast.show({
							type: 'success',
							text1: t('PasswordChangeSuccessMsg'),
							position: 'bottom',
						});
					} else {
						Toast.show({
							type: 'error',
							text1: t('PasswordChangeErrorMsg'),
							position: 'bottom',
						});
					}
				}
			}
		} catch (error) {
			hideLoadingIndicator();
			Toast.show({
				type: 'error',
				text1: t('PasswordChangeErrorMsg'),
				position: 'bottom',
			});
		}
	};

	const CancelNewPasswordAsync = () => {
		setPasswordModalVisible(false);
	};

	//#endregion

	//#region Render General Parameter

	const renderGeneralParameter = () => {
		const setGPITypeDefaults = (gpiState: number) => {
			if (gpiState === 1) {
				setGpiNormalState(ExternalInputNormalState.eShort);
				setUnbalancedEventTriggered(ExternalInputAction.eResetAlarmAndFault);
			}
			if (gpiState === 0) {
				setEventTriggerOnClose(ExternalInputAction.eResetAlarmAndFault);
				setEventTriggerOnOpen(ExternalInputAction.eResetAlarmAndFault);
			}
			setGpiInputState(gpiState);
		};

		return (
			<SafeAreaView style={{ flex: 1 }}>
				<ScrollView>
					<View
						style={[styles.container, { opacity: offlineMode ? 0.6 : 1 }]}
						pointerEvents={offlineMode ? 'none' : 'auto'}>
						{IsRealConfigOutOfBox && (
							<View
								style={[
									styles.section,
									{
										flexDirection: 'row',
										alignItems: 'center',
										marginBottom: 15,
									},
								]}>
								<FailIcon height={20} width={20} />
								<Text
									style={{
										fontSize: 17,
										fontWeight: '600',
										color: 'red',
									}}>
									{t('realConfigOutOfBoxErrorMessage')}
								</Text>
							</View>
						)}
						{/* Trend Log Inrterval */}
						<View style={styles.section}>
							{/* Heading */}
							<View
								style={{
									paddingVertical: 10,
									borderBottomWidth: 1,
									borderColor: '#e0e0e0',
									marginBottom: 10,
								}}>
								<Text style={{ fontSize: 17, fontWeight: '600' }}>
									{t('GeneralParams')}
								</Text>
							</View>

							<View
								style={{
									flexDirection: 'row',
									alignItems: 'center',
									marginBottom: 5,
								}}>
								<Text style={styles.GeneralParameterradioTitle}>
									{t('realconfig')} :{' '}
								</Text>
								<Text>{RealConfiguration}</Text>
							</View>

							{/* Password */}
							<View style={{ marginVertical: 0, marginBottom: 5 }}>
								<Text
									style={[
										styles.GeneralParameterradioTitle,
										{ marginBottom: 5 },
									]}>
									{t('password')}
								</Text>
								<Text style={styles.passwordChangeBox}>{t('TapToChange')}</Text>
								<TouchableOpacity onPress={() => showChangePasscodeModal()}>
									<Text
										style={{
											color: '#1791E4',
											fontSize: 12,
										}}>
										{t('TapToChange')}
									</Text>
								</TouchableOpacity>
							</View>

							{/* Orientation */}
							<Controller
								name='Orientation'
								control={generalControl}
								render={({ field: { onChange, value } }) => (
									<TextInputField
										name={t('orientation')}
										control={generalControl}
										placeholder='Upright Orientation'
										title={t('orientation')}
										isRequired={true}
										errorMessage={generalErrors.Orientation?.message}
										isDisable={true}
										value={value}
										onChangeText={onChange}
									/>
								)}
							/>

							{/* Date Time */}
							<Controller
								name='selectedDate'
								control={generalControl}
								render={({
									field: { onChange: onDateChange, value: dateValue },
								}) => (
									<Controller
										name='selectedTime'
										control={generalControl}
										render={({
											field: { onChange: onTimeChange, value: timeValue },
										}) => (
											<View style={{ marginVertical: 0 }}>
												<Text
													style={[
														styles.GeneralParameterradioTitle,
														{ marginBottom: 0 },
													]}>
													{t('DeviceDate')}
												</Text>
												<DateTime
													selectedDate={dateValue}
													setSelectedDate={onDateChange}
													selectedTime={timeValue}
													setSelectedTime={onTimeChange}
												/>
												{(generalErrors.selectedDate ||
													generalErrors.selectedTime) && (
													<Text
														style={{
															color: 'red',
															fontSize: 12,
														}}>
														{generalErrors.selectedDate?.message ||
															generalErrors.selectedTime?.message}
													</Text>
												)}
												{deviceDateSaveFailed && (
													<Text
														style={{
															color: '#ff5252',
															fontSize: 12,
															marginTop: 4,
														}}>
														{t('ChangesNotSavedErrMsg')}
													</Text>
												)}
											</View>
										)}
									/>
								)}
							/>

							<View style={{ marginVertical: 0 }}>
								<CustomInput
									name='TrendLogInterval'
									control={generalControl}
									placeholder=''
									title={t('TrendLogInterval')}
									isRequired={true}
									errorMessage={generalErrors.TrendLogInterval?.message}
									belowText={t('TrendLogIntervalRangeInfo')}
									minValue={1}
									maxValue={240}
									unit={t('minutes')}
									keyboardType='numeric'
									maxLength={3}
								/>
								{trendLogIntervalSaveFailed && (
									<Text
										style={{
											color: '#ff5252',
											fontSize: 12,
											marginTop: 4,
										}}>
										{t('ChangesNotSavedErrMsg')}
									</Text>
								)}
							</View>

							<Text style={styles.GeneralParameterradioTitle}>
								{t('TemperatureFaultSetsRelays')}
							</Text>
							<Controller
								name='isTemparatureFaultSetRelays'
								control={generalControl}
								render={({ field: { onChange, value } }) => (
									<View style={styles.GeneralParameterradioContainer}>
										<View style={styles.radiospacebetween}>
											<RadioButton
												option={{
													id: 0,
													text: t('Yes'),
												}}
												isSelected={value === 0}
												onOptionChange={onChange}
											/>
										</View>
										<View style={styles.radiospacebetween}>
											<RadioButton
												option={{
													id: 1,
													text: t('no'),
												}}
												isSelected={value === 1}
												onOptionChange={onChange}
											/>
										</View>
										{tempFaultSetsRelaysSaveFailed && (
											<Text
												style={{
													color: '#ff5252',
													fontSize: 12,
													marginTop: 4,
												}}>
												{t('ChangesNotSavedErrMsg')}
											</Text>
										)}
									</View>
								)}
							/>
							<Text style={styles.GeneralParameterradioTitle}>
								{t('LowPowerFaultsetsRelays')}
							</Text>
							<Controller
								name='isLowPowerFaultSetRelays'
								control={generalControl}
								render={({ field: { onChange, value } }) => (
									<View style={styles.GeneralParameterradioContainer}>
										<View style={styles.radiospacebetween}>
											<RadioButton
												option={{
													id: 0,
													text: t('Yes'),
												}}
												isSelected={value === 0}
												onOptionChange={onChange}
											/>
										</View>
										<View style={styles.radiospacebetween}>
											<RadioButton
												option={{
													id: 1,
													text: t('no'),
												}}
												isSelected={value === 1}
												onOptionChange={onChange}
											/>
										</View>
										{tempFaultSetsRelaysSaveFailed && (
											<Text
												style={{
													color: '#ff5252',
													fontSize: 12,
													marginTop: 4,
												}}>
												{t('ChangesNotSavedErrMsg')}
											</Text>
										)}
									</View>
								)}
							/>
						</View>

						{/* GPI Input */}
						{IsGPIVisible && (
							<View
								style={[
									styles.section,
									{
										opacity: IsGPIEnabledConfig ? 1 : 0.5,
										paddingBottom: 10,
									},
								]}
								pointerEvents={IsGPIEnabledConfig ? 'auto' : 'none'}>
								<View
									style={{
										paddingVertical: 10,
										marginBottom: 0,
										flexDirection: 'row',
										justifyContent: 'space-between',
										alignItems: 'center',
									}}>
									<Text style={styles.sectionTitle}>{t('GPIInput')}</Text>
									<TouchableOpacity
										onPress={() => GetGPIParametersFromDevice()}>
										<SyncBlue height={20} width={20} />
									</TouchableOpacity>
								</View>

								<Text style={styles.dropdownLabel}>{t('State')}</Text>

								<View style={styles.radioContainer}>
									<View style={styles.radiospacebetween}>
										<RadioButton
											option={{
												id: 1,
												text: t('lblSupervised'),
											}}
											isSelected={gpiInputState === 1}
											onOptionChange={(value: any) => setGPITypeDefaults(value)}
										/>
									</View>
									<View style={styles.radiospacebetween}>
										<RadioButton
											option={{
												id: 0,
												text: t('lblUnSupervised'),
											}}
											isSelected={gpiInputState === 0}
											onOptionChange={(value: any) => setGPITypeDefaults(value)}
										/>
									</View>
								</View>

								{gpiInputState === 1 ? (
									<View style={styles.dropdownSection}>
										<Text style={styles.dropdownLabel}>
											{t('EventTriggeredOnClose')}
										</Text>
										<RNPickerSelect
											onValueChange={selectedValue => {
												if (selectedValue !== null) {
													setEventTriggerOnClose(selectedValue);
												}
											}}
											items={getExternalInputActionItems()}
											value={eventTriggerOnClose}
											style={pickerSelectStyles}
											useNativeAndroidPickerStyle={false}
											Icon={() => <DropDownIcon height={20} width={20} />}
										/>
										<Text style={styles.dropdownLabel}>
											{t('EventTriggeredOnOpen')}
										</Text>
										<RNPickerSelect
											onValueChange={selectedValue => {
												if (selectedValue !== null) {
													setEventTriggerOnOpen(selectedValue);
												}
											}}
											items={getExternalInputActionItems()}
											value={eventTriggerOnOpen}
											style={pickerSelectStyles}
											useNativeAndroidPickerStyle={false}
											Icon={() => <DropDownIcon height={20} width={20} />}
										/>
									</View>
								) : (
									<View style={styles.dropdownSection}>
										<Text style={styles.dropdownLabel}>
											{t('GPINormalState')}
										</Text>
										<RNPickerSelect
											onValueChange={selectedValue => {
												if (selectedValue !== null) {
													setGpiNormalState(selectedValue);
												}
											}}
											items={getExternalInputNormalStateItems()}
											value={gpiNormalState}
											style={pickerSelectStyles}
											useNativeAndroidPickerStyle={false}
											Icon={() => <DropDownIcon height={20} width={20} />}
										/>
										<Text style={[styles.dropdownLabel, { paddingTop: 5 }]}>
											{t('unbalancedaction')}
										</Text>
										<RNPickerSelect
											onValueChange={selectedValue => {
												if (selectedValue !== null) {
													setUnbalancedEventTriggered(selectedValue);
												}
											}}
											items={getExternalInputActionItems()}
											value={unbalancedEventTriggered}
											style={pickerSelectStyles}
											useNativeAndroidPickerStyle={false}
											Icon={() => <DropDownIcon height={20} width={20} />}
										/>
									</View>
								)}
								{gpiSaveFailed && (
									<Text
										style={{
											color: '#ff5252',
											fontSize: 12,
											marginTop: 4,
										}}>
										{t('ChangesNotSavedErrMsg')}
									</Text>
								)}
							</View>
						)}

						{/* Aspirator Speed */}
						<View style={styles.section}>
							<View
								style={{
									paddingVertical: 10,
									borderBottomWidth: 1,
									borderColor: '#e0e0e0',
									marginBottom: 10,
									flexDirection: 'row',
									justifyContent: 'space-between',
									alignItems: 'center',
								}}>
								<Text style={{ fontSize: 16, fontWeight: '600' }}>
									{t('Blower')}
								</Text>
								<TouchableOpacity
									onPress={() => StartAspiratorSparePartChange()}>
									<Text
										style={{
											color: '#1791E4',
											fontSize: 12,
										}}>
										{t('lblAddSparePart')}
									</Text>
								</TouchableOpacity>
							</View>
							<Text style={styles.radioTitle}>{t('Speed')}</Text>
							<Controller
								name='blowerSpeed'
								control={generalControl}
								render={({ field: { onChange, value } }) => (
									<View style={styles.radioContainer}>
										<View style={styles.radiospacebetween}>
											<RadioButton
												option={{
													id: 0,
													text: t('Low'),
												}}
												isSelected={value === 0}
												onOptionChange={onChange}
											/>
										</View>
										<View style={styles.radiospacebetween}>
											<RadioButton
												option={{
													id: 1,
													text: t('High'),
												}}
												isSelected={value === 1}
												onOptionChange={onChange}
											/>
										</View>
									</View>
								)}
							/>

							<CustomInput
								name='blowerCorrection'
								control={generalControl}
								placeholder=''
								title={t('BlowerCorrection')}
								isRequired={false}
								errorMessage={generalErrors.blowerCorrection?.message}
								belowText={t('BlowerCorrectionRange')}
								minValue={-6}
								maxValue={6}
								unit=''
								keyboardType='numeric'
								maxLength={3}
								isDisable={true}
								customOpacity={0.5}
							/>

							{aspiratorSpeedSaveFailed && (
								<Text
									style={{
										color: '#ff5252',
										fontSize: 12,
										marginTop: 4,
									}}>
									{t('ChangesNotSavedErrMsg')}
								</Text>
							)}
						</View>
					</View>
				</ScrollView>

				{/* Password Modal */}
				{isPasswordModalVisible && (
					<PasswordModal
						onClose={() => {
							CancelNewPasswordAsync();
						}}
						password={password}
						setPassword={ChangePasswordCommand}
						maximumLength={6}
					/>
				)}
			</SafeAreaView>
		);
	};
	//#endregion

	//#region Channel and sensors region
	const renderChannelsandSensors = () => {
		function onObscurationChanged(val: any): void {
			const unit: number = val ?? 1;
			setSelectedObscurationUnit(unit);
		}

		return (
			<SafeAreaView style={{ flex: 1 }}>
				<ScrollView style={{ flex: 1 }}>
					<View
						style={[styles.container, { opacity: offlineMode ? 0.6 : 1 }]}
						pointerEvents={offlineMode ? 'none' : 'auto'}>
						{/* Temperature Fault Sets Relays */}
						<View style={styles.section}>
							<Text style={styles.ActionCongigsectionTitle}>
								{t('ActionConfiguration')}
							</Text>
							<View style={{ marginVertical: 0 }}>
								<CustomInput
									name='ActionDelay'
									control={csControl}
									placeholder={t('EnterActionDelay')}
									title={t('ActionDelay')}
									isRequired={true}
									errorMessage={csErrors.ActionDelay?.message}
									belowText={t('max240secondsRange')}
									minValue={0}
									maxValue={240}
									unit={t('seconds')}
									keyboardType='numeric'
									maxLength={3}
								/>
								{actionDelaySaveFailed && (
									<Text
										style={{
											color: '#ff5252',
											fontSize: 12,
											marginTop: 4,
										}}>
										{t('ChangesNotSavedErrMsg')}
									</Text>
								)}
							</View>

							<View style={{ marginVertical: 0 }}>
								<CustomInput
									name='AlarmDelay'
									control={csControl}
									placeholder={t('EnterAlarmDelay')}
									title={t('AlarmDelay')}
									isRequired={true}
									errorMessage={csErrors.AlarmDelay?.message}
									belowText={t('max240secondsRange')}
									minValue={0}
									maxValue={240}
									unit={t('seconds')}
									keyboardType='numeric'
									maxLength={3}
								/>
								{alarmDelaySaveFailed && (
									<Text
										style={{
											color: '#ff5252',
											fontSize: 12,
											marginTop: 4,
										}}>
										{t('ChangesNotSavedErrMsg')}
									</Text>
								)}
							</View>

							<View style={{ marginVertical: 0 }}>
								<CustomInput
									name='FlowFaultDelay'
									control={csControl}
									placeholder='Enter Flow Fault Delay'
									title={t('FlowFaultDelay')}
									isRequired={true}
									errorMessage={csErrors.FlowFaultDelay?.message}
									belowText={t('max250secondsRange')}
									minValue={1}
									maxValue={250}
									unit={t('seconds')}
									keyboardType='numeric'
									maxLength={3}
								/>
								{flowFaultDelaySaveFailed && (
									<Text
										style={{
											color: '#ff5252',
											fontSize: 12,
											marginTop: 4,
										}}>
										{t('ChangesNotSavedErrMsg')}
									</Text>
								)}
							</View>

							<Text style={styles.radioTitle}>{t('AlarmConfiguration')}</Text>
							<Controller
								name='AlarmConfiguration'
								control={csControl}
								render={({ field: { onChange, value } }) => (
									<View style={styles.radioContainer}>
										<View style={styles.radiospacebetween}>
											<RadioButton
												option={{
													id: 0,
													text: t('Latched'),
												}}
												isSelected={value === 0}
												onOptionChange={onChange}
											/>
										</View>

										{!isChineseDevice && (
											<View style={styles.radiospacebetween}>
												<RadioButton
													option={{
														id: 1,
														text: t('Unlatched'),
													}}
													isSelected={value === 1}
													onOptionChange={onChange}
												/>
											</View>
										)}
										{alarmConfigSaveFailed && (
											<Text
												style={{
													color: '#ff5252',
													fontSize: 12,
													marginTop: 4,
												}}>
												{t('ChangesNotSavedErrMsg')}
											</Text>
										)}
									</View>
								)}
							/>
							<Text style={styles.radioTitle}>{t('ActionConfiguration')}</Text>
							<Controller
								name='ActionConfiguration'
								control={csControl}
								render={({ field: { onChange, value } }) => (
									<View style={styles.radioContainer}>
										<View style={styles.radiospacebetween}>
											<RadioButton
												option={{
													id: 0,
													text: t('Latched'),
												}}
												isSelected={value === 0}
												onOptionChange={onChange}
											/>
										</View>
										<View style={styles.radiospacebetween}>
											<RadioButton
												option={{
													id: 1,
													text: t('Unlatched'),
												}}
												isSelected={value === 1}
												onOptionChange={onChange}
											/>
										</View>
										{actionConfigSaveFailed && (
											<Text
												style={{
													color: '#ff5252',
													fontSize: 12,
													marginTop: 4,
												}}>
												{t('ChangesNotSavedErrMsg')}
											</Text>
										)}
									</View>
								)}
							/>
							<Text style={styles.radioTitle}>{t('FaultConfiguration')}</Text>
							<Controller
								name='FaultConfiguration'
								control={csControl}
								render={({ field: { onChange, value } }) => (
									<View style={styles.radioContainer}>
										<View style={styles.radiospacebetween}>
											<RadioButton
												option={{
													id: 0,
													text: t('Latched'),
												}}
												isSelected={value === 0}
												onOptionChange={onChange}
											/>
										</View>
										<View style={styles.radiospacebetween}>
											<RadioButton
												option={{
													id: 1,
													text: t('Unlatched'),
												}}
												isSelected={value === 1}
												onOptionChange={onChange}
											/>
										</View>
										{faultConfigSaveFailed && (
											<Text
												style={{
													color: '#ff5252',
													fontSize: 12,
													marginTop: 4,
												}}>
												{t('ChangesNotSavedErrMsg')}
											</Text>
										)}
									</View>
								)}
							/>
							<Text style={styles.radioTitle}>{t('AlarmMode')}</Text>
							<Controller
								name='AlarmMode'
								control={csControl}
								render={({ field: { onChange, value } }) => (
									<View style={styles.radioContainer}>
										<View style={styles.radiospacebetween}>
											<RadioButton
												option={{
													id: 0,
													text: t('Instant'),
												}}
												isSelected={value === 0}
												onOptionChange={onChange}
											/>
										</View>
										<View style={styles.radiospacebetween}>
											<RadioButton
												option={{
													id: 1,
													text: t('Cumulative'),
												}}
												isSelected={value === 1}
												onOptionChange={onChange}
											/>
										</View>
										{alarmModeSaveFailed && (
											<Text
												style={{
													color: '#ff5252',
													fontSize: 12,
													marginTop: 4,
												}}>
												{t('ChangesNotSavedErrMsg')}
											</Text>
										)}
									</View>
								)}
							/>
						</View>

						<View style={styles.section}>
							<>
								{IsChannel2Available === false ? (
									<View
										style={{
											flexDirection: 'row',
											justifyContent: 'center',
											borderRadius: 10,
											marginBottom: 10,
										}}>
										<Text style={styles.sectionTitle}>{t('Channel1')}</Text>
									</View>
								) : (
									<View
										style={{
											flexDirection: 'row',
											justifyContent: 'space-between',
											borderRadius: 10,
											marginBottom: 10,
										}}>
										<TouchableOpacity
											onPress={() => {
												setIsChannel(1);
											}}
											style={[
												isChannel === 1
													? {
															borderBottomWidth: 6,
															borderColor: commonColors.backgroundColor_Blue,
													  }
													: {},
												{
													flex: 1,
													alignItems: 'center',
													justifyContent: 'center',
													paddingVertical: 15,
												},
											]}>
											<Text style={styles.sectionTitleHeading}>
												{t('Channel1')}
											</Text>
										</TouchableOpacity>
										<View
											style={{
												width: 1,
												backgroundColor: 'gray',
												marginVertical: 10,
											}}
										/>
										<TouchableOpacity
											onPress={() => {
												setIsChannel(2);
											}}
											style={[
												isChannel === 2
													? {
															borderBottomWidth: 6,
															borderColor: commonColors.backgroundColor_Blue,
													  }
													: {},
												{
													flex: 1,
													alignItems: 'center',
													justifyContent: 'center',
													paddingVertical: 15,
												},
											]}>
											<Text style={styles.sectionTitleHeading}>
												{t('Channel2')}
											</Text>
										</TouchableOpacity>
									</View>
								)}

								<View style={{ marginVertical: 0 }}>
									<View style={{ width: '50%', margin: 0 }}>
										<RNPickerSelect
											onValueChange={(val, index) => onObscurationChanged(val)}
											items={[
												{
													label: t('AlarmLevel'),
													value: 1,
												},
												{
													label: t('lblImperialUnit'),
													value: 2,
												},
												{
													label: t('lblMetricUnit'),
													value: 3,
												},
											]}
											value={selectedObscurationUnit}
											useNativeAndroidPickerStyle={false}
											Icon={() => <DropDownIcon height={24} width={24} />}
											style={obscurationPickerStyles}
										/>
									</View>
								</View>
							</>

							{isChannel === 1 ? (
								<View>
									{/* Action Level */}
									<Controller
										key='ActionLevel1'
										name='ActionLevel1'
										control={csControl}
										render={({ field: { onChange, value } }) => (
											<View>
												<IncrementDecrement
													label={t('ActionLevel')}
													value={Number(value)}
													setValue={onChange}
													min={0}
													max={8}
													belowText={t('ChannelActionLevelRange')}
													refState={csWatch('AlarmLevel1')}
													referingLabel={t('AlarmLevel')}
													obscurationType={selectedObscurationUnit}
												/>
												{ch1ActionLevelSaveFailed && (
													<Text
														style={{
															color: '#ff5252',
															fontSize: 12,
															marginTop: 4,
														}}>
														{t('ChangesNotSavedErrMsg')}
													</Text>
												)}
											</View>
										)}
									/>

									<Controller
										key='AlarmLevel1'
										name='AlarmLevel1'
										control={csControl}
										render={({ field: { onChange, value } }) => (
											<View>
												<IncrementDecrement
													label={t('AlarmLevel')}
													value={Number(value)}
													setValue={onChange}
													min={0}
													max={9}
													belowText={t('ChannelAlarmLevelRange')}
													referencingState={csWatch('ActionLevel1')}
													referingLabel={t('ActionLevel')}
													obscurationType={selectedObscurationUnit}
												/>
												{ch1AlarmLevelSaveFailed && (
													<Text
														style={{
															color: '#ff5252',
															fontSize: 12,
															marginTop: 4,
														}}>
														{t('ChangesNotSavedErrMsg')}
													</Text>
												)}
											</View>
										)}
									/>

									{/* Reference Flow */}
									<View style={{ marginBottom: 10 }}>
										<View
											style={{
												flexDirection: 'row',
												justifyContent: 'space-between',
											}}>
											<Text>{t('ReferenceFlow')}</Text>
											<TouchableOpacity
												onPress={() => {
													handleNormalizeParameters();
												}}>
												<Text
													style={{
														color: '#1791E4',
													}}>
													{t('NormalizeParameters')}
												</Text>
											</TouchableOpacity>
										</View>
										<Controller
											key='Referenceflow1'
											name='Referenceflow1'
											control={csControl}
											render={({ field: { value } }) => (
												<View style={styles.fixedFieldWrapper}>
													<Text style={styles.fixedFieldInput}>
														{value !== undefined && value !== null
															? value.toString()
															: '0'}
													</Text>
													<Text style={styles.fixedFieldRightText}>
														{t('litPerMin')}
													</Text>
												</View>
											)}
										/>
									</View>

									<Text style={styles.radioTitle}>
										<Text>{t('FlowFaultThreshold')}</Text>
										{t('percentInBrackets')}
									</Text>
									<Controller
										key='FlowFaultThreshold1'
										name='FlowFaultThreshold1'
										control={csControl}
										render={({ field: { onChange, value } }) => (
											<View
												style={[
													styles.radioContainer,
													{ borderBottomWidth: 0 },
												]}>
												<View style={styles.radiospacebetween}>
													<RadioButton
														option={{
															id: 0,
															text: t('lblen54Limit'),
														}}
														isSelected={value === 0}
														onOptionChange={() => {
															onChange(0);
															csSetValue('FlowFaultThreshold1Value', 15);
														}}
													/>
												</View>
												<View style={styles.radiospacebetween}>
													<RadioButton
														option={{
															id: 1,
															text: t('lblotherLimit'),
														}}
														isSelected={value === 1}
														onOptionChange={() => {
															onChange(1);
															csSetValue('FlowFaultThreshold1Value', 20);
														}}
													/>
												</View>
											</View>
										)}
									/>
									<View style={{ marginTop: -20 }}>
										<Controller
											key='FlowFaultThreshold1Value'
											name='FlowFaultThreshold1Value'
											control={csControl}
											render={({ field: { onChange, value } }) => (
												<IncrementDecrement
													label=''
													value={csWatch('FlowFaultThreshold1Value')}
													setValue={newValue => {
														csSetValue('FlowFaultThreshold1Value', newValue);
													}}
													min={0}
													max={80}
													belowText={t('FlowFaultThresholdRange')}
													isDisabled={csWatch('FlowFaultThreshold1') === 0}
												/>
											)}
										/>
										{ch1FlowFaultThresholdSaveFailed && (
											<Text
												style={{
													color: '#ff5252',
													fontSize: 12,
													marginTop: 4,
													marginBottom: 10,
												}}>
												{t('ChangesNotSavedErrMsg')}
											</Text>
										)}
									</View>
								</View>
							) : (
								<View>
									{/* Action Level */}
									<Controller
										key='ActionLevel2'
										name='ActionLevel2'
										control={csControl}
										render={({ field: { onChange, value } }) => (
											<View>
												<IncrementDecrement
													label={t('ActionLevel')}
													value={Number(value)}
													setValue={onChange}
													min={0}
													max={8}
													belowText={t('ChannelActionLevelRange')}
													refState={csWatch('AlarmLevel2')}
													referingLabel={t('AlarmLevel')}
													obscurationType={selectedObscurationUnit}
												/>
												{ch2ActionLevelSaveFailed && (
													<Text
														style={{
															color: 'red',
															fontSize: 12,
															marginTop: 4,
														}}>
														{t('ChangesNotSavedErrMsg')}
													</Text>
												)}
											</View>
										)}
									/>

									<Controller
										key='AlarmLevel2'
										name='AlarmLevel2'
										control={csControl}
										render={({ field: { onChange, value } }) => (
											<View>
												<IncrementDecrement
													label={t('AlarmLevel')}
													value={Number(value)}
													setValue={onChange}
													min={0}
													max={9}
													belowText={t('ChannelAlarmLevelRange')}
													referencingState={csWatch('ActionLevel2')}
													referingLabel={t('ActionLevel')}
													obscurationType={selectedObscurationUnit}
												/>
												{ch2AlarmLevelSaveFailed && (
													<Text
														style={{
															color: '#ff5252',
															fontSize: 12,
															marginTop: 4,
														}}>
														{t('ChangesNotSavedErrMsg')}
													</Text>
												)}
											</View>
										)}
									/>
									{/* Reference Flow 2 */}
									<View style={{ marginBottom: 10 }}>
										<View
											style={{
												flexDirection: 'row',
												justifyContent: 'space-between',
											}}>
											<Text>{t('ReferenceFlow')}</Text>
											<TouchableOpacity
												onPress={() => {
													handleNormalizeParameters();
												}}>
												<Text
													style={{
														color: '#1791E4',
													}}>
													{t('NormalizeParameters')}
												</Text>
											</TouchableOpacity>
										</View>
										<Controller
											key='Referenceflow2'
											name='Referenceflow2'
											control={csControl}
											render={({ field: { value } }) => (
												<View style={styles.fixedFieldWrapper}>
													<Text style={styles.fixedFieldInput}>
														{value !== undefined && value !== null
															? value.toString()
															: '0'}
													</Text>
													<Text style={styles.fixedFieldRightText}>
														{t('litPerMin')}
													</Text>
												</View>
											)}
										/>
									</View>

									<Text style={styles.radioTitle}>
										<Text>{t('FlowFaultThreshold')}</Text>
										{t('percentInBrackets')}
									</Text>
									<Controller
										key='FlowFaultThreshold2'
										name='FlowFaultThreshold2'
										control={csControl}
										render={({ field: { onChange, value } }) => (
											<View
												style={[
													styles.radioContainer,
													{ borderBottomWidth: 0 },
												]}>
												<View style={styles.radiospacebetween}>
													<RadioButton
														option={{
															id: 0,
															text: t('lblen54Limit'),
														}}
														isSelected={value === 0}
														onOptionChange={() => {
															onChange(0);
															csSetValue('FlowFaultThreshold2Value', 15);
														}}
													/>
												</View>
												<View style={styles.radiospacebetween}>
													<RadioButton
														option={{
															id: 1,
															text: t('lblotherLimit'),
														}}
														isSelected={value === 1}
														onOptionChange={() => {
															onChange(1);
															csSetValue('FlowFaultThreshold2Value', 20);
														}}
													/>
												</View>
											</View>
										)}
									/>
									<View style={{ marginTop: -20 }}>
										<Controller
											key='FlowFaultThreshold2Value'
											name='FlowFaultThreshold2Value'
											control={csControl}
											render={({ field: { onChange, value } }) => (
												<IncrementDecrement
													label=''
													value={csWatch('FlowFaultThreshold2Value')}
													setValue={newValue => {
														csSetValue('FlowFaultThreshold2Value', newValue);
													}}
													min={0}
													max={80}
													belowText={t('FlowFaultThresholdRange')}
													isDisabled={csWatch('FlowFaultThreshold2') === 0}
												/>
											)}
										/>
										{ch2FlowFaultThresholdSaveFailed && (
											<Text
												style={{
													color: '#ff5252',
													fontSize: 12,
													marginTop: 4,
													marginBottom: 10,
												}}>
												{t('ChangesNotSavedErrMsg')}
											</Text>
										)}
									</View>
								</View>
							)}
						</View>
					</View>
				</ScrollView>
			</SafeAreaView>
		);
	};
	//#endregion

	//#region  More Options and Normalization
	const handleNormalizeParameters = () => {
		normalizeParameters();
	};
	async function normalizeParameters() {
		var doWeNeedBothChannelsNormalized = true;
		if (IsChannel2Available)
			doWeNeedBothChannelsNormalized = await confirmAlert(
				t('msgNormalizebothchannels'),
				t('lblNOTE'),
				t('ok'),
				t('cancel'),
			);
		if (doWeNeedBothChannelsNormalized) {
			showLoadingIndicator(t('SendingNormalizedCommand'));
			var isNormalized =
				await faastflexBluetoothCommunicator.SetNormalizedCommand();
			hideLoadingIndicator();
			if (isNormalized.isReset) {
				showLoadingIndicator(t('NormalizationInProgressMsg'));
				await delay(60000);
				hideLoadingIndicator();
				Toast.show({
					type: 'info',
					text2: t('NormalizationCompleteMsg'),
					position: 'bottom',
				});
			} else {
				Toast.show({
					type: 'error',
					text2: t('NormalizedCommandError'),
					position: 'bottom',
				});
			}
		}
	}
	//#endregion

	//#region Tab Press Handler
	function handleGeneralParametersPress() {
		if (isGeneralParameterVisible) return;
		saveParametersToDevice(true);
	}

	function handleChannelAndSensorsPress() {
		if (isChannelsAndSensorsVisible) return;
		saveParametersToDevice(true);
		setIsChannel2Available(selectedDeviceRef.current.channels > 1);
	}
	//#endregion

	const renderFooter = () => {
		return (
			<View>
				<View
					style={[styles.buttonFooter, { opacity: offlineMode ? 0.5 : 1 }]}
					pointerEvents={offlineMode ? 'none' : 'auto'}>
					<SingleButtonFooter
						buttonText={t('saveandconfigure')}
						onButtonPress={onSaveParamsPressed}
						buttonDisabled={false}
						buttonStyle={{ backgroundColor: '#1791E4' }}
						buttonTextStyle={{ color: '#fff' }}
					/>
				</View>
				<View style={styles.footer}>
					<ImageButtonSVG
						svgComponent={<GeneralEnabled />}
						disabledSvgComponent={<General />}
						disabled={!isGeneralParameterVisible}
						svgHeight={30}
						svgWidth={30}
						text='General'
						onPress={() => {
							handleGeneralParametersPress();
						}}
						style={styles.button}
						textStyle={
							isGeneralParameterVisible
								? styles.buttonTextBlue
								: styles.buttonText
						}></ImageButtonSVG>

					<ImageButtonSVG
						svgComponent={<DashboardEnabled />}
						disabledSvgComponent={<Dashboard />}
						disabled={!isChannelsAndSensorsVisible}
						svgHeight={30}
						svgWidth={30}
						text='ChannelandSensors'
						onPress={() => {
							handleChannelAndSensorsPress();
						}}
						style={styles.button}
						textStyle={
							isChannelsAndSensorsVisible
								? styles.buttonTextBlue
								: styles.buttonText
						}></ImageButtonSVG>
				</View>
			</View>
		);
	};

	function getPanelImage(image: string): ReactElement {
		if (image === 'PanelConnected.png') {
			return <BluetoothConnected height={30} width={30} />;
		} else if (image === 'PanelNotConnected.png') {
			return <BluetoothDisabled height={30} width={30} />;
		} else {
			return <BluetoothDisabled height={30} width={30} />;
		}
	}

	return (
		<View style={styles.mainContainer}>
			{/* Header - 10% of height */}
			<SafeAreaContextView edges={['top']} style={styles.safeHeader}>
				<View
					style={[
						styles.headerSection,
						{
							backgroundColor: '#000',
							alignItems: 'center',
						},
					]}>
					<View
						style={{
							flexDirection: 'row',
							alignItems: 'center',
							paddingHorizontal: 10,
							height: '100%',
						}}>
						<TouchableOpacity
							onPress={() => handleBackPress()}
							style={{
								height: '100%',
								padding: 0,
								margin: 0,
								justifyContent: 'center',
							}}>
							<LeftArrowWhite height={30} width={30} />
						</TouchableOpacity>

						<View style={[{ flex: 2 }]}>
							<Text
								style={{
									color: '#fff',
									fontSize: 18,
									fontWeight: 'bold',
									textAlign: 'center',
								}}>
								Device Parameters
							</Text>
						</View>

						{getPanelImage(BluetoothImage)}

						<TouchableOpacity
							disabled={!IsSyncEnabled}
							onPress={() => SyncCommandAsync()}
							style={{
								height: '100%',
								paddingHorizontal: 15,
								margin: 0,
								justifyContent: 'center',
								opacity: IsSyncEnabled ? 1 : 0.5,
							}}>
							<SyncWhite height={24} width={24} />
						</TouchableOpacity>

						<DropdownMenu
							triggerText=''
							menuOptions={[
								...(offlineMode
									? []
									: [
											{
												label: t('ImportConfiguration'),
												onSelect: handleImport,
											},
									  ]),
								{
									label: t('ExportConfiguration'),
									onSelect: exportDeviceParameters,
								}, //TODO : Sailendra : Export DeviceParametersModel to Downloads
							]}
							triggerTextStyle={styles.buttonText}
						/>
					</View>
				</View>
			</SafeAreaContextView>

			<View style={styles.contentSection}>
				<MenuProvider>
					<View style={{ flex: 1 }}>
						{/* Main content area - conditionally render based on active screen */}
						{isGeneralParameterVisible && renderGeneralParameter()}
						{isChannelsAndSensorsVisible && renderChannelsandSensors()}
						{!isGeneralParameterVisible && !isChannelsAndSensorsVisible && (
							<View>{/* Items when both screens are false */}</View>
						)}
					</View>
				</MenuProvider>
			</View>

			{/* Footer */}
			<View style={styles.footerSection}>{renderFooter()}</View>
			<TimeoutPopup
				isVisible={showTimeoutPopup}
				onClose={handleCloseTimeoutMessage}
			/>
			{IsAddSparepartVisible && renderAspiratorSparePartChange()}
		</View>
	);
}
const styles = StyleSheet.create({
	//#region Main Content Styles
	mainContainer: {
		flex: 1,
		backgroundColor: '#f5f5f5',
	},
	headerSection: {
		backgroundColor: '#000',
		height: 56,
		width: '100%',
	},
	safeHeader: {
		backgroundColor: '#000',
	},
	contentSection: {
		flex: 1,
		width: '100%',
	},
	footerSection: {
		width: '100%',
		backgroundColor: '#ffffff',
	},
	//#endregion

	footer: {
		backgroundColor: '#ffffffff',
		borderTopWidth: 1,
		borderTopColor: '#e0e0e0',
		flexDirection: 'row',
		justifyContent: 'space-around',
		alignItems: 'center',
	},
	button: {
		marginTop: 5,
		backgroundColor: '#ffffff',
	},
	buttonText: {
		color: '#000000',
		fontSize: 14,
		textAlign: 'center',
	},
	buttonTextBlue: {
		color: '#1792E5',
		fontSize: 14,
		textAlign: 'center',
	},

	container: {
		flex: 1,
		marginHorizontal: 14,
		marginTop: 10,
	},
	header: {
		fontSize: 20,
		fontWeight: 'bold',
		marginBottom: 20,
	},
	section: {
		backgroundColor: '#fff',
		borderRadius: 5,
		paddingHorizontal: 16,
		paddingTop: 16,
		marginBottom: 16,
		borderWidth: 1,
		borderColor: '#e0e0e0',
		elevation: 5,
	},
	sectionTitle: {
		fontSize: 16,
		fontWeight: '600',
		marginBottom: 10,
		paddingBottom: 10,
		borderBottomWidth: 1,
		borderBottomColor: '#e0e0e0',
	},
	GeneralParameterradioContainer: {
		flexDirection: 'row',
		justifyContent: 'flex-start',
		alignItems: 'center',
		marginVertical: 8,
		paddingBottom: 10,
	},
	radioContainer: {
		flexDirection: 'row',
		justifyContent: 'flex-start',
		alignItems: 'center',
		marginVertical: 8,
		paddingBottom: 5,
		borderBottomWidth: 1,
		borderBottomColor: '#e0e0e0',
	},
	GeneralParameterradioTitle: {
		color: commonColors.textColor_Black,
		fontSize: 15,
		fontWeight: '500',
	},
	radioTitle: {
		fontSize: 15,
		fontWeight: '400',
		marginBottom: 5,
	},
	radiospacebetween: {
		flex: 1,
	},
	radioField: {
		marginTop: 10,
		borderBottomWidth: 1,
		borderBottomColor: '#e0e0e0',
	},
	buttonFooter: {
		borderTopWidth: 1,
		borderTopColor: '#e0e0e0',
		backgroundColor: '#fff',
	},
	dropdownSection: {
		marginTop: 5,
	},
	dropdownLabel: {
		color: commonColors.textColor_Black,
		fontSize: 15,
		fontWeight: '500',
		paddingBottom: 5,
	},
	dropdownButton: {
		flexDirection: 'row',
		alignItems: 'center',
		justifyContent: 'space-between',
		marginBottom: 10,
		height: commonSizes.textBoxHeight_L,
		borderColor: commonColors.textBoxBorderColor,
		borderWidth: commonSizes.textBoXBorderWidthXS,
		borderRadius: commonSizes.cornerRadius,
		paddingHorizontal: commonSizes.paddingM_Percent,
		marginTop: commonSizes.heightS_Pixel,
	},
	dropdownText: {
		flex: 1,
		fontSize: 15,
		color: '#000',
	},
	dropdownIcon: {
		width: 15,
		height: 15,
		marginRight: 10,
	},

	sectionTitleHeading: {
		fontSize: 16,
		fontWeight: '600',
	},
	ActionCongigsectionTitle: {
		fontSize: 16,
		fontWeight: '600',
		marginBottom: 15,
		paddingBottom: 10,
		borderBottomWidth: 1,
		borderBottomColor: '#e0e0e0',
	},
	incrementContainer: {
		flexDirection: 'row',
		alignItems: 'center',
		marginVertical: 8,
		borderWidth: 1,
		borderColor: '#e0e0e0',
	},
	incrementButton: {
		width: 30,
		height: 30,
		justifyContent: 'center',
		alignItems: 'center',
		borderWidth: 1,
		borderColor: '#e0e0e0',
		borderRadius: 5,
	},
	incrementButtonText: {
		fontSize: 18,
		fontWeight: 'bold',
	},
	incrementValueContainer: {
		flex: 1,
		justifyContent: 'center',
		alignItems: 'center',
	},
	incrementValue: {
		fontSize: 16,
	},

	//#region Aspitoror Spare Part Change Modal

	// Add to your existing styles object

	buttonGrid: {
		flexDirection: 'row',
		justifyContent: 'space-between',
		marginBottom: 10,
	},
	buttonGridColumn: {
		flex: 1,
		paddingHorizontal: 5,
	},
	cancelButton: {
		backgroundColor: 'white',
		paddingVertical: 12,
		paddingHorizontal: 10,
		borderRadius: 5,
		borderWidth: 1,
		borderColor: '#1791E4',
		alignItems: 'center',
		justifyContent: 'center',
	},
	cancelButtonText: {
		color: '#1791E4',
		fontSize: 16,
	},
	actionButton: {
		backgroundColor: '#1791E4',
		paddingVertical: 12,
		paddingHorizontal: 10,
		borderRadius: 5,
		alignItems: 'center',
		justifyContent: 'center',
	},
	disabledButton: {
		opacity: 0.5,
	},
	actionButtonText: {
		color: 'white',
		fontSize: 16,
	},
	boldText: {
		fontWeight: 'bold',
	},
	doneButton: {
		backgroundColor: '#1791E4',
		paddingVertical: 12,
		paddingHorizontal: 10,
		borderRadius: 5,
		alignItems: 'center',
		justifyContent: 'center',
		marginTop: 5,
	},
	stepImage: {
		width: 200,
		height: 150,
		resizeMode: 'contain',
		marginBottom: 15,
	},
	//#endregion
	//#region Password change Styles
	passwordChangeBox: {
		height: commonSizes.textBoxHeight_L,
		borderColor: commonColors.textBoxBorderColor,
		borderWidth: commonSizes.textBoXBorderWidthXS,
		borderRadius: commonSizes.cornerRadius,
		paddingHorizontal: commonSizes.paddingM_Percent,
		color: commonColors.textColor_Grey,
		fontSize: commonSizes.textSizeM,
		textAlignVertical: 'center',
	},
	//#endregion
	fixedFieldWrapper: {
		flexDirection: 'row',
		alignItems: 'center',
		justifyContent: 'space-between',
		height: commonSizes.textBoxHeight_L,
		borderColor: commonColors.textBoxBorderColor,
		borderWidth: commonSizes.textBoXBorderWidthXS,
		borderRadius: commonSizes.cornerRadius,
		paddingHorizontal: commonSizes.paddingM_Percent,
		color: commonColors.textColor_Grey,
		fontSize: commonSizes.textSizeM,
		marginTop: commonSizes.heightS_Pixel,
		opacity: 0.7,
	},
	fixedFieldInput: {
		flex: 1,
		padding: 10,
		color: '#495057',
		fontSize: 16,
	},
	fixedFieldRightText: {
		fontSize: 14,
		color: 'rgba(100,100,100,0.5)',
	},
});

const pickerSelectStyles = {
	inputIOS: {
		fontSize: 15,
		padding: 10,
		borderWidth: 1,
		borderColor: '#9D9D9D',
		borderRadius: 4,
		color: '#000',
		paddingHorizontal: 20,
		backgroundColor: '#fff',
		margin: 0,
	},
	inputAndroid: {
		fontSize: 15,
		padding: 10,
		borderWidth: 1,
		borderColor: '#9D9D9D',
		borderRadius: 2,
		color: '#000',
		paddingHorizontal: 20,
		backgroundColor: '#fff',
		margin: 0,
	},
	iconContainer: {
		top: 12,
		right: 12,
	},
};

const obscurationPickerStyles = {
	inputIOS: {
		fontSize: 15,
		padding: 10,
		borderWidth: 1,
		borderColor: '#9D9D9D',
		borderRadius: 4,
		color: '#000',
		paddingHorizontal: 10,
		backgroundColor: '#fff',
		margin: 0,
	},
	inputAndroid: {
		fontSize: 15,
		padding: 10,
		borderWidth: 1,
		borderColor: '#9D9D9D',
		borderRadius: 2,
		color: '#000',
		paddingHorizontal: 10,
		backgroundColor: '#fff',
		margin: 0,
	},
	iconContainer: {
		top: 12,
		right: 12,
	},
};
