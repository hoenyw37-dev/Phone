import React, {
	View,
	ScrollView,
	StyleSheet,
	ActivityIndicator,
	Button,
	Text,
	FlatList,
	Modal,
	Alert,
	TouchableOpacity,
	TextInput,
	NativeModules,
	Platform,
	Linking,
	Pressable,
	BackHandler,
} from 'react-native';
import { useEffect, useState, useRef, ReactElement } from 'react';
import { SafeAreaProvider, SafeAreaView } from 'react-native-safe-area-context';
import {
	selectDevicesStatus,
	selectDevicesError,
} from '@ff_redux/deviceRedux/devicesSlice.ts';
import { useAppDispatch, useAppSelector } from '@global/hooks';
import {
	deleteDeviceWithId,
	fetchDeviceById,
	updateExistingDevice,
	fetchDevicesByProjectId,
} from '@ff_redux/deviceRedux/devicesThunk.ts';
import { useDatabase } from '@global/DatabaseContext';
import InfoCard from '@components/InfoCard';
import Toast from 'react-native-toast-message';
import BluetoothManager from '../../../bleCommunicator/enableBluetooth.ts';
// Scan Device Modal

import { useBLE } from '../../../bleCommunicator/bleContext.tsx';
import {
	Configuration,
	Country,
	DeviceAuthenticated,
	DeviceStatus,
	DeviceType,
	ErrorCode,
	getConfigurationDescription,
	getCountryDescription,
	getDeviceStatusDescription,
	getDeviceTypeDescription,
	getRelayEnabledDescription,
	PasswordValid,
	RelayEnabled,
} from '@faastflexCommands/commandEnum.ts';

import { PermissionsAndroid } from 'react-native';
import { BluetoothDevice } from '../../../bleCommunicator/bleService.ts';
import { useLoading } from '@global/GlobalContext/LoadingContext.tsx';
import { confirmAlert } from '@ff_utils/confirmAlert.ts';
import faastflexBluetoothCommunicator from '@faastflexCommunicator/faastflexBluetoothCommunicator.ts';
import {
	DeviceModel,
	DeviceState,
	getDeviceStateDescription,
} from '@ff_model/deviceModel.ts';
import EncryptedStorage from 'react-native-encrypted-storage';
import { FaastFlexDeviceStatus } from 'faastflexCommandModel/faastflexResponseParserModel.ts';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { delay } from '@ff_utils/timeDelay.ts';
import SoundPairingDecoder from '@ff_utils/soundPairingDecoder.ts';
import SearchIconWhite from '@assets/images/SearchIconWhite.svg';
import MoreIcon from '@assets/images/TripleDotIconGrey.svg';
import { FaastFlexScannedDevice } from '@ff_model/faastFlexScannedDevice.ts';
import ActivityIndicatorWhite from '@global/GlobalContext/ActivityIndicatorWhite.tsx';
import { BleErrorCode } from '@global/GlobalConstants/globalConstants.ts';
import useSyncedState from '@global/Hooks/useSyncedState.ts';
import { useNative } from 'NativeCommunicator/nativeContext.tsx';
import { check, PERMISSIONS, request, RESULTS } from 'react-native-permissions';
import {
	Menu,
	MenuOption,
	MenuOptions,
	MenuTrigger,
	renderers,
} from 'react-native-popup-menu';
import { commonColors, commonSizes, commonStyles } from '@styles/base.ts';
import { AppConstants } from '../../../global/GlobalConstants/globalConstants.ts';
import { eventHandler } from '@global/utils/EventBus.ts';
import { useTranslation } from 'react-i18next';
import DeviceParking from '@faastflexCommunicator/deviceParking.ts';
import DateTimePicker from '@react-native-community/datetimepicker';
import DoubleButtonFooter from '@components/doubleButtonFooter.tsx';

import ExpandArrow from '@assets/images/Expandarrow.svg';
import FilterWhite from '@assets/images/Filterwhite.svg';
import Mic from '@assets/images/Mic.svg';
import Silenced from '@assets/images/Silenced.svg';
import Log from '@assets/images/Log.svg';
import BluetoothConnected from '@assets/images/BluetoothConnected.svg';
import BleutoothWhite from '@assets/images/BleutoothWhite.svg';
import ResetWhite from '@assets/images/ResetWhite.svg';
import SyncBlue from '@assets/images/SyncBlue.svg';
import CloseIconGray from '@assets/images/CloseIconGray.svg';
import LeftArrowWhite from '@assets/images/LeftArrowWhite.svg';
import SoundPairing from '@assets/images/SoundPairing.svg';
import ManualPairingInstruction1 from '@assets/images/AspiratorCoverRemoval.svg';
import ManualPairingInstruction2 from '@assets/images/ManualPairingInstruction2.svg';
import SignalStrength1 from '@assets/images/signalstrength1.svg';
import SignalStrength2 from '@assets/images/signalstrength2.svg';
import SignalStrength3 from '@assets/images/signalstrength3.svg';
import SignalStrength4 from '@assets/images/signalstrength4.svg';
import Pass from '@assets/images/Pass.svg';
import Fail from '@assets/images/Fail.svg';
import SingleButtonFooter from '@components/singleButtonFooter.tsx';
import { stringFunction } from '@ff_utils/stringFunction.ts';
import { ModalLoadingIndicator } from '../controllers/modalLoadingIndicator.tsx';
import DropdownMenu, {
	MenuOptionItem,
} from '../controllers/dropdownController';
import {
	getStateIcon,
	getStatusIcon,
} from '@faastflex/converters/iconConverter.tsx';

//#region Constants
const { PcmRecorder } = NativeModules;
const Const_ACTIVE = 'Active';
const Const_Focus = 'focus';
//#endregion

export default function DeviceList({ route, navigation }: any) {
	//#region Properties
	const [onAssign, setOnAssign] = useState(false);
	const [isBleScanning, setIsBleScanning] = useState(false);
	const [blePeripherals, setBlePeripherals] = useState<
		FaastFlexScannedDevice[]
	>([]);
	const {
		scanDevices,
		connectToDevice,
		disconnectDevice,
		scannedDevices,
		bleError,
		getEventEmitter,
		stopDeviceScan,
		IsConnectionEstablished,
	} = useBLE();
	const {
		EnableBluetooth,
		GetPermission,
		getNativeEventEmitter,
		CheckBluetoothTurnedOn,
		turnOnBluetooth,
		requestBluetoothPermissions,
	} = useNative();
	const [showConnectingModal, setShowConnectingModal] = useState(false);
	const [showConnectionFailedModal, setShowConnectionFailedModal] =
		useState(false);
	const [showAvailableDevices, setShowAvailableDevices] = useState(false);
	const [RegisteredFaastFlexDeviceFound, setRegisteredFaastFlexDeviceFound] =
		useState(false);
	const [RegisteredFaastFlexDevice, setRegisteredFaastFlexDevice] =
		useState<BluetoothDevice | null>(null);
	const ConnectedDeviceobj = useRef<BluetoothDevice | null>(null);
	const projectId = useRef<number>(0);
	const [isLedStatusVisible, setIsLedStatusVisible] = useState<boolean>(true);

	const { showLoadingIndicator, hideLoadingIndicator } = useLoading();
	const { t } = useTranslation();

	// Above code is modal code
	const [confirmationModal, setConfirmationModal] = useState(false);
	const [confirmationId, setConfirmationId] = useState(-1);
	const [confirmationName, setConfirmationName] = useState('');

	const bluetoothManager = new BluetoothManager();
	const [displayDeviceCreation, setDisplayDeviceCreation] = useState();
	const [moreInfoDevice, setMoreInfoDevice, moreInfoDeviceRef] =
		useSyncedState<DeviceModel>(new DeviceModel());

	const dispatch = useAppDispatch(); //return dispatch function from redux store

	const { dataSource } = useDatabase(); // Access the database instance from context
	console.log('DevicesLIST.........');

	//appselector selects function from the redux store
	//const devices = useAppSelector(selectAllDevices);
	const devicesStatus = useAppSelector(selectDevicesStatus);
	const devicesError = useAppSelector(selectDevicesError);

	//const fetchedDevice = useAppSelector(state => selectDeviceById(state, moreInfoDevice.deviceId));

	const [filterFromDate, setFilterFromDate] = useState<Date>(new Date());
	const [filterToDate, setFilterToDate] = useState<Date>(new Date());
	const [isItemSelected, setIsItemSelected] = useState(true);
	const [filteredDeviceList, setFilteredDeviceList] = useState<DeviceModel[]>(
		[],
	);
	const [isDeviceAvailable, setIsDeviceAvailable] = useState(false);
	const [deviceCount, setDeviceCount] = useState<string>('');
	const [panelImage, setPanelImage] = useState<string>('');
	const [IsSearchEntryVisible, setIsSearchEntryVisible] =
		useState<boolean>(false);
	const [showAddedDevices, setShowAddedDevices] = useState(true);
	const [showScannedDevices, setShowScannedDevices] = useState(false);
	const [showLoader, setShowLoader] = useState(false);
	const [showValidatingSoundLabel, setShowValidatingSoundLabel] =
		useState(false);
	const [showAcceptWaitingLabel, setShowAcceptWaitingLabel] = useState(false);
	const [showSuccessValidatedLabel, setShowSuccessValidatedLabel] =
		useState(false);
	const [showUnableToValidate, setShowUnableToValidate] = useState(false);
	const [showManualPasscode, setShowManualPasscode] = useState(false);
	const [showSoundPairingInstruction, setShowSoundPairingInstruction] =
		useState(false);
	const [
		isSoundPairingStartButtonsVisible,
		setIsSoundPairingStartButtonsVisible,
	] = useState(false);
	const [
		isSoundPairingDoneButtonsVisible,
		setIsSoundPairingDoneButtonsVisible,
	] = useState(false);
	const [
		isSoundPairingRetryButtonsVisible,
		setIsSoundPairingRetryButtonsVisible,
	] = useState(false);
	const [soundPairingText1, setSoundPairingText1] = useState('');
	const [soundPairingText2, setSoundPairingText2] = useState('');
	const [soundPairingStatusColor, setSoundPairingStatusColor] = useState('');
	const [soundPairingRetryCount, setSoundPairingRetryCount] = useState(0);
	const [isMicroPhoneAccessRequired, setIsMicroPhoneAccessRequired] =
		useState(false);
	const [SoundPairingRetryText, setSoundPairingRetryText] = useState('');
	const [SwitchBluetooth, setSwitchBluetooth] = useState(false);
	const [showFilterModal, setShowFilterModal] = useState<boolean>(false);
	const bleAdapterStatusUnsubscribe = useRef<(() => void) | null>(null);

	const DeviceCountry = useRef<string>('');
	const listOfDevices = useRef<DeviceModel[]>([]);
	const reassignDevice = useRef<boolean>(false);
	const IsDeviceDisconnected = useRef<boolean>(false);
	const connectPairedDevice = useRef<boolean>(false);
	const permissionCounter = useRef<number>(0);
	const pairedDeviceFound = useRef<boolean>(false);
	const _isItemSelected = useRef<boolean>(false);

	//#endregion

	//#region Mirror HMI
	const [configModalVisible, setConfigModalVisible] = useState<boolean>(false);

	const [isMirrorHMIVisible, setIsMirrorHMIVisible] = useState<boolean>(false);
	const [AlarmLEDStatus1, setAlarmLEDStatus1] = useState<string>('Not Active');
	const [PreAlarmLEDStatus1, setPreAlarmLEDStatus1] =
		useState<string>('Not Active');
	const [AlarmLEDStatus2, setAlarmLEDStatus2] = useState<string>('Not Active');
	const [PreAlarmLEDStatus2, setPreAlarmLEDStatus2] =
		useState<string>('Not Active');
	const [FaultLEDStatus, setFaultLEDStatus] = useState<string>('Not Active');
	const [AlertStatus, setAlertStatus] = useState<string>('Not Active');
	const [DeviceStateColor, setDeviceStateColor] = useState<string>('');
	const [IsDeviceCountryCodeChina, setIsDeviceCountryCodeChina] =
		useState<boolean>(false);
	const [IsSelfTestChinaEnabled, setIsSelfTestChinaEnabled] =
		useState<boolean>(false);
	const [isDualChannelDevice, setIsDualChannelDevice] =
		useState<boolean>(false);
	const [passwordValues, setPasswordValues] = useState([
		'',
		'',
		'',
		'',
		'',
		'',
	]);
	const passwordInputRefs = useRef<Array<TextInput | null>>([]);

	const IsMirrorHMIResetCommand = useRef<boolean>(false);
	const IsSelfTestChina = useRef<boolean>(false);
	const IsConfigurePage = useRef<boolean>(false);

	const autoRefreshTimer = useRef<NodeJS.Timeout | null>(null);
	const autoRefreshTimerCounter = useRef<number>(0);
	const deviceTypeRef = useRef<string>(
		getDeviceTypeDescription(DeviceType.eUnknown),
	);
	//#endregion

	//#region Pairing Command
	const [manualPasscode, setManualPasscode] = useState('');
	const [showManualPairingInstructions, setShowManualPairingInstructions] =
		useState<boolean>(false);
	const [showManualPairingStep1, setShowManualPairingStep1] = useState(true);
	const [showAcceptPairing, setShowAcceptPairing] = useState(false);
	const [showConnectingLabel, setShowConnectingLabel] = useState(false);
	const [showManualPairingStep2, setShowManualPairingStep2] = useState(false);
	const [showPWDValidationFailedModal, setShowPWDValidationFailedModal] =
		useState(false);
	const [showPreviousPasswordExpired, setShowPreviousPasswordExpired] =
		useState(false);
	const [showValidatingPWDModal, setShowValidatingPWDModal] = useState(false);
	const [showPWDValidationSuccessModal, setShowPWDValidationSuccessModal] =
		useState(false);

	const [mirrorHMILoadingIndicator, setMirrorHMILoadingIndicator] =
		useState(false);
	const [soundDecodeLoadingIndicator, setSoundDecodeLoadingIndicator] =
		useState(false);
	const [mirrorHMILoadingMessage, setMirrorHMILoadingMessage] = useState('');
	const connectScannedDevicesRef = useRef<BluetoothDevice[]>([]);
	const connectDeviceMultiCallBlocker = useRef(false);
	const scanCompletedHandled = useRef(false);
	//#endregion

	//#region  On Screen Appeared
	useEffect(() => {
		console.log('Route params:', route.params);
		InitializeAsync();
		GenerateUniqueIdentifier();
	}, []);

	useEffect(() => {
		const unsubscribe = navigation.addListener('focus', () => {
			OnPageAppeared();
		});
		const blurUnsubscribe = navigation.addListener('blur', () => {
			eventListenerCleanUp();
		});
		return () => {
			unsubscribe();
			blurUnsubscribe();
		};
	}, [navigation]);
	//#endregion

	useEffect(() => {
		return () => {
			eventListenerCleanUp();
		};
	}, []);

	//#region Prevent Device Back Functionality
	//Android
	useEffect(() => {
		const backHandler = BackHandler.addEventListener(
			'hardwareBackPress',
			() => {
				return true; // Return true to prevent default back behavior
			},
		);

		return () => backHandler.remove();
	}, []);

	//iOS
	useEffect(() => {
		navigation.setOptions({
			gestureEnabled: false, // Disable swipe back gesture
		});
	}, [navigation]);
	//#endregion

	//#region UniqueIdentifier
	async function GenerateUniqueIdentifier() {
		try {
			var uniqueIdentifier = await EncryptedStorage.getItem('UniqueIdentifier');
			if (
				uniqueIdentifier === null ||
				uniqueIdentifier === undefined ||
				uniqueIdentifier === ''
			) {
				await EncryptedStorage.setItem(
					'UniqueIdentifier',
					generateRandomString(12),
				);
			}
		} catch (error) {}
	}
	function generateRandomString(size: number): string {
		const alphabet =
			'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
		let result = '';
		for (let i = 0; i < size; i++) {
			result += alphabet.charAt(Math.floor(Math.random() * alphabet.length));
		}
		return result;
	}
	//#endregion

	//#region Handle the ble State changes

	//Handle Scanned Scenario
	useEffect(() => {
		if (scannedDevices.length > 0) {
			if (connectPairedDevice.current) {
				// CheckAndConnectPairedDevice(scannedDevices);
				connectScannedDevicesRef.current = [
					...connectScannedDevicesRef.current,
					...scannedDevices,
				];
			} else {
				ScannedDevicesSorting(scannedDevices);
			}
		}
	}, [scannedDevices]);

	//Handle Ble Error Scenario
	useEffect(() => {
		if (bleError) {
			if (bleError !== BleErrorCode.UNKNOWN) {
				OnBleCommunicationFailure(bleError);
			}
		}
	}, [bleError]);

	//Handle Connected Scenario
	// useEffect(() => {
	//   if(connectedDevice){
	//     if(connectedDevice.connected){
	//       //TODO: Reset Retry Count if needed
	//    // OnSuccessfullconnection(connectedDevice);
	//     }
	//     else{
	//     hideLoadingIndicator();
	//     setShowConnectionFailedModal(true);
	//     Toast.show({
	//       type: 'error',
	//       text1: 'Error',
	//       text2: 'DeviceConnectionFailedPleaseRetry',
	//     });
	//   }
	//   }
	// }, [connectedDevice]);

	useEffect(() => {
		const unsubscribe = eventHandler.subscribe('deviceConnected', device => {
			onSuccess(device);
		});

		return () => unsubscribe();
	}, []);

	async function onSuccess(device: BluetoothDevice) {
		if (device !== null) {
			//TODO: Reset Retry Count if needed
			OnSuccessfullconnection(device);
		} else {
			hideLoadingIndicator();
			setShowConnectionFailedModal(true);
			Toast.show({
				type: 'error',
				text2: t('DeviceConnectionFailedPleaseRetry'),
				position: 'bottom',
			});
		}
	}

	//Handle Disconnected Scenario
	useEffect(() => {
		const unsubscribe = eventHandler.subscribe('deviceDisconnected', () => {
			OnDeviceConnectionFailed();
		});

		return () => unsubscribe();
	}, []);

	function OnBleCommunicationFailure(bleError: BleErrorCode) {
		if (bleError === BleErrorCode.BLUETOOTH_NOT_ENABLED) {
			hideLoadingIndicator();
			hideActivityIndicator();
			setShowConnectingModal(false);
			setShowScannedDevices(false);
			AskBluetoothConsent();
		} else if (bleError === BleErrorCode.BLUETOOTH_NOT_SUPPORTED) {
			hideLoadingIndicator();
			hideActivityIndicator();
			if (connectPairedDevice.current) {
				setShowConnectingModal(false);
				setShowConnectionFailedModal(true);
			} else {
				setShowConnectingModal(false);
				setShowScannedDevices(false);
				setShowAddedDevices(true);
			}
			Toast.show({
				type: 'error',
				text2: t('SmartConfigPanelNotFoundTryDisconnecting'),
				position: 'bottom',
			});
		} else if (bleError === BleErrorCode.BLUETOOTH_TIMEOUT) {
			hideLoadingIndicator();
			hideActivityIndicator();
			setShowConnectingModal(false);
			setShowScannedDevices(false);
			if (connectPairedDevice.current) {
				setShowConnectionFailedModal(true);
			}
			Toast.show({
				type: 'error',
				text2: t('SmartConfigPanelNotFoundTryDisconnecting'),
				position: 'bottom',
			});
		} else {
			hideLoadingIndicator();
			setSwitchBluetooth(false);
			Alert.alert(t('Error'), 'BLE Error: ' + bleError, [{ text: t('ok') }]);
		}
	}
	async function AskBluetoothConsent() {
		try {
			var enableBle = await confirmAlert(
				t('appneedsbluetooth'),
				t('EnableBluetooth'),
				t('EnableUpperCase'),
				t('cancel'),
			);
			if (enableBle) {
				await turnOnBluetooth();
			}
		} catch (error) {
			console.error('AskBluetoothConsent error:', error);
		}
	}

	async function OnSuccessfullconnection(device: BluetoothDevice) {
		try {
			if (device !== null) {
				ConnectedDeviceobj.current = device;
				DeviceParking.parkDevice('ConnectedPanel', device);

				var a = DeviceParking.getParkedDevice('ConnectedPanel');
				if (moreInfoDeviceRef.current !== null) {
					const allKeys = await AsyncStorage.getAllKeys();
					if (allKeys.length > 0) {
						await AsyncStorage.clear();
					}
					await AsyncStorage.setItem(
						moreInfoDeviceRef.current.deviceId.toString(),
						String(true),
					);
					const deviceMacAddress = device.address;
					const lastConnected = new Date().toISOString();
					await delay(5000);

					setShowConnectingModal(false);
					showLoadingIndicator(t(''));
					var uniqueIdentifier = await EncryptedStorage.getItem(
						'UniqueIdentifier',
					);
					let authenticatedAwnser =
						await faastflexBluetoothCommunicator.checkAuthenticated(
							uniqueIdentifier!!,
						);
					let authenticatedStatus = authenticatedAwnser.isValid;
					if (authenticatedStatus === DeviceAuthenticated.eUnknown) {
						await delay(500);
						authenticatedAwnser =
							await faastflexBluetoothCommunicator.checkAuthenticated(
								uniqueIdentifier!!,
							);
						authenticatedStatus = authenticatedAwnser.isValid;
					}
					const isManualPairingCompleted =
						authenticatedStatus === DeviceAuthenticated.eAuthenticated;

					if (
						deviceTypeRef.current ===
						getDeviceTypeDescription(DeviceType.eUnknown)
					) {
						await CheckDeviceType();
					}
					hideActivityIndicator();
					// Set the state
					setMoreInfoDevice({
						deviceMacAddress: deviceMacAddress,
						lastConnected: lastConnected,
						authenticatedStatus: authenticatedStatus,
						isManualPairingCompleted: isManualPairingCompleted,
						deviceType: deviceTypeRef.current,
					});

					if (authenticatedStatus === DeviceAuthenticated.eAuthenticated) {
						const deviceModeResult =
							await faastflexBluetoothCommunicator.GetDeviceMode();
						if (deviceModeResult.deviceMode === DeviceStatus.MAIN_FSM_SERVICE) {
							Alert.alert('Error', t('DeviceServiceModeErrorMsg'));
							await Disconnect(false);
							return;
						}
						await dispatch(
							updateExistingDevice({
								dataSource,
								deviceId: moreInfoDeviceRef.current.deviceId,
								updates: moreInfoDeviceRef.current,
							}),
						);

						await GetDeviceStatus(true);

						await OnPageAppeared();
						hideLoadingIndicator();

						if (!IsDeviceDisconnected.current) {
							Toast.show({
								type: 'success',
								position: 'bottom',
								text2: t('DeviceConnectedText'),
							});
						}
						IsDeviceDisconnected.current = false;

						await dispatch(
							updateExistingDevice({
								dataSource,
								deviceId: moreInfoDeviceRef.current.deviceId,
								updates: moreInfoDeviceRef.current,
							}),
						);

						setPanelImage('PanelConnected.png');
					} else if (
						authenticatedStatus === DeviceAuthenticated.eNotAuthenticated
					) {
						await dispatch(
							updateExistingDevice({
								dataSource,
								deviceId: moreInfoDeviceRef.current.deviceId,
								updates: moreInfoDeviceRef.current,
							}),
						);

						hideLoadingIndicator();
						await SelectManualPairingProcess();
					} else {
						hideLoadingIndicator();
						setShowConnectingModal(false);
						await DisconnectedDevice();
						Toast.show({
							type: 'error',
							position: 'bottom',
							text2: t('DeviceConnectionFailedPleaseRetry'),
						});
					}
				}
			}
		} catch (error) {
			hideLoadingIndicator();
			setShowConnectingModal(false);
			await DisconnectedDevice();
		}
		//TODO Park Divice Instance to maintain the connection
	}
	async function OnDeviceConnectionFailed() {
		try {
			var a = DeviceParking.getParkedDevice('ConnectedPanel');
			const errorMessage = t('EstablishConnectionFailedPleaseRetry');
			hideLoadingIndicator();
			setShowConnectingModal(false);
			if (!isDesconnectFromMenu.current) {
				const answer = await confirmAlert(errorMessage, 'Error', 'ok', 'help');
				if (!answer) {
					Alert.alert(t('titileBleSOP'), t('msgBleSOP'), [{ text: t('ok') }]);
				}
			}
			await DisconnectedDevice();
		} catch (e) {
			console.error('Error in UnableToConnectToDevice:', e);
		}
	}
	//#endregion

	//#region TODO CHECK and clean code

	async function OnBlePeripheralSelected(item: FaastFlexScannedDevice) {
		try {
			if (item) {
				if (
					moreInfoDevice.deviceMacAddress !== AppConstants.NotYetConnected &&
					moreInfoDevice.deviceMacAddress !== item.connectedDevice.address
				) {
					const answer = await confirmAlert(
						t('ConnectWrongDeviceConfirmation'),
						t('Alert'),
						t('Connect_PascalCase'),
						t('Cancel_PascalCase'),
					);

					if (answer) {
						await ConnectToFaastFlexDevice(item.connectedDevice);
					}
				} else {
					// Connect directly if it's the expected device
					await ConnectToFaastFlexDevice(item.connectedDevice);
				}
			}
		} catch (error) {
			console.error('OnBlePeripheralSelected error:', error);
			// Consider implementing error tracking equivalent
		}
	}
	async function ConnectToFaastFlexDevice(device: BluetoothDevice) {
		try {
			// Store the selected device
			setRegisteredFaastFlexDevice(device);

			// Hide device list UI elements
			setShowAvailableDevices(false);
			setShowScannedDevices(false);
			setShowConnectionFailedModal(false);

			// Show connecting modal
			setShowConnectingModal(true);

			await connectToDevice(device);
		} catch (error) {}
	}

	//#endregion

	//#region Initial functions

	async function InitializeAsync() {
		if (
			route.params !== null &&
			route.params !== undefined &&
			route.params.projectId !== null
		) {
			projectId.current = route.params.projectId as number;
		}
		setIsSearchEntryVisible(false);
	}

	async function OnPageAppeared() {
		var a = DeviceParking.getParkedDevice('ConnectedPanel');
		// const status = await requestBluetoothPermissions();
		await GetPermission();
		await handleBluetoothPermissions();
		SetupNativeListenersForBleCommunication();
		//TODO : BLEAdapterStatus Event Subscription logic to be added

		setPanelImage('PanelNotConnected.png');
		_isItemSelected.current = true;

		setFilterFromDate(new Date());
		setFilterToDate(new Date());
		setIsSelfTestChinaEnabled(false);
		setIsItemSelected(true);
		showLoadingIndicator(t('loadingtext'));
		await LoadDataAsync();
		//initializeDeviceFilters(true);
		resetAllFilters();
	}

	async function handleBluetoothPermissions() {
		const isEnabled = await CheckBluetoothTurnedOn();
		if (!isEnabled) {
			// await turnOnBluetooth();
			//return;
		}
		await GetPermission();
		const status = await requestBluetoothPermissions();

		if (status === 'granted') {
			return;
		} else if (status === 'denied') {
			await GetPermission();
		} else if (status === 'never_ask_again') {
			// Show alert to guide user to settings
			Alert.alert(
				t('EnableBluetooth'),
				t('Please enable Bluetooth permissions in settings.'),
				[
					{ text: t('cancel'), style: 'cancel' },
					{
						text: t('EnableUpperCase'),
						onPress: () => OpenSettings(),
					},
				],
				{ cancelable: false },
			);
		}
	}

	async function OpenSettings(isBluetooth: boolean = true) {
		try {
			if (Platform.OS === 'android') {
				Linking.openSettings();
				return;
			} else if (Platform.OS === 'ios') {
				if (!isBluetooth) {
					Linking.openSettings();
				} else {
					const url = 'App-Prefs:root=Bluetooth';
					const supported = await Linking.canOpenURL(url);
					if (supported) {
						await Linking.openURL(url);
					}
				}

				return;
			}
		} catch (error) {}
	}

	async function SetupNativeListenersForBleCommunication() {
		eventListenerCleanUp();
		// Store the unsubscribe function
		const unsubscribe = eventHandler.subscribe('BLEAdapterStatus', status => {
			handleBluetoothConnectionChanges(status);
		});
		bleAdapterStatusUnsubscribe.current = unsubscribe;
		// Return it so it can be called later if needed
		return unsubscribe;
	}
	async function eventListenerCleanUp() {
		// If you have a stored unsubscribe function, call it here
		if (bleAdapterStatusUnsubscribe.current) {
			bleAdapterStatusUnsubscribe.current();
			bleAdapterStatusUnsubscribe.current = null;
		}
	}
	async function handleBluetoothConnectionChanges(event: any) {
		try {
			if (event != null && event.toString() != '') {
				const status = event.toString();
				if (status === 'TurnedOff' || status === 'NotResponding') {
					if (status === 'TurnedOff') {
						showLoadingIndicator('DeviceDisconnected');
						ConnectedDeviceobj.current = null;
					}
					if (moreInfoDevice !== null) {
						const isDeviceConnected = false;
						const deviceStatus = DeviceStatus.UNKNOWN;
						const deviceStatusStr = t(
							getDeviceStatusDescription(DeviceStatus.UNKNOWN),
						);
						const deviceState = DeviceState.eUnknown;
						const deviceStateString = t(
							getDeviceStateDescription(DeviceState.eUnknown),
						);
						const deviceConfig = Configuration.Unknown;
						const deviceConfigString = t(
							getConfigurationDescription(Configuration.Unknown),
						);
						const relayEnabled = RelayEnabled.Unknown;
						const relayEnabledStr = t(
							getRelayEnabledDescription(RelayEnabled.Unknown),
						);
						const deviceType = getDeviceTypeDescription(DeviceType.eUnknown);
						deviceTypeRef.current = deviceType;
						setMoreInfoDevice({
							...moreInfoDevice,
							isDeviceConnected: isDeviceConnected,
							deviceStatus: deviceStatus,
							deviceStatusStr: deviceStatusStr,
							deviceState: deviceState,
							deviceStateString: deviceStateString,
							deviceConfig: deviceConfig,
							deviceConfigStr: deviceConfigString,
							relayEnabled: relayEnabled,
							relayEnabledStr: relayEnabledStr,
							deviceType: deviceType,
						});
					}
					setPanelImage('PanelNotConnected.png');
					await AsyncStorage.clear();
					if (ConnectedDeviceobj.current) {
						await disconnectDevice(ConnectedDeviceobj.current.address);
						ConnectedDeviceobj.current = null;
					}
					if (status === 'NotResponding') {
						hideLoadingIndicator();
						Alert.alert(
							t('DisconnectDevice'),
							t('DeviceNotRespondingErrorMsg'),
							[{ text: t('OK') }],
						);
					}
					//eventListenerCleanUp();
					await LoadDataAsync();
					scanCompletedHandled.current = false;
				} else if (status === 'ScanCompleted') {
					setShowLoader(false);
					if (connectPairedDevice.current && !scanCompletedHandled.current) {
						scanCompletedHandled.current = true;
						CheckAndConnectPairedDevice(connectScannedDevicesRef.current);
					}
				}
			}
			hideLoadingIndicator();
		} catch (error) {
			hideLoadingIndicator();
		}
	}

	async function IsBluetoothEnabled() {
		const isEnabled = await CheckBluetoothTurnedOn();
		if (!isEnabled) {
			await GetPermission();
		}
	}

	function ShowHomePageCommand(validate = true) {
		// Show only the device list
		setShowAddedDevices(true);

		// Hide everything else
		setShowScannedDevices(false);
		setShowLoader(false);
		setShowAcceptPairing(false);
		setShowConnectingLabel(false);
		setShowValidatingSoundLabel(false);
		setShowAcceptWaitingLabel(false);
		setShowSuccessValidatedLabel(false);
		setShowUnableToValidate(false);
		setShowManualPasscode(false);
		setShowManualPairingInstructions(false);
		setShowManualPairingStep1(false);
		setShowManualPairingStep2(false);
		setShowValidatingPWDModal(false);
		setShowPWDValidationSuccessModal(false);
		setShowPWDValidationFailedModal(false);
		setShowSoundPairingInstruction(false);

		// Conditionally load data if validate is true
		if (validate) {
			LoadDataAsync();
		}
	}

	async function LoadDataAsync() {
		hideLoadingIndicator();

		// Fetch devices from database using Redux
		let updatedDevices: DeviceModel[] = [];
		const devicesfromdb = await dispatch(
			fetchDevicesByProjectId({
				dataSource,
				projectId: projectId.current,
			}),
		).unwrap();
		//TODO Temp Check
		console.log('Devices fetched:', devicesfromdb);

		if (devicesfromdb && devicesfromdb.length > 0) {
			updatedDevices = devicesfromdb.map(device => {
				if (
					device.deviceStatusStr === AppConstants.Unknown ||
					device.deviceStateString === AppConstants.Unknown
				) {
					return {
						...device,
						deviceStatusStr: t(device.deviceStatusStr),
						deviceStateString: t(device.deviceStateString),
					};
				}
				return device;
			});
			listOfDevices.current = updatedDevices;
			setFilteredDeviceList(updatedDevices);
			setIsItemSelected(updatedDevices.length > 0);

			if (updatedDevices.length > 0) {
				setIsDeviceAvailable(true);
				if (updatedDevices.length === 1) {
					setDeviceCount(updatedDevices.length + ' ' + t('device'));
				} else {
					setDeviceCount(updatedDevices.length + ' ' + t('devices'));
				}
			} else setIsDeviceAvailable(true);
		} else {
			setIsDeviceAvailable(false);
		}

		const allKeys = await AsyncStorage.getAllKeys();
		if (allKeys.length > 0) {
			const deviceIndex = updatedDevices.findIndex(dev =>
				allKeys.includes(dev.deviceId.toString()),
			);

			if (deviceIndex !== -1) {
				const device = updatedDevices[deviceIndex];
				if (device.deviceMacAddress !== AppConstants.NotYetConnected) {
					const isConnected = await IsConnectionEstablished(
						device.deviceMacAddress,
					);
					// const isConnected = await AsyncStorage.getItem(device.deviceId.toString());
					device.isDeviceConnected = isConnected;
					device.isDeviceExpanded = isConnected;
					if (device.isDeviceConnected) {
						if (ConnectedDeviceobj.current === null) {
							setPanelImage('PanelConnected.png');
							ConnectedDeviceobj.current =
								DeviceParking.getParkedDevice('ConnectedPanel');
						}
						if (ConnectedDeviceobj.current !== null) {
							setPanelImage('PanelConnected.png');
							const deviceStatus_value = await AsyncStorage.getItem(
								'DeviceStatus',
							);
							const deviceState_value = await AsyncStorage.getItem(
								'DeviceState',
							);
							const deviceConfig_value = await AsyncStorage.getItem(
								'DeviceConfig',
							);
							const deviceRelayEnabled_value = await AsyncStorage.getItem(
								'DeviceRelayEnabled',
							);
							if (deviceStatus_value) {
								device.deviceStatus = parseInt(deviceStatus_value);
								device.deviceStatusStr = t(
									getDeviceStatusDescription(device.deviceStatus),
								);
							}
							if (deviceState_value) {
								device.deviceState = parseInt(deviceState_value);
								device.deviceStateString = t(
									getDeviceStateDescription(device.deviceState),
								);
							}
							if (deviceConfig_value) {
								device.deviceConfig = parseInt(deviceConfig_value);
								device.deviceConfigStr = t(
									getConfigurationDescription(device.deviceConfig),
								);
							}
							if (deviceRelayEnabled_value) {
								device.relayEnabled = parseInt(deviceRelayEnabled_value);
								device.relayEnabledStr = t(
									getRelayEnabledDescription(device.relayEnabled),
								);
							}
						}
					}
				}
				listOfDevices.current = updatedDevices;
				setFilteredDeviceList([...updatedDevices]);
			}
		}
	}
	async function initializeDeviceFilters(isInitialize: boolean = false) {}
	//#endregion

	//#region TODO CHECK and clean code

	//#region  Check and clean code for Menu

	const [menu_isMirrorHMIVisible, setMenu_IsMirrorHMIMenuVisible] =
		useState(false);
	const [menu_isDisconnectVisible, setMenu_IsDisconnectVisible] =
		useState(false);
	const [menu_isConnectVisible, setMenu_IsConnectVisible] = useState(false);
	const [menu_isReassignVisible, setMenu_IsReassignVisible] = useState(false);
	const [menu_isPairVisible, setMenu_IsPairVisible] = useState(false);
	const [menu_isAssignVisible, setMenu_IsAssignVisible] = useState(false);
	const [menu_isDeleteVisible, setMenu_IsDeleteVisible] = useState(false);

	async function OnMenupressed(device: DeviceModel) {
		reassignDevice.current = false;
		connectPairedDevice.current = false;
		pairedDeviceFound.current = true;
		setMoreInfoDevice(device);
		const deviceCountryCode =
			stringFunction.isStringNullOrEmpty(device.deviceCountryCode) ||
			device.deviceCountryCode === getCountryDescription(Country.Unknown)
				? DeviceCountry.current
				: device.deviceCountryCode;
		setMoreInfoDevice({ deviceCountryCode: deviceCountryCode });

		setMenu_IsMirrorHMIMenuVisible(
			device.isDeviceConnected &&
				device.deviceStatusStr != AppConstants.Unknown,
		);
		setMenu_IsDisconnectVisible(device.isDeviceConnected);
		setMenu_IsConnectVisible(
			!device.isDeviceConnected &&
				device.deviceMacAddress != AppConstants.NotYetConnected &&
				device.isManualPairingCompleted,
		);
		setMenu_IsPairVisible(
			!device.isDeviceConnected &&
				device.deviceMacAddress != AppConstants.NotYetConnected &&
				!device.isManualPairingCompleted,
		);
		setMenu_IsReassignVisible(
			!device.isDeviceConnected &&
				device.deviceMacAddress != AppConstants.NotYetConnected,
		);
		setMenu_IsAssignVisible(
			!device.isDeviceConnected &&
				device.deviceMacAddress === AppConstants.NotYetConnected,
		);
		setMenu_IsDeleteVisible(!device.isDeviceConnected);
	}

	//#endregion

	async function ExpandCommand(device: DeviceModel) {
		const updatedDeviceList = filteredDeviceList.map(item => {
			if (item.deviceId === device.deviceId) {
				return {
					...item,
					isDeviceExpanded: !item.isDeviceExpanded,
				};
			} else {
				// Make sure other devices are collapsed
				return {
					...item,
					isDeviceExpanded: false,
				};
			}
		});
		setFilteredDeviceList(updatedDeviceList);
		setMoreInfoDevice({ isDeviceExpanded: !device.isDeviceExpanded });
	}
	const handleDeviceModalClose = () => {};

	async function createNewDevice() {
		navigation.navigate(AppConstants.CreateOrEditDeviceScreen, {
			projectId: projectId.current,
			isNewDevice: true,
			isFromProjectHome: false,
		});
	}

	const renderDeviceCard = ({ item }: { item: DeviceModel }) => {
		return (
			<TouchableOpacity
				activeOpacity={0.8}
				style={styles.deviceCardContainer}
				onPress={() => onDeviceSelected(item)}>
				<View style={[styles.cardFrame, { backgroundColor: '#ffffffff' }]}>
					<View style={styles.cardContent}>
						{/* Connection indicator bar */}
						{item.isDeviceConnected && (
							<View style={styles.connectionIndicator} />
						)}

						{/* Header section */}
						<View style={styles.deviceCardheaderSection}>
							<View style={styles.deviceInfoSection}>
								<Text style={styles.deviceNameText}>{item.deviceName}</Text>
								<Text style={styles.locationText}>{item.deviceLocation}</Text>
								<Text style={styles.macAddressText}>
									{item.deviceMacAddress}
								</Text>

								<View style={styles.statusRow}>
									<View style={styles.statusGroup}>
										<Text style={styles.statusLabel}>{t('workingmode')}</Text>
										<Text style={styles.statusValue}>
											{item.deviceStatusStr}
										</Text>
									</View>

									<View style={styles.spacer} />

									<View style={styles.statusGroup}>
										<Text style={styles.statusLabel}>{t('StatusColon')}</Text>
										<View style={styles.stateIconContainer}>
											{getStateIcon(item.deviceState)}
											<Text style={styles.statusValue}>
												{item.deviceStateString}
											</Text>
										</View>
									</View>
								</View>
							</View>

							{/* Buttons */}
							<View style={styles.actionButtons}>
								<TouchableOpacity
									style={styles.expandButton}
									onPress={() => ExpandCommand(item)}>
									<ExpandArrow
										width={20}
										height={20}
										style={
											item.isDeviceExpanded
												? {
														transform: [
															{
																rotate: '180deg',
															},
														],
												  }
												: undefined
										}
									/>
								</TouchableOpacity>

								<Menu renderer={renderers.Popover}>
									<MenuTrigger onPress={() => OnMenupressed(item)}>
										<View
											style={{
												height: 30,
												width: 50,
												justifyContent: 'center',
												alignItems: 'center',
											}}>
											<MoreIcon />
										</View>
									</MenuTrigger>
									<MenuOptions>
										{menu_isMirrorHMIVisible && (
											<MenuOption
												onSelect={OpenMirrorHMI}
												style={{
													backgroundColor: '#F6F6F6',
												}}>
												<View style={styles.popUp}>
													<Text style={styles.popUpText}>{t('MirrorHMI')}</Text>
												</View>
											</MenuOption>
										)}
										{menu_isDisconnectVisible && (
											<MenuOption
												onSelect={() => Disconnect(true)}
												style={{
													backgroundColor: '#F6F6F6',
												}}>
												<View style={styles.popUp}>
													<Text style={styles.popUpText}>
														{t('Disconnect')}
													</Text>
												</View>
											</MenuOption>
										)}
										{menu_isConnectVisible && (
											<MenuOption
												onSelect={() => ConnectPairedDevice(item)}
												style={{
													backgroundColor: '#F6F6F6',
												}}>
												<View style={styles.popUp}>
													<Text style={styles.popUpText}>
														{t('Connect_PascalCase')}
													</Text>
												</View>
											</MenuOption>
										)}
										{menu_isPairVisible && (
											<MenuOption
												onSelect={() => PairDevice(item)}
												style={{
													backgroundColor: '#F6F6F6',
												}}>
												<View style={styles.popUp}>
													<Text style={styles.popUpText}>
														{t('PairDevice')}
													</Text>
												</View>
											</MenuOption>
										)}
										{menu_isReassignVisible && (
											<MenuOption
												onSelect={ReassignDevice}
												style={{
													backgroundColor: '#F6F6F6',
												}}>
												<View style={styles.popUp}>
													<Text style={styles.popUpText}>
														{t('ReassignDevice')}
													</Text>
												</View>
											</MenuOption>
										)}
										{menu_isAssignVisible && (
											<MenuOption
												onSelect={Connect}
												style={{
													backgroundColor: '#F6F6F6',
												}}>
												<View style={styles.popUp}>
													<Text style={styles.popUpText}>
														{t('AssignDevice')}
													</Text>
												</View>
											</MenuOption>
										)}
										<MenuOption
											onSelect={() => EditPanel(item.deviceId)}
											style={{
												backgroundColor: '#F6F6F6',
											}}>
											<View style={styles.popUp}>
												<Text style={styles.popUpText}>{t('editdevice')}</Text>
											</View>
										</MenuOption>
										{menu_isDeleteVisible && (
											<MenuOption
												onSelect={() =>
													DeleteDevice(item.deviceId, item.deviceName)
												}
												style={{
													backgroundColor: '#F6F6F6',
												}}>
												<View style={styles.popUp}>
													<Text style={styles.popUpText}>
														{t('DeleteDevice')}
													</Text>
												</View>
											</MenuOption>
										)}

										{/* Add more options here if needed */}
									</MenuOptions>
								</Menu>
							</View>
						</View>

						{/* Expanded details section */}
						{item.isDeviceExpanded && (
							<View style={styles.expandedSection}>
								<View style={styles.expandedRow}>
									<View style={styles.expandedColumn}>
										<Text style={styles.expandedLabel}>{t('channels')}</Text>
										<Text style={styles.expandedValue}>{item.channels}</Text>
									</View>

									<View style={styles.expandedDivider} />

									<View style={styles.expandedColumn}>
										<Text style={styles.expandedLabel}>{t('PipeConfig')}</Text>
										<Text style={styles.expandedValue}>
											{item.pipeConfiguration}
										</Text>
									</View>

									<View style={styles.expandedDivider} />

									<View style={styles.expandedColumn}>
										<Text style={styles.expandedLabel}>
											{t('TransportTime')}
										</Text>
										<Text style={styles.expandedValue}>
											{item.transportationTime}
										</Text>
									</View>
								</View>

								<View style={styles.expandedSeparator} />

								<View style={styles.expandedRow}>
									<View style={styles.expandedWideColumn}>
										<Text style={styles.expandedLabel}>{t('DisableMode')}</Text>
										<Text style={styles.expandedValue}>
											{item.relayEnabledStr}
										</Text>
									</View>

									<View style={styles.expandedDivider} />

									<View style={styles.expandedWideColumn}>
										<Text style={styles.expandedLabel}>
											{t('ConfigurationMode')}
										</Text>
										<Text style={styles.expandedValue}>
											{item.deviceConfigStr}
										</Text>
									</View>
								</View>

								<View style={styles.expandedSeparator} />

								{item.deviceMacAddress &&
									item.deviceMacAddress !== AppConstants.NotYetConnected && (
										<View style={styles.expandedRow}>
											<View style={styles.expandedWideColumn}>
												<Text style={styles.expandedLabel}>
													{t('lastconnected')}
												</Text>
												<Text style={styles.expandedValue}>
													{item.lastConnectedString}
												</Text>
											</View>
											<View style={styles.expandedWideColumn}>
												<Text style={styles.expandedLabel}>
													{t('DeviceType')}
												</Text>
												<Text style={styles.expandedValue}>
													{item.deviceType}
												</Text>
											</View>
										</View>
									)}
							</View>
						)}
					</View>
				</View>
			</TouchableOpacity>
		);
	};

	const searchEntryClosed = () => {
		setIsSearchEntryVisible(false);
		setSearchQuery('');
	};

	const renderContent = () => {
		const displayDevices = getDisplayDevices();
		return (
			<View style={{ flex: 1 }}>
				{IsSearchEntryVisible && (
					<View style={styles.searchContainer}>
						<View style={styles.searchInputContainer}>
							<TouchableOpacity onPress={() => searchEntryClosed()}>
								<CloseIconGray height={24} width={24} />
							</TouchableOpacity>
							<TextInput
								style={styles.searchInput}
								placeholder='Search...'
								value={searchQuery}
								onChangeText={setSearchQuery}
								clearButtonMode='while-editing'
							/>
						</View>
					</View>
				)}

				{displayDevices?.length > 0 ? (
					<View style={[styles.container]}>
						<Text>{deviceCount}</Text>

						<FlatList
							data={displayDevices}
							renderItem={renderDeviceCard}
							keyExtractor={item => item.deviceId.toString()}
							contentContainerStyle={[
								{ paddingHorizontal: 5, paddingBottom: 10 },
							]}
							showsVerticalScrollIndicator={false}
						/>
					</View>
				) : (
					<>
						<InfoCard
							heading='No Devices Found.'
							description={t('nodeviceslist')}
						/>
						<View style={{ flex: 1 }} />
					</>
				)}
				<SingleButtonFooter
					buttonTextStyle={{ color: '#fff' }}
					buttonStyle={{ margin: 10, backgroundColor: '#1791E4' }}
					onButtonPress={() => createNewDevice()}
					buttonText={t('addnewdevice')}
				/>
			</View>
		);
	};
	//#endregion

	//#region Pair Device
	async function ManualPairing() {
		try {
			if (ConnectedDeviceobj.current !== null) {
				if (
					moreInfoDevice.authenticatedStatus !==
					DeviceAuthenticated.eAuthenticated
				) {
					await SendManualPasswordCommand();
				} else {
					const answer = await confirmAlert(
						t('ManualPairingConfirmation'),
						t('ManualPairing'),
						t('Yes_UpperCase'),
						t('No_UpperCase'),
					);
					if (answer) {
						await SendManualPasswordCommand();
					}
				}
			} else {
				Toast.show({
					type: 'error',
					text1: t('PlsConnectDevice'),
					position: 'bottom',
				});
			}
		} catch (error) {
			hideLoadingIndicator();
		}
	}

	async function SendManualPasswordCommand(retry = false) {
		try {
			if (!retry) {
				showLoadingIndicator(t('GettingManualPairingFromDevice'));
			}

			// Get unique identifier from secure storage
			let uniqueIdentifier = await EncryptedStorage.getItem('UniqueIdentifier');
			uniqueIdentifier = uniqueIdentifier ? uniqueIdentifier : '';
			// Call StarManualConnection to get passcode
			const result = await faastflexBluetoothCommunicator.StarManualConnection(
				uniqueIdentifier,
			);
			const passcode = result?.passcode;

			hideLoadingIndicator();

			if (passcode && passcode !== '') {
				if (passcode === AppConstants.NOT_ALLOWED_FOR_COVER_CLOSED) {
					Alert.alert(t('Error'), t('openCoverAndRetryManualPairing'), [
						{ text: t('ok') },
					]);
				} else {
					// Set state variables for UI updates
					setManualPasscode(passcode);
					setShowManualPairingStep1(false);
					setShowAcceptPairing(true);
					setShowConnectingLabel(false);
					setShowManualPairingStep2(true);

					if (retry) {
						setShowPWDValidationFailedModal(false);
						setShowPreviousPasswordExpired(true);
					}
				}
			} else {
				if (!retry) {
					Toast.show({
						type: 'error',
						text1: t('ManualPairingCommandSentFail'),
						position: 'bottom',
					});
				}
			}
		} catch (error) {
			hideLoadingIndicator();
		}
	}

	async function ValidateManualPairing() {
		setShowPWDValidationFailedModal(false);
		setShowValidatingPWDModal(true);

		await delay(100);

		try {
			// Get unique identifier from secure storage
			let uniqueIdentifier = await EncryptedStorage.getItem('UniqueIdentifier');
			uniqueIdentifier = uniqueIdentifier ? uniqueIdentifier : '';
			// Check if device is authenticated
			const authResult =
				await faastflexBluetoothCommunicator.checkAuthenticated(
					uniqueIdentifier,
				);
			const authenticated = authResult.isValid;

			// Update device authentication status
			setMoreInfoDevice({ authenticatedStatus: authenticated });

			setShowValidatingPWDModal(false);

			if (authenticated === DeviceAuthenticated.eAuthenticated) {
				setMoreInfoDevice({ isManualPairingCompleted: true });

				await dispatch(
					updateExistingDevice({
						dataSource,
						deviceId: moreInfoDeviceRef.current.deviceId,
						updates: moreInfoDeviceRef.current,
					}),
				);

				setShowPWDValidationSuccessModal(true);

				await GetDeviceStatus(false);

				ShowHomePageCommand(false);

				await OnPageAppeared();

				// Set device as responding and update
				const isDeviceResponding = true;
				//TODO: Check if above functions have modified the value of moreInfoDevice
				await dispatch(
					updateExistingDevice({
						dataSource,
						deviceId: moreInfoDevice.deviceId,
						updates: moreInfoDevice,
					}),
				);
			} else if (authenticated === DeviceAuthenticated.eNotAuthenticated) {
				await SendManualPasswordCommand(true);
			} else {
				// Show validation failed modal
				setShowPWDValidationFailedModal(true);
			}
		} catch (error) {
			console.error('Error in ValidateManualPairing:', error);
			setShowValidatingPWDModal(false);
			setShowPWDValidationFailedModal(true);
		}
	}

	//#endregion

	//#region Connect/Disconnect

	async function ReassignDevice() {
		try {
			reassignDevice.current = true;
			setShowAvailableDevices(false);
			await Connect();
		} catch (error) {}
	}
	async function PairDevice(connectItem: DeviceModel) {
		try {
			let isManualPairing = false;
			var AllKeys = await AsyncStorage.getAllKeys();
			if (AllKeys.length > 0) {
				const firstValue = await AsyncStorage.getItem(AllKeys[0]);
				isManualPairing = firstValue === 'true';
			}
			if (isManualPairing) {
				setShowAcceptPairing(true);
				setShowManualPairingStep1(true);
			} else {
				await ConnectPairedDevice(connectItem);
			}
		} catch (error) {}
	}

	async function ConnectPairedDevice(connectItem: DeviceModel) {
		//Disconnect message if already connected
		if (panelImage === 'PanelConnected.png') {
			const answer = await confirmAlert(
				t('DisconnectDeviceConfirmation'),
				t('DisconnectDevice'),
				t('Disconnect'),
				t('cancel'),
			);
			if (answer) {
				if (ConnectedDeviceobj.current) {
					await disconnectDevice(ConnectedDeviceobj.current.address);
					ConnectedDeviceobj.current = null;
				}
			}
			hideLoadingIndicator();
			return;
		}
		if (
			connectItem.deviceMacAddress &&
			connectItem.deviceMacAddress !== '' &&
			connectItem.deviceMacAddress !== AppConstants.NotYetConnected
		) {
			ShowActivityIndicator(t('connectingWithDevice'));
			if (
				ConnectedDeviceobj.current !== null &&
				connectItem.isDeviceConnected
			) {
				await disconnectDevice(ConnectedDeviceobj.current.address);
				await delay(300);
			}
			setShowConnectingModal(true);
			connectPairedDevice.current = true;
			scanCompletedHandled.current = false;
			connectScannedDevicesRef.current = [];
			await scanDevices();
		} else if (connectItem.deviceMacAddress === AppConstants.NotYetConnected) {
			hideActivityIndicator();
			await Connect();
		}
	}
	async function Connect() {
		try {
			if (panelImage === 'PanelNotConnected.png') {
				// setShowConnectingModal(true);
			} else if (panelImage === 'PanelConnected.png') {
				showLoadingIndicator(t('DisconnectingText'));
			} else {
				showLoadingIndicator(t('loadingtext'));
			}

			await ConnectPanelAsync();
		} catch (error) {
			console.error('Error in Connect:', error);
			hideLoadingIndicator();
		}
	}

	async function ConnectPanelAsync() {
		try {
			console.log('listOfDevices.current', listOfDevices.current);
			if (listOfDevices.current && listOfDevices.current.length > 0) {
				if (moreInfoDeviceRef.current === null) {
					setMoreInfoDevice(listOfDevices.current[0]);
				}
				if (panelImage === 'PanelNotConnected.png') {
					if (
						moreInfoDeviceRef.current.deviceMacAddress ===
						AppConstants.NotYetConnected
					) {
						setShowScannedDevices(true);
						setShowLoader(true);
					} else {
						if (reassignDevice.current) {
							setShowScannedDevices(true);
							setShowLoader(true);
						}
					}
					if (ConnectedDeviceobj.current) {
						await disconnectDevice(ConnectedDeviceobj.current.address);
						await delay(300);
					}

					setBlePeripherals([]);
					await scanDevices();
				} else if (panelImage === 'PanelConnected.png') {
					const answer = await confirmAlert(
						t('DisconnectDeviceConfirmation'),
						t('DisconnectDevice'),
						t('Disconnect'),
						t('cancel'),
					);
					if (answer) {
						if (ConnectedDeviceobj.current) {
							await disconnectDevice(ConnectedDeviceobj.current.address);
							ConnectedDeviceobj.current = null;
						}
					}
					hideLoadingIndicator();
				}
			} else {
				hideLoadingIndicator();
				setShowConnectingModal(false);

				Toast.show({
					type: 'error',
					text1: t('AddOfflineDeviceToConnectToDevice'),
					position: 'bottom',
				});
			}
		} catch (error) {
			hideLoadingIndicator();
			setShowConnectingModal(false);
		}
	}

	async function CheckAndConnectPairedDevice(devices: BluetoothDevice[]) {
		try {
			if (connectDeviceMultiCallBlocker.current) {
				return;
			}
			connectDeviceMultiCallBlocker.current = true;
			const pairedDevices = devices.filter(
				device => device.address === moreInfoDeviceRef.current.deviceMacAddress,
			);
			if (pairedDevices.length > 0) {
				await stopDeviceScan();
				await connectToDevice(pairedDevices[0]);
				hideActivityIndicator();
				connectPairedDevice.current = false;
				pairedDeviceFound.current = true;
				scanCompletedHandled.current = false;
				return;
			} else if (devices && devices.length > 0 && pairedDevices.length <= 0) {
				pairedDeviceFound.current = false;
				hideActivityIndicator();
				setShowConnectingModal(false);
				setShowConnectionFailedModal(true);
				scanCompletedHandled.current = false;
			}
		} catch (error) {
			console.error('Error in CheckAndConnectPairedDevice:', error);
		} finally {
			connectDeviceMultiCallBlocker.current = false;
		}
	}

	async function ScannedDevicesSorting(devices: BluetoothDevice[]) {
		try {
			let sortedDevices = blePeripherals;
			if (devices && devices.length > 0) {
				devices.forEach((device, index) => {
					var scannedDevice = new FaastFlexScannedDevice();
					scannedDevice.connectedDevice = device;
					let isDevicePaired = true;
					const lastConnectedOfflineDevice = listOfDevices.current.find(
						x => x.deviceMacAddress === device.address,
					);
					if (lastConnectedOfflineDevice !== null) {
						scannedDevice.lastPairedOfflineDeviceName =
							lastConnectedOfflineDevice?.deviceName
								? lastConnectedOfflineDevice?.deviceName
								: '';
						isDevicePaired = true;
					} else {
						scannedDevice.lastPairedOfflineDeviceName = t('Unknown');
						isDevicePaired = false;
					}
					if (moreInfoDevice.deviceMacAddress === device.address) {
						scannedDevice.isLastConnectedWithSelectedDevice = true;
						if (showAvailableDevices) {
							setRegisteredFaastFlexDevice(device);
							setRegisteredFaastFlexDeviceFound(true);
						} else {
							pairedDeviceFound.current = true;
						}
					}
					if (
						!(
							showAvailableDevices &&
							moreInfoDevice.deviceMacAddress === device.address
						)
					) {
						if (isDevicePaired) {
							scannedDevice.pairingStatus = t('lblPAIRED');
						} else {
							scannedDevice.pairingStatus = t('lblNOTPAIRED');
						}

						const rssi = device.rssi;
						if (rssi >= -30) {
							scannedDevice.signalStrength = 'signalstrength4.png';
						} else if (rssi >= -60) {
							scannedDevice.signalStrength = 'signalstrength3.png';
						} else if (rssi >= -80) {
							scannedDevice.signalStrength = 'signalstrength2.png';
						} else if (rssi >= -100) {
							scannedDevice.signalStrength = 'signalstrength1.png';
						} else {
							scannedDevice.signalStrength = 'signalstrength1.png';
						}
						sortedDevices.push(scannedDevice);
						var tempDevices = sortedDevices.sort(
							(a, b) => b.connectedDevice.rssi - a.connectedDevice.rssi,
						);
						setBlePeripherals(tempDevices);
					}
				});
			}
		} catch (error) {}
	}
	const isDesconnectFromMenu = useRef(false);
	async function Disconnect(fromMenu: boolean = false) {
		try {
			let answer = true;
			IsDeviceDisconnected.current = true;
			if (fromMenu) {
				answer = await confirmAlert(
					t('DisconnectDeviceConfirmation'),
					t('DisconnectDevice'),
					t('Disconnect'),
					t('cancel'),
				);
			}

			if (answer) {
				isDesconnectFromMenu.current = true;
				if (ConnectedDeviceobj.current === null) {
					ConnectedDeviceobj.current =
						DeviceParking.getParkedDevice('ConnectedPanel');
				}
				if (ConnectedDeviceobj.current !== null) {
					showLoadingIndicator(t('DisconnectingText'));
					await disconnectDevice(ConnectedDeviceobj.current.address);
				} else {
					await DisconnectedDevice();
				}
			}
			hideLoadingIndicator();
		} catch (error) {
			hideLoadingIndicator();
		}
	}

	async function DisconnectedDevice() {
		try {
			setPanelImage('PanelNotConnected.png');
			ConnectedDeviceobj.current = null;
			hideLoadingIndicator();
			if (listOfDevices.current && listOfDevices.current.length > 0) {
				const updatedDevices = listOfDevices.current.map(item => {
					if (item.isDeviceConnected) {
						return {
							...item,
							isDeviceConnected: false,
							deviceStatus: DeviceStatus.UNKNOWN,
							deviceStatusStr: DeviceStatus.UNKNOWN.toString(),
							deviceState: DeviceState.eUnknown,
							deviceStateString: getDeviceStateDescription(
								DeviceState.eUnknown,
							),
							deviceConfig: Configuration.Unknown,
							deviceConfigStr: getConfigurationDescription(
								Configuration.Unknown,
							),
							relayEnabled: RelayEnabled.Unknown,
							relayEnabledStr: getRelayEnabledDescription(RelayEnabled.Unknown),
							isDeviceExpanded: false,
							deviceType: getDeviceTypeDescription(DeviceType.eUnknown),
						};
					}
					return item;
				});
				deviceTypeRef.current = getDeviceTypeDescription(DeviceType.eUnknown);
				listOfDevices.current = updatedDevices;
				setFilteredDeviceList(updatedDevices);
			}
			await AsyncStorage.clear();
			//TODO Stop Timer
		} catch (error) {
			hideLoadingIndicator();
		}
		isDesconnectFromMenu.current = false;
	}

	async function ViewAvailableDevicesCommand() {
		setShowConnectionFailedModal(false);
		connectPairedDevice.current = false;
		reassignDevice.current = true;
		ConnectPanelAsync();
	}
	async function RetryConnectionCommand() {
		setShowConnectionFailedModal(false);
		ShowActivityIndicator(t('connectingWithDevice'));
		await Connect();
		hideActivityIndicator();
	}

	//#endregion

	//#region Edit/Delete Device

	async function DeleteDevice(deviceId: number, deviceName: string) {
		try {
			let answer = false;

			if (moreInfoDeviceRef.current.isDeviceConnected) {
				// answer = await confirmAlert(`ConnectedDeviceDeleteConfirmation${moreInfoDeviceRef.current.deviceName}`, 'DeleteDevice', 'delete', 'cancel');
				// if (answer) {
				//   if (ConnectedDeviceobj.current) {
				//     await Disconnect();//TODO: Check
				//   }
				// }
			} else {
				answer = await confirmAlert(
					t('DeviceDeleteConfirmation').replace(
						'{0}',
						moreInfoDeviceRef.current.deviceName,
					),
					t('DeleteDevice'),
					t('delete'),
					t('cancel'),
				);
			}

			if (answer) {
				// Delete device from database through Redux
				await dispatch(
					deleteDeviceWithId({
						dataSource,
						deviceId: moreInfoDeviceRef.current.deviceId,
					}),
				);
				//TODO: Delete Device Parameter data in db

				// Remove any device-specific preferences from storage
				if (
					await AsyncStorage.getItem(
						`AutoRefresh${moreInfoDeviceRef.current.deviceId}`,
					)
				) {
					await AsyncStorage.removeItem(
						`AutoRefresh${moreInfoDeviceRef.current.deviceId}`,
					);
				}

				// Update local state
				if (listOfDevices.current) {
					listOfDevices.current = listOfDevices.current.filter(
						device => device.deviceId !== moreInfoDevice.deviceId,
					);

					if (listOfDevices.current.length === 0) {
						setIsDeviceAvailable(false);
					}
				}
				setFilteredDeviceList(listOfDevices.current);
			}
		} catch (error) {}
	}
	async function EditPanel(deviceId: number) {
		navigation.navigate(AppConstants.CreateOrEditDeviceScreen, {
			device: moreInfoDeviceRef.current,
			projectId: projectId.current,
			isNewDevice: false,
			isFromProjectHome: false,
		});
	}
	//#endregion

	//#region Device Item Selected
	async function onDeviceSelected(item: DeviceModel) {
		if (_isItemSelected.current) {
			try {
				_isItemSelected.current = false;

				if (item.isDeviceConnected) {
					showLoadingIndicator(t('loadingtext'));

					const uniqueIdentifier =
						(await EncryptedStorage.getItem('UniqueIdentifier')) || '';

					const authResult =
						await faastflexBluetoothCommunicator.checkAuthenticated(
							uniqueIdentifier,
						);
					const authenticated = authResult.isValid;

					hideLoadingIndicator();
					if (
						item.deviceStatusStr ===
						t(getDeviceStatusDescription(DeviceStatus.UNKNOWN))
					) {
						_isItemSelected.current = true;
						if (authenticated === DeviceAuthenticated.eNotAuthenticated) {
							const manualPair = await confirmAlert(
								t('msgMannuallypairandtryagain'),
								t('PairDevice'),
								t('PairDevice'),
								t('cancel'),
							);

							if (manualPair) {
								await SelectManualPairingProcess();
							}
						} else {
							Alert.alert(t('warning'), t('msgPleaseTryAgain'), [
								{ text: t('ok') },
							]);
						}
					} else if (authenticated === DeviceAuthenticated.eAuthenticated) {
						_isItemSelected.current = false;
						if (item.deviceStatus === DeviceStatus.UNKNOWN) {
							await GetDeviceStatus();
						}
						navigation.navigate(AppConstants.DeviceDetailsScreen, {
							selectedItem: item,
							connectedDevice: ConnectedDeviceobj.current,
						});
					} else {
						_isItemSelected.current = true;
					}
				} else {
					// Not connected device scenarios
					if (item.deviceMacAddress !== AppConstants.NotYetConnected) {
						_isItemSelected.current = false;
						navigation.navigate(AppConstants.DeviceDetailsScreen, {
							selectedItem: item,
						});
					} else {
						_isItemSelected.current = true;
					}
				}
			} catch (error) {
				_isItemSelected.current = true;
				hideLoadingIndicator();
			}
			_isItemSelected.current = true;
		}
	}

	async function SelectManualPairingProcess() {
		setShowScannedDevices(false);
		setShowLoader(false);
		setShowAcceptPairing(true);
		setShowConnectingLabel(false);
		setShowValidatingSoundLabel(false);
		setShowAcceptWaitingLabel(false);
		setShowSuccessValidatedLabel(false);
		setShowUnableToValidate(false);
		setShowManualPairingStep2(false);
		setShowManualPasscode(false);
		const version = await GetDeviceFirmware();
		const isHigherFirmware = version >= 4;
		if (isHigherFirmware) {
			// Setup for sound pairing
			setShowManualPairingStep1(false);
			setShowSoundPairingInstruction(true);
			setIsSoundPairingStartButtonsVisible(true);
			setIsSoundPairingDoneButtonsVisible(false);
			setSoundPairingText1(t('msgValidateSoundFrom'));
			setSoundPairingText2('');
			setSoundPairingStatusColor('#1792E5');
			setSoundPairingRetryCount(2);
		} else {
			setShowManualPairingInstructions(true);
			setShowManualPairingStep1(true);
			setShowManualPairingStep2(false);
			setShowSoundPairingInstruction(false);
		}
	}

	//#endregion

	//#region Mirror HMI

	async function OpenMirrorHMI() {
		try {
			if (ConnectedDeviceobj.current !== null) {
				showLoadingIndicator(t('GettingDeviceStatus'));
				setIsLedStatusVisible(
					deviceTypeRef.current !==
						getDeviceTypeDescription(DeviceType.eIntelligent),
				);
				const deviceModeResult =
					await faastflexBluetoothCommunicator.GetDeviceMode();
				if (deviceModeResult.deviceMode === DeviceStatus.MAIN_FSM_SERVICE) {
					hideLoadingIndicator();
					Alert.alert(t('Error'), t('DeviceServiceModeErrorMsg'), [
						{ text: t('OK') },
					]);
					return;
				}
				hideLoadingIndicator();
				if (
					moreInfoDevice.authenticatedStatus ===
					DeviceAuthenticated.eAuthenticated
				) {
					if (moreInfoDevice.deviceStatus === DeviceStatus.UNKNOWN) {
						await GetDeviceStatus();
					}
					ShowMirrorHMIDetails();
				} else {
					let uniqueIdentifier = '';
					await EncryptedStorage.getItem('UniqueIdentifier').then(value => {
						if (value) {
							uniqueIdentifier = value;
						}
					});
					const authResult =
						await faastflexBluetoothCommunicator.checkAuthenticated(
							uniqueIdentifier,
						);
					setMoreInfoDevice({
						authenticatedStatus: authResult.isValid,
					});
					if (authResult.isValid == DeviceAuthenticated.eAuthenticated) {
						if (moreInfoDevice.deviceStatus === DeviceStatus.UNKNOWN) {
							await GetDeviceStatus();
						}
						ShowMirrorHMIDetails();
					} else {
						const answer = await confirmAlert(
							t('msgMannuallypairandtryagain'),
							t('PairDevice'),
							t('PairDevice'),
							t('close'),
						);
						if (answer) {
							await ManualPairing();
						}
					}
				}
			} else {
				const answer = await confirmAlert(
					t('PlsConnectDevice'),
					t('connectDevice'),
					t('Connect_PascalCase'),
					t('close'),
				);
				if (answer) {
					await Connect();
				}
			}
		} catch (error) {
			hideLoadingIndicator();
		}
	}

	async function ShowMirrorHMIDetails() {
		const isSelftest = !!(moreInfoDevice.firmwareVersion &&
		moreInfoDevice.firmwareVersion.length > 0
			? parseInt(moreInfoDevice.firmwareVersion.split('.')[0]) >= 4
			: await GetDeviceFirmware());
		setIsSelfTestChinaEnabled(isSelftest);
		setIsMirrorHMIVisible(true);
		hideLoadingIndicator();
	}

	async function GetDeviceFirmware(): Promise<number> {
		let version = 0;
		if (ConnectedDeviceobj.current !== null) {
			const firmwareResult =
				await faastflexBluetoothCommunicator.GetFirmwareVersion();
			const majorVersion =
				firmwareResult.firmwareVersion !== '' &&
				firmwareResult.firmwareVersion.length > 0
					? parseInt(firmwareResult.firmwareVersion.split('.')[0])
					: 0;
			if (majorVersion > 0) {
				setMoreInfoDevice({
					firmwareVersion: firmwareResult.firmwareVersion,
				});
				await dispatch(
					updateExistingDevice({
						dataSource,
						deviceId: moreInfoDeviceRef.current.deviceId,
						updates: {
							firmwareVersion: firmwareResult.firmwareVersion,
						},
					}),
				);
				version = majorVersion;
			}
		}
		return version;
	}

	async function CheckDeviceType() {
		const deviceTypeResult =
			await faastflexBluetoothCommunicator.GetDeviceType();
		if (deviceTypeResult.error === ErrorCode.eOK) {
			deviceTypeRef.current = deviceTypeResult.deviceType;
		}
	}

	async function GetDeviceStatus(showLoader: boolean = false) {
		try {
			if (showLoader) {
				showLoadingIndicator(t('GettingDeviceStatus'));
			}
			let deviceData: FaastFlexDeviceStatus | null = null;
			const version = await GetDeviceFirmware();
			const isHigherFirmware = version >= 4;
			if (
				deviceTypeRef.current === getDeviceTypeDescription(DeviceType.eUnknown)
			) {
				await CheckDeviceType();
				await dispatch(
					updateExistingDevice({
						dataSource,
						deviceId: moreInfoDeviceRef.current.deviceId,
						updates: {
							deviceType: deviceTypeRef.current,
						},
					}),
				);
			}
			if (
				deviceTypeRef.current ===
				getDeviceTypeDescription(DeviceType.eIntelligent)
			) {
				let status22Result =
					await faastflexBluetoothCommunicator.getFFIDeviceStatusData();
				deviceData = status22Result.deviceStatus;
				if (deviceData.Channels === 0) {
					await delay(500);
					status22Result =
						await faastflexBluetoothCommunicator.getFFIDeviceStatusData();
					deviceData = status22Result.deviceStatus;
				}
			} else {
				if (isHigherFirmware) {
					let status22Result =
						await faastflexBluetoothCommunicator.getDeviceStatusData22();
					deviceData = status22Result.deviceStatus;
					console.log('Device Data Channels:', deviceData.Channels);
					if (deviceData.Channels === 0) {
						await delay(500);
						status22Result =
							await faastflexBluetoothCommunicator.getDeviceStatusData22();
						deviceData = status22Result.deviceStatus;
					}
				} else {
					let statusResult =
						await faastflexBluetoothCommunicator.getDeviceStatusData();
					deviceData = statusResult.deviceStatus;
					if (deviceData.Channels === 0) {
						await delay(500);
						statusResult =
							await faastflexBluetoothCommunicator.getDeviceStatusData();
						deviceData = statusResult.deviceStatus;
					}
				}
			}
			const resultAction = await dispatch(
				fetchDeviceById({
					dataSource,
					deviceId: moreInfoDeviceRef.current.deviceId,
				}),
			).unwrap();
			let devicemodelData = resultAction as DeviceModel;
			if (deviceData.Channels !== devicemodelData.channels) {
				const answer = await confirmAlert(
					t('ChannelMismatchConfirmation'),
					t('ChannelIncompatible'),
					t('replace'),
					t('Disconnect'),
				);
				if (answer) {
					devicemodelData.channels = deviceData.Channels;
					await dispatch(
						updateExistingDevice({
							dataSource,
							deviceId: devicemodelData.deviceId,
							updates: devicemodelData,
						}),
					);
				} else {
					Disconnect(false);
					return;
				}
			}
			const deviceStatus = deviceData.DeviceStatus;
			const deviceStatusStr = getDeviceStatusDescription(deviceStatus);
			const countryCode = getCountryDescription(deviceData.Country);
			if (deviceData.Channels > 1) {
				setIsDualChannelDevice(true);
			}
			DeviceCountry.current =
				!countryCode || countryCode === ''
					? getCountryDescription(Country.Unknown)
					: countryCode;
			if (countryCode === getCountryDescription(Country.EU)) {
				setIsDeviceCountryCodeChina(false);
			} else if (countryCode === getCountryDescription(Country.CHINA)) {
				setIsDeviceCountryCodeChina(true);
			}
			let temp_deviceState = DeviceState.eUnknown;
			const ledstatus = deviceData.LEDStatus;
			if (ledstatus != null && ledstatus.length > 1) {
				setAlarmLEDStatus1(ledstatus[0]);
				setPreAlarmLEDStatus1(ledstatus[1]);
				setAlarmLEDStatus2(ledstatus[2]);
				setPreAlarmLEDStatus2(ledstatus[3]);
				setFaultLEDStatus(ledstatus[4]);
				if (isHigherFirmware) {
					setAlertStatus(ledstatus[5]);
				}
				if (ledstatus[0] === Const_ACTIVE || ledstatus[2] === Const_ACTIVE) {
					temp_deviceState = DeviceState.eAlarm;
				} else if (
					ledstatus[1] === Const_ACTIVE ||
					ledstatus[3] === Const_ACTIVE
				) {
					temp_deviceState = DeviceState.eAction;
				} else if (isHigherFirmware && ledstatus[5] === Const_ACTIVE) {
					temp_deviceState = DeviceState.eAlert;
				} else if (ledstatus[4] === Const_ACTIVE) {
					temp_deviceState = DeviceState.eFault;
				} else {
					temp_deviceState = DeviceState.eNormal;
				}
			} else {
				temp_deviceState = DeviceState.eUnknown;
			}
			const deviceStateStr = t(getDeviceStateDescription(temp_deviceState));

			const deviceConfig = deviceData.DeviceConfiguration;
			const deviceConfigStr = t(getConfigurationDescription(deviceConfig));

			const deviceRelayEnabled = deviceData.RelayEnabled;
			const deviceRelayEnabledStr = t(
				getRelayEnabledDescription(deviceRelayEnabled),
			);

			setMoreInfoDevice({
				deviceStatus: deviceStatus,
				deviceStatusStr: deviceStatusStr,
				channels: deviceData.Channels,
				deviceCountryCode: countryCode,
				deviceState: temp_deviceState,
				deviceStateString: deviceStateStr,
				deviceConfig: deviceConfig,
				deviceConfigStr: deviceConfigStr,
				relayEnabled: deviceRelayEnabled,
				relayEnabledStr: deviceRelayEnabledStr,
				deviceType: deviceTypeRef.current,
			});

			await AsyncStorage.removeItem('DeviceStatus');
			await AsyncStorage.removeItem('DeviceState');
			await AsyncStorage.removeItem('DeviceConfig');
			await AsyncStorage.removeItem('DeviceRelayEnabled');

			await AsyncStorage.setItem('DeviceStatus', deviceStatus.toString());
			await AsyncStorage.setItem('DeviceState', temp_deviceState.toString());
			await AsyncStorage.setItem('DeviceConfig', deviceConfig.toString());
			await AsyncStorage.setItem(
				'DeviceRelayEnabled',
				deviceRelayEnabled.toString(),
			);

			hideLoadingIndicator();
		} catch (error) {
			hideLoadingIndicator();
		}
	}

	async function CloseMirrorHMI() {
		setIsMirrorHMIVisible(false);
	}

	async function RefreshDeviceStatusCommand() {
		try {
			if (ConnectedDeviceobj.current !== null) {
				setMirrorHMILoadingIndicator(true);
				setMirrorHMILoadingMessage(t('ReadingDeviceStatus'));
				await GetDeviceStatus();
				setMirrorHMILoadingIndicator(false);
				setMirrorHMILoadingMessage('');
			} else {
				Toast.show({
					type: 'error',
					text1: t('PlsConnectDevice'),
					position: 'bottom',
				});
			}
		} catch (error) {
			setMirrorHMILoadingIndicator(false);
			setMirrorHMILoadingMessage('');
		}
	}
	async function ResetCommand() {
		if (ConnectedDeviceobj.current !== null) {
			var answer = await confirmAlert(
				t('resetconfirmation'),
				t('resetdevice'),
				t('reset'),
				t('cancel'),
			);
			if (answer) {
				setConfigModalVisible(true);
			}
			setIsMirrorHMIVisible(false);
		} else {
			Toast.show({
				type: 'error',
				text1: t('PlsConnectDevice'),
				position: 'bottom',
			});
		}
	}

	async function ResetDeviceCommand() {
		try {
			setMirrorHMILoadingIndicator(true);
			setMirrorHMILoadingMessage(t('ResettingDevice'));
			var resetDeviceResult =
				await faastflexBluetoothCommunicator.ResetDevice();
			setMirrorHMILoadingIndicator(false);
			setMirrorHMILoadingMessage('');

			if (resetDeviceResult.isReset) {
				Toast.show({
					type: 'success',
					text1: t('ResetDeviceCommandSentSuccessfully'),
					position: 'bottom',
				});
			} else {
				Toast.show({
					type: 'error',
					text1: t('ResetDeviceCommandFailed'),
					position: 'bottom',
				});
			}
			IsMirrorHMIResetCommand.current = false;

			setMirrorHMILoadingIndicator(false);
			setMirrorHMILoadingMessage('');
		} catch (error) {
			setMirrorHMILoadingIndicator(false);
			setMirrorHMILoadingMessage('');
		}
	}
	async function ValidateChinaSelfTestCommand() {
		if (ConnectedDeviceobj.current !== null) {
			setIsMirrorHMIVisible(false);
			setConfigModalVisible(true);
			IsSelfTestChina.current = true;
		}
	}
	async function SelfTestCommand() {
		try {
			IsSelfTestChina.current = false;
			if (ConnectedDeviceobj.current !== null) {
				var answer = await confirmAlert(
					t('selftestconfirmation'),
					t('selftestdevice'),
					t('start'),
					t('cancel'),
				);
				if (answer) {
					setMirrorHMILoadingIndicator(true);
					setMirrorHMILoadingMessage(t('InitiatingSelfTest'));
					if (IsDeviceCountryCodeChina) {
						var selftestChinaResult =
							await faastflexBluetoothCommunicator.StartSelfTestForChina();
						setMirrorHMILoadingIndicator(false);
						setMirrorHMILoadingMessage('');
						if (selftestChinaResult.isStarted) {
							Toast.show({
								type: 'success',
								text1: t('SelfTestCommandSentSuccessfully'),
								position: 'bottom',
							});
						} else {
							Toast.show({
								type: 'error',
								text1: t('SelfTestCommandFailed'),
								position: 'bottom',
							});
						}
						setMirrorHMILoadingIndicator(false);
						setMirrorHMILoadingMessage('');
					}
				}
			} else {
				setMirrorHMILoadingIndicator(false);
				setMirrorHMILoadingMessage('');
				Toast.show({
					type: 'error',
					text1: t('PlsConnectDevice'),
					position: 'bottom',
				});
			}
		} catch (error) {
			setMirrorHMILoadingIndicator(false);
			setMirrorHMILoadingMessage('');
		}
	}
	async function SilenceCommand() {
		try {
			if (ConnectedDeviceobj.current !== null) {
				var answer = await confirmAlert(
					t('silenceconfirmation'),
					t('silencedevice'),
					t('silence'),
					t('cancel'),
				);
				if (answer) {
					setMirrorHMILoadingIndicator(true);
					setMirrorHMILoadingMessage(t('SilencingDevice'));
					var silenceResult =
						await faastflexBluetoothCommunicator.SilenceDeviceBuzzerChina();
					setMirrorHMILoadingIndicator(false);
					setMirrorHMILoadingMessage('');
					if (silenceResult.isStarted) {
						Toast.show({
							type: 'success',
							text1: t('SilenceDeviceCommandSentSuccessfully'),
							position: 'bottom',
						});
					} else {
						Toast.show({
							type: 'error',
							text1: t('SilenceDeviceCommandFailed'),
							position: 'bottom',
						});
					}
				}
			} else {
				Toast.show({
					type: 'error',
					text1: t('PlsConnectDevice'),
					position: 'bottom',
				});
			}
		} catch (error) {
			setMirrorHMILoadingIndicator(false);
			setMirrorHMILoadingMessage('');
		}
	}

	const renderMirrorHMI = () => {
		return (
			<Modal
				animationType='slide'
				transparent={true}
				visible={isMirrorHMIVisible}
				onRequestClose={() => {
					setIsMirrorHMIVisible(!isMirrorHMIVisible);
				}}>
				<View style={[styles.mirrorHmiCenteredView]}>
					<View style={[styles.mirrorHmiModalView]}>
						<ScrollView style={{ flexGrow: 1 }}>
							<View
								style={{
									backgroundColor: '#F2F2F2',
									padding: 10,
								}}>
								<View
									style={{
										flexDirection: 'row',
										alignItems: 'center',
										justifyContent: 'space-between',
									}}>
									<Text
										style={[
											styles.mirrorHmiModalText,
											{
												alignItems: 'center',
												fontWeight: 'bold',
											},
										]}>
										{moreInfoDevice.deviceName}
									</Text>
									<TouchableOpacity
										style={styles.mirrorHmiCloseButton}
										onPress={() => setIsMirrorHMIVisible(false)}>
										<CloseIconGray height={20} width={20} />
									</TouchableOpacity>
								</View>

								<Text style={styles.mirrorHmiModalText}>
									{moreInfoDevice.deviceLocation}
								</Text>
								<Text style={styles.mirrorHmiModalText}>
									{moreInfoDevice.deviceMacAddress}
								</Text>

								<View
									style={{
										flexDirection: 'row',
										alignItems: 'center',
										justifyContent: 'flex-start',
									}}>
									<Text style={styles.mirrorHmiInlineText}>
										{t('workingmode')}
									</Text>
									{getStatusIcon(moreInfoDevice.deviceStatus)}
									<Text
										style={[styles.mirrorHmiInlineText, { marginStart: 4 }]}>
										{moreInfoDevice.deviceStatusStr}
									</Text>
								</View>

								<View
									style={{
										flexDirection: 'row',
										alignItems: 'center',
										justifyContent: 'flex-start',
									}}>
									<Text style={styles.mirrorHmiInlineText}>
										{t('DeviceStatusColon')}
									</Text>
									{getStateIcon(moreInfoDevice.deviceState)}
									<Text
										style={[styles.mirrorHmiInlineText, { marginStart: 4 }]}>
										{moreInfoDevice.deviceStateString}
									</Text>
									<TouchableOpacity
										style={styles.mirrorHmiCloseButton}
										onPress={() => RefreshDeviceStatusCommand()}>
										<SyncBlue height={20} width={20} />
									</TouchableOpacity>
								</View>
								<View
									style={{
										paddingBottom: isLedStatusVisible ? 0 : 10,
									}}
								/>
							</View>

							{isLedStatusVisible && (
								<View style={styles.mirrorHmiInfoSection}>
									<Text
										style={[styles.mirrorHmiModalText, { fontWeight: 'bold' }]}>
										{t('ledStatus')}
									</Text>

									<View
										style={{
											flexDirection: 'row',
											alignItems: 'center',
											justifyContent: 'space-between',
											marginVertical: 6,
										}}>
										<Text style={styles.mirrorHmiInlineText}>
											{t('Alarm1')}
										</Text>
										<Text style={styles.mirrorHmiInlineText}>
											{AlarmLEDStatus1}
										</Text>
									</View>
									<View
										style={{
											height: 1,
											backgroundColor: '#E9E9E9',
										}}
									/>

									<View
										style={{
											flexDirection: 'row',
											alignItems: 'center',
											justifyContent: 'space-between',
											marginVertical: 6,
										}}>
										<Text style={styles.mirrorHmiInlineText}>
											{t('Action1')}
										</Text>
										<Text style={styles.mirrorHmiInlineText}>
											{PreAlarmLEDStatus1}
										</Text>
									</View>
									<View
										style={{
											height: 1,
											backgroundColor: '#E9E9E9',
										}}
									/>

									{isDualChannelDevice && (
										<View
											style={{
												flexDirection: 'row',
												alignItems: 'center',
												justifyContent: 'space-between',
												marginVertical: 6,
											}}>
											<Text style={styles.mirrorHmiInlineText}>
												{t('Alarm2')}
											</Text>
											<Text style={styles.mirrorHmiInlineText}>
												{AlarmLEDStatus2}
											</Text>
										</View>
									)}
									{isDualChannelDevice && (
										<View
											style={{
												height: 1,
												backgroundColor: '#E9E9E9',
											}}
										/>
									)}

									{isDualChannelDevice && (
										<View
											style={{
												flexDirection: 'row',
												alignItems: 'center',
												justifyContent: 'space-between',
												marginVertical: 6,
											}}>
											<Text style={styles.mirrorHmiInlineText}>
												{t('Action2')}
											</Text>
											<Text style={styles.mirrorHmiInlineText}>
												{PreAlarmLEDStatus2}
											</Text>
										</View>
									)}
									{isDualChannelDevice && (
										<View
											style={{
												height: 1,
												backgroundColor: '#E9E9E9',
											}}
										/>
									)}

									<View
										style={{
											flexDirection: 'row',
											alignItems: 'center',
											justifyContent: 'space-between',
											marginVertical: 6,
										}}>
										<Text style={styles.mirrorHmiInlineText}>{t('Fault')}</Text>
										<Text style={styles.mirrorHmiInlineText}>
											{FaultLEDStatus}
										</Text>
									</View>

									<View
										style={{
											height: 1,
											backgroundColor: '#E9E9E9',
										}}
									/>
								</View>
							)}
						</ScrollView>
						<View style={styles.mirrorHmiFooter}>
							<TouchableOpacity
								style={[
									styles.mirrorHmiFooterButton,
									styles.mirrorHmiFooterButtonDark,
								]}
								onPress={() => ResetCommand()}>
								<View style={styles.mirrorHmiFooterButtonContent}>
									<ResetWhite width={20} height={20} />
									<Text style={styles.mirrorHmiFooterButtonText}>
										{t('reset')}
									</Text>
								</View>
							</TouchableOpacity>

							{IsDeviceCountryCodeChina && (
								<>
									{IsSelfTestChinaEnabled && (
										<TouchableOpacity
											style={[
												styles.mirrorHmiFooterButton,
												styles.mirrorHmiFooterButtonDarker,
											]}
											onPress={() => ValidateChinaSelfTestCommand()}>
											<View style={styles.mirrorHmiFooterButtonContent}>
												<Log width={16} height={16} />
												<Text style={styles.mirrorHmiFooterButtonText}>
													{t('selfTest')}
												</Text>
											</View>
										</TouchableOpacity>
									)}
									<TouchableOpacity
										style={[
											styles.mirrorHmiFooterButton,
											styles.mirrorHmiFooterButtonDark,
										]}
										onPress={() => SilenceCommand()}>
										<View style={styles.mirrorHmiFooterButtonContent}>
											<Silenced width={16} height={16} />
											<Text style={styles.mirrorHmiFooterButtonText}>
												{t('silence')}
											</Text>
										</View>
									</TouchableOpacity>
								</>
							)}
						</View>
					</View>

					<ModalLoadingIndicator
						visible={mirrorHMILoadingIndicator}
						message={mirrorHMILoadingMessage}></ModalLoadingIndicator>
				</View>
			</Modal>
		);
	};
	//#endregion

	//#region Password Modal Handle

	async function ValidateL3PasscodeAsync() {
		var passcode = passwordValues.join('');
		if (passcode.length < 6) {
			Alert.alert(t('password'), t('PWDLengthErrorMessage'), [
				{ text: t('ok') },
			]);
		} else {
			if (ConnectedDeviceobj.current !== null) {
				showLoadingIndicator(t('ValidatingPassword'));
				var pwdResult =
					await faastflexBluetoothCommunicator.SendFaastflexDevicePassword(
						passcode,
					);
				hideLoadingIndicator();
				if (pwdResult.passwordValid === PasswordValid.eValid) {
					setConfigModalVisible(false);
					Toast.show({
						type: 'success',
						text1: t('PasswordAuthenticated'),
						position: 'bottom',
					});

					if (IsSelfTestChina.current) {
						SelfTestCommand();
					} else {
						ResetDeviceCommand();
					}
				} else if (pwdResult.passwordValid === PasswordValid.ePasswordDelay) {
					setConfigModalVisible(false);
					passcode = '';
					Toast.show({
						type: 'error',
						text1: t('PasswordDelayErrorMsg'),
						position: 'bottom',
					});
				} else {
					setConfigModalVisible(false);
					passcode = '';
					Toast.show({
						type: 'error',
						text1: t('PlsEnterCorrectPWD'),
						position: 'bottom',
					});
				}
				setPasswordValues(['', '', '', '', '', '']);
			} else {
				setConfigModalVisible(false);
				passcode = '';
				Toast.show({
					type: 'error',
					text1: t('PlsConnectDevice'),
					position: 'bottom',
				});
			}
			passcode = '';
			setPasswordValues(['', '', '', '', '', '']);
		}
	}
	async function CancelPasswordCommandasync() {
		setConfigModalVisible(false);
		setPasswordValues(['', '', '', '', '', '']);
		IsMirrorHMIResetCommand.current = false;
		IsSelfTestChina.current = false;
	}

	function ConfigureDeviceParamterCommand() {
		IsConfigurePage.current = true;
		if (moreInfoDevice?.deviceStatusStr === t('Unknown')) {
			setConfigModalVisible(false);
			navigation.navigate(AppConstants.DeviceParameterScreen);
		} else {
			setConfigModalVisible(true);
		}
	}

	function PerformDeviceTestCommand() {
		setConfigModalVisible(true);
		IsConfigurePage.current = false;
	}

	const handleConfigOption = (option: boolean) => {
		if (option) {
			ValidateL3PasscodeAsync();
		} else {
			CancelPasswordCommandasync();
		}
	};
	const handlePasswordChangeText = (text: string, index: number): void => {
		// Only allow numeric input
		if (!/^\d*$/.test(text)) return;

		// Create a new values array
		const newValues = [...passwordValues];
		newValues[index] = text.slice(0, 1); // Take only first digit
		setPasswordValues(newValues);

		// If a digit was entered and there's a next input, focus it
		if (text && index < 5 && passwordInputRefs.current[index + 1]) {
			passwordInputRefs.current[index + 1]?.focus();
		}
	};

	const handlePasswordKeyPress = (e: any, index: number): void => {
		// Handle backspace
		if (e.nativeEvent.key === 'Backspace') {
			// Clear current value if it exists
			if (passwordValues[index]) {
				const newValues = [...passwordValues];
				newValues[index] = '';
				setPasswordValues(newValues);
				return;
			}

			// If current box is empty and not the first box, move focus left
			if (index > 0 && passwordInputRefs.current[index - 1]) {
				// Create a new values array and clear the previous value
				const newValues = [...passwordValues];
				newValues[index - 1] = '';
				setPasswordValues(newValues);

				// Move focus to previous input
				passwordInputRefs.current[index - 1]?.focus();
			}
		}
	};

	const renderConfigModal = () => {
		return (
			<Modal
				animationType='fade'
				transparent={true}
				visible={configModalVisible}
				onRequestClose={() => setConfigModalVisible(false)}>
				<View style={styles.modalOverlay}>
					<View style={styles.modalContainer}>
						<View style={styles.modalContent}>
							<Text style={styles.modalTitle}>{t('EnterPassword')}</Text>
							<Text style={styles.modalDescription}>
								{t('UnlockConfigPwd')}
							</Text>

							<View style={styles.inputContainer}>
								{[0, 1, 2, 3, 4, 5].map(index => (
									<TextInput
										key={index}
										ref={(ref: TextInput | null) =>
											(passwordInputRefs.current[index] = ref)
										}
										style={styles.inputBox}
										value={passwordValues[index]}
										onChangeText={text => handlePasswordChangeText(text, index)}
										onKeyPress={e => handlePasswordKeyPress(e, index)}
										onFocus={() => {
											// If user tries to focus on a box that shouldn't be active, redirect to correct box
											if (index > 0) {
												const hasAllPreviousFilled = passwordValues
													.slice(0, index)
													.every(value => value !== '');
												if (!hasAllPreviousFilled) {
													const nextEmptyIndex = passwordValues.findIndex(
														value => value === '',
													);
													if (
														nextEmptyIndex >= 0 &&
														nextEmptyIndex < index &&
														passwordInputRefs.current[nextEmptyIndex]
													) {
														passwordInputRefs.current[nextEmptyIndex]?.focus();
													}
												}
											}
										}}
										keyboardType='numeric'
										maxLength={1}
										selectTextOnFocus
										secureTextEntry
									/>
								))}
							</View>
							<Text style={styles.modalDescription}>
								{t('block3attemptsMsg')}
							</Text>
							<View style={styles.modalButtons}>
								<View style={{ flex: 1, marginHorizontal: 5 }}>
									<Button
										title={t('cancel')}
										onPress={() => handleConfigOption(false)}
										color='#1792E5'
									/>
								</View>

								<View style={{ flex: 1, marginHorizontal: 5 }}>
									<Button
										title={t('ok')}
										onPress={() => handleConfigOption(true)}
										color='#1792E5'
									/>
								</View>
							</View>
						</View>
					</View>
				</View>
			</Modal>
		);
	};
	//#endregion

	//#region Manual pairing Modal
	function handleManualPairingBackPress() {
		ShowHomePageCommand();
	}

	const manualPairingModal = () => {
		return (
			<Modal
				animationType='fade'
				visible={showManualPairingInstructions}
				onRequestClose={() => setShowManualPairingInstructions(false)}>
				<View
					style={{
						flex: 1,
						flexDirection: 'column',
						backgroundColor: '#fff',
					}}>
					{/*Header*/}
					<SafeAreaView>
						<View
							style={[
								styles.headerSection,
								{
									height: 56,
									backgroundColor: '#000',
									alignItems: 'center',
								},
							]}>
							<View
								style={{
									flexDirection: 'row',
									alignItems: 'center',
									paddingHorizontal: 10,
									height: '100%',
									backgroundColor: '#000',
								}}>
								<TouchableOpacity
									onPress={() => handleManualPairingBackPress()}
									style={{
										height: '100%',
										padding: 0,
										margin: 0,
										justifyContent: 'center',
									}}>
									<LeftArrowWhite height={30} width={30} />
								</TouchableOpacity>

								<View style={[{ flex: 2 }]}>
									<Text
										style={{
											color: '#fff',
											fontSize: 18,
											fontWeight: 'bold',
											textAlign: 'center',
										}}>
										{t('PairDevice')}
									</Text>
								</View>
							</View>
						</View>
					</SafeAreaView>
					{/*Step:1 Manual Pairing*/}
					{showManualPairingStep1 && (
						<View style={{ flex: 1, flexDirection: 'column' }}>
							{/*Content*/}
							<View style={{ flex: 1, padding: 0 }}>
								<ScrollView style={{ flex: 1 }}>
									<View style={{ padding: 0 }}>
										<View
											style={{
												alignItems: 'flex-start',
												marginBottom: 20,
												padding: 10,
											}}>
											<Text
												style={{
													fontSize: 16,
													color: '#3D3D3D',
													marginBottom: 10,
												}}>
												{t('Step1RemoveDeviceCover')}
											</Text>
										</View>

										<View
											style={{
												backgroundColor: '#ffffff',
												padding: 15,
												alignItems: 'center',
												marginVertical: 10,
											}}>
											<Text
												style={{
													fontSize: 17,
													color: '#3D3D3D',
													textAlign: 'center',
												}}>
												{t('PleaseRemoveDeviceCoverOf')}
											</Text>
											<Text
												style={{
													fontSize: 18,
													color: '#3D3D3D',
													textAlign: 'center',
												}}>
												<Text>"</Text>
												<Text>{moreInfoDevice.deviceName}</Text>
												<Text>" </Text>
												<Text>{t('device')}</Text>
											</Text>
											<Text
												style={{
													fontSize: 17,
													color: '#3D3D3D',
													textAlign: 'center',
												}}>
												{t('toEnterThePassword')}
											</Text>
										</View>

										<View style={{ padding: 10, flex: 1 }}>
											<Text
												style={{
													fontSize: 17,
													fontWeight: 'bold',
													color: '#3D3D3D',
													marginBottom: 10,
												}}>
												{t('Instructions')}
											</Text>
											<Text
												style={{
													fontSize: 15,
													color: '#3D3D3D',
													marginTop: 10,
												}}>
												{t('Step1InstructionsA')}
											</Text>
											<Text
												style={{
													fontSize: 15,
													color: '#3D3D3D',
													marginTop: 10,
												}}>
												{t('Step1InstructionsB')}
											</Text>
											<ManualPairingInstruction1 />
										</View>
									</View>
								</ScrollView>
							</View>

							{/* Footer with Next button */}
							<View style={styles.mp_footerContainer}>
								<TouchableOpacity
									style={styles.mp_nextButton}
									onPress={() => {
										SendManualPasswordCommand();
									}}>
									<Text style={styles.mp_nextButtonText}>
										{t('Next_UpperCase')}
									</Text>
								</TouchableOpacity>
							</View>
						</View>
					)}
					{/*Step:2 Manual Pairing*/}
					{showManualPairingStep2 && (
						<View style={{ flex: 1, flexDirection: 'column' }}>
							{/*Content*/}
							<View style={{ flex: 1, padding: 0 }}>
								<ScrollView style={{ flex: 1 }}>
									<View style={{ padding: 10 }}>
										{/* Step 2 Header */}
										<View style={{ marginBottom: 10 }}>
											<Text
												style={{
													fontSize: 16,
													color: '#3D3D3D',
												}}>
												{'Step2EnterPassword'}
											</Text>
										</View>

										{/* Passcode Display Area */}
										<View
											style={{
												padding: 30,
												backgroundColor: '#ffffff',
												alignItems: 'center',
												marginVertical: 10,
											}}>
											{!showPreviousPasswordExpired ? (
												<Text
													style={{
														fontSize: 17,
														color: '#3D3D3D',
														textAlign: 'center',
													}}>
													{t('EnterBelowPasscodeAndValidate')}
												</Text>
											) : (
												<Text
													style={{
														fontSize: 17,
														color: '#3D3D3D',
														textAlign: 'center',
													}}>
													{t('PreviousPasswordExpired')}
												</Text>
											)}

											<Text
												style={{
													fontSize: 30,
													textAlign: 'center',
													marginTop: 10,
												}}>
												{manualPasscode}
											</Text>
										</View>

										{/* Instructions */}
										<View style={{ marginTop: 10 }}>
											<Text
												style={{
													fontSize: 16,
													fontStyle: 'italic',
													color: '#3D3D3D',
												}}>
												{t('PasswordEntryNote')}
											</Text>

											<Text
												style={{
													fontSize: 17,
													fontWeight: 'bold',
													color: '#3D3D3D',
													marginTop: 10,
												}}>
												{t('Instructions')}
											</Text>

											<Text
												style={{
													fontSize: 15,
													color: '#3D3D3D',
													marginTop: 10,
												}}>
												{t('Step2InstructionsA')}
											</Text>
											<Text
												style={{
													fontSize: 15,
													color: '#3D3D3D',
													marginTop: 10,
												}}>
												{t('Step2InstructionsB')}
											</Text>
											<Text
												style={{
													fontSize: 15,
													color: '#3D3D3D',
													marginTop: 10,
												}}>
												{t('Step2InstructionsC')}
											</Text>
											<Text
												style={{
													fontSize: 15,
													color: '#3D3D3D',
													marginTop: 10,
												}}>
												{t('Step2InstructionsD')}
											</Text>
											<Text
												style={{
													fontSize: 15,
													color: '#3D3D3D',
													marginTop: 10,
												}}>
												{t('Step2InstructionsE')}
											</Text>

											<ManualPairingInstruction2 />
										</View>
									</View>
								</ScrollView>
							</View>

							{/* Footer with Next button */}
							<View style={styles.mp_footerContainer}>
								<TouchableOpacity
									style={styles.mp_nextButton}
									onPress={() => {
										ValidateManualPairing();
									}}>
									<Text style={styles.mp_nextButtonText}>
										{t('Validate_UpperCase')}
									</Text>
								</TouchableOpacity>
							</View>
						</View>
					)}
				</View>
			</Modal>
		);
	};
	//#endregion

	//#region Native Sound Recorder Setup

	async function requestMicrophonePermission() {
		if (Platform.OS === 'android') {
			try {
				const granted = await PermissionsAndroid.request(
					PermissionsAndroid.PERMISSIONS.RECORD_AUDIO,
					{
						title: 'Microphone Permission',
						message: 'App needs access to your microphone to record audio',
						buttonNeutral: 'Ask Me Later',
						buttonNegative: 'Cancel',
						buttonPositive: 'OK',
					},
				);
				return granted === PermissionsAndroid.RESULTS.GRANTED;
			} catch (err) {
				console.error('Failed to request microphone permission:', err);
				return false;
			}
		} else if (Platform.OS === 'ios') {
			// try {
			//   const result = await request(PERMISSIONS.IOS.MICROPHONE);
			//   console.log('iOS microphone permission result:', result);
			//   return result === RESULTS.GRANTED;
			// } catch (err) {
			//   console.error('Failed to request microphone permission (iOS):', err);
			//   return false;
			// }
			return true;
		}
		return false; // Default to false for unsupported platforms
	}

	const checkMicrophonePermission = async () => {
		if (Platform.OS === 'ios') {
			return true;
		}
		// const permission = Platform.OS === 'ios' ? PERMISSIONS.IOS.MICROPHONE : PERMISSIONS.ANDROID.RECORD_AUDIO;
		const permission = PERMISSIONS.ANDROID.RECORD_AUDIO;
		try {
			const status = await check(permission);

			if (status === RESULTS.GRANTED) {
				return true;
			}

			if (
				status === RESULTS.DENIED ||
				status === RESULTS.LIMITED ||
				status === RESULTS.UNAVAILABLE
			) {
				try {
					const req = await request(permission);
					return req === RESULTS.GRANTED;
				} catch (e) {
					return false;
				}
			}

			if (status === RESULTS.BLOCKED) {
				return false;
			}

			return false;
		} catch (err) {
			return false;
		}
	};

	const pcmRecording = useRef<boolean>(false);
	async function startRecording(): Promise<number[] | null> {
		try {
			console.log('Requesting microphone permission...', PcmRecorder);

			if (Platform.OS === 'android' && PcmRecorder) {
				console.log('Starting PCM recording using native module (memory)...');
				await PcmRecorder.startPcmRecording();
				pcmRecording.current = true;
				// Return a promise that resolves after 6 seconds and stopRecording
				return new Promise(resolve => {
					setTimeout(async () => {
						if (pcmRecording.current) {
							const digits = await stopRecording();
							resolve(digits);
						} else {
							resolve(null);
						}
					}, 6000);
				});
			} else {
				//TODO: iOS implementation
				return null;
			}
		} catch (error) {
			console.error('Error starting recording:', error);
			return null;
		}
	}
	async function stopRecording(): Promise<number[] | null> {
		if (Platform.OS === 'android' && pcmRecording.current && PcmRecorder) {
			try {
				console.log('Stopping PCM recording using native module (memory)...');
				const result = await PcmRecorder.stopPcmRecording();
				pcmRecording.current = false;
				if (result && result.pcmData && result.sampleRate) {
					// Directly decode the PCM data
					setSoundDecodeLoadingIndicator(true);
					await new Promise(resolve => setTimeout(resolve, 100));
					const digits = await decode(result.sampleRate, result.pcmData);
					setSoundDecodeLoadingIndicator(false);
					return digits;
				} else {
					console.error('No PCM data returned from native module');
					return null;
				}
			} catch (error) {
				setSoundDecodeLoadingIndicator(false);
				console.error('Error stopping PCM recording:', error);
				return null;
			}
		} else if (Platform.OS === 'ios' && pcmRecording.current && PcmRecorder) {
			try {
				console.log('Stopping PCM recording using native module (memory)...');
				const result = await PcmRecorder.stopPcmRecording();
				pcmRecording.current = false;
				if (result && result.pcmData && result.sampleRate) {
					// Directly decode the PCM data
					setSoundDecodeLoadingIndicator(true);
					await new Promise(resolve => setTimeout(resolve, 100));
					const digits = await decode(result.sampleRate, result.pcmData);
					setSoundDecodeLoadingIndicator(false);
					return digits;
				} else {
					console.error('No PCM data returned from native module');
					return null;
				}
			} catch (error) {
				setSoundDecodeLoadingIndicator(false);
				console.error('Error stopping PCM recording:', error);
				return null;
			}
		} else {
			setSoundDecodeLoadingIndicator(false);
			return null;
		}
	}

	/**
	 * Decode the PCM data to extract the password digits, similar to decode_prod in C#
	 * @param {number} sampleRate - Sample rate of the audio
	 * @param {number[]} binaryRawData - Array of PCM float samples
	 * @returns {Promise<number[]|null>} - The decoded password digits or null if not found
	 */
	async function decode(
		sampleRate: number,
		binaryRawData: number[],
	): Promise<number[] | null> {
		try {
			// 1. Get recording time (ms)
			const recordingTimeMs = SoundPairingDecoder.getRecordingTime();

			// 2. Create decoder instance
			const decoder = new SoundPairingDecoder();

			// 3. Prepare digits array (like password in C#)
			const digits = new Array(6).fill(0);
			// 4. Call getDigits (async in JS)
			const error = await decoder.getDigits(
				sampleRate,
				binaryRawData,
				recordingTimeMs,
				digits,
			);

			// 5. Build password string
			const pwd = digits.join('');
			console.log('BeepCapture: Decoded password string:', pwd);

			// 6. Return null if all zeros, else return digits
			if (pwd === '000000') {
				console.log(
					'BeepCapture: Decoded password is all zeros, returning null',
				);
				return null;
			} else {
				console.log('BeepCapture: Decoded password:', pwd);
				return digits;
			}
		} catch (error) {
			console.error('BeepCapture: Error in decode:', error);
			return null;
		}
	}

	//#endregion

	//#region Sound Pairing Modal
	async function GrantMicrophoneAccessCommand() {
		try {
			setIsMicroPhoneAccessRequired(false);
			if (permissionCounter.current <= 1) {
				await requestMicrophonePermission();
			} else {
				await OpenSettings();
				permissionCounter.current = 0;
			}
		} catch (err) {}
	}

	async function TryManualPairingCommand() {
		hideLoadingIndicator();

		// Set UI visibility states
		setShowScannedDevices(false);
		setShowLoader(false);
		setShowAcceptPairing(true);
		setShowConnectingLabel(false);
		setShowValidatingSoundLabel(false);
		setShowAcceptWaitingLabel(false);
		setShowSuccessValidatedLabel(false);
		setShowUnableToValidate(false);
		setShowManualPasscode(false);

		// Show manual pairing step 1
		setShowManualPairingInstructions(true);
		setShowManualPairingStep1(true);
		setShowManualPairingStep2(false);
		setShowSoundPairingInstruction(false);
	}

	function SoundPairingRetryCommand() {
		if (soundPairingRetryCount > 0) {
			setSoundPairingRetryCount(prevCount => prevCount - 1);
			StartSoundPairingCommand();
		}
	}
	async function StartSoundPairingCommand() {
		//TODO: Check Microphone Permission
		let hasPermission = await checkMicrophonePermission();
		if (hasPermission) {
			permissionCounter.current = 0;
			setIsSoundPairingStartButtonsVisible(false);
			setIsSoundPairingRetryButtonsVisible(false);
			setIsSoundPairingDoneButtonsVisible(false);
			setIsMicroPhoneAccessRequired(false);
			setSoundPairingText1(t('msgWaitToAcceptPairing'));
			setSoundPairingText2(t('lblToAcceptPairing'));
			setSoundPairingStatusColor('#1792E5');
			setSoundDecodeLoadingIndicator(false);
			await delay(300);
			await StartSoundPairing();
		} else {
			setIsMicroPhoneAccessRequired(true);
			permissionCounter.current += 1;
		}
	}

	async function StartSoundPairing() {
		try {
			if (ConnectedDeviceobj.current !== null) {
				const uniqueIdentifier =
					(await EncryptedStorage.getItem('UniqueIdentifier')) || '';
				const recordingPromise = new Promise<number[] | null>(resolve => {
					// Start the recording
					if (Platform.OS === 'android' && PcmRecorder) {
						console.log('Starting PCM recording with 10-second timeout...');
						PcmRecorder.startPcmRecording();
						pcmRecording.current = true;

						// Set timeout to stop recording after 10 seconds
						setTimeout(async () => {
							if (pcmRecording.current) {
								console.log('Stopping PCM recording after timeout...');
								const digits = await stopRecording();
								resolve(digits);
							} else {
								resolve(null);
							}
						}, 10000); // 10 seconds timeout
					} else if (Platform.OS === 'ios' && PcmRecorder) {
						console.log('Starting PCM recording with 10-second timeout...');
						PcmRecorder.startPcmRecording();
						pcmRecording.current = true;

						// Set timeout to stop recording after 10 seconds
						setTimeout(async () => {
							if (pcmRecording.current) {
								console.log('Stopping PCM recording after timeout...');
								const digits = await stopRecording();
								resolve(digits);
							} else {
								resolve(null);
							}
						}, 10000);
					} else {
						// iOS implementation would go here
						resolve(null);
					}
				});
				var isStarted =
					await faastflexBluetoothCommunicator.SoundPairingSequence(
						uniqueIdentifier,
					);

				const recordingResult = await recordingPromise;

				if (recordingResult !== null && recordingResult.length === 6) {
					await SendPairingPassword(recordingResult);
				} else {
					Alert.alert(t('lblNOTE'), t('msgSoundPairFailureInstruction'), [
						{ text: t('ok') },
					]);
					setSoundPairingStatusColor('#ff5252');
					setIsSoundPairingStartButtonsVisible(false);
					setIsSoundPairingDoneButtonsVisible(false);
					setIsSoundPairingRetryButtonsVisible(true);
					setSoundPairingText1(t('lblUnableToValidate'));
					setSoundPairingText2(
						`${t('noteSoundPairingAttemptsLeft')} ${soundPairingRetryCount}`,
					);
					setSoundPairingRetryText(`${t('retry')} (${soundPairingRetryCount})`);
				}
			}
		} catch (error) {}
	}

	async function SendPairingPassword(passcode: number[]) {
		try {
			if (ConnectedDeviceobj.current !== null) {
				// Call the FaastFlex communicator to send the decoded password digits
				const authResult =
					await faastflexBluetoothCommunicator.StartDecodedPwdDigits(
						passcode[0],
						passcode[1],
						passcode[2],
						passcode[3],
						passcode[4],
						passcode[5],
					);

				// Check if authentication was successful
				if (authResult.isAuthenticated === DeviceAuthenticated.eAuthenticated) {
					// Update device information
					setMoreInfoDevice({ isManualPairingCompleted: true });
					// Update the device in the database
					await dispatch(
						updateExistingDevice({
							dataSource,
							deviceId: moreInfoDeviceRef.current.deviceId,
							updates: moreInfoDeviceRef.current,
						}),
					);
					await delay(500);
					// Update sound pairing UI states
					setSoundPairingStatusColor('#0aca91');
					setIsSoundPairingStartButtonsVisible(false);
					setIsSoundPairingRetryButtonsVisible(false);
					setIsSoundPairingDoneButtonsVisible(true);
				} else {
					setSoundPairingStatusColor('#ff5252');
					setIsSoundPairingStartButtonsVisible(false);
					setIsSoundPairingDoneButtonsVisible(false);
					setIsSoundPairingRetryButtonsVisible(true);
					setSoundPairingText1(t('lblUnableToValidate'));
					setSoundPairingText2(
						`${t('noteSoundPairingAttemptsLeft')} ${soundPairingRetryCount}`,
					);
					setSoundPairingRetryText(`${t('retry')} (${soundPairingRetryCount})`);
				}
			} else {
				Toast.show({
					type: 'error',
					text1: t('lblPlsConnectDevice'),
					position: 'bottom',
				});
			}
		} catch (error) {}
	}

	let isHomepageLoaded = true;
	async function SoundPairingCompletedCommand() {
		if (!isHomepageLoaded) {
			return;
		}
		isHomepageLoaded = false;
		await GetDeviceStatus(false);
		ShowHomePageCommand(false);
		await OnPageAppeared();
	}

	function handleSoundPairingBackPress() {
		ShowHomePageCommand();
	}

	const soundPairingModal = () => {
		return (
			<Modal
				animationType='fade'
				visible={showSoundPairingInstruction}
				onRequestClose={() => setShowSoundPairingInstruction(false)}>
				<View style={{ flex: 1, flexDirection: 'column' }}>
					{/*Header*/}
					<SafeAreaView>
						<View
							style={[
								styles.headerSection,
								{
									height: 56,
									backgroundColor: '#000',
									alignItems: 'center',
								},
							]}>
							<View
								style={{
									flexDirection: 'row',
									alignItems: 'center',
									paddingHorizontal: 10,
									height: '100%',
									backgroundColor: '#000',
								}}>
								<TouchableOpacity
									onPress={() => handleSoundPairingBackPress()}
									style={{
										padding: 0,
										margin: 0,
										justifyContent: 'center',
									}}>
									<LeftArrowWhite height={30} width={30} />
								</TouchableOpacity>
								<View style={[{ flex: 2 }]}>
									<Text
										style={{
											color: '#fff',
											fontSize: 18,
											fontWeight: 'bold',
											textAlign: 'center',
										}}>
										{t('PairDevice')}
									</Text>
								</View>
							</View>
						</View>
					</SafeAreaView>
					<View style={{ backgroundColor: '#ffffff' }}>
						<View
							style={{
								height: 6,
								backgroundColor: soundPairingStatusColor,
							}}
						/>
						<View
							style={{
								padding: 20,
								alignItems: 'center',
								justifyContent: 'center',
							}}>
							<Text
								style={{
									marginTop: 30,
									marginBottom: 10,
									fontSize: 17,
									color: '#3D3D3D',
									textAlign: 'center',
								}}>
								{soundPairingText1}
							</Text>
							<Text
								style={{
									fontSize: 18,
									fontWeight: 'bold',
									color: '#3D3D3D',
									textAlign: 'center',
								}}>
								"{moreInfoDevice?.deviceMacAddress}"
							</Text>
							<Text
								style={{
									fontSize: 17,
									color: '#3D3D3D',
									textAlign: 'center',
								}}>
								{soundPairingText2}
							</Text>
						</View>
					</View>
					<ScrollView style={{ flex: 1 }}>
						<View style={{ alignItems: 'center', padding: 20 }}>
							<Text
								style={{
									fontSize: 15,
									color: '#3D3D3D',
									textAlign: 'center',
									marginBottom: 50,
								}}>
								{t('msgKeepMobileCloseToDevice')}
							</Text>
							<SoundPairing height={400} width={400} />
						</View>
					</ScrollView>

					<View style={{ padding: 20 }}>
						{/* Retry buttons */}
						{isSoundPairingRetryButtonsVisible && (
							<View style={{ flexDirection: 'row' }}>
								<TouchableOpacity
									style={[
										styles.mp_nextButton,
										{
											flex: 1,
											marginRight: 5,
											backgroundColor: '#1792E5',
											opacity: soundPairingRetryCount > 0 ? 1 : 0.5,
										},
									]}
									onPress={SoundPairingRetryCommand}
									disabled={soundPairingRetryCount <= 0}>
									<Text style={styles.mp_nextButtonText}>
										{SoundPairingRetryText}
									</Text>
								</TouchableOpacity>
								<TouchableOpacity
									style={[styles.mp_nextButton, { flex: 1, marginLeft: 5 }]}
									onPress={TryManualPairingCommand}>
									<Text style={styles.mp_nextButtonText}>
										{t('pairManually')}
									</Text>
								</TouchableOpacity>
							</View>
						)}

						{/* Start button */}
						{isSoundPairingStartButtonsVisible && (
							<TouchableOpacity
								style={styles.mp_nextButton}
								onPress={StartSoundPairingCommand}>
								<Text style={styles.mp_nextButtonText}>{t('lblInitiate')}</Text>
							</TouchableOpacity>
						)}

						{/* Done button */}
						{isSoundPairingDoneButtonsVisible && (
							<TouchableOpacity
								style={styles.mp_nextButton}
								onPress={SoundPairingCompletedCommand}>
								<Text style={styles.mp_nextButtonText}>{t('done')}</Text>
							</TouchableOpacity>
						)}
					</View>

					{isMicroPhoneAccessRequired && (
						<View
							style={{
								position: 'absolute',
								top: 0,
								left: 0,
								right: 0,
								bottom: 0,
								backgroundColor: 'rgba(0,0,0,0.4)',
								justifyContent: 'center',
								alignItems: 'center',
							}}>
							<View
								style={{
									width: '80%',
									backgroundColor: 'white',
									padding: 20,
									borderRadius: 5,
									alignItems: 'center',
								}}>
								<Mic width={40} height={40} />
								<Text
									style={{
										fontSize: 18,
										fontWeight: 'bold',
										color: '#3D3D3D',
										textAlign: 'center',
										marginBottom: 10,
									}}>
									{t('txtMicrophoneAccessRequired')}
								</Text>
								<Text
									style={{
										fontSize: 16,
										color: '#666',
										textAlign: 'center',
										marginBottom: 20,
									}}>
									{t('msgMicrophoneAccess')}
								</Text>
								<TouchableOpacity
									style={styles.mp_nextButton}
									onPress={GrantMicrophoneAccessCommand}>
									<Text style={styles.mp_nextButtonText}>
										{t('btnGrantAccess')}
									</Text>
								</TouchableOpacity>
							</View>
						</View>
					)}
					<ModalLoadingIndicator
						visible={soundDecodeLoadingIndicator}
						message={t('lblValidating')}></ModalLoadingIndicator>
				</View>
			</Modal>
		);
	};
	//#endregion

	//#region Render Scanned Devices

	function handleBleScanBackPress() {
		hideLoadingIndicator();

		setShowConnectingModal(false);
		setShowScannedDevices(false);
		setShowConnectionFailedModal(false);
		setShowLoader(false);
		setShowAcceptPairing(false);
		setShowConnectingLabel(false);
		setShowValidatingSoundLabel(false);
		setShowAcceptWaitingLabel(false);
		setShowSuccessValidatedLabel(false);
		setShowUnableToValidate(false);

		setShowManualPasscode(false);
		setShowManualPairingInstructions(false);
		setShowManualPairingStep1(false);
		setShowManualPairingStep2(false);
		setShowValidatingPWDModal(false);
		setShowPWDValidationSuccessModal(false);
		setShowPWDValidationFailedModal(false);
		setShowSoundPairingInstruction(false);

		setShowAddedDevices(true);
	}

	function getSignalStrengthIcon(signalStrength: string): ReactElement {
		switch (signalStrength) {
			case 'signalstrength4.png':
				return <SignalStrength4 height={24} width={24} />;
			case 'signalstrength3.png':
				return <SignalStrength3 height={24} width={24} />;
			case 'signalstrength2.png':
				return <SignalStrength2 height={24} width={24} />;
			case 'signalstrength1.png':
				return <SignalStrength1 height={24} width={24} />;
			default:
				return <SignalStrength4 height={24} width={24} />;
		}
	}

	const renderScannedDeviceList = ({
		item,
	}: {
		item: FaastFlexScannedDevice;
	}) => (
		<TouchableOpacity
			style={styles.itemContainer}
			onPress={() => OnBlePeripheralSelected(item)}>
			<View style={styles.deviceItemGrid}>
				{/* Signal Strength Column */}
				<View style={styles.signalStrengthContainer}>
					{getSignalStrengthIcon(item.signalStrength)}
				</View>

				{/* Device Info Column */}
				<View style={styles.deviceInfoColumn}>
					{/* Row 1: Device Name + Paired Status */}
					<View style={styles.deviceNameRow}>
						<Text style={styles.deviceNameLabel}>
							{t('DeviceName_PascalCase')}
						</Text>
						<Text style={styles.deviceNameValue}>
							{item.lastPairedOfflineDeviceName}
						</Text>
						<Text style={styles.pairingStatus}>{item.pairingStatus}</Text>
					</View>

					{/* Row 2: MAC Address */}
					<View style={styles.deviceDetailRow}>
						<Text style={styles.deviceDetailText}>
							{t('MAC_Address')}: {item.connectedDevice.address}
						</Text>
					</View>

					{/* Row 3: Device ID + Registered Device indicator */}
					<View style={styles.deviceDetailRow}>
						<Text style={styles.deviceDetailText}>
							{t('ID')}: {item.connectedDevice.name}
						</Text>

						{item.isLastConnectedWithSelectedDevice && (
							<View style={styles.registeredDeviceContainer}>
								<Text style={styles.registeredDeviceText}>
									{t('RegisteredDevice')}
								</Text>
							</View>
						)}
					</View>
				</View>
			</View>
		</TouchableOpacity>
	);
	const renderScannedDevices = () => {
		return (
			<Modal
				animationType='slide'
				transparent={false}
				visible={showScannedDevices}
				onRequestClose={() => setShowScannedDevices(false)}>
				<SafeAreaProvider>
					<View style={{ flex: 1, backgroundColor: '#F6F6F6' }}>
						<SafeAreaView edges={['top']} style={styles.safeHeader}>
							<View
								style={[
									styles.headerSection,
									{
										height: 56,
										backgroundColor: '#000',
										alignItems: 'center',
									},
								]}>
								<View
									style={{
										flexDirection: 'row',
										alignItems: 'center',
										paddingHorizontal: 10,
										height: '100%',
										backgroundColor: '#000',
									}}>
									<TouchableOpacity
										onPress={() => handleBleScanBackPress()}
										style={{
											padding: 0,
											margin: 0,
											justifyContent: 'center',
										}}>
										<LeftArrowWhite height={30} width={30} />
									</TouchableOpacity>
									<View style={[{ flex: 2 }]}>
										<Text
											style={{
												color: '#fff',
												fontSize: 18,
												fontWeight: 'bold',
												textAlign: 'center',
											}}>
											{t('AvailableDevices')}
										</Text>
									</View>
								</View>
							</View>
						</SafeAreaView>

						{showLoader && (
							<>
								<View style={styles.loaderContainer}>
									<ActivityIndicator size='large' color='black' />
									<Text style={styles.loadingText}>Searching Device</Text>
								</View>
							</>
						)}
						<View style={{ paddingHorizontal: 20, paddingVertical: 10 }}>
							<FlatList
								data={blePeripherals}
								renderItem={renderScannedDeviceList}
								keyExtractor={item => item.connectedDevice.address}
								ListHeaderComponent={() => (
									<View style={styles.headerContainer}>
										<Text style={styles.headerText}>Not Paried Devices</Text>
									</View>
								)}
							/>
						</View>
					</View>
				</SafeAreaProvider>
			</Modal>
		);
	};
	//#endregion

	//#region Create Template
	async function CreateTemplate() {
		try {
			navigation.navigate(AppConstants.CreatetemplateModalPopup);
		} catch (error) {}
	}

	const menuOptions: MenuOptionItem[] = [
		{
			label: t('createTemplate'),
			onSelect: () => CreateTemplate(),
		},
	];
	//#endregion

	//#region Render Header
	async function SearchDeviceCommand() {
		setSearchQuery(''); // Clear any existing search query
		setIsSearchEntryVisible(true);
	}
	async function FilterDeviceCommand() {
		setShowFilterModal(true);
	}
	function getPanelImage(image: string): ReactElement {
		if (image === 'PanelConnected.png') {
			return <BluetoothConnected height={30} width={30} />;
		} else if (image === 'PanelNotConnected.png') {
			return <BleutoothWhite height={30} width={30} />;
		} else {
			return <BleutoothWhite height={30} width={30} />;
		}
	}

	function handleBackPress() {
		navigation.goBack();
	}

	const renderHeader = () => {
		return (
			<SafeAreaView edges={['top']} style={styles.safeHeader}>
				<View
					style={[
						styles.headerSection,
						{
							backgroundColor: '#000',
							alignItems: 'center',
						},
					]}>
					<View
						style={{
							flexDirection: 'row',
							alignItems: 'center',
							paddingHorizontal: 10,
							height: '100%',
							backgroundColor: '#000',
						}}>
						<TouchableOpacity
							onPress={() => handleBackPress()}
							style={{
								height: '100%',
								padding: 0,
								margin: 0,
								justifyContent: 'center',
							}}>
							<LeftArrowWhite height={30} width={30} />
						</TouchableOpacity>

						<View style={[{ flex: 2 }]}>
							<Text
								style={{
									color: '#fff',
									fontSize: 18,
									fontWeight: 'bold',
									textAlign: 'center',
								}}>
								{t('faastFlexDetectors')}
							</Text>
						</View>
						<TouchableOpacity onPress={() => Connect()}>
							{getPanelImage(panelImage)}
						</TouchableOpacity>
						<TouchableOpacity
							onPress={() => SearchDeviceCommand()}
							style={{ paddingHorizontal: 8 }}>
							<SearchIconWhite />
						</TouchableOpacity>
						<TouchableOpacity
							onPress={() => FilterDeviceCommand()}
							style={{ paddingHorizontal: 8 }}>
							<FilterWhite height={30} width={30} />
						</TouchableOpacity>

						{/* <TouchableOpacity onPress={showActionSheet} style={{paddingHorizontal: 8}}>
            <MoreIconWhite/>
          </TouchableOpacity> */}
						<View style={{ paddingHorizontal: 8 }}>
							<DropdownMenu
								menuOptions={menuOptions}
								cancelLabel={t('cancel')}
							/>
						</View>
					</View>
				</View>
			</SafeAreaView>
		);
	};
	//#endregion

	//#region Password Validation Failed Modal
	const pwdvalidationFailedModal = () => {
		return (
			<Modal
				animationType='fade'
				transparent={true}
				visible={showPWDValidationFailedModal}
				onRequestClose={() => setShowPWDValidationFailedModal(false)}>
				<View style={styles.modalOverlay}>
					<View style={styles.modalContainer}>
						<View style={[styles.modalContent, { alignItems: 'center' }]}>
							<Fail height={50} width={50} />
							<Text style={styles.modalTitle}>
								{t('PasswordValidationFailed')}
							</Text>

							<View style={styles.modalButtons}>
								<View style={{ flex: 1, marginHorizontal: 5 }}>
									<Button
										title={t('cancel')}
										onPress={() => setShowPWDValidationFailedModal(false)}
										color='#1792E5'
									/>
								</View>

								<View style={{ flex: 1, marginHorizontal: 5 }}>
									<Button
										title={t('Retry_UpperCase')}
										onPress={() => ValidateManualPairing()}
										color='#1792E5'
									/>
								</View>
							</View>
						</View>
					</View>
				</View>
			</Modal>
		);
	};
	//#endregion

	//#region Password Validation Modal
	const pwdvalidationSuccessModal = () => {
		return (
			<Modal
				animationType='fade'
				transparent={true}
				visible={showPWDValidationSuccessModal}
				onRequestClose={() => setShowPWDValidationSuccessModal(false)}>
				<View style={styles.modalOverlay}>
					<View style={styles.modalContainer}>
						<View style={[styles.modalContent, { alignItems: 'center' }]}>
							<Pass height={50} width={50} />
							<View style={styles.modalContent}>
								<Text style={styles.modalTitle}>
									{t('PasswordValidatedSuccessfully')}
								</Text>
								<Text style={styles.modalDescription}>
									{t('NavigatingBackToHomePage')}
								</Text>
							</View>
						</View>
					</View>
				</View>
			</Modal>
		);
	};
	//#endregion

	//#region Filter
	const [filteredDevices, setFilteredDevices] = useState(filteredDeviceList);
	const [filtersApplied, setFiltersApplied] = useState(false);

	const [searchQuery, setSearchQuery] = useState('');

	// Function to get devices to display (combines search and filter)

	const getDisplayDevices = () => {
		let devicesToShow = filtersApplied ? filteredDevices : filteredDeviceList;
		if (searchQuery.trim() !== '') {
			devicesToShow = devicesToShow.filter(device =>
				device.deviceName.toLowerCase().includes(searchQuery.toLowerCase()),
			);
		}
		return devicesToShow;
	};

	useEffect(() => {
		const displayDevices = getDisplayDevices();
		if (displayDevices.length === 1) {
			setDeviceCount(displayDevices.length + ' ' + t('device'));
		} else {
			setDeviceCount(displayDevices.length + ' ' + t('devices'));
		}
	}, [filteredDevices, filteredDeviceList, filtersApplied, searchQuery]);

	// Render Filter Modal Supporting functions
	function handleManualFilterBackPress() {
		console.log('clicking back button');
		setShowFilterModal(false);
	}

	const [channel1, setChannel1] = useState(false);
	const [channel2, setChannel2] = useState(false);

	const [isAddressable, setAddressable] = useState(false);
	const [isStandalone, setStandalone] = useState(false);

	const [pipeConfig, setPipeConfig] = useState<{ [key: string]: boolean }>({
		I: false,
		M: false,
		U: false,
		'2U': false,
	});

	// Date picker states
	const [fromDate, setFromDate] = useState(new Date(2000, 0, 1)); // Default: 01/01/00
	const [toDate, setToDate] = useState(new Date()); // Default: Current date
	const [showFromDatePicker, setShowFromDatePicker] = useState(false);
	const [showToDatePicker, setShowToDatePicker] = useState(false);

	// Helper function to format date as DD/MM/YY
	const formatDate = (date: Date): string => {
		const day = date.getDate().toString().padStart(2, '0');
		const month = (date.getMonth() + 1).toString().padStart(2, '0');
		const year = date.getFullYear().toString().slice(-2);
		return `${day}/${month}/${year}`;
	};

	// Date picker handlers
	const onFromDateChange = (event: any, selectedDate?: Date) => {
		setShowFromDatePicker(Platform.OS === 'ios');
		if (selectedDate) {
			setFromDate(selectedDate);
		}
	};

	const onToDateChange = (event: any, selectedDate?: Date) => {
		setShowToDatePicker(Platform.OS === 'ios');
		if (selectedDate) {
			setToDate(selectedDate);
		}
	};

	const togglePipeConfig = (key: string) => {
		setPipeConfig(prev => ({ ...prev, [key]: !prev[key] }));
	};

	const renderCheckbox = (
		checked: boolean,
		label: string,
		onPress: () => void,
	) => (
		<Pressable style={styles.checkboxContainer} onPress={onPress}>
			{/* <View style={[styles.checkbox, checked && styles.checkedBox]} /> */}

			<View style={styles.wrapper} key={label}>
				<View style={styles.radio}>
					{checked === true ? <View style={styles.radioBG} /> : null}
				</View>
			</View>
			<Text style={styles.checkboxLabel}>{label}</Text>
		</Pressable>
	);

	const cancel = () => {
		console.log('cancelling...');
		// navigation.goBack();
		setShowFilterModal(false);
	};

	// Update the handleProceed function
	const handleProceed = () => {
		console.log('proceeding with filters...');

		let filtered = filteredDeviceList.filter(device => {
			// Check channel filter
			if (channel1 && device.channels !== 1) return false;
			if (channel2 && device.channels !== 2) return false;

			// Check pipe configuration filter
			if (pipeConfig.I && device.pipeConfiguration !== 'I') return false;
			if (pipeConfig.M && device.pipeConfiguration !== 'M') return false;
			if (pipeConfig.U && device.pipeConfiguration !== 'U') return false;
			if (pipeConfig['2U'] && device.pipeConfiguration !== '2U') return false;

			// Check date filter
			if (device.lastConnected) {
				const deviceDate = new Date(device.lastConnected);
				if (deviceDate < fromDate || deviceDate > toDate) return false;
			}

			return true; // Device passes all filters
		});

		setFilteredDevices(filtered);
		setFiltersApplied(true);
		setShowFilterModal(false); // Close the modal
	};

	// Add a reset filters function
	const resetAllFilters = () => {
		setChannel1(false);
		setChannel2(false);
		setPipeConfig({ I: false, M: false, U: false, '2U': false });
		setFromDate(new Date(2000, 0, 1));
		setToDate(new Date());
		setFilteredDevices(filteredDeviceList);
		setFiltersApplied(false);
	};
	const renderFilterModal = () => {
		return (
			<Modal
				animationType='fade'
				visible={showFilterModal}
				onRequestClose={() => setShowFilterModal(false)}>
				<View
					style={{
						flex: 1,
						flexDirection: 'column',
						backgroundColor: '#fff',
					}}>
					{/*Header*/}
					<SafeAreaView>
						<View
							style={[
								styles.headerSection,
								{
									height: 56,
									backgroundColor: '#000',
									alignItems: 'center',
								},
							]}>
							<View
								style={{
									flexDirection: 'row',
									alignItems: 'center',
									paddingHorizontal: 10,
									height: '100%',
									backgroundColor: '#000',
								}}>
								<TouchableOpacity onPress={() => handleManualFilterBackPress()}>
									<LeftArrowWhite height={30} width={30} />
								</TouchableOpacity>
								<View style={[{ flex: 2 }]}>
									<Text
										style={{
											color: '#fff',
											fontSize: 18,
											fontWeight: 'bold',
											textAlign: 'center',
										}}>
										{t('filterdevicelist')}
									</Text>
								</View>
							</View>
						</View>
					</SafeAreaView>
					<View style={styles.container}>
						<ScrollView
							contentContainerStyle={styles.scrollContainer}
							showsVerticalScrollIndicator={true}>
							<Pressable onPress={resetAllFilters}>
								<Text style={styles.resetFilters}>
									{t('btnResetAllFilters')}
								</Text>
							</Pressable>

							<View
								style={{
									borderBottomWidth: 1,
									borderColor: '#D0D0D0',
									marginTop: 10,
								}}
							/>

							{/* By Channel */}
							<Text style={styles.sectionTitle}>{t('lblByChannel')}</Text>
							{renderCheckbox(channel1, '1-Channel', () =>
								setChannel1(!channel1),
							)}
							{renderCheckbox(channel2, '2-Channel', () =>
								setChannel2(!channel2),
							)}

							{/* <View style={{ borderBottomWidth:1, borderColor: '#D0D0D0' ,marginTop: 10  }}/> */}
							{/*Device type*/}
							{/* <Text style={styles.sectionTitle}>{t('DeviceType')}</Text>
      {renderCheckbox(isAddressable, 'Addressable', () => setAddressable(!isAddressable))}
      {renderCheckbox(isStandalone, 'Standalone', () => setStandalone(!isStandalone))} */}

							<View
								style={{
									borderBottomWidth: 1,
									borderColor: '#D0D0D0',
									marginTop: 10,
								}}
							/>

							{/* By Pipe Configuration */}
							<Text style={[styles.sectionTitle, { marginTop: 10 }]}>
								{t('lblByPipeConfig')}
							</Text>
							{Object.keys(pipeConfig).map(key => (
								<View key={key}>
									{renderCheckbox(pipeConfig[key], key, () =>
										togglePipeConfig(key),
									)}
								</View>
							))}

							<View
								style={{
									borderBottomWidth: 1,
									borderColor: '#D0D0D0',
									marginTop: 10,
								}}
							/>
							{/* Last Connected */}
							<View style={styles.dateSection}>
								<Text
									style={[
										styles.sectionTitle,
										{ marginTop: 10, marginBottom: 15 },
									]}>
									{t('lblLastConnected')}
								</Text>
								<View style={styles.dateRow}>
									<View style={styles.dateInputContainer}>
										<Text style={styles.dateLabel}>{t('lblFromDate')}</Text>
										<TouchableOpacity
											style={styles.dateInput}
											onPress={() => setShowFromDatePicker(true)}>
											<Text style={styles.dateText}>
												{formatDate(fromDate)}
											</Text>
										</TouchableOpacity>
									</View>
									<View style={styles.dateSpacer} />
									<View style={styles.dateInputContainer}>
										<Text style={styles.dateLabel}>{t('lblToDate')}</Text>
										<TouchableOpacity
											style={styles.dateInput}
											onPress={() => setShowToDatePicker(true)}>
											<Text style={styles.dateText}>{formatDate(toDate)}</Text>
										</TouchableOpacity>
									</View>
								</View>
							</View>

							{/* Date Pickers */}
							{showFromDatePicker && (
								<DateTimePicker
									testID='fromDateTimePicker'
									value={fromDate}
									mode='date'
									is24Hour={true}
									display='default'
									onChange={onFromDateChange}
								/>
							)}

							{showToDatePicker && (
								<DateTimePicker
									testID='toDateTimePicker'
									value={toDate}
									mode='date'
									is24Hour={true}
									display='default'
									onChange={onToDateChange}
								/>
							)}
						</ScrollView>
						<View
							style={{
								borderTopColor: commonColors.lineColor,
								borderTopWidth: commonSizes.lineThicknessS,
								backgroundColor: commonColors.backgroundColor_White,
							}}>
							<View style={{ marginHorizontal: '2%' }}>
								<DoubleButtonFooter
									leftButtonText={t('cancel')}
									rightButtonText={t('btnApply')}
									onLeftButtonPress={() => cancel()}
									onRightButtonPress={handleProceed}
								/>
							</View>
						</View>
					</View>
				</View>
			</Modal>
		);
	};

	//#endregion

	//#region Activity Indicator
	const [showActivity, setShowActivity] = useState(false);
	const [activityMessage, setActivityMessage] = useState('');
	function ShowActivityIndicator(message: string) {
		setActivityMessage(message);
		setShowActivity(true);
	}
	function hideActivityIndicator() {
		setActivityMessage('');
		setShowActivity(false);
	}
	//#endregion

	//#region Connection Failed Modal
	const connectionFailedModal = () => {
		return (
			<Modal
				animationType='fade'
				transparent={true}
				visible={showConnectionFailedModal}
				onRequestClose={() => setShowConnectionFailedModal(false)}>
				<View style={styles.modalOverlay}>
					<View style={styles.modalContainer}>
						<View
							style={{
								flexDirection: 'row',
								alignItems: 'center',
								justifyContent: 'space-between',
							}}>
							<TouchableOpacity
								style={[styles.mirrorHmiCloseButton, { padding: 10 }]}
								onPress={() => setShowConnectionFailedModal(false)}>
								<CloseIconGray height={20} width={20} />
							</TouchableOpacity>
						</View>

						<View style={[styles.modalContent, { alignItems: 'center' }]}>
							<Fail height={50} width={50} />
							<Text style={styles.modalTitle}>
								{t('UnableConnectWithDevice')}
							</Text>

							<View
								style={[
									styles.modalButtons,
									{
										flexDirection: 'column',
										justifyContent: 'center',
									},
								]}>
								<View style={{ marginVertical: 5 }}>
									<Button
										title={t('Retry_UpperCase')}
										onPress={() => RetryConnectionCommand()}
										color='#1792E5'
									/>
								</View>

								<View style={{ marginVertical: 5 }}>
									<Button
										title={t('ViewAvailableDevices')}
										onPress={() => ViewAvailableDevicesCommand()}
										color='#1792E5'
									/>
								</View>
							</View>
						</View>
					</View>
				</View>
			</Modal>
		);
	};
	//#endregion

	return (
		<View style={styles.container}>
			{renderHeader()}

			<View style={styles.content}>{renderContent()}</View>
			{showScannedDevices && renderScannedDevices()}
			{isMirrorHMIVisible && renderMirrorHMI()}
			{configModalVisible && renderConfigModal()}
			{showManualPairingInstructions && manualPairingModal()}
			{showSoundPairingInstruction && soundPairingModal()}
			{showPWDValidationFailedModal && pwdvalidationFailedModal()}
			{showPWDValidationSuccessModal && pwdvalidationSuccessModal()}
			{showFilterModal && renderFilterModal()}
			{showConnectionFailedModal && connectionFailedModal()}
			<ActivityIndicatorWhite
				visible={showValidatingPWDModal}
				message={t('ValidatingPassword')}
			/>
			<ActivityIndicatorWhite
				visible={showActivity}
				message={activityMessage}
				indicatorColor='#1792E5'
			/>
			<ActivityIndicatorWhite
				visible={showConnectingModal}
				message={t('connectingWithDevice')}
				indicatorColor='#1792E5'
			/>
		</View>
	);
}
const styles = StyleSheet.create({
	container: {
		flex: 1,
	},
	content: {
		flex: 1,
		justifyContent: 'center',
	},

	// Styels for the scanned device list
	itemContainer: {
		padding: 10,
		borderWidth: 1,
		borderColor: '#ccc',
		backgroundColor: '#fff',
		borderRadius: 1,
		elevation: 1,
		marginBottom: 10,
	},
	signalStrengthContainer: {
		justifyContent: 'center',
		alignItems: 'center',
		width: 40,
		height: 40,
	},
	signalStrengthImage: {
		width: 30,
		height: 30,
		resizeMode: 'contain',
	},
	deviceInfoContainer: {
		flex: 1,
		justifyContent: 'center',
		paddingLeft: 10,
	},
	deviceName: {
		fontSize: 16,
		fontWeight: '400',
		marginBottom: 8,
	},
	pairingStatus: {
		fontSize: 12,
		color: '#606060',
	},
	deviceDetailsContainer: {
		flex: 1,
		justifyContent: 'center',
		paddingLeft: 10,
	},
	deviceDetailText: {
		fontSize: 14,
		color: '#606060',
		marginBottom: 8,
	},

	loaderContainer: {
		padding: 20,
		backgroundColor: '#dee2e6',
		justifyContent: 'center',
		alignItems: 'center',
	},
	loadingText: {
		fontSize: 14,
		color: '#000',
		marginTop: 10,
	},
	headerContainer: {
		paddingBottom: 10,
	},
	headerText: {
		fontSize: 15,
		fontWeight: 'bold',
		color: '#000',
	},

	//#region Mirror HMI Modal Styles
	mirrorHmiContainer: {
		flex: 1,
		justifyContent: 'center',
		alignItems: 'center',
		marginTop: 22,
	},
	mirrorHmiCenteredView: {
		flex: 1,
		justifyContent: 'center',
		alignItems: 'center',
		marginTop: 22,
	},
	mirrorHmiModalView: {
		width: '90%',
		backgroundColor: 'white',
		padding: 0,
		shadowOpacity: 0.25,
		shadowRadius: 4,
		elevation: 5,
		paddingBottom: 70,
	},
	mirrorHmiCloseButton: {
		position: 'absolute',
		top: 0,
		right: 0,
		padding: 5,
		zIndex: 0,
	},
	mirrorHmiCloseButtonText: {
		fontSize: 34,
		lineHeight: 34,
		fontWeight: '300',
	},
	mirrorHmiButton: {
		borderRadius: 20,
		padding: 10,
		elevation: 2,
	},
	mirrorHmiButtonOpen: {
		backgroundColor: '#F194FF',
	},
	mirrorHmiButtonClose: {
		backgroundColor: '#2196F3',
	},
	mirrorHmiTextStyle: {
		color: 'white',
		fontWeight: 'bold',
	},
	mirrorHmiModalText: {
		fontSize: 16,
		marginBottom: 6,
		lineHeight: 18,
	},
	mirrorHmiInlineText: {
		fontSize: 16,
		marginBottom: 0,
		marginRight: 4,
		lineHeight: 18,
	},
	mirrorHmiBold: {
		fontWeight: 'bold',
	},
	mirrorHmiStatusDot: {
		color: 'red',
		fontSize: 16,
		lineHeight: 18,
		marginRight: 4,
	},
	mirrorHmiStatusRow: {
		flexDirection: 'row',
		alignItems: 'center',
		justifyContent: 'space-between',
		marginBottom: 6,
	},

	mirrorHmiTable: { marginTop: 4 },
	mirrorHmiTableRow: {
		flexDirection: 'row',
		borderBottomWidth: 1,
		borderBottomColor: '#bbb',
		paddingVertical: 4,
	},
	mirrorHmiTableRowLast: { borderBottomWidth: 0 },
	mirrorHmiTableCell: { flex: 1, paddingHorizontal: 4, lineHeight: 18 },
	mirrorHmiTableCellRight: { textAlign: 'right' },
	mirrorHmiInfoSection: {
		backgroundColor: '#fff',
		padding: 10,
		borderBottomWidth: 1,
		borderBottomColor: '#000',
		zIndex: 0,
	},
	mirrorHmiFooter: {
		position: 'absolute',
		left: 0,
		right: 0,
		bottom: 0,
		flexDirection: 'row',
		borderWidth: 1,
		borderColor: '#000',
		backgroundColor: '#fafafa',
	},
	mirrorHmiFooterButton: {
		flex: 1,
		paddingVertical: 14,
		minHeight: 56,
		alignItems: 'center',
		justifyContent: 'center',
		borderRightWidth: 2,
		borderRightColor: '#000',
	},
	mirrorHmiFooterButtonLast: {
		borderRightWidth: 0,
	},
	mirrorHmiFooterButtonDark: { backgroundColor: '#444' },
	mirrorHmiFooterButtonDarker: { backgroundColor: '#2f2f2f' },
	mirrorHmiFooterButtonContent: {
		alignItems: 'center',
		justifyContent: 'center',
	},
	mirrorHmiFooterIcon: {
		fontSize: 20,
		marginBottom: 4,
		color: '#fff',
	},
	mirrorHmiFooterButtonText: {
		fontSize: 16,
		fontWeight: '600',
		color: '#fff',
	},

	//#endregion

	//#region Config Modal Styles
	modalOverlay: {
		flex: 1,
		backgroundColor: 'rgba(0, 0, 0, 0.5)',
		justifyContent: 'center',
		alignItems: 'center',
	},
	modalContainer: {
		width: '90%',
		maxWidth: 400,
		minWidth: 320,
		backgroundColor: 'white',
		borderRadius: 12,
		overflow: 'hidden',
		elevation: 5,
		shadowColor: '#000',
		shadowOffset: { width: 0, height: 2 },
	},
	modalContent: {
		padding: 20,
	},
	modalTitle: {
		fontSize: 20,
		fontWeight: '600',
		color: '#333',
		marginBottom: 10,
		textAlign: 'center',
	},
	modalDescription: {
		fontSize: 16,
		color: '#666',
		marginBottom: 20,
		textAlign: 'center',
	},
	modalButtons: {
		flexDirection: 'row',
		justifyContent: 'space-between',
	},
	configButton: {
		flex: 1,
		backgroundColor: '#1792E5',
		padding: 12,
		borderRadius: 5,
		marginHorizontal: 5,
		alignItems: 'center',
	},
	configButtonText: {
		color: 'white',
		fontSize: 16,
		fontWeight: '500',
	},
	inputContainer: {
		flexDirection: 'row',
		justifyContent: 'space-between',
		alignItems: 'center',
		marginBottom: 30,
		paddingHorizontal: 10,
	},
	inputBox: {
		flex: 1,
		height: 55,
		borderWidth: 1,
		borderColor: '#ccc',
		borderRadius: 8,
		textAlign: 'center',
		fontSize: 24,
		color: '#333',
		marginHorizontal: 3,
		backgroundColor: '#f9f9f9',
		maxWidth: 45,
		minWidth: 35,
	},
	//#endregion

	headerSection: {
		height: 56,
		width: '100%',
	},
	safeHeader: {
		backgroundColor: '#000',
	},
	deviceCardheaderSection: {
		flexDirection: 'row',
		paddingHorizontal: 10,
	},
	mp_footerContainer: {
		padding: 20,
		borderTopWidth: 1,
		borderColor: '#E5E5E5',
		backgroundColor: '#fff',
	},
	mp_nextButton: {
		backgroundColor: '#1792E5',
		paddingVertical: 15,
		paddingHorizontal: 20,
		borderRadius: 5,
		alignItems: 'center',
		justifyContent: 'center',
	},
	mp_nextButtonText: {
		color: '#fff',
		fontSize: 16,
		fontWeight: 'bold',
	},
	//#region Scanned Device List Styles
	deviceItemGrid: {
		flexDirection: 'row',
		alignItems: 'center',
	},
	deviceInfoColumn: {
		flex: 1,
	},
	deviceNameRow: {
		flexDirection: 'row',
		alignItems: 'center',
	},
	deviceNameLabel: {
		fontSize: 16,
		fontWeight: '500',
		color: '#000',
		marginRight: 4,
	},
	deviceNameValue: {
		fontSize: 16,
		fontWeight: '500',
		color: '#000',
		flex: 1,
	},

	deviceDetailRow: {
		flexDirection: 'row',
		alignItems: 'center',
		justifyContent: 'space-between',
		marginTop: 4,
	},

	registeredDeviceContainer: {
		backgroundColor: '#f0f0f0',
		borderRadius: 4,
		padding: 5,
		marginLeft: 10,
	},
	registeredDeviceText: {
		fontSize: 12,
		color: '#333',
		fontWeight: '500',
	},

	//#endregion
	//#region  Temp List Styling

	deviceCountText: {
		fontSize: 14,
		color: '#606060',
		fontWeight: '500',
		margin: 5,
	},
	listContent: {
		paddingHorizontal: 5,
		paddingBottom: 10,
	},
	deviceCardContainer: {
		backgroundColor: '#ffffff',
		marginBottom: 10,
	},
	cardFrame: {
		backgroundColor: 'white',
		borderRadius: 4,
		shadowColor: '#000',
		shadowOffset: { width: 0, height: 1 },
		shadowOpacity: 0.22,
		shadowRadius: 2.22,
		elevation: 3,
		overflow: 'hidden',
	},
	cardContent: {
		position: 'relative',
		paddingVertical: 5,
	},
	connectionIndicator: {
		position: 'absolute',
		left: 0,
		top: 0,
		bottom: 0,
		width: 4,
		backgroundColor: '#7EB338',
	},

	deviceInfoSection: {
		flex: 1,
		paddingVertical: 5,
	},
	deviceNameText: {
		fontSize: 16,
		fontWeight: 'bold',
		color: '#000000',
		marginBottom: 1,
	},
	locationText: {
		fontSize: 12,
		color: '#606060',
		marginBottom: 1,
	},
	macAddressText: {
		fontSize: 12,
		color: '#606060',
		marginBottom: 4,
	},
	statusRow: {
		flexDirection: 'row',
		alignItems: 'center',
		marginTop: 2,
	},
	statusGroup: {
		flexDirection: 'row',
		alignItems: 'center',
	},
	statusLabel: {
		fontSize: 12,
		color: '#9D9D9D',
		marginRight: 4,
	},
	statusValue: {
		fontSize: 12,
		color: '#606060',
	},
	stateIconContainer: {
		flexDirection: 'row',
		alignItems: 'center',
	},
	stateIcon: {
		width: 14,
		height: 14,
		marginRight: 4,
	},
	spacer: {
		width: 20,
	},
	actionButtons: {
		flexDirection: 'row',
		alignItems: 'flex-start',
		paddingTop: 5,
	},
	expandButton: {
		width: 34,
		height: 34,
		justifyContent: 'center',
		alignItems: 'center',
	},
	expandIcon: {
		width: 24,
		height: 24,
	},
	expandIconRotated: {
		transform: [{ rotate: '90deg' }],
	},
	moreButton: {
		width: 34,
		height: 34,
		justifyContent: 'center',
		alignItems: 'center',
	},
	moreIcon: {
		width: 24,
		height: 24,
	},
	expandedSection: {
		paddingHorizontal: 10,
		paddingVertical: 5,
		marginTop: 5,
	},
	expandedRow: {
		flexDirection: 'row',
		marginVertical: 2,
	},
	expandedColumn: {
		flex: 1,
	},
	expandedWideColumn: {
		flex: 1.5,
	},
	expandedDivider: {
		width: 2,
		backgroundColor: 'transparent',
	},
	expandedSeparator: {
		height: 2,
		backgroundColor: 'transparent',
		marginVertical: 2,
	},
	expandedLabel: {
		fontSize: 12,
		color: '#9D9D9D',
		marginBottom: 2,
	},
	expandedValue: {
		fontSize: 14,
		color: '#606060',
		fontWeight: '500',
	},
	//#endregion

	//#region Popup Styles
	box: { ...commonStyles.box },
	popup_content: {
		...commonStyles.boxContent,
		marginLeft: commonSizes.widthL_Pixel,
	},
	heading: { ...commonStyles.boxHeading },
	description: { ...commonStyles.boxDescription },
	popUp: { ...commonStyles.boxMenuPopUp },
	popUpText: { ...commonStyles.boxMenuText },
	verticalLine: { ...commonStyles.verticalLine },
	clickableMenu: {
		...commonStyles.boxClickableMenu,
		marginHorizontal: commonSizes.widthM_Pixel,
	},
	//#endregion

	//#region Filter CSS
	resetFilters: {
		color: commonColors.backgroundColor_Blue,
		fontSize: commonSizes.textSizeL,
		fontWeight: '500',
	},
	sectionTitle: {
		fontWeight: 'bold',
		color: commonColors.textColor_Black,
		fontSize: commonSizes.textSizeL,
	},
	checkboxContainer: {
		paddingLeft: 20,
		flexDirection: 'row',
		alignItems: 'center',
	},
	checkboxLabel: {
		fontSize: commonSizes.textSizeM,
	},
	dateSection: {
		marginVertical: commonSizes.heightS_Pixel,
	},
	dateRow: {
		flexDirection: 'row',
		justifyContent: 'space-between',
		alignItems: 'flex-end',
	},
	dateInputContainer: {
		flex: 1,
	},
	dateLabel: {
		fontSize: commonSizes.textSizeS,
		color: commonColors.textColor_Black,
		marginBottom: commonSizes.heightS_Pixel,
	},
	dateInput: {
		borderWidth: commonSizes.textBoXBorderWidthXS,
		borderColor: commonColors.lineColor,
		backgroundColor: commonColors.backgroundColor_White,
		paddingHorizontal: commonSizes.paddingS_Percent,
		paddingVertical: commonSizes.heightXS_Pixel,
		borderRadius: commonSizes.cornerRadius,
		minHeight: commonSizes.textBoxHeight_L,
		justifyContent: 'center',
	},
	dateText: {
		fontSize: commonSizes.textSizeM1,
		color: commonColors.textColor_Black,
		fontWeight: '400',
		textAlign: 'center',
	},
	dateSpacer: {
		width: commonSizes.widthL_Pixel,
	},
	wrapper: {
		flexDirection: 'row',
		alignItems: 'center',
		marginRight: 15,
	},
	radio: {
		height: commonSizes.textSizeXL,
		width: commonSizes.textSizeXL,
		// borderRadius: commonSizes.textSizeL,
		borderWidth: commonSizes.lineThickness,
		borderColor: commonColors.lineColor,
		alignItems: 'center',
		justifyContent: 'center',
	},
	radioBG: {
		width: commonSizes.textSizeM,
		height: commonSizes.textSizeM,
		// borderRadius: commonSizes.textSizeS,
		backgroundColor: commonColors.backgroundColor_Blue,
	},
	scrollContainer: {
		flexGrow: 1,
		paddingHorizontal: commonSizes.paddingXL_Percent,
		paddingTop: commonSizes.paddingXL_Percent,
		gap: '2%',
	},
	//#endregion

	//#region search box
	searchContainer: {
		paddingHorizontal: commonSizes.paddingS_Percent,
		paddingVertical: commonSizes.heightS_Pixel,
		backgroundColor: commonColors.backgroundColor_White,
	},
	searchInputContainer: {
		flexDirection: 'row',
		alignItems: 'center',
		backgroundColor: commonColors.textColor_White,
		minHeight: commonSizes.textBoxHeight_L,
		borderBlockColor: commonColors.lineColor,
		borderWidth: commonSizes.lineThicknessS,
		paddingHorizontal: commonSizes.paddingS_Percent,
		borderRadius: commonSizes.cornerRadius,
	},
	searchIcon: {
		marginLeft: commonSizes.paddingL_Percent,
		marginRight: commonSizes.paddingL_Percent,
	},
	searchInput: {
		flex: 1,
		paddingHorizontal: commonSizes.paddingS_Percent,
		paddingVertical: commonSizes.heightXS_Pixel,
		fontSize: commonSizes.textSizeM1,
		color: commonColors.shadowColor,
	},

	// ActionSheet styles
	actionSheetContainer: {
		padding: 20,
	},
	actionSheetOption: {
		paddingVertical: 8,
		borderBottomColor: '#eee',
	},
	actionSheetText: {
		fontSize: 18,
		textAlign: 'center',
	},
	//#endregion
});
