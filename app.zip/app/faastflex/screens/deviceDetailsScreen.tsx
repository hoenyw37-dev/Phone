import React, { useState, useEffect, useRef } from 'react';
import {
	View,
	Text,
	Dimensions,
	StyleSheet,
	TouchableOpacity,
	TextInput,
	Alert,
	Modal,
	Button,
	FlatList,
	Platform,
	ScrollView,
	BackHandler,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { DeviceMeasures } from '@faastflexCommands/common_objects.ts';
import {
	ErrorCode,
	DeviceStatus,
	PasswordValid,
	Country,
	RelayEnabled,
	getDeviceStatusDescription,
	getCountryDescription,
	Configuration,
	getConfigurationDescription,
	getRelayEnabledDescription,
	SmokeAlarmLevel,
	getExternalInputNormalStateDescription,
	getExternalInputActionDescription,
	ExternalInputMode,
	getFanPWMPercCorrectionDescription,
	FanSpeedLevel,
	getDeviceTypeDescription,
	DeviceAuthenticated,
	DeviceType,
} from '@faastflexCommands/commandEnum.ts';
import {} from '@faastflexCommands/command_getDeviceMeasures.ts';
import SemiCircularProgressBar from './radialGauge.tsx';
import { commonColors, commonSizes } from '@styles/base.ts';
import RNFS from 'react-native-fs';
import { useDatabase } from '../../../global/DatabaseContext.tsx';
import { useAppDispatch } from '../../../global/hooks.ts';
import EncryptedStorage from 'react-native-encrypted-storage';
import {
	fetchAllLogsWithMAC,
	deleteAllEventLogs,
	addNewEventLog,
} from '@ff_redux/eventLogRedux/eventLogThunk.ts';
import DropdownMenu, {
	MenuOptionItem,
} from '@ff_controllers/dropdownController.tsx';
import { EventLogModel } from '@ff_model/eventLogModel.ts';
import { LogEventType } from 'faastflexCommands/command_log.ts';
import {
	DeviceModel,
	DeviceState,
	getDeviceStateDescription,
} from '@ff_model/deviceModel.ts';
import { useLoading } from '../../../global/GlobalContext/LoadingContext.tsx';
import { confirmAlert } from '@ff_utils/confirmAlert.ts';
import { delay } from '@ff_utils/timeDelay.ts';
import Toast from 'react-native-toast-message';
import faastflexBluetoothCommunicator from 'faastflexCommunicator/faastflexBluetoothCommunicator.ts';
import { FaastFlexDeviceStatus } from '../../../faastflexCommandModel/faastflexResponseParserModel.ts';
import { updateExistingDevice } from '../redux/deviceRedux/devicesThunk';
import { Channels } from '@ff_model/channels.ts';
import { DeviceGPIParams } from '@faastflexCommands/common_objects.ts';
import { useBLE } from '../../../bleCommunicator/bleContext.tsx';
import { responsiveWidth, responsiveHeight } from '@global/responsiveUI';
import useSyncedState from '@global/Hooks/useSyncedState.ts';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { AppConstants } from '@global/GlobalConstants/globalConstants.ts';
import { BluetoothDevice } from 'bleCommunicator/bleService.ts';
import { useTranslation } from 'react-i18next';
import { format as dateFormat } from 'date-fns';
import stringFormat from '@ff_utils/stringFormat.ts';
import ResetWhite from '@assets/images/ResetWhite.svg';
import SyncBlue from '@assets/images/SyncBlue.svg';
import SyncWhite from '@assets/images/SyncWhite.svg';
import CloseIconGray from '@assets/images/CloseIconGray.svg';
import ImageButtonSVG from '@ff_controllers/imageButtonSVG.tsx';
import Dashboard from '@assets/images/Dashboard.svg';
import DashboardEnabled from '@assets/images/DashboardEnabled.svg';
import Log from '@assets/images/Log.svg';
import LogEnabled from '@assets/images/LogEnabled.svg';
import Silenced from '@assets/images/Silenced.svg';
import LeftArrowWhite from '@assets/images/LeftArrowWhite.svg';
import { SheetManager } from 'react-native-actions-sheet';
import { stringFunction } from '@ff_utils/stringFunction.ts';
import { ModalLoadingIndicator } from '../controllers/modalLoadingIndicator.tsx';
import Share from 'react-native-share';
import { eventHandler } from '@global/utils/EventBus.ts';
import {
	getStateIcon,
	getStatusIcon,
} from '@faastflex/converters/iconConverter.tsx';

//#region DeviceDetailsScreen Constants
const Const_All = 'all';
const Const_Alarms = 'alarms';
const Const_FaultsAndAlerts = 'faultsAndAlerts';
const Const_System = 'system';
const Const_UserAction = 'userAction';
const Const_LogsContent = 'logs';
const Const_GraphContent = 'graph';
const Const_ACTIVE = 'Active';
const BARPLOT_MARGIN_HORIZONTAL = '1%';
const BARPLOT_PADDING_HORIZONTAL = '2%';
const screenWidth = Dimensions.get('window').width;
const Const_BarWidth = screenWidth * (1 - 2 * 0.01 - 2 * 0.02);
const Const_Smoke_DataPoints = 11;
const Const_SmokeEachPointWidth = Const_BarWidth / Const_Smoke_DataPoints;
//#endregion

export default function DeviceDetailsScreen({ route, navigation }: any) {
	//#region Properties
	//Database
	const dispatch = useAppDispatch();
	const { dataSource } = useDatabase();
	const { showLoadingIndicator, hideLoadingIndicator } = useLoading();
	const {} = useBLE();
	const { t } = useTranslation();

	// State to hold devMeasures
	const [devMeasures, setDevMeasures] = useState<DeviceMeasures | null>(null);
	const [error, setError] = useState<ErrorCode | null>(null);
	const [activeScreen, setActiveScreen] = useState(Const_GraphContent);
	const [passwordValues, setPasswordValues] = useState([
		'',
		'',
		'',
		'',
		'',
		'',
	]);
	const passwordInputRefs = useRef<Array<TextInput | null>>([]);
	const [currentDeviceId, setCurrentDeviceId] = useState(0);
	const [selectedDevice, setSelectedDevice, selectedDeviceRef] =
		useSyncedState<DeviceModel>(new DeviceModel());
	const [isDeviceStatusLabelVisible, setIsDeviceStatusLabelVisible] =
		useState(false);
	const [isLogPageContentVisible, setIsLogPageContentVisible] = useState(false);
	const [isStatusPageContentVisible, setIsStatusPageContentVisible] =
		useState(false);
	const [EventLogs, setEventLogs] = useState<EventLogModel[]>([]);
	const [FilteredAllLogs, setFilteredAllLogs] = useState<EventLogModel[]>([]);
	const [FilteredFaultLogs, setFilteredFaultLogs] = useState<EventLogModel[]>(
		[],
	);
	const [FilteredUserActionLogs, setFilteredUserActionLogs] = useState<
		EventLogModel[]
	>([]);
	const [FilteredSystemLogs, setFilteredSystemLogs] = useState<EventLogModel[]>(
		[],
	);
	const [FilteredAlarmLogs, setFilteredAlarmLogs] = useState<EventLogModel[]>(
		[],
	);
	const [isGenerateReportVisible, setIsGenerateReportVisible] = useState(false);
	const [configModalVisible, setConfigModalVisible] = useState<boolean>(false);
	const [isDualChannelDevice, setIsDualChannelDevice] =
		useState<boolean>(false);
	const [DeviceCountry, setDeviceCountry] = useState<string>(
		getCountryDescription(Country.Unknown),
	);

	const [DeviceName, setDeviceName] = useState<string>('');
	const [BlowerRPMValue, setBlowerRPMValue] = useState<number>(0);

	const [Channel, setChannel] = useState<number>(1);
	const [NoOfChannels, setNoOfChannels] = useState<number>(2);

	const [smokeSensitivityLevel1Str, setSmokeSensitivityLevel1Str] =
		useState<string>('');
	const [ch1ChartErrorList, setCh1ChartErrorList] = useState<string[]>([]);
	const [IsCh1ErrorExist, setIsCh1ErrorExist] = useState<boolean>(false);

	const [smokeSensitivityLevel2Str, setSmokeSensitivityLevel2Str] =
		useState<string>('');
	const [ch2ChartErrorList, setCh2ChartErrorList] = useState<string[]>([]);
	const [IsCh2ErrorExist, setIsCh2ErrorExist] = useState<boolean>(false);
	const [IsChannel2Visible, setIsChannel2Visible] = useState<boolean>(false);
	const [DeviceConnected, setDeviceConnected] = useState<boolean>(false);
	const [IsConfigDataFetched, setIsConfigDataFetched] =
		useState<boolean>(false);
	const [IsMoreButtonVisible, setIsMoreButtonVisible] =
		useState<boolean>(false);
	const [SyncImage, setSyncImage] = useState<string>('Sync.png');
	const [isAboutDeviceVisible, setIsAboutDeviceVisible] =
		useState<boolean>(false);
	const [aboutDeviceNumberofChannels, setAboutDeviceNumberofChannels] =
		useState<number>(0);
	const [aboutDeviceFirmwareVersion, setAboutDeviceFirmwareVersion] =
		useState<string>('');
	const [aboutDeviceType, setAboutDeviceType] = useState<string>('');
	const [aboutDeviceSerialNumber, setAboutDeviceSerialNumber] =
		useState<string>('');
	const [aboutDeviceProductionDate, setAboutDeviceProductionDate] =
		useState<string>('');
	const [aboutDeviceModelNumber, setAboutDeviceModelNumber] =
		useState<string>('');
	const [showObscurationTable, setShowObscurationTable] =
		useState<boolean>(false);

	const [isMirrorHMIVisible, setIsMirrorHMIVisible] = useState<boolean>(false);
	const [AlarmLEDStatus1, setAlarmLEDStatus1] = useState<string>('Not Active');
	const [PreAlarmLEDStatus1, setPreAlarmLEDStatus1] =
		useState<string>('Not Active');
	const [AlarmLEDStatus2, setAlarmLEDStatus2] = useState<string>('Not Active');
	const [PreAlarmLEDStatus2, setPreAlarmLEDStatus2] =
		useState<string>('Not Active');
	const [FaultLEDStatus, setFaultLEDStatus] = useState<string>('Not Active');
	const [AlertStatus, setAlertStatus] = useState<string>('Not Active');
	const [DeviceStateColor, setDeviceStateColor] = useState<string>('');
	const [IsDeviceCountryCodeChina, setIsDeviceCountryCodeChina] =
		useState<boolean>(false);
	const [IsSelfTestChinaEnabled, setIsSelfTestChinaEnabled] =
		useState<boolean>(false);
	const [moreMenuOptions, setMoreMenuOptions] = useState<MenuOptionItem[]>([]);

	//Chart Constants
	const [ch1Temperature, setCh1Temperature] = useState<string>('');
	const [ch2Temperature, setCh2Temperature] = useState<string>('');
	const [ch1MinFlow, setCh1MinFlow] = useState(0);
	const [ch1RefFlow, setCh1RefFlow] = useState(0);
	const [ch1MaxFlow, setCh1MaxFlow] = useState(0);
	const [ch1FlowRate, setCh1FlowRate] = useState(0);
	const [ch1ActionValue, setCh1ActionValue] = useState(0);
	const [ch1AlarmValue, setCh1AlarmValue] = useState(0);
	const [ch1SmokeLevel, setCh1SmokeLevel] = useState<number>(-1);

	const [ch2MinFlow, setCh2MinFlow] = useState(0);
	const [ch2RefFlow, setCh2RefFlow] = useState(0);
	const [ch2MaxFlow, setCh2MaxFlow] = useState(0);
	const [ch2FlowRate, setCh2FlowRate] = useState(0);
	const [ch2ActionValue, setCh2ActionValue] = useState(0);
	const [ch2AlarmValue, setCh2AlarmValue] = useState(0);
	const [ch2SmokeLevel, setCh2SmokeLevel] = useState<number>(-1);

	// Smoke level visibility control for Channel 2
	const [SmokeLevelVisible, setSmokeLevelVisible] = useState<boolean>(false);

	const [isLedStatusVisible, setIsLedStatusVisible] = useState<boolean>(true);

	// Use Ref
	const ConnectedDeviceobj = useRef<BluetoothDevice | null>();
	const isDeviceResponding = useRef<boolean>(true);
	const ExportLogs = useRef<EventLogModel[]>([]);
	const IsMirrorHMIResetCommand = useRef<boolean>(false);
	const IsSelfTestChina = useRef<boolean>(false);
	const IsConfigurePage = useRef<boolean>(false);
	const [
		IsAutoRefreshEnabled,
		setIsAutoRefreshEnabled,
		IsAutoRefreshEnabledRef,
	] = useSyncedState<boolean>(false);
	const isENSelfTestAvailable = useRef<boolean>(false);
	const NoOfDataPoints1 = useRef<number>(0);
	const NoOfDataPoints2 = useRef<number>(0);
	const EachDataPointWidth1 = useRef<number>(0);
	const EachDataPointWidth2 = useRef<number>(0);
	const autoRefreshTimer = useRef<NodeJS.Timeout | null>(null);
	const autoRefreshTimerCounter = useRef<number>(0);
	const MAX_TIMER_COUNT = 40;
	const FilteredLogs = useRef<EventLogModel[]>([]);
	const IsChannel2AvailableRef = useRef<boolean>(false);
	const deviceTypeRef = useRef<string>(
		getDeviceTypeDescription(DeviceType.eStandAlone),
	);
	const bleAdapterStatusUnsubscribe = useRef<(() => void) | null>(null);

	//#region Properties - Report Generation
	const IsReportGeneration = useRef<boolean>(false);
	const Report_ModelType = useRef<string>('NA');
	const Report_Channels = useRef<string>('NA');
	const Report_SerialNumber = useRef<string>('NA');
	const Report_PDay = useRef<string>('NA');
	const Report_PMonth = useRef<string>('NA');
	const Report_PYear = useRef<string>('NA');
	const Report_PHour = useRef<string>('NA');
	const Report_PMinute = useRef<string>('NA');
	const Report_PSecond = useRef<string>('NA');
	const Report_FWversion = useRef<string>('NA');
	const Report_FWRelease = useRef<string>('NA');
	const Report_FWMajor = useRef<string>('NA');
	const Report_FWMinor = useRef<string>('NA');
	const Report_FWBuild = useRef<string>('NA');
	const Report_Model = useRef<string>('NA');
	const Report_Configuration = useRef<string>('NA');
	const Report_Orientation = useRef<string>('NA');
	const Report_Ch1Alarm = useRef<string>('NA');
	const Report_Ch1Action = useRef<string>('NA');
	const Report_Ch1Reference = useRef<string>('NA');
	const Report_Ch1MinFlow = useRef<string>('NA');
	const Report_Ch1MaxFlow = useRef<string>('NA');
	const Report_Ch2Alarm = useRef<string>('NA');
	const Report_Ch2Action = useRef<string>('NA');
	const Report_Ch2Reference = useRef<string>('NA');
	const Report_Ch2MinFlow = useRef<string>('NA');
	const Report_Ch2MaxFlow = useRef<string>('NA');
	const Report_GPIInput = useRef<string>('NA');
	const Report_SupervisedOpen = useRef<string>('NA');
	const Report_SupervisedClosed = useRef<string>('NA');
	const Report_UnSupervisedInput = useRef<string>('NA');
	const Report_UnSupervisedAction = useRef<string>('NA');
	const Report_BlowerSpeed = useRef<string>('NA');
	const Report_BlowerCorrection = useRef<string>('NA');
	const Report_PowerSupply = useRef<string>('NA');
	const Report_DeviceState = useRef<string>('NA');
	const Report_Disabled = useRef<string>('NA');

	//Mirror HMI Loading Indicator
	const [mirrorHMILoadingIndicator, setMirrorHMILoadingIndicator] =
		useState(false);
	const [mirrorHMILoadingMessage, setMirrorHMILoadingMessage] = useState('');
	//#endregion

	//#endregion
	// const { t } = useTranslation();

	//#region  On Screen Appeared
	useEffect(() => {
		console.log('Route params:', route.params);
		InitializeAsync();
	}, []);

	useEffect(() => {
		const unsubscribe = navigation.addListener('focus', () => {
			OnPageAppeared();
		});
		const blurUnsubscribe = navigation.addListener('blur', () => {
			eventListenerCleanUp();
		});
		return () => {
			unsubscribe();
			blurUnsubscribe();
		};
	}, [navigation]);
	//#endregion

	//#region Prevent Device Back Functionality
	useEffect(() => {
		const backHandler = BackHandler.addEventListener(
			'hardwareBackPress',
			() => {
				return true; // Return true to prevent default back behavior
			},
		);

		return () => backHandler.remove();
	}, []);

	//iOS
	useEffect(() => {
		navigation.setOptions({
			gestureEnabled: false, // Disable swipe back gesture
		});
	}, [navigation]);

	//#endregion

	//#region Back Handler
	async function handleBackPress(): Promise<void> {
		navigation.goBack();
	}
	//#endregion

	//#region Event Handlers
	async function SetupNativeListenersForBleCommunication() {
		eventListenerCleanUp();
		// Store the unsubscribe function
		const unsubscribe = eventHandler.subscribe('BLEAdapterStatus', status => {
			handleBluetoothConnectionChanges(status);
		});
		bleAdapterStatusUnsubscribe.current = unsubscribe;
		// Return it so it can be called later if needed
		return unsubscribe;
	}
	async function eventListenerCleanUp() {
		// If you have a stored unsubscribe function, call it here
		if (bleAdapterStatusUnsubscribe.current) {
			bleAdapterStatusUnsubscribe.current();
			bleAdapterStatusUnsubscribe.current = null;
		}
	}
	async function handleBluetoothConnectionChanges(event: any) {
		try {
			if (event != null && event.toString() != '') {
				const status = event.toString();
				if (status === 'TurnedOff' || status === 'NotResponding') {
					hideLoadingIndicator();
					if (status === 'NotResponding') {
						isDeviceResponding.current = false;
						hideLoadingIndicator();
					}
					if (status === 'TurnedOff') {
						hideLoadingIndicator();
						await handleDeviceDisconnect();
					}
				}
			}
		} catch (error) {}
	}
	//#endregion

	//#region Initialize
	async function InitializeAsync() {
		if (
			route.params !== null &&
			route.params !== undefined &&
			route.params.connectedDevice !== null
		) {
			ConnectedDeviceobj.current = route.params
				.connectedDevice as BluetoothDevice;
			setIsMoreButtonVisible(true);
		}
		if (
			route.params !== null &&
			route.params !== undefined &&
			route.params.selectedItem !== null
		) {
			var device = route.params.selectedItem as DeviceModel;
			setSelectedDevice(device);
			if (
				!(
					device.isDeviceConnected ||
					device.deviceStatusStr === AppConstants.Unknown
				)
			) {
				if (device.listOfChannels == null) {
					setSelectedDevice({ listOfChannels: [] });
				}
			}
			setDeviceConnected(device.isDeviceConnected);
			setIsConfigDataFetched(
				device.isDeviceConnected ? true : device.isConfigDataFetched,
			);
			setIsDeviceStatusLabelVisible(true);
			setActiveScreen(Const_GraphContent);
			setIsStatusPageContentVisible(true);
			setIsLogPageContentVisible(false);
			IsChannel2AvailableRef.current = device !== null && device.channels === 2;
			setNoOfChannels(device.channels);
			deviceTypeRef.current = device.deviceType;
			if (ConnectedDeviceobj.current !== null) {
				isENSelfTestAvailable.current =
					device.deviceCountryCode === getCountryDescription(Country.EU) &&
					(await GetDeviceFirmware());
				if (
					deviceTypeRef.current ===
					getDeviceTypeDescription(DeviceType.eUnknown)
				) {
					await CheckDeviceType();
				}
			}
			//Get Obscuration List
		}
	}
	async function CheckDeviceType() {
		const deviceTypeResult =
			await faastflexBluetoothCommunicator.GetDeviceType();
		if (deviceTypeResult.error === ErrorCode.eOK) {
			deviceTypeRef.current = deviceTypeResult.deviceType;
		}
	}
	//#endregion

	//#region Auto Refresh
	// Make sure to clean up on component unmount
	useEffect(() => {
		return () => {
			stopTimer();
		};
	}, []);

	function startTimer() {
		// First stop any existing timer to avoid duplicates
		stopTimer();

		autoRefreshTimer.current = setInterval(() => {
			AutoRefreshData();
		}, 7000); // 7 seconds interval
	}

	function stopTimer() {
		if (autoRefreshTimer.current) {
			clearInterval(autoRefreshTimer.current);
			autoRefreshTimer.current = null;
		}
	}

	//TODO: Call from header menu
	async function AutoRefreshAsync() {
		console.log('AutoRefreshAsync called' + IsAutoRefreshEnabledRef.current);
		console.log('IsAutoRefreshEnabledRef ID: ' + IsAutoRefreshEnabledRef);
		if (IsAutoRefreshEnabledRef.current === true) {
			await AsyncStorage.setItem(
				AppConstants.DeviceDetails +
					AppConstants.AutoRefresh +
					selectedDeviceRef.current.deviceId,
				'false',
			);
			if (autoRefreshTimer.current != null) {
				stopTimer();
			}
			autoRefreshTimerCounter.current = 0;
			setSyncImage('Sync.png');
		} else {
			await AsyncStorage.setItem(
				AppConstants.DeviceDetails +
					AppConstants.AutoRefresh +
					selectedDeviceRef.current.deviceId,
				'true',
			);
			autoRefreshTimerCounter.current = 0;
			startTimer();
			setSyncImage('Sync_Active.png');
		}
		setIsAutoRefreshEnabled(!IsAutoRefreshEnabledRef.current);
	}

	async function AutoRefreshData() {
		if (
			DeviceConnected &&
			activeScreen !== Const_GraphContent &&
			autoRefreshTimer != null
		) {
			stopTimer();
			autoRefreshTimerCounter.current = 0;
			return;
		}
		if (autoRefreshTimerCounter.current >= MAX_TIMER_COUNT) {
			await AsyncStorage.setItem(
				AppConstants.DeviceDetails +
					AppConstants.AutoRefresh +
					selectedDeviceRef.current.deviceId,
				'false',
			);
			if (autoRefreshTimer != null) {
				stopTimer();
			}
			autoRefreshTimerCounter.current = 0;
			setIsAutoRefreshEnabled(false);
			setSyncImage('Sync.png');
			return;
		}
		autoRefreshTimerCounter.current++;
		DeviceDataSyncCommandAsync();
	}

	//#endregion

	//#region Device Disconnection
	async function handleDeviceDisconnect() {
		try {
			setSelectedDevice({ isDeviceConnected: false });
			await dispatch(
				updateExistingDevice({
					dataSource,
					deviceId: selectedDeviceRef.current.deviceId,
					updates: {
						isDeviceConnected: false,
					},
				}),
			);
			setDeviceConnected(false);
			setIsConfigDataFetched(selectedDeviceRef.current.isConfigDataFetched);
			IsChannel2AvailableRef.current =
				selectedDeviceRef.current !== null &&
				selectedDeviceRef.current.channels === 2;
			setBlowerRPMValue(0);
			setActiveScreen(Const_GraphContent);
			setIsDeviceStatusLabelVisible(true);
			setIsStatusPageContentVisible(true);
			setChannel(1);
			setIsLogPageContentVisible(false);
			setIsMoreButtonVisible(false);
			setIsAutoRefreshEnabled(false);
			setIsCh2ErrorExist(false);
			setIsCh1ErrorExist(false);
			isENSelfTestAvailable.current = false;
			AddMoreMenuItems();
			setCh1ChartErrorList([]);
			setCh2ChartErrorList([]);
			setSyncImage(
				IsAutoRefreshEnabledRef.current ? 'Sync_Active.png' : 'Sync.png',
			);
			stopTimer();
			setBlowerRPMValue(0);
			setCh1FlowRate(0);
			setCh1Temperature('');
			setCh2FlowRate(0);
			setCh2Temperature('');

			await RedrawGraph();
		} catch (error) {
			console.log('Error in Device Details handleDeviceDisconnect: ', error);
		}
	}
	//#endregion

	async function OnPageAppeared() {
		SetupNativeListenersForBleCommunication();
		setChannel(1);
		setActiveScreen(Const_GraphContent);
		setIsDeviceStatusLabelVisible(true);
		setIsStatusPageContentVisible(true);
		setIsLogPageContentVisible(false);
		setIsMoreButtonVisible(false);
		passwordInputRefs.current = passwordInputRefs.current.slice(0, 6);
		setIsAutoRefreshEnabled(false);
		if (selectedDeviceRef.current.isDeviceConnected) {
			const autoRefresh = await AsyncStorage.getItem(
				AppConstants.DeviceDetails +
					AppConstants.AutoRefresh +
					selectedDeviceRef.current.deviceId,
			);
			if (
				autoRefresh !== null &&
				selectedDeviceRef.current.deviceConfig !== Configuration.OutOfTheBox
			) {
				setIsAutoRefreshEnabled(autoRefresh === 'true');
			} else {
				await AsyncStorage.setItem(
					AppConstants.DeviceDetails +
						AppConstants.AutoRefresh +
						selectedDeviceRef.current.deviceId,
					'false',
				);
				setIsAutoRefreshEnabled(false);
			}

			await DeviceDataSyncCommandAsync();
			if (IsAutoRefreshEnabledRef.current) {
				startTimer();
			}

			//Setting device connected for few offline scenarios
			setDeviceConnected(true);
		} else {
			if (selectedDeviceRef.current.listOfChannels == null) {
				setSelectedDevice({ listOfChannels: [] });
			}
			//Setting device connected for few offline scenarios
			setDeviceConnected(false);
			setDeviceStateColor('');
			if (
				selectedDeviceRef.current.deviceType ===
				getDeviceTypeDescription(DeviceType.eIntelligent)
			) {
				setSmokeLevelVisible(false);
			} else {
				setSmokeLevelVisible(true);
			}
			await RedrawGraph();
		}
		setSyncImage(
			IsAutoRefreshEnabledRef.current ? 'Sync_Active.png' : 'Sync.png',
		);
		await AddMoreMenuItems();
	}

	async function AddMoreMenuItems() {
		let menuOptions: MenuOptionItem[] = [];
		menuOptions.push({
			label: t('ConfigureDevice'),
			onSelect: () => ConfigureDeviceParamterCommand(),
		});
		if (isENSelfTestAvailable.current) {
			menuOptions.push({
				label: t('PerformDeviceTest'),
				onSelect: () => PerformDeviceTestCommand(),
			});
		}
		setMoreMenuOptions(menuOptions);
	}

	let _isStatusLoaded = true; //TODO: This implementation is to prevent multiple renderers when back or navigation clicked multiple times, check if needed
	async function DeviceDataSyncCommandAsync() {
		try {
			if (_isStatusLoaded) {
				_isStatusLoaded = false;
				showLoadingIndicator(t('LoadingDeviceDetails'));
				if (
					ConnectedDeviceobj.current !== null &&
					selectedDeviceRef.current.isDeviceConnected
				) {
					const deviceModeResult =
						await faastflexBluetoothCommunicator.GetDeviceMode();

					if (deviceModeResult.deviceMode === DeviceStatus.MAIN_FSM_SERVICE) {
						await GetDeviceMeasures(selectedDeviceRef.current);
						_isStatusLoaded = true;
						Alert.alert(t('Error'), t('DeviceServiceModeErrorMsg'), [
							{ text: t('OK') },
						]);
						hideLoadingIndicator();
						return;
					}
				}

				// Give device time to be ready after mode check
				await delay(300);

				await GetDeviceMeasures(selectedDeviceRef.current);

				// Give device time before next BLE command
				await delay(500);
				await GetDeviceRegionAndWorkingMode();

				// Check if EN self-test is available
				if (ConnectedDeviceobj.current !== null) {
					isENSelfTestAvailable.current =
						selectedDeviceRef.current.isDeviceConnected &&
						selectedDeviceRef.current.deviceCountryCode ===
							getCountryDescription(Country.EU) &&
						(await GetDeviceFirmware());
				}
				if (
					deviceTypeRef.current ===
					getDeviceTypeDescription(DeviceType.eIntelligent)
				) {
					setSmokeLevelVisible(false);
					setIsLedStatusVisible(false);
				} else {
					setSmokeLevelVisible(true);
					setIsLedStatusVisible(true);
				}
				hideLoadingIndicator();
				_isStatusLoaded = true;
			}
		} catch (error) {
			hideLoadingIndicator();
			_isStatusLoaded = true;
		}
	}
	async function ManualDataSync() {
		if (IsAutoRefreshEnabledRef.current) return;
		await DeviceDataSyncCommandAsync();
	}
	//#region Log screen
	const [selectedTab, setSelectedTab] = useState(Const_All);
	useEffect(() => {
		//TODO:
		switch (selectedTab) {
			case Const_All:
				LogsAll(selectedTab);
				FilteredLogs.current = FilteredAllLogs;
				break;
			case Const_UserAction:
				LogsUserAction(selectedTab);
				FilteredLogs.current = FilteredUserActionLogs;
				break;
			case Const_System:
				LogsSystem(selectedTab);
				FilteredLogs.current = FilteredSystemLogs;
				break;
			case Const_Alarms:
				LogsAlarm(selectedTab);
				FilteredLogs.current = FilteredAlarmLogs;
				break;
			case Const_FaultsAndAlerts:
				LogsFaultAndAlert(selectedTab);
				FilteredLogs.current = FilteredFaultLogs;
				break;
			default:
				LogsAll(selectedTab);
				FilteredLogs.current = FilteredAllLogs;
				break;
		}

		setEventLogs(FilteredLogs.current);
	}, [selectedTab]);

	const currentLogsCount = useRef(0);
	const pageSize = useRef(0);
	const dbPrimaryKey = useRef(0);
	const _isLogsLoaded = useRef(true);
	async function LogTabCommandAsync() {
		stopTimer();
		if (selectedDeviceRef.current.deviceStatus === DeviceStatus.UNKNOWN) {
			setActiveScreen(Const_LogsContent);
			setIsDeviceStatusLabelVisible(true);
			setIsStatusPageContentVisible(false);
			setIsLogPageContentVisible(true);
		} else {
			setActiveScreen(Const_LogsContent);
			setIsLogPageContentVisible(true);
			setIsDeviceStatusLabelVisible(false);
			setIsStatusPageContentVisible(false);
			currentLogsCount.current = 0;
			var allLogs: EventLogModel[] = [];
			if (
				deviceTypeRef.current ===
				getDeviceTypeDescription(DeviceType.eIntelligent)
			) {
				allLogs = FilteredLogs.current;
			} else {
				allLogs = await dispatch(
					fetchAllLogsWithMAC({
						dataSource,
						deviceMacAddress: selectedDeviceRef.current.deviceMacAddress,
					}),
				)
					.unwrap()
					.then(data => {
						return data;
					});
			}
			if (allLogs !== null && allLogs.length > 0) {
				setSelectedTab(Const_All);
				var tempLogs = GetFilteredLogs(allLogs);
				setEventLogs(tempLogs);
				FilteredLogs.current = tempLogs;
			} else {
				const errorLog = {
					Id: 0,
					showErrorMessage: true,
					eventBarColor: '#FFD153',
				} as EventLogModel;

				// Set both EventLogs and FilteredLogs to an array containing just the error log
				setEventLogs([errorLog]);
				FilteredLogs.current = [errorLog];
			}
		}
	}

	function GetFilteredLogs(allLogs: EventLogModel[]): EventLogModel[] {
		const eventLogs: EventLogModel[] = [];
		if (allLogs !== null && allLogs.length > 0) {
			allLogs.forEach(log => {
				const eventLog = new EventLogModel();
				eventLog.Id = log.Id;
				eventLog.logId = log.logId;
				eventLog.eventDateTime = log.eventDateTime;
				eventLog.eventName = log.eventName;
				eventLog.eventDescription = t(log.eventDescription);
				eventLog.addtionalInfo = log.addtionalInfo;
				eventLog.eventDate = log.eventDate;
				eventLog.eventTime = log.eventTime;
				eventLog.eventType = log.eventType;
				eventLog.eventTypeStr = t(log.eventTypeStr);
				eventLog.logChannel = log.logChannel;
				eventLog.logChannelsStr = log.logChannelsStr;
				eventLog.eventBarColor = log.eventBarColor;
				eventLog.statusIcon = log.statusIcon;
				eventLog.eventIdInfo = log.eventIdInfo;
				eventLog.showErrorMessage = log.showErrorMessage;
				eventLog.ch1Temperature = log.ch1Temperature;
				eventLog.ch2Temperature = log.ch2Temperature;
				eventLog.ch1Flow = log.ch1Flow;
				eventLog.ch2Flow = log.ch2Flow;
				eventLog.ch1Sensor = log.ch1Sensor;
				eventLog.ch2Sensor = log.ch2Sensor;
				eventLog.blowerRPM = log.blowerRPM;
				eventLogs.push(eventLog);
			});
		}
		setEventLogs(eventLogs);
		setFilteredAllLogs(eventLogs);
		setFilteredFaultLogs(
			eventLogs.filter(log => log.eventType === LogEventType.eFaultandAlert),
		);
		setFilteredUserActionLogs(
			eventLogs.filter(log => log.eventType === LogEventType.eUserAction),
		);
		setFilteredSystemLogs(
			eventLogs.filter(log => log.eventType === LogEventType.eSystem),
		);
		setFilteredAlarmLogs(
			eventLogs.filter(log => log.eventType === LogEventType.eAlarm),
		);
		return eventLogs;
	}

	async function DeleteLogsAsync() {
		try {
			showLoadingIndicator(t('txtClearingLogs'));
			if (
				deviceTypeRef.current !==
				getDeviceTypeDescription(DeviceType.eIntelligent)
			) {
				const deleteResult = await dispatch(
					deleteAllEventLogs({
						dataSource,
						deviceMacAddress: selectedDeviceRef.current.deviceMacAddress,
					}),
				);
			}
			setEventLogs([]);
			setFilteredAllLogs([]);
			setFilteredFaultLogs([]);
			setFilteredUserActionLogs([]);
			setFilteredSystemLogs([]);
			setFilteredAlarmLogs([]);
			FilteredLogs.current = [];
			await delay(500); // Simulate a delay for better UX
			hideLoadingIndicator();
		} catch (error) {
			setEventLogs([]);
			setFilteredAllLogs([]);
			setFilteredFaultLogs([]);
			setFilteredUserActionLogs([]);
			setFilteredSystemLogs([]);
			setFilteredAlarmLogs([]);
			FilteredLogs.current = [];
		}
	}
	async function GetMoreLogsCommandAsync() {
		try {
			if (_isLogsLoaded.current) {
				_isLogsLoaded.current = false;
				showLoadingIndicator(t('Downloading Logs'));
				setSelectedTab(Const_All);
				FilteredLogs.current = FilteredAllLogs;
				const tempLogs = await GetLogs();
				FilteredLogs.current = tempLogs;
				setEventLogs(tempLogs);
				delay(500); // Simulate a delay for better UX
				hideLoadingIndicator();
				_isLogsLoaded.current = true;
			}
		} catch (error) {
			_isLogsLoaded.current = true;
			hideLoadingIndicator();
		}
	}

	async function GetLogs(): Promise<EventLogModel[]> {
		let filteredLogs: EventLogModel[] = [];
		let isFirstLogFetchFailed = false;
		let logs: EventLogModel[] = [];
		try {
			if (ConnectedDeviceobj.current !== null) {
				if (
					deviceTypeRef.current ===
					getDeviceTypeDescription(DeviceType.eIntelligent)
				) {
					//#region Intelligent faastflex Device Logs Fetch Logic
					let currentLogNumber = 0;
					if (
						FilteredLogs.current !== null &&
						FilteredLogs.current.length > 0
					) {
						if (
							FilteredLogs.current.length === 1 &&
							FilteredLogs.current[0].showErrorMessage
						) {
							FilteredLogs.current = [];
							currentLogNumber = 0;
						} else {
							currentLogNumber =
								FilteredLogs.current[FilteredLogs.current.length - 1].Id;
						}
						logs = FilteredLogs.current;
					}
					const seqIDToDownload: number[] = [];
					for (let i = 0; i < 10; i++) {
						seqIDToDownload.push(currentLogNumber + i);
					}
					for (const i of seqIDToDownload) {
						if (isDeviceResponding.current) {
							// Get recent logs from device
							const trendLogMSB = (i >> 8) & 0xff;
							const trendLogLSB = i & 0xff;
							var tempLog =
								await faastflexBluetoothCommunicator.GetFFIRecentlogs(
									trendLogLSB,
									trendLogMSB,
								);
							let eventLog = tempLog.eventLog;

							// Set properties
							eventLog.eventTypeStr = eventLog.eventTypeStr;
							eventLog.eventDescription = eventLog.eventDescription;
							eventLog.showErrorMessage = eventLog.logId === 0;
							eventLog.Id = i + 1;
							eventLog.addtionalInfo = eventLog.addtionalInfo;
							logs.push(eventLog);
						} else {
							break;
						}
					}
					//#endregion
				} else {
					//#region Conventional faastflex Logs Fetch Logic
					const allLogs = await dispatch(
						fetchAllLogsWithMAC({
							dataSource,
							deviceMacAddress: selectedDeviceRef.current.deviceMacAddress,
						}),
					).unwrap();
					let fetchedlog: EventLogModel = new EventLogModel();
					if (isDeviceResponding.current) {
						const trendLogMSB = (1 >> 8) & 0xff;
						const trendLogLSB = 1 & 0xff;
						var tempLog = await faastflexBluetoothCommunicator.GetRecentlogs(
							trendLogLSB,
							trendLogMSB,
						);
						fetchedlog = tempLog.eventLog;
					}
					let dBSeqIdList: number[] = [];
					let seqIDToDownload: number[] = [];
					if (allLogs !== null && allLogs.length > 0) {
						allLogs.forEach(log => {
							if (log.logId && log.logId > 0) {
								dBSeqIdList.push(log.logId);
							}
						});
					}
					if (dBSeqIdList !== null) {
						if (fetchedlog.logId > 0) {
							for (let j = fetchedlog.logId; j >= 0; j--) {
								if (dBSeqIdList.length > 0) {
									// If the ID is not in the database, add it to download list
									if (!dBSeqIdList.includes(j)) {
										seqIDToDownload.push(fetchedlog.logId - j + 1);
									}
								} else {
									// If no logs in database, add all IDs to download list
									seqIDToDownload.push(fetchedlog.logId - j + 1);
								}

								// Limit to downloading 10 logs at a time
								if (seqIDToDownload.length >= 10) {
									break;
								}
							}
						} else {
							isFirstLogFetchFailed = true;
						}
					}

					if (seqIDToDownload && seqIDToDownload.length > 0) {
						for (const i of seqIDToDownload) {
							if (isDeviceResponding.current) {
								// Update the database primary key
								dbPrimaryKey.current = allLogs.length + 1;

								// Get recent logs from device
								const trendLogMSB = (i >> 8) & 0xff;
								const trendLogLSB = i & 0xff;
								var tempLog =
									await faastflexBluetoothCommunicator.GetRecentlogs(
										trendLogLSB,
										trendLogMSB,
									);
								let eventLog = tempLog.eventLog;

								// Set properties
								eventLog.eventTypeStr = eventLog.eventTypeStr;
								eventLog.eventDescription = eventLog.eventDescription;
								eventLog.showErrorMessage = eventLog.logId === 0;
								eventLog.Id = dbPrimaryKey.current;
								eventLog.addtionalInfo = eventLog.addtionalInfo;

								// Save log if it doesn't exist or is an error message
								if (
									!allLogs.some(x => x.logId === eventLog.logId) ||
									eventLog.showErrorMessage
								) {
									await SaveLogsInDB(eventLog);
								}
							} else {
								break;
							}
						}
					}

					logs = await dispatch(
						fetchAllLogsWithMAC({
							dataSource,
							deviceMacAddress: selectedDevice.deviceMacAddress,
						}),
					).unwrap();
					//#endregion
				}
				filteredLogs = GetFilteredLogs(logs);
				setSelectedTab(Const_All);
				if (isFirstLogFetchFailed) {
					const errorLog = {
						showErrorMessage: true,
						eventBarColor: '#FFD153',
					} as EventLogModel;

					filteredLogs.push(errorLog);
					isFirstLogFetchFailed = false;
				}
				return filteredLogs;
			} else {
				Toast.show({
					type: 'error',
					text1: t('PlsConnectDevice'),
					position: 'bottom',
				});
				return filteredLogs;
			}
		} catch (error) {
			filteredLogs = [];
			if (
				deviceTypeRef.current ===
				getDeviceTypeDescription(DeviceType.eIntelligent)
			) {
				_isLogsLoaded.current = true;
				hideLoadingIndicator();
				return filteredLogs;
			} else {
				const logs = await dispatch(
					fetchAllLogsWithMAC({
						dataSource,
						deviceMacAddress: selectedDevice.deviceMacAddress,
					}),
				).unwrap();
				if (logs !== null && logs.length > 0) {
					filteredLogs = GetFilteredLogs(logs);
					setSelectedTab(Const_All);
				}
				_isLogsLoaded.current = true;
				hideLoadingIndicator();
				return filteredLogs;
			}
		}
	}
	async function SaveLogsInDB(eventLog: EventLogModel) {
		try {
			// Set the eventLog ID to the current primary key value
			eventLog.Id = dbPrimaryKey.current;
			eventLog.deviceMacAddress = selectedDeviceRef.current.deviceMacAddress;
			var obj = await dispatch(addNewEventLog({ dataSource, eventLog }));
		} catch (error) {
			_isLogsLoaded.current = true;
			hideLoadingIndicator();
		}
	}
	function LogsAll(tab: string) {
		if (tab !== Const_All) {
			setSelectedTab(Const_All);
			setEventLogs(FilteredAllLogs);
		}
	}
	function LogsFaultAndAlert(tab: string) {
		if (tab !== Const_FaultsAndAlerts) {
			setSelectedTab(Const_FaultsAndAlerts);
			setEventLogs(FilteredFaultLogs);
		}
	}
	function LogsUserAction(tab: string) {
		if (tab !== Const_UserAction) {
			setSelectedTab(Const_UserAction);
			setEventLogs(FilteredUserActionLogs);
		}
	}
	function LogsSystem(tab: string) {
		if (tab !== Const_System) {
			setSelectedTab(Const_System);
			setEventLogs(FilteredSystemLogs);
		}
	}
	function LogsAlarm(tab: string) {
		if (tab !== Const_Alarms) {
			setSelectedTab(Const_Alarms);
			setEventLogs(FilteredAlarmLogs);
		}
	}
	// Tab options

	const logFilters = [
		{ id: Const_All, label: t('all') },
		{ id: Const_Alarms, label: t('alarms') },
		{ id: Const_FaultsAndAlerts, label: t('lblFaultandAlert') },
		{ id: Const_System, label: t('lblSystem') },
		{ id: Const_UserAction, label: t('lblUserAction') },
	];
	const renderLogItem = ({ item }: { item: EventLogModel }) => {
		if (item.showErrorMessage) {
			return (
				<View style={styles.logItemContainer}>
					<View
						style={[styles.logItemBar, { backgroundColor: item.eventBarColor }]}
					/>
					<View style={styles.logItemContent}>
						<Text style={styles.logErrorText}>{t('LogDisplayErrorMsg')}</Text>
					</View>
				</View>
			);
		}

		return (
			<View style={styles.logItemContainer}>
				<View
					style={[styles.logItemBar, { backgroundColor: item.eventBarColor }]}
				/>
				<View style={styles.logItemContent}>
					<View style={styles.logItemTopRow}>
						<Text style={styles.logItemTitle}>
							{item.eventTypeStr} - {item.eventDescription}
						</Text>
						<Text style={styles.logItemTime}>{item.eventTime}</Text>
					</View>
					<View style={styles.logItemMiddleRow}>
						<Text style={styles.logItemIdInfo}>{item.eventIdInfo}</Text>
						<Text style={styles.logItemDate}>{item.eventDate}</Text>
					</View>
					<View style={styles.logItemBottomRow}>
						<Text style={styles.logItemAdditionalInfo}>
							{item.addtionalInfo}
						</Text>
					</View>
				</View>
			</View>
		);
	};
	const loadMoreLogs = () => {
		// Implement your logic to load more logs
		// For now, just simulating a delay
		setTimeout(() => {
			// Add more logs to the existing list
		}, 1000);
	};

	//#region Mirror HMI Commands

	async function ResetCommand() {
		if (ConnectedDeviceobj.current !== null) {
			var answer = await confirmAlert(
				t('resetconfirmation'),
				t('resetdevice'),
				t('reset'),
				t('cancel'),
			);
			if (answer) {
				IsMirrorHMIResetCommand.current = true;
				setConfigModalVisible(true);
			}
			setIsMirrorHMIVisible(false);
		} else {
			Toast.show({
				type: 'error',
				text1: t('PlsConnectDevice'),
				position: 'bottom',
			});
		}
	}

	async function ResetDeviceCommand() {
		try {
			setMirrorHMILoadingIndicator(true);
			setMirrorHMILoadingMessage(t('ResettingDevice'));
			var resetDeviceResult =
				await faastflexBluetoothCommunicator.ResetDevice();
			setMirrorHMILoadingIndicator(false);
			setMirrorHMILoadingMessage('');

			if (resetDeviceResult.isReset) {
				Toast.show({
					type: 'success',
					text1: t('ResetDeviceCommandSentSuccessfully'),
					position: 'bottom',
				});
			} else {
				Toast.show({
					type: 'error',
					text1: t('ResetDeviceCommandFailed'),
					position: 'bottom',
				});
			}
			IsMirrorHMIResetCommand.current = false;
			if (autoRefreshTimer.current != null) {
				stopTimer();
			}
			if (IsAutoRefreshEnabledRef.current) {
				autoRefreshTimerCounter.current = 0;
				startTimer();
				setSyncImage('Sync_Active.png');
			}
			setMirrorHMILoadingIndicator(false);
			setMirrorHMILoadingMessage('');
		} catch (error) {
			setMirrorHMILoadingIndicator(false);
			setMirrorHMILoadingMessage('');
		}
	}
	async function ValidateChinaSelfTestCommand() {
		if (ConnectedDeviceobj.current !== null) {
			setIsMirrorHMIVisible(false);
			setConfigModalVisible(true);
			IsSelfTestChina.current = true;
		}
	}
	async function SelfTestCommand() {
		try {
			IsSelfTestChina.current = false;
			if (ConnectedDeviceobj.current !== null) {
				var answer = await confirmAlert(
					t('selftestconfirmation'),
					t('selftestdevice'),
					t('start'),
					t('cancel'),
				);
				if (answer) {
					setMirrorHMILoadingIndicator(true);
					setMirrorHMILoadingMessage(t('InitiatingSelfTest'));
					if (IsDeviceCountryCodeChina) {
						var selftestChinaResult =
							await faastflexBluetoothCommunicator.StartSelfTestForChina();
						setMirrorHMILoadingIndicator(false);
						setMirrorHMILoadingMessage('');
						if (selftestChinaResult.isStarted) {
							Toast.show({
								type: 'success',
								text1: t('SelfTestCommandSentSuccessfully'),
								position: 'bottom',
							});
						} else {
							Toast.show({
								type: 'error',
								text1: t('SelfTestCommandFailed'),
								position: 'bottom',
							});
						}
						setMirrorHMILoadingIndicator(false);
						setMirrorHMILoadingMessage('');
					} else {
						setMirrorHMILoadingIndicator(false);
						setMirrorHMILoadingMessage('');
						Toast.show({
							type: 'error',
							text1: t('PlsConnectDevice'),
							position: 'bottom',
						});
					}
				}
			}
		} catch (error) {
			setMirrorHMILoadingIndicator(false);
			setMirrorHMILoadingMessage('');
		}
	}
	async function SilenceCommand() {
		try {
			if (ConnectedDeviceobj.current !== null) {
				var answer = await confirmAlert(
					t('silenceconfirmation'),
					t('silencedevice'),
					t('silence'),
					t('cancel'),
				);
				if (answer) {
					setMirrorHMILoadingIndicator(true);
					setMirrorHMILoadingMessage(t('SilencingDevice'));
					var silenceResult =
						await faastflexBluetoothCommunicator.SilenceDeviceBuzzerChina();
					setMirrorHMILoadingIndicator(false);
					setMirrorHMILoadingMessage('');
					if (silenceResult.isStarted) {
						Toast.show({
							type: 'success',
							text1: t('SilenceDeviceCommandSentSuccessfully'),
							position: 'bottom',
						});
					} else {
						Toast.show({
							type: 'error',
							text1: t('SilenceDeviceCommandFailed'),
							position: 'bottom',
						});
					}
				}
			} else {
				Toast.show({
					type: 'error',
					text1: t('PlsConnectDevice'),
					position: 'bottom',
				});
			}
		} catch (error) {
			setMirrorHMILoadingIndicator(false);
			setMirrorHMILoadingMessage('');
		}
	}

	let _isDeviceRefreshing = false;
	async function RefreshDeviceStatusCommand() {
		try {
			if (_isDeviceRefreshing) {
				return;
			}
			_isDeviceRefreshing = true;
			if (ConnectedDeviceobj.current !== null) {
				var deviceModeResult =
					await faastflexBluetoothCommunicator.GetDeviceMode();
				if (deviceModeResult.deviceMode === DeviceStatus.MAIN_FSM_SERVICE) {
					Alert.alert(t('Error'), t('DeviceServiceModeErrorMsg'), [
						{ text: t('OK') },
					]);
					return;
				}
				setMirrorHMILoadingIndicator(true);
				setMirrorHMILoadingMessage(t('ReadingDeviceStatus'));
				await GetDeviceStatus();
				await delay(500); // Give time for better UX
				setMirrorHMILoadingIndicator(false);
				setMirrorHMILoadingMessage('');
			}
		} catch (error) {
			setMirrorHMILoadingIndicator(false);
			setMirrorHMILoadingMessage('');
		}
	}

	async function GetDeviceStatus() {
		try {
			let deviceData: FaastFlexDeviceStatus | null = null;
			const isHigherFirmware = await GetDeviceFirmware();
			if (
				deviceTypeRef.current === getDeviceTypeDescription(DeviceType.eUnknown)
			) {
				await CheckDeviceType();
			}
			if (
				deviceTypeRef.current ===
				getDeviceTypeDescription(DeviceType.eIntelligent)
			) {
				const status22Result =
					await faastflexBluetoothCommunicator.getFFIDeviceStatusData();
				deviceData = status22Result.deviceStatus;
			} else {
				if (isHigherFirmware) {
					const status22Result =
						await faastflexBluetoothCommunicator.getDeviceStatusData22();
					deviceData = status22Result.deviceStatus;
				} else {
					const statusResult =
						await faastflexBluetoothCommunicator.getDeviceStatusData();
					deviceData = statusResult.deviceStatus;
				}
			}
			if (deviceData !== null) {
				const temp_deviceStatus = deviceData.DeviceStatus;
				const temp_deviceStatusStr = t(
					getDeviceStatusDescription(temp_deviceStatus),
				);
				const temp_channels = deviceData.Channels;
				if (temp_channels > 1) setIsDualChannelDevice(true);

				const temp_countrycode = getCountryDescription(deviceData.Country);
				const countryDescription = stringFunction.isStringNullOrEmpty(
					selectedDevice.deviceCountryCode,
				)
					? getCountryDescription(Country.Unknown)
					: selectedDevice.deviceCountryCode;
				setDeviceCountry(countryDescription);

				if (temp_countrycode === getCountryDescription(Country.EU)) {
					setIsDeviceCountryCodeChina(false);
				} else if (temp_countrycode === getCountryDescription(Country.CHINA)) {
					setIsDeviceCountryCodeChina(true);
				}
				let temp_deviceState = DeviceState.eUnknown;
				const ledstatus = deviceData.LEDStatus;
				if (ledstatus != null && ledstatus.length > 1) {
					setAlarmLEDStatus1(ledstatus[0]);
					setPreAlarmLEDStatus1(ledstatus[1]);
					setAlarmLEDStatus2(ledstatus[2]);
					setPreAlarmLEDStatus2(ledstatus[3]);
					setFaultLEDStatus(ledstatus[4]);
					if (isHigherFirmware) {
						setAlertStatus(ledstatus[5]);
					}
					if (ledstatus[0] === Const_ACTIVE || ledstatus[2] === Const_ACTIVE) {
						temp_deviceState = DeviceState.eAlarm;
					} else if (
						ledstatus[1] === Const_ACTIVE ||
						ledstatus[3] === Const_ACTIVE
					) {
						temp_deviceState = DeviceState.eAction;
					} else if (isHigherFirmware && ledstatus[5] === Const_ACTIVE) {
						temp_deviceState = DeviceState.eAlert;
					} else if (ledstatus[4] === Const_ACTIVE) {
						temp_deviceState = DeviceState.eFault;
					} else {
						temp_deviceState = DeviceState.eNormal;
					}
				} else {
					temp_deviceState = DeviceState.eUnknown;
				}
				const temp_deviceStateString = t(
					getDeviceStateDescription(temp_deviceState),
				);

				const temp_deviceConfig = deviceData.DeviceConfiguration;
				const temp_deviceConfigString = t(
					getConfigurationDescription(temp_deviceConfig),
				);
				const temp_relayEnabled = deviceData.RelayEnabled;
				const temp_relayEnabledString = t(
					getRelayEnabledDescription(temp_relayEnabled),
				);

				setSelectedDevice({
					deviceStatus: temp_deviceStatus,
					deviceStatusStr: temp_deviceStatusStr,
					deviceStateString: temp_deviceStateString,
					channels: temp_channels,
					deviceCountryCode: temp_countrycode,
					deviceState: temp_deviceState,
					deviceConfig: temp_deviceConfig,
					deviceConfigStr: temp_deviceConfigString,
					relayEnabled: temp_relayEnabled,
					relayEnabledStr: temp_relayEnabledString,
				});
			}
			hideLoadingIndicator();
		} catch (error) {
			Toast.show({
				type: 'error',
				text1: t('PlsConnectDevice'),
				position: 'bottom',
			});
			hideLoadingIndicator();
		}
	}
	//#endregion

	//#region More Tab - Device Information
	async function GetDeviceFirmware(): Promise<boolean> {
		let isFirmwareHigher = false;

		if (
			selectedDeviceRef.current.firmwareVersion != '' &&
			selectedDeviceRef.current.firmwareVersion.length > 0
		) {
			isFirmwareHigher =
				parseInt(selectedDeviceRef.current.firmwareVersion.split('.')[0]) >= 4;
		} else {
			if (ConnectedDeviceobj.current !== null) {
				const firmwareResult =
					await faastflexBluetoothCommunicator.GetFirmwareVersion();
				const majorVersion =
					firmwareResult.firmwareVersion !== '' &&
					firmwareResult.firmwareVersion.length > 0
						? parseInt(firmwareResult.firmwareVersion.split('.')[0])
						: 0;
				if (majorVersion > 0) {
					setSelectedDevice({
						firmwareVersion: firmwareResult.firmwareVersion,
					});
					await dispatch(
						updateExistingDevice({
							dataSource,
							deviceId: selectedDeviceRef.current.deviceId,
							updates: {
								firmwareVersion: firmwareResult.firmwareVersion,
							},
						}),
					);
					isFirmwareHigher = majorVersion >= 4;
				}
			}
		}
		return isFirmwareHigher;
	}
	async function GetDeviceRegionAndWorkingMode() {
		if (ConnectedDeviceobj.current !== null) {
			let deviceData: FaastFlexDeviceStatus | null = null;
			const isHigherFirmware = await GetDeviceFirmware();
			if (
				deviceTypeRef.current === getDeviceTypeDescription(DeviceType.eUnknown)
			) {
				await CheckDeviceType();
			}
			if (
				deviceTypeRef.current ===
				getDeviceTypeDescription(DeviceType.eIntelligent)
			) {
				const status22Result =
					await faastflexBluetoothCommunicator.getFFIDeviceStatusData();
				deviceData = status22Result.deviceStatus;
			} else {
				if (isHigherFirmware) {
					const status22Result =
						await faastflexBluetoothCommunicator.getDeviceStatusData22();
					deviceData = status22Result.deviceStatus;
				} else {
					const statusResult =
						await faastflexBluetoothCommunicator.getDeviceStatusData();
					deviceData = statusResult.deviceStatus;
				}
			}
			if (deviceData !== null) {
				switch (deviceData.DeviceStatus) {
					case DeviceStatus.MAIN_FSM_INITIALIZATION:
					case DeviceStatus.MAIN_FSM_SERVICE:
					case DeviceStatus.MAIN_FSM_PRODUCTION:
					case DeviceStatus.MAIN_FSM_WAIT:
					case DeviceStatus.MAIN_FSM_REBOOT:
					case DeviceStatus.MAIN_FSM_STATE_COUNT:
						setDeviceStateColor('#F9D311'); // Yellow
						break;
					case DeviceStatus.MAIN_FSM_NORMAL:
						setDeviceStateColor('#8CB55A'); // Green
						break;
					case DeviceStatus.MAIN_FSM_PROTECTION:
						setDeviceStateColor('#ff0000'); // Red
						break;
					default:
						setDeviceStateColor('');
						break;
				}
				if (selectedDeviceRef.current != null) {
					const deviceCountryCode = getCountryDescription(deviceData.Country);
					if (
						deviceData.Country !== Country.Unknown ||
						selectedDeviceRef.current.deviceCountryCode !==
							getCountryDescription(deviceData.Country)
					) {
						await dispatch(
							updateExistingDevice({
								dataSource,
								deviceId: selectedDeviceRef.current.deviceId,
								updates: {
									deviceCountryCode: deviceCountryCode,
								},
							}),
						);
					}
					setSelectedDevice({
						deviceCountryCode: deviceCountryCode,
					});
				}
			}
		}
	}
	//#endregion

	//#region Validate L3 Passcode

	async function ValidateL3PasscodeAsync() {
		var passcode = passwordValues.join('');
		if (passcode.length < 6) {
			Alert.alert(t('password'), t('PWDLengthErrorMessage'), [
				{ text: t('ok') },
			]);
		} else {
			setConfigModalVisible(false);
			if (ConnectedDeviceobj.current !== null) {
				showLoadingIndicator(t('ValidatingPassword'));
				var pwdResult =
					await faastflexBluetoothCommunicator.SendFaastflexDevicePassword(
						passcode,
					);
				hideLoadingIndicator();
				if (pwdResult.passwordValid === PasswordValid.eValid) {
					if (IsMirrorHMIResetCommand.current) {
						Toast.show({
							type: 'success',
							text1: t('PasswordAuthenticated'),
							position: 'bottom',
						});
						ResetDeviceCommand();
					} else if (IsSelfTestChina.current) {
						Toast.show({
							type: 'success',
							text1: t('PasswordAuthenticated'),
							position: 'bottom',
						});
						SelfTestCommand();
					} else if (IsReportGeneration.current) {
						Toast.show({
							type: 'success',
							text1: t('PasswordAuthenticated'),
							position: 'bottom',
						});
						setIsGenerateReportVisible(false);
						ExportandShareLogs();
					} else {
						stopTimer();
						if (IsConfigurePage.current) {
							if (
								deviceTypeRef.current ===
								getDeviceTypeDescription(DeviceType.eIntelligent)
							) {
								navigation.navigate(AppConstants.FFIDeviceParameterScreen, {
									selectedItem: selectedDeviceRef.current,
									connectedDevice: ConnectedDeviceobj.current,
								});
							} else {
								navigation.navigate(AppConstants.DeviceParameterScreen, {
									selectedItem: selectedDeviceRef.current,
									connectedDevice: ConnectedDeviceobj.current,
								});
							}
						} else {
							navigation.navigate(AppConstants.DeviceTestScreen, {
								selectedItem: selectedDeviceRef.current,
								connectedDevice: ConnectedDeviceobj.current,
							});
						}
					}
				} else if (pwdResult.passwordValid === PasswordValid.ePasswordDelay) {
					passcode = '';
					Toast.show({
						type: 'error',
						text1: t('PasswordDelayErrorMsg'),
						position: 'bottom',
					});
				} else {
					passcode = '';
					Toast.show({
						type: 'error',
						text1: t('PlsEnterCorrectPWD'),
						position: 'bottom',
					});
				}
				setPasswordValues(['', '', '', '', '', '']);
			} else {
				passcode = '';
				Toast.show({
					type: 'error',
					text1: t('PlsConnectDevice'),
					position: 'bottom',
				});
			}
			passcode = '';
			setPasswordValues(['', '', '', '', '', '']);
		}
	}
	async function CancelPasswordCommandasync() {
		setConfigModalVisible(false);
		setPasswordValues(['', '', '', '', '', '']);
		IsMirrorHMIResetCommand.current = false;
		IsSelfTestChina.current = false;
		IsReportGeneration.current = false;
	}

	//#endregion

	//#region Report Generation
	async function StartReportGeneration() {
		setIsGenerateReportVisible(true);
		setSelectedFilter(Const_All);
		ExportLogs.current = FilteredLogs.current;
	}
	async function ExportLogGenerateCommand() {
		//TODO Check Storage Access
		setIsGenerateReportVisible(false);
		setConfigModalVisible(true);
		IsReportGeneration.current = true;
	}
	function onLogsFilterCancel(): void {
		setIsGenerateReportVisible(false);
	}

	function handleSelectFilter(id: any): void {
		setSelectedFilter(id);
		switch (id) {
			case Const_All:
				ExportLogs.current = FilteredAllLogs;
				break;
			case Const_UserAction:
				ExportLogs.current = FilteredUserActionLogs;
				break;
			case Const_System:
				ExportLogs.current = FilteredSystemLogs;
				break;
			case Const_Alarms:
				ExportLogs.current = FilteredAlarmLogs;
				break;
			case Const_FaultsAndAlerts:
				ExportLogs.current = FilteredFaultLogs;
				break;
			default:
				ExportLogs.current = FilteredAllLogs;
				break;
		}
	}

	async function GetReportDiagnosticInfo(): Promise<void> {
		try {
			// Model Type
			const deviceTypeResult =
				await faastflexBluetoothCommunicator.GetDeviceType();
			Report_ModelType.current = deviceTypeResult.deviceType || 'NA';
			await delay(20);

			// Serial Number
			const serialNumberResult =
				await faastflexBluetoothCommunicator.GetSerialNumber();
			Report_SerialNumber.current = serialNumberResult.serialNumber || 'NA';
			await delay(20);

			// Number of Channels
			Report_Channels.current = selectedDevice.channels.toString();
			await delay(20);

			// Production Date
			const productionDateResult =
				await faastflexBluetoothCommunicator.GetProductionDate();
			if (
				productionDateResult.productionDate &&
				productionDateResult.error === ErrorCode.eOK &&
				productionDateResult.productionDate !== 'Unknown'
			) {
				const dateParts = productionDateResult.productionDate.split(' ');
				const date = dateParts[0];
				const time = dateParts[2];

				const dateSplit = date.split('-');
				Report_PDay.current = dateSplit[0];
				Report_PMonth.current = dateSplit[1];
				Report_PYear.current = dateSplit[2];

				const timeSplit = time.split(':');
				Report_PHour.current = timeSplit[0];
				Report_PMinute.current = timeSplit[1];
				Report_PSecond.current = timeSplit[2];
			} else {
				Report_PDay.current = '00';
				Report_PMonth.current = '00';
				Report_PYear.current = '00';
				Report_PHour.current = '00';
				Report_PMinute.current = '00';
				Report_PSecond.current = '00';
			}
			await delay(20);

			// Firmware Version
			const firmwareResult =
				await faastflexBluetoothCommunicator.GetFirmwareVersion();
			if (firmwareResult.firmwareVersion) {
				const firmwareParts = firmwareResult.firmwareVersion.split('.');
				Report_FWversion.current = firmwareResult.firmwareVersion;
				Report_FWRelease.current = firmwareParts[0] || '0';
				Report_FWMajor.current = firmwareParts[1] || '0';
				Report_FWMinor.current = firmwareParts[2] || '0';
				Report_FWBuild.current = firmwareParts[3] || '0';
			} else {
				Report_FWversion.current = '0.0.0.0';
				Report_FWRelease.current = '0';
				Report_FWMajor.current = '0';
				Report_FWMinor.current = '0';
				Report_FWBuild.current = '0';
			}

			// Model Number
			const modelTypeResult =
				await faastflexBluetoothCommunicator.GetModelType();
			Report_Model.current = modelTypeResult.modelType || 'NA';
			Report_Configuration.current = getConfigurationDescription(
				selectedDevice.deviceConfig,
			);

			// Device Orientation
			const orientationResult =
				await faastflexBluetoothCommunicator.GetDeviceOrientation();
			Report_Orientation.current = orientationResult.deviceOrientation || 'NA';

			// Channel information
			if (
				selectedDevice.listOfChannels &&
				selectedDevice.listOfChannels.length > 0
			) {
				const channel1 = selectedDevice.listOfChannels[0];

				Report_Ch1Alarm.current =
					channel1.alarmLevel > 0 ? channel1.alarmLevel.toString() : '0';
				Report_Ch1Action.current =
					channel1.preAlarmLevel > 0 ? channel1.preAlarmLevel.toString() : '0';
				Report_Ch1Reference.current =
					channel1.refFlowRate > 0
						? `${channel1.refFlowRate} l/min`
						: '0 l/min';
				Report_Ch1MinFlow.current =
					channel1.minFlowRate > 0
						? `${channel1.minFlowRate} l/min`
						: '0 l/min';
				Report_Ch1MaxFlow.current =
					channel1.maxFlowRate > 0
						? `${channel1.maxFlowRate} l/min`
						: '0 l/min';

				if (IsChannel2AvailableRef.current) {
					const channel2 = selectedDevice.listOfChannels[1];
					Report_Ch2Alarm.current =
						channel2.alarmLevel > 0 ? channel2.alarmLevel.toString() : '0';
					Report_Ch2Action.current =
						channel2.preAlarmLevel > 0
							? channel2.preAlarmLevel.toString()
							: '0';
					Report_Ch2Reference.current =
						channel2.refFlowRate > 0
							? `${channel2.refFlowRate} l/min`
							: '0 l/min';
					Report_Ch2MinFlow.current =
						channel2.minFlowRate > 0
							? `${channel2.minFlowRate} l/min`
							: '0 l/min';
					Report_Ch2MaxFlow.current =
						channel2.maxFlowRate > 0
							? `${channel2.maxFlowRate} l/min`
							: '0 l/min';
				}
			} else {
				Report_Ch1Alarm.current = '0';
				Report_Ch1Action.current = '0';
				Report_Ch1Reference.current = '0 l/min';
				Report_Ch1MinFlow.current = '0 l/min';
				Report_Ch1MaxFlow.current = '0 l/min';
				Report_Ch2Alarm.current = '0';
				Report_Ch2Action.current = '0';
				Report_Ch2Reference.current = '0 l/min';
				Report_Ch2MinFlow.current = '0 l/min';
				Report_Ch2MaxFlow.current = '0 l/min';
			}
			await delay(20);

			// GPI Information
			var deviceGPIParams = new DeviceGPIParams();
			var result = await faastflexBluetoothCommunicator.GetDeviceGPIParams();
			if (result.error === ErrorCode.eOK && result) {
				deviceGPIParams = result.gpiParams;
				Report_GPIInput.current =
					deviceGPIParams.GPIExternalInput ===
					ExternalInputMode.eBalanced_Open_or_Short_eol
						? 'Supervised'
						: deviceGPIParams.GPIExternalInput ===
						  ExternalInputMode.eUnbalanced_Open_or_Short
						? 'Unsupervised'
						: 'Unknown';
				if (
					deviceGPIParams.GPIExternalInput ===
					ExternalInputMode.eBalanced_Open_or_Short_eol
				) {
					Report_SupervisedOpen.current = getExternalInputActionDescription(
						deviceGPIParams.SupervisedExternalTriggerOnOpen,
					);
					Report_SupervisedClosed.current = getExternalInputActionDescription(
						deviceGPIParams.SupervisedExternalTriggerOnClosed,
					);
				} else {
					Report_UnSupervisedInput.current =
						getExternalInputNormalStateDescription(
							deviceGPIParams.UnSupervisedNormalState,
						);
					Report_UnSupervisedAction.current = getExternalInputActionDescription(
						deviceGPIParams.UnSupervisedEventTriggered,
					);
				}
			} else {
				Report_GPIInput.current = 'Unknown';
				Report_SupervisedOpen.current = 'Unknown';
				Report_SupervisedClosed.current = 'Unknown';
			}

			// Blower Speed
			const blowerSpeedResult =
				await faastflexBluetoothCommunicator.GetBlowerSpeed();
			Report_BlowerSpeed.current =
				blowerSpeedResult.fanSpeedLevel !== FanSpeedLevel.eUnknown
					? blowerSpeedResult.fanSpeedLevel == FanSpeedLevel.eLevel_7 ||
					  blowerSpeedResult.fanSpeedLevel == FanSpeedLevel.eLevel_8 ||
					  blowerSpeedResult.fanSpeedLevel == FanSpeedLevel.eLevel_9 ||
					  blowerSpeedResult.fanSpeedLevel == FanSpeedLevel.eLevel_10
						? 'High'
						: 'Low'
					: 'Unknown';

			// Blower Correction
			//TODO : Implementation Missing
			const correctionResult =
				await faastflexBluetoothCommunicator.GetBlowerSpeedCorrection();
			Report_BlowerCorrection.current =
				getFanPWMPercCorrectionDescription(
					correctionResult.fanCorrectionValue,
				) || 'NA';

			// Power Supply
			const powerVoltageResult =
				await faastflexBluetoothCommunicator.GetPowerVoltage();
			Report_PowerSupply.current = powerVoltageResult.powerVoltage || 'NA';
			await delay(20);

			// Device State
			const isHigherFirmware = parseInt(Report_FWRelease.current) >= 4;
			let deviceData;

			if (
				deviceTypeRef.current === getDeviceTypeDescription(DeviceType.eUnknown)
			) {
				await CheckDeviceType();
			}
			if (
				deviceTypeRef.current ===
				getDeviceTypeDescription(DeviceType.eIntelligent)
			) {
				const status22Result =
					await faastflexBluetoothCommunicator.getFFIDeviceStatusData();
				deviceData = status22Result.deviceStatus;
			} else {
				if (isHigherFirmware) {
					const status22Result =
						await faastflexBluetoothCommunicator.getDeviceStatusData22();
					deviceData = status22Result.deviceStatus;
				} else {
					const statusResult =
						await faastflexBluetoothCommunicator.getDeviceStatusData();
					deviceData = statusResult.deviceStatus;
				}
			}

			Report_DeviceState.current =
				deviceData && deviceData.LEDStatus && deviceData.LEDStatus.length > 4
					? deviceData.LEDStatus[4] === Const_ACTIVE
						? 'Yes'
						: 'No'
					: 'Unknown';

			// Disabled
			const relayEnabledResult =
				await faastflexBluetoothCommunicator.GetDeviceRelayEnabled();
			if (
				relayEnabledResult.relayEnabled !== undefined &&
				relayEnabledResult.relayEnabled !== RelayEnabled.Unknown
			) {
				Report_Disabled.current =
					relayEnabledResult.relayEnabled === RelayEnabled.Disabled
						? 'Yes'
						: 'No';
			} else {
				Report_Disabled.current = 'Unknown';
			}

			return;
		} catch (error) {
			hideLoadingIndicator();
			return;
		}
	}
	async function ExportandShareLogs() {
		try {
			IsReportGeneration.current = false;
			showLoadingIndicator(t('lblGeneratingReport'));
			const ret = await GetReportDiagnosticInfo();
			await delay(300); // Small delay for better UX
			const _isIntelligentDevice =
				deviceTypeRef.current ===
				getDeviceTypeDescription(DeviceType.eIntelligent);
			const logs = ExportLogs.current;

			// Create report content as a string
			let reportData = '';

			reportData += `-------------------------------------------\n`;
			reportData += `FAAST FLEX Diagnostic\t${new Date().toLocaleDateString()}\n`;
			reportData += `-------------------------------------------\n`;

			// INFO section
			const infoCompMaxLength = 'Number of channels'.length + 1;
			reportData += `----------------INFO-----------------\n`;
			reportData += `${'Model Type'.padEnd(infoCompMaxLength)}:\t${
				Report_ModelType.current
			}\n`;
			reportData += `${'Number of channels'.padEnd(infoCompMaxLength)}:\t${
				Report_Channels.current
			}\n`;
			reportData += `${'Standard'.padEnd(infoCompMaxLength)}:\t${
				selectedDevice.deviceCountryCode
			}\n`;
			reportData += `${'Model'.padEnd(infoCompMaxLength)}:\t${
				Report_Model.current
			}\n`;
			reportData += `${'Serial number'.padEnd(infoCompMaxLength)}:\t${
				Report_SerialNumber.current
			}\n`;
			reportData += `${'FW version'.padEnd(infoCompMaxLength)}:\t${
				Report_FWversion.current
			}\n`;
			reportData += `${'FW Release Version'.padEnd(infoCompMaxLength)}:\t${
				Report_FWRelease.current
			}\n`;
			reportData += `${'FW Major Version'.padEnd(infoCompMaxLength)}:\t${
				Report_FWMajor.current
			}\n`;
			reportData += `${'FW Minor Version'.padEnd(infoCompMaxLength)}:\t${
				Report_FWMinor.current
			}\n`;

			// Manufacturing Date
			const dateTimeMaxLength = 'SECOND'.length + 1;
			reportData += `-------------Manufacturing Date GMT-------------\n`;
			reportData += `${'DAY'.padEnd(dateTimeMaxLength)}:\t${
				Report_PDay.current
			}\n`;
			reportData += `${'MONTH'.padEnd(dateTimeMaxLength)}:\t${
				Report_PMonth.current
			}\n`;
			reportData += `${'YEAR'.padEnd(dateTimeMaxLength)}:\t${
				Report_PYear.current
			}\n`;
			reportData += `${'HOUR'.padEnd(dateTimeMaxLength)}:\t${
				Report_PHour.current
			}\n`;
			reportData += `${'MINUTE'.padEnd(dateTimeMaxLength)}:\t${
				Report_PMinute.current
			}\n`;
			reportData += `${'SECOND'.padEnd(dateTimeMaxLength)}:\t${
				Report_PSecond.current
			}\n`;

			// SETTINGS section
			const settingsMaxLength = 'GPI Event Triggered Closed'.length + 1;
			reportData += `--------------------SETTINGS--------------------\n`;
			reportData += `${'Configuration'.padEnd(settingsMaxLength)}:\t${
				Report_Configuration.current
			}\n`;
			reportData += `${'Detector orientation'.padEnd(settingsMaxLength)}:\t${
				Report_Orientation.current
			}\n`;
			if (!_isIntelligentDevice) {
				reportData += `${'Alarm level 1'.padEnd(settingsMaxLength)}:\t${
					Report_Ch1Alarm.current
				}\n`;
				reportData += `${'Action level 1'.padEnd(settingsMaxLength)}:\t${
					Report_Ch1Action.current
				}\n`;
			}

			reportData += `${'Reference flow 1'.padEnd(settingsMaxLength)}:\t${
				Report_Ch1Reference.current
			}\n`;
			reportData += `${'Minimum flow 1'.padEnd(settingsMaxLength)}:\t${
				Report_Ch1MinFlow.current
			}\n`;
			reportData += `${'Maximum flow 1'.padEnd(settingsMaxLength)}:\t${
				Report_Ch1MaxFlow.current
			}\n`;

			// Add channel 2 info if available
			if (selectedDevice.channels > 1) {
				if (!_isIntelligentDevice) {
					reportData += `${'Alarm level 2'.padEnd(settingsMaxLength)}:\t${
						Report_Ch2Alarm.current
					}\n`;
					reportData += `${'Action level 2'.padEnd(settingsMaxLength)}:\t${
						Report_Ch2Action.current
					}\n`;
				}

				reportData += `${'Reference flow 2'.padEnd(settingsMaxLength)}:\t${
					Report_Ch2Reference.current
				}\n`;
				reportData += `${'Minimum flow 2'.padEnd(settingsMaxLength)}:\t${
					Report_Ch2MinFlow.current
				}\n`;
				reportData += `${'Maximum flow 2'.padEnd(settingsMaxLength)}:\t${
					Report_Ch2MaxFlow.current
				}\n`;
			}

			// GPI info
			reportData += `${'GPI mode'.padEnd(settingsMaxLength)}:\t${
				Report_GPIInput.current
			}\n`;
			if (Report_GPIInput.current === 'Supervised') {
				reportData += `${'GPI Event Triggered Open'.padEnd(
					settingsMaxLength,
				)}:\t${Report_SupervisedOpen.current}\n`;
				reportData += `${'GPI Event Triggered Closed'.padEnd(
					settingsMaxLength,
				)}:\t${Report_SupervisedClosed.current}\n`;
			} else if (Report_GPIInput.current === 'Unsupervised') {
				reportData += `${'GPI Normal State'.padEnd(settingsMaxLength)}:\t${
					Report_UnSupervisedInput.current
				}\n`;
				reportData += `${'GPI Change State Action'.padEnd(
					settingsMaxLength,
				)}:\t${Report_UnSupervisedAction.current}\n`;
			} else {
				reportData += `${'GPI Normal State'.padEnd(settingsMaxLength)}:\t${
					Report_GPIInput.current
				}\n`;
				reportData += `${'GPI Change State Action'.padEnd(
					settingsMaxLength,
				)}:\t${Report_GPIInput.current}\n`;
			}

			reportData += `${'Blower speed'.padEnd(settingsMaxLength)}:\t${
				Report_BlowerSpeed.current
			}\n`;
			reportData += `${'Blower correction'.padEnd(settingsMaxLength)}:\t${
				Report_BlowerCorrection.current
			}\n`;

			// STATE section
			const stateMaxLength = 'Device in fault'.length + 1;
			reportData += `-------------------STATE------------------------\n`;
			reportData += `${'Device in fault'.padEnd(stateMaxLength)}:\t${
				Report_DeviceState.current
			}\n`;
			reportData += `${'Disabled'.padEnd(stateMaxLength)}:\t${
				Report_Disabled.current
			}\n`;
			reportData += ` \n`;
			reportData += `------------------------------------------------\n`;

			// Calculate column widths for log table
			const maxProgressLength = 'Progress'.length;
			const maxDateLength = 'Day-Month-Year'.length;
			const maxTimeLength = 'Hour:Minute:Second'.length;
			const maxEventLength = 'Event'.length;
			let maxEventDescLength = 'Event description'.length;
			const maxTemp1Length = 'Temperature 1'.length;
			const maxFlow1Length = 'Flow 1'.length;
			const maxSensor1Length = 'Sensor 1'.length;
			const maxTemp2Length = 'Temperature 2'.length;
			const maxFlow2Length = 'Flow 2'.length;
			const maxSensor2Length = 'Sensor 2'.length;
			const maxRPMLength = 'Blower RPM'.length;

			// Find the longest event description
			logs.forEach(row => {
				maxEventDescLength = Math.max(
					maxEventDescLength,
					row.eventDescription ? row.eventDescription.length : 0,
				);
			});

			// Add log table header and rows
			if (IsChannel2AvailableRef.current) {
				// Header for dual channel device
				reportData +=
					`${'Progress'.toUpperCase().padEnd(maxProgressLength)}\t` +
					`${'Day-Month-Year'.toUpperCase().padEnd(maxDateLength)}\t` +
					`${'Hour:Minute:Second'.toUpperCase().padEnd(maxTimeLength)}\t` +
					`${'Event'.toUpperCase().padEnd(maxEventLength)}\t` +
					`${'Event description'.toUpperCase().padEnd(maxEventDescLength)}\t` +
					`${'Temperature 1'.toUpperCase().padEnd(maxTemp1Length)}\t` +
					`${'Flow 1'.toUpperCase().padEnd(maxFlow1Length)}\t`;
				if (!_isIntelligentDevice) {
					reportData += `${'Sensor 1'
						.toUpperCase()
						.padEnd(maxSensor1Length)}\t`;
				}
				reportData +=
					`${'Temperature 2'.toUpperCase().padEnd(maxTemp2Length)}\t` +
					`${'Flow 2'.toUpperCase().padEnd(maxFlow2Length)}\t`;
				if (!_isIntelligentDevice) {
					reportData += `${'Sensor 2'
						.toUpperCase()
						.padEnd(maxSensor2Length)}\t`;
				}
				reportData += `${'Blower RPM'.toUpperCase().padEnd(maxRPMLength)}\n`;

				// Add log rows
				let id = 0;
				logs.forEach(row => {
					if (row.logId > 0) {
						reportData +=
							`${id.toString().padEnd(maxProgressLength)}\t` +
							`${(row.eventDate || 'NA').padEnd(maxDateLength)}\t` +
							`${(row.eventTime || 'NA').padEnd(maxTimeLength)}\t` +
							`${(row.logId > 0 ? row.logId.toString() : '0').padEnd(
								maxEventLength,
							)}\t` +
							`${(row.eventDescription || 'NA').padEnd(maxEventDescLength)}\t` +
							`${(row.ch1Temperature
								? row.ch1Temperature.toString()
								: 'NA'
							).padEnd(maxTemp1Length)}\t` +
							`${(row.ch1Flow ? row.ch1Flow.toString() : 'NA').padEnd(
								maxFlow1Length,
							)}\t`;
						if (!_isIntelligentDevice) {
							reportData += `${(row.ch1Sensor
								? row.ch1Sensor.toString()
								: 'NA'
							).padEnd(maxSensor1Length)}\t`;
						}
						reportData +=
							`${(row.ch2Temperature
								? row.ch2Temperature.toString()
								: 'NA'
							).padEnd(maxTemp2Length)}\t` +
							`${(row.ch2Flow ? row.ch2Flow.toString() : 'NA').padEnd(
								maxFlow2Length,
							)}\t`;
						if (!_isIntelligentDevice) {
							reportData += `${(row.ch2Sensor
								? row.ch2Sensor.toString()
								: 'NA'
							).padEnd(maxSensor2Length)}\t`;
						}
						reportData += `${(row.blowerRPM
							? row.blowerRPM.toString()
							: 'NA'
						).padEnd(maxRPMLength)}\n`;
						id++;
					}
				});
			} else {
				// Header for single channel device
				reportData +=
					`${'Progress'.toUpperCase().padEnd(maxProgressLength)}\t` +
					`${'Day-Month-Year'.toUpperCase().padEnd(maxDateLength)}\t` +
					`${'Hour:Minute:Second'.toUpperCase().padEnd(maxTimeLength)}\t` +
					`${'Event'.toUpperCase().padEnd(maxEventLength)}\t` +
					`${'Event description'.toUpperCase().padEnd(maxEventDescLength)}\t` +
					`${'Temperature 1'.toUpperCase().padEnd(maxTemp1Length)}\t` +
					`${'Flow 1'.toUpperCase().padEnd(maxFlow1Length)}\t`;
				if (!_isIntelligentDevice) {
					reportData += `${'Sensor 1'
						.toUpperCase()
						.padEnd(maxSensor1Length)}\t`;
				}
				reportData += `${'Blower RPM'.toUpperCase().padEnd(maxRPMLength)}\n`;

				// Add log rows
				let id = 0;
				logs.forEach(row => {
					if (row.logId > 0) {
						reportData +=
							`${id.toString().padEnd(maxProgressLength)}\t` +
							`${(row.eventDate || 'NA').padEnd(maxDateLength)}\t` +
							`${(row.eventTime || 'NA').padEnd(maxTimeLength)}\t` +
							`${(row.logId > 0 ? row.logId.toString() : '0').padEnd(
								maxEventLength,
							)}\t` +
							`${(row.eventDescription || 'NA').padEnd(maxEventDescLength)}\t` +
							`${(row.ch1Temperature
								? row.ch1Temperature.toString()
								: 'NA'
							).padEnd(maxTemp1Length)}\t` +
							`${(row.ch1Flow ? row.ch1Flow.toString() : 'NA').padEnd(
								maxFlow1Length,
							)}\t`;
						if (!_isIntelligentDevice) {
							reportData += `${(row.ch1Sensor
								? row.ch1Sensor.toString()
								: 'NA'
							).padEnd(maxSensor1Length)}\t`;
						}
						reportData += `${(row.blowerRPM
							? row.blowerRPM.toString()
							: 'NA'
						).padEnd(maxRPMLength)}\n`;
						id++;
					}
				});
			}
			const fileName = `FAAST_FLEX_Logs_D${dateFormat(
				new Date(),
				'dd MMMM yyyy',
			)}_T${dateFormat(new Date(), 'HH-mm-ss')}.txt`;

			// Get the proper directory path for iOS/Android
			const dirPath =
				Platform.OS === 'ios'
					? `${RNFS.DocumentDirectoryPath}`
					: `${RNFS.DownloadDirectoryPath}`;
			const filePath = `${dirPath}/${fileName}`;

			// Write the report to a file
			await RNFS.writeFile(filePath, reportData, 'utf8');
			await delay(100);

			hideLoadingIndicator();

			// Translate
			const share = await confirmAlert(
				t('txtReportgeneratedsuccessfully') + ' ' + filePath,
				t('lblReportGenerated'),
				t('Share'),
				t('Cancel_PascalCase'),
			);

			if (share) {
				try {
					const shareOptions = {
						title: t('lblReportGenerated'),
						url: Platform.OS === 'ios' ? filePath : `file://${filePath}`,
						type: 'text/plain',
						filename: fileName,
						failOnCancel: false, // Don't throw error if user cancels
					};

					await Share.open(shareOptions)
						.then(res => {
							console.log('Share result:', res);
							Toast.show({
								type: 'success',
								text1: t('lblReportGenerated'),
								text2: t('txtReportgeneratedsuccessfully'),
								position: 'bottom',
							});
						})
						.catch(error => {
							console.log('Share error:', error);
							if (
								error.message &&
								error.message.includes('User did not share')
							) {
								console.log('User cancelled share');
							} else {
								Alert.alert(t('warning'), t('msgPleaseTryAgain'), [
									{ text: t('ok') },
								]);
							}
						});
				} catch (error) {
					Alert.alert(t('warning'), t('msgPleaseTryAgain'), [
						{ text: t('ok') },
					]);
				}
			}
			setIsGenerateReportVisible(false);
		} catch (error: any) {
			delay(100);
			hideLoadingIndicator();
			Alert.alert(t('warning'), t('msgPleaseTryAgain'), [{ text: t('ok') }]);
		}
	}

	//#endregion

	const renderListFooter = () => {
		return (
			<TouchableOpacity
				style={styles.downloadButton}
				onPress={GetMoreLogsCommandAsync}>
				<Text style={styles.downloadButtonText}>{t('lblDownload')}</Text>
			</TouchableOpacity>
		);
	};
	const renderLogScreen = (): JSX.Element => {
		return (
			<View style={styles.logScreenContainer}>
				<View style={styles.logContainer}>
					{logFilters.map((tab, index) => (
						<TouchableOpacity
							key={tab.id}
							style={[
								styles.tabContainer,
								selectedTab === tab.id
									? styles.selectedTabContainer
									: styles.notSelectedTabContainer,
								index > 0 ? styles.overlappingTab : {},
							]}
							onPress={() => setSelectedTab(tab.id)}>
							<Text
								style={[
									styles.tabText,
									selectedTab === tab.id
										? styles.selectedTabText
										: styles.notSelectedTabText,
								]}>
								{tab.label}
							</Text>
						</TouchableOpacity>
					))}
				</View>

				<FlatList
					data={EventLogs}
					key={EventLogs.length}
					renderItem={renderLogItem}
					keyExtractor={(item, index) => index.toString()}
					style={styles.logList}
					contentContainerStyle={styles.logListContent}
					ListFooterComponent={renderListFooter}
				/>
			</View>
		);
	};

	const [selectedFilter, setSelectedFilter] = useState(Const_All);
	const generateReportFilterModal = () => {
		return (
			<Modal
				animationType='fade'
				transparent={true}
				visible={isGenerateReportVisible}
				onRequestClose={onLogsFilterCancel}>
				<View
					style={{
						flex: 1,
						justifyContent: 'center',
						alignItems: 'center',
						backgroundColor: 'rgba(0,0,0,0.5)',
					}}>
					<View style={styles.log_filterContainer}>
						<Text style={styles.log_filterTitle}>
							{t('txtSelectEventFilterToDownload')}
						</Text>

						{/* Filter Options */}
						{logFilters.map(filter => (
							<TouchableOpacity
								key={filter.id}
								style={styles.log_filterOption}
								onPress={() => handleSelectFilter(filter.id)}>
								<View style={styles.log_filterRow}>
									<View
										style={[
											styles.log_radioButton,
											selectedFilter === filter.id &&
												styles.log_radioButtonSelected,
										]}>
										{selectedFilter === filter.id && (
											<View style={styles.log_radioButtonInner} />
										)}
									</View>
									<Text style={styles.log_filterLabel}>{filter.label}</Text>
								</View>
							</TouchableOpacity>
						))}

						{/* Action Buttons */}
						<View style={styles.log_buttonContainer}>
							<TouchableOpacity
								style={[styles.log_cancelButton]}
								onPress={onLogsFilterCancel}>
								<Text style={styles.log_buttonText}>
									{t('Cancel_PascalCase')}
								</Text>
							</TouchableOpacity>

							<TouchableOpacity
								style={[styles.log_applyButton]}
								onPress={ExportLogGenerateCommand}>
								<Text style={[styles.log_applyButtonText]}>
									{t('btnApply')}
								</Text>
							</TouchableOpacity>
						</View>
					</View>
				</View>
			</Modal>
		);
	};
	//#endregion

	//#region Obscuration Table
	async function ObscurationTableCommand() {
		stopTimer();
		setShowObscurationTable(true);
	}

	async function ObscurationTableCloseCommand() {
		if (IsAutoRefreshEnabledRef.current) {
			autoRefreshTimerCounter.current = 0;
			startTimer();
			setSyncImage('sync.png');
		}

		setShowObscurationTable(false);
	}
	const obscurationData = [
		{
			level: 'Alarm level 0',
			imperial: '0.014% obs/ft',
			metric: '0.046% obs/m',
		},
		{
			level: 'Alarm level 1',
			imperial: '0.03% obs/ft',
			metric: '0.046% obs/m',
		},
		{
			level: 'Alarm level 2',
			imperial: '0.03% obs/ft',
			metric: '0.098% obs/m',
		},
		{
			level: 'Alarm level 3',
			imperial: '0.05% obs/ft',
			metric: '0.164% obs/m',
		},
		{
			level: 'Alarm level 4',
			imperial: '0.10% obs/ft',
			metric: '0.328% obs/m',
		},
		{
			level: 'Alarm level 5',
			imperial: '0.20% obs/ft',
			metric: '0.656% obs/m',
		},
		{
			level: 'Alarm level 6',
			imperial: '0.50% obs/ft',
			metric: '1.640% obs/m',
		},
		{
			level: 'Alarm level 7',
			imperial: '1.00% obs/ft',
			metric: '1.281% obs/m',
		},
		{
			level: 'Alarm level 8',
			imperial: '1.50% obs/ft',
			metric: '1.921% obs/m',
		},
		{
			level: 'Alarm level 9',
			imperial: '2.00% obs/ft',
			metric: '2.562% obs/m',
		},
	];

	const renderObscurationTable = () => {
		return (
			<Modal
				visible={showObscurationTable}
				transparent={true}
				animationType='slide'
				onRequestClose={() => setShowObscurationTable(false)}>
				<View style={styles.modalOverlay}>
					<View style={styles.modalContent}>
						<View style={styles.modalHeader}>
							<Text style={styles.modalTitle}>
								{t('lblObscurationDetails')}
							</Text>
							<TouchableOpacity
								style={[styles.closeButton, { marginBottom: 10 }]}
								onPress={() => ObscurationTableCloseCommand()}>
								<CloseIconGray height={20} width={20} />
							</TouchableOpacity>
						</View>
						<View style={styles.tableHeader}>
							<Text style={styles.headerText}>{t('lblALARMLEVEL')}</Text>
							<Text style={styles.headerText}>{t('lblImperialUnits')}</Text>
							<Text style={styles.headerText}>{t('lblMetricUnits')}</Text>
						</View>
						<FlatList
							data={obscurationData}
							keyExtractor={item => item.level}
							style={styles.tableContainer}
							renderItem={({ item, index }) => (
								<View
									style={[styles.tableRow, index % 2 === 0 && styles.evenrow]}>
									<Text style={styles.cellText}>{item.level}</Text>
									<Text style={styles.cellText}>{item.imperial}</Text>
									<Text style={styles.cellText}>{item.metric}</Text>
								</View>
							)}
						/>
					</View>
				</View>
			</Modal>
		);
	};

	//#endregion

	//#region  Graph Calculation

	//Get Device Measures

	async function fetchMeasures(type: string): Promise<DeviceMeasures> {
		let result;
		if (type === getDeviceTypeDescription(DeviceType.eIntelligent)) {
			result = await faastflexBluetoothCommunicator.GetFFIDeviceViewMeasures();
		} else {
			result = await faastflexBluetoothCommunicator.GetDeviceViewMeasures();
		}

		if (!result.devMeasures || result.error !== ErrorCode.eOK) {
			await delay(800);
			if (type === getDeviceTypeDescription(DeviceType.eIntelligent)) {
				result =
					await faastflexBluetoothCommunicator.GetFFIDeviceViewMeasures();
			} else {
				result = await faastflexBluetoothCommunicator.GetDeviceViewMeasures();
			}
		}
		return result.devMeasures;
	}
	async function GetDeviceMeasures(devModel: DeviceModel) {
		devModel.listOfChannels = [];
		const channel1 = new Channels();
		channel1.channel = 'Channel1'; //translate

		let deviceMeasures: DeviceMeasures | null = null;
		if (
			deviceTypeRef.current !== getDeviceTypeDescription(DeviceType.eUnknown)
		) {
			//If device type is unnkown , use command find type and then populate values
			deviceMeasures = await fetchMeasures(deviceTypeRef.current);
		} else {
			await CheckDeviceType();
			deviceMeasures = await fetchMeasures(deviceTypeRef.current);
		}

		if (deviceMeasures) {
			// Update device model with blower RPM
			devModel.blowerRPMSpeed = deviceMeasures.RPM;

			// Populate channel 1 data
			channel1.rate = deviceMeasures.CH1Flow;
			channel1.maxFlowRate = deviceMeasures.CH1MaxFlow;
			channel1.minFlowRate = deviceMeasures.CH1MinFlow;
			channel1.refFlowRate = deviceMeasures.CH1RefFlow;
			channel1.temperature = deviceMeasures.CH1Temperature.toString();
			channel1.smokeLevel = deviceMeasures.CH1SmokeLevel;
			channel1.preAlarmLevel = deviceMeasures.CH1PreAlarmLevel;
			channel1.alarmLevel = deviceMeasures.CH1AlarmLevel;

			// Add channel 1 to the list
			devModel.listOfChannels.push(channel1);

			// If device has 2 channels, create and populate channel 2
			if (devModel.channels === 2) {
				const channel2 = new Channels();
				channel2.channel = 'Channel2'; //translate

				// Populate channel 2 data
				channel2.rate = deviceMeasures.CH2Flow;
				channel2.maxFlowRate = deviceMeasures.CH2MaxFlow;
				channel2.minFlowRate = deviceMeasures.CH2MinFlow;
				channel2.refFlowRate = deviceMeasures.CH2RefFlow;
				channel2.temperature = deviceMeasures.CH2Temperature.toString();
				channel2.smokeLevel = deviceMeasures.CH2SmokeLevel;
				channel2.preAlarmLevel = deviceMeasures.CH2PreAlarmLevel;
				channel2.alarmLevel = deviceMeasures.CH2AlarmLevel;

				// Add channel 2 to the list
				devModel.listOfChannels.push(channel2);
				IsChannel2AvailableRef.current = true;
			}
			setDeviceName(devModel.deviceName);
			// Update state with the new data
			setSelectedDevice({
				blowerRPMSpeed: devModel.blowerRPMSpeed,
				listOfChannels: devModel.listOfChannels,
			});

			// Update UI based on the new data
			await bindData();
		} else {
			setBlowerRPMValue(0);
			setCh1FlowRate(0);
			setCh1Temperature('');
			setCh2FlowRate(0);
			setCh2Temperature('');
			await RedrawGraph();
		}
	}

	async function bindData() {
		try {
			let errorList1: string[] = [];
			let errorList2: string[] = [];
			let tempErrorList1: string[] = [];
			let tempErrorList2: string[] = [];
			const rpm =
				Math.round(selectedDeviceRef.current.blowerRPMSpeed / 10) * 10;
			setBlowerRPMValue(rpm);
			if (
				selectedDeviceRef.current.listOfChannels &&
				selectedDeviceRef.current.listOfChannels.length > 0
			) {
				const channel1 = selectedDeviceRef.current.listOfChannels[0];
				setCh1FlowRate(channel1.rate);
				setCh1Temperature(
					channel1.temperature === null ? '' : channel1.temperature,
				);
				// Set smoke level data
				const smokeLevel1String = getSmokelevelValue(channel1.smokeLevel);

				setSmokeSensitivityLevel1Str(
					stringFormat(
						t('smokeSenstivityLevelWithValues'),
						channel1.preAlarmLevel,
						channel1.alarmLevel,
					),
				);
				if (
					smokeLevel1String === 'No Smoke Detected' ||
					smokeLevel1String === 'Unknown'
				) {
					setCh1SmokeLevel(-1);
				} else {
					try {
						const level = parseFloat(smokeLevel1String);
						setCh1SmokeLevel(level);
					} catch {
						setCh1SmokeLevel(-1);
					}
				}

				// TODO - Translate

				errorList1.push(
					channel1.rate > channel1.maxFlowRate
						? t('Ch1 flow is above the max limit')
						: '',
				);
				errorList1.push(
					channel1.rate < channel1.minFlowRate
						? t('Ch1 flow is below the min limit')
						: '',
				);
				errorList1.push(
					parseInt(channel1.temperature || '0') > 55
						? t('Ch1 High Temperature Alert')
						: '',
				);
				errorList1.push(
					parseInt(channel1.temperature || '0') < -40
						? t('Ch1 Low Temperature Alert')
						: '',
				);
				if (
					deviceTypeRef.current !==
					getDeviceTypeDescription(DeviceType.eIntelligent)
				) {
					const smokeLevel = channel1.smokeLevel;
					let errorSmokelevel = '';
					switch (smokeLevel) {
						case SmokeAlarmLevel.eDustLevel_0:
							errorSmokelevel = t('CH1 Dust Contamination');
							break;

						case SmokeAlarmLevel.eDustLevel_1:
						case SmokeAlarmLevel.eDustLevel_2:
						case SmokeAlarmLevel.eDustLevel_3:
							errorSmokelevel = t('Ch1 Sensing Head Dust Contimation Level 2');
							break;

						case SmokeAlarmLevel.eDustLevel_4:
						case SmokeAlarmLevel.eDustLevel_5:
						case SmokeAlarmLevel.eDustLevel_6:
							errorSmokelevel = t('Ch1 Sensing Head Dust Contimation Level 1');
							break;

						default:
							errorSmokelevel = '';
					}
					errorList1.push(errorSmokelevel);
					errorList1.push(
						channel1.preAlarmLevel >= channel1.alarmLevel &&
							channel1.alarmLevel > 0
							? t('AlarmLevelActionLevelValidation')
							: '',
					);
				}
				tempErrorList1 = errorList1.filter(error => error !== '');
				setCh1ChartErrorList(tempErrorList1);
				if (IsChannel2AvailableRef.current) {
					const channel2 = selectedDeviceRef.current.listOfChannels[1];
					setCh2FlowRate(channel2.rate);
					setCh2Temperature(
						channel2.temperature === null ? '' : channel2.temperature,
					);
					// Set smoke level data
					const smokeLevel2String = getSmokelevelValue(channel2.smokeLevel);
					setSmokeSensitivityLevel2Str(
						stringFormat(
							t('smokeSenstivityLevelWithValues'),
							channel2.preAlarmLevel,
							channel2.alarmLevel,
						),
					);
					if (
						smokeLevel2String === 'No Smoke Detected' ||
						smokeLevel2String === 'Unknown'
					) {
						setCh2SmokeLevel(-1);
					} else {
						try {
							const level = parseFloat(smokeLevel2String);
							setCh2SmokeLevel(level);
						} catch {
							setCh2SmokeLevel(-1);
						}
					}

					// TODO - Translate

					errorList2.push(
						channel2.rate > channel2.maxFlowRate
							? t('Ch2 flow is above the max limit')
							: '',
					);
					errorList2.push(
						channel2.rate < channel2.minFlowRate
							? t('Ch2 flow is below the min limit')
							: '',
					);
					errorList2.push(
						parseInt(channel2.temperature || '0') > 55
							? t('Ch2 High Temperature Alert')
							: '',
					);
					errorList2.push(
						parseInt(channel2.temperature || '0') < -40
							? t('Ch2 Low Temperature Alert')
							: '',
					);
					if (
						deviceTypeRef.current !==
						getDeviceTypeDescription(DeviceType.eIntelligent)
					) {
						const smokeLevel = channel2.smokeLevel;
						let errorSmokelevel = '';
						switch (smokeLevel) {
							case SmokeAlarmLevel.eDustLevel_0:
								errorSmokelevel = t('CH2 Dust Contamination');
								break;

							case SmokeAlarmLevel.eDustLevel_1:
							case SmokeAlarmLevel.eDustLevel_2:
							case SmokeAlarmLevel.eDustLevel_3:
								errorSmokelevel = t(
									'Ch2 Sensing Head Dust Contimation Level 2',
								);
								break;

							case SmokeAlarmLevel.eDustLevel_4:
							case SmokeAlarmLevel.eDustLevel_5:
							case SmokeAlarmLevel.eDustLevel_6:
								errorSmokelevel = t(
									'Ch2 Sensing Head Dust Contimation Level 1',
								);
								break;

							default:
								errorSmokelevel = '';
						}
						errorList2.push(errorSmokelevel);
						errorList2.push(
							channel2.preAlarmLevel >= channel2.alarmLevel &&
								channel2.alarmLevel > 0
								? t('AlarmLevelActionLevelValidation')
								: '',
						);
					}
					tempErrorList2 = errorList2.filter(error => error !== '');
					setCh2ChartErrorList(tempErrorList2);
				}
			}
			setIsCh2ErrorExist(
				selectedDeviceRef.current.isDeviceConnected &&
					!(Channel === 2) &&
					tempErrorList2.length > 0,
			);
			await RedrawGraph(true);
		} catch (error) {
			hideLoadingIndicator();
		}
	}

	function getSmokelevelValue(selectedSmokeLevel: SmokeAlarmLevel): string {
		switch (selectedSmokeLevel) {
			case SmokeAlarmLevel.eNormal:
			case SmokeAlarmLevel.eDustLevel_0:
			case SmokeAlarmLevel.eDustLevel_1:
			case SmokeAlarmLevel.eDustLevel_2:
			case SmokeAlarmLevel.eDustLevel_3:
			case SmokeAlarmLevel.eDustLevel_4:
			case SmokeAlarmLevel.eDustLevel_5:
			case SmokeAlarmLevel.eDustLevel_6:
			case SmokeAlarmLevel.eDustLevel_7:
			case SmokeAlarmLevel.eDustLevel_8:
			case SmokeAlarmLevel.eDustLevel_9:
				return t('NoSmokeDetected');
			case SmokeAlarmLevel.eAlarmLevel_0:
				return '0';
			case SmokeAlarmLevel.eAlarmLevel_1:
				return '1';
			case SmokeAlarmLevel.eAlarmLevel_2:
				return '2';
			case SmokeAlarmLevel.eAlarmLevel_3:
				return '3';
			case SmokeAlarmLevel.eAlarmLevel_4:
				return '4';
			case SmokeAlarmLevel.eAlarmLevel_5:
				return '5';
			case SmokeAlarmLevel.eAlarmLevel_6:
				return '6';
			case SmokeAlarmLevel.eAlarmLevel_7:
				return '7';
			case SmokeAlarmLevel.eAlarmLevel_8:
				return '8';
			case SmokeAlarmLevel.eAlarmLevel_9:
				return '9';
			case SmokeAlarmLevel.eUnknown:
				return t('Unknown');
			default:
				return t('SmokeDetected');
		}
	}

	// Log the data

	// Bar Graph Data

	async function RedrawGraph(isDeviceConnected: boolean = false) {
		if (isDeviceConnected) {
			const max1 = selectedDeviceRef.current.listOfChannels[0].maxFlowRate;
			const min1 = selectedDeviceRef.current.listOfChannels[0].minFlowRate;
			const ref1 = selectedDeviceRef.current.listOfChannels[0].refFlowRate;
			// const max1 = 27;
			// const min1 = 21;
			// const ref1 = 24;
			setCh1MinFlow(min1);
			setCh1RefFlow(ref1);
			setCh1MaxFlow(max1);
			setCh1ActionValue(
				selectedDeviceRef.current.listOfChannels[0].preAlarmLevel,
			);
			setCh1AlarmValue(selectedDeviceRef.current.listOfChannels[0].alarmLevel);
			NoOfDataPoints1.current = max1 - min1; // (input data points)
			EachDataPointWidth1.current = Const_BarWidth / NoOfDataPoints1.current;
			if (IsChannel2AvailableRef.current) {
				const max2 = selectedDeviceRef.current.listOfChannels[1].maxFlowRate;
				const min2 = selectedDeviceRef.current.listOfChannels[1].minFlowRate;
				const ref2 = selectedDeviceRef.current.listOfChannels[1].refFlowRate;
				setCh2MinFlow(min2);
				setCh2RefFlow(ref2);
				setCh2MaxFlow(max2);
				setCh2ActionValue(
					selectedDeviceRef.current.listOfChannels[1].preAlarmLevel,
				);
				setCh2AlarmValue(
					selectedDeviceRef.current.listOfChannels[1].alarmLevel,
				);
				NoOfDataPoints2.current = max2 - min2; // (input data points)
				EachDataPointWidth2.current = Const_BarWidth / NoOfDataPoints2.current;
			}
		} else {
			setCh1MinFlow(0);
			setCh1RefFlow(0);
			setCh1MaxFlow(0);
			setCh1ActionValue(0);
			setCh1AlarmValue(0);
			setCh1SmokeLevel(-2);
			setCh2SmokeLevel(-2);
			if (IsChannel2AvailableRef.current) {
				setCh2MinFlow(0);
				setCh2RefFlow(0);
				setCh2MaxFlow(0);
				setCh2ActionValue(0);
				setCh2AlarmValue(0);
			}
		}
		// No of data points
	}

	// Width of the Bar
	const Width1 = (val: number) => {
		if (val < ch1MinFlow || val > ch1MaxFlow) {
			// value equal to min
			return (NoOfDataPoints1.current / 2) * EachDataPointWidth1.current;
		} else if (val < ch1RefFlow) {
			return (ch1RefFlow - val) * EachDataPointWidth1.current;
		} else if (val > ch1RefFlow) {
			return (val - ch1RefFlow) * EachDataPointWidth1.current; // 391.42 - 207 = 184.42
		}
		return 2;
	};

	// Margin Left
	const Marigin1 = (val: number) => {
		if (ch1MinFlow === 0 && ch1RefFlow === 0 && ch1MaxFlow === 0) {
			return Const_BarWidth / 2;
		} else if (val == ch1MinFlow) {
			// value equal to min
			return 0;
		} else if (val < ch1MinFlow) {
			// values less than min
			return 0;
		} else if (val > ch1MaxFlow) {
			// values greater than max
			return (NoOfDataPoints1.current / 2) * EachDataPointWidth1.current;
		} else if (val < ch1RefFlow) {
			// values less than ref
			return (val - ch1MinFlow) * EachDataPointWidth1.current;
		} else if (val >= ch1RefFlow) {
			// values greater than or equal to ref (includes max and ref)
			return (ch1RefFlow - ch1MinFlow) * EachDataPointWidth1.current;
		}
		return 0;
	};

	// Color Selctor
	const colorPicker1 = (val: number) => {
		if (val < ch1MinFlow || val > ch1MaxFlow) {
			return 'orange';
		} else if (val == ch1RefFlow) {
			return '#000';
		}
		return 'green';
	};

	// Width of the Bar
	const Width2 = (val: number) => {
		if (val < ch2MinFlow || val > ch2MaxFlow) {
			// value equal to min
			return (NoOfDataPoints2.current / 2) * EachDataPointWidth2.current;
		} else if (val < ch2RefFlow) {
			return (ch2RefFlow - val) * EachDataPointWidth2.current;
		} else if (val > ch2RefFlow) {
			return (val - ch2RefFlow) * EachDataPointWidth2.current; // 391.42 - 207 = 184.42
		}
		return 2;
	};

	// Margin Left
	const Marigin2 = (val: number) => {
		if (ch2MinFlow === 0 && ch2RefFlow === 0 && ch2MaxFlow === 0) {
			return Const_BarWidth / 2;
		} else if (val == ch2MinFlow) {
			// value equal to min
			return 0;
		} else if (val < ch2MinFlow) {
			// values less than min
			return 0;
		} else if (val > ch2MaxFlow) {
			// values greater than max
			return (NoOfDataPoints2.current / 2) * EachDataPointWidth2.current;
		} else if (val < ch2RefFlow) {
			// values less than ref
			return (val - ch2MinFlow) * EachDataPointWidth2.current;
		} else if (val >= ch2RefFlow) {
			// values greater than or equal to ref (includes max and ref)
			return (ch2RefFlow - ch2MinFlow) * EachDataPointWidth2.current;
		}
		return 0;
	};

	// Color Selctor
	const colorPicker2 = (val: number) => {
		if (val < ch2MinFlow || val > ch2MaxFlow) {
			return 'orange';
		} else if (val == ch2RefFlow) {
			return '#000';
		}
		return 'green';
	};

	// Smoke Level Data

	//const screenWidth = Dimensions.get('window').width; // Get the screen width
	// width of each data point

	const smokeWidth = (val: number) => {
		if (val >= 0) {
			val += 2;
			return val * Const_SmokeEachPointWidth;
		} else if (val === -2) {
			return 0;
		}
		return Const_SmokeEachPointWidth;
	};

	const marginLeftForLabel = (val: number) => {
		// Alarm point and Action Point
		if (val == 9) return (val + 2) * Const_SmokeEachPointWidth - 27;
		return (val + 2) * Const_SmokeEachPointWidth - 9;
	};

	const marginLeftForSlide = (val: number) => {
		// Alarm point and Action Point slide
		if (val == 0) return Const_SmokeEachPointWidth;
		return (val + 1) * Const_SmokeEachPointWidth;
	};
	const smokecolorPicker1 = (val: number) => {
		if (val < ch1AlarmValue) {
			return 'green';
		} else if (val >= ch1AlarmValue && val < ch1ActionValue) {
			return 'orange';
		} else {
			return 'red'; // Assuming 'red' is used for action point and above
		}
	};

	const smokecolorPicker2 = (val: number) => {
		if (val < ch2AlarmValue) {
			return 'green';
		} else if (val >= ch2AlarmValue && val < ch2ActionValue) {
			return 'orange';
		} else {
			return 'red'; // Assuming 'red' is used for action point and above
		}
	};

	//#region Graph screen

	async function ChannelTappedCommand(channelId: number) {
		if (channelId === 1) {
			setChannel(1);
			setIsCh2ErrorExist(
				selectedDeviceRef.current.isDeviceConnected &&
					ch2ChartErrorList.length > 0,
			);
			setIsCh1ErrorExist(false);
		} else {
			setChannel(2);
			setIsCh1ErrorExist(
				selectedDeviceRef.current.isDeviceConnected &&
					ch1ChartErrorList.length > 0,
			);
			setIsCh2ErrorExist(false);
		}
	}

	const renderGraphScreen = () => {
		return (
			<>
				<View style={{ backgroundColor: '#fff', flex: 1 }}>
					<View
						style={{
							width: '100%',
							height: 0,
							backgroundColor: '#fff',
						}}></View>
					{/* Aspirator RPM */}
					<View
						style={{
							flexDirection: 'row',
							justifyContent: 'space-between',
							alignItems: 'center',
							borderBottomWidth: 1,
							borderColor: '#ccc',
							paddingHorizontal: 20,
							paddingVertical: 3,
							elevation: 1,
							backgroundColor: '#fff',
						}}>
						<View style={{ width: '50%' }}>
							<Text
								style={{
									fontSize: 20,
									marginBottom: 15,
									fontWeight: '500',
									color: '#7f7f7f',
								}}>
								{t('blowerRPM')}
							</Text>
							<Text
								style={{
									fontSize: 12,
									flexWrap: 'wrap',
									color: '#7f7f7f',
								}}>
								{t('blowerRPMRangeMsg')}
							</Text>
						</View>
						<View style={{ marginLeft: -500 }}>
							<SemiCircularProgressBar value={BlowerRPMValue} />
						</View>
					</View>

					{/* Channel 1 */}

					<ScrollView
						style={{ flex: 1 }}
						showsVerticalScrollIndicator={true}
						nestedScrollEnabled={true}>
						{NoOfChannels === 1 ? (
							<View
								style={{
									alignItems: 'center',
									justifyContent: 'center',
									padding: 8,
									borderBottomWidth: 3,
									borderColor: '#1792E5',
									marginBottom: 10,
									flexDirection: 'row',
								}}>
								<Text style={{ fontSize: 20, fontWeight: '500' }}>
									{t('Channel1')}
								</Text>
								{IsCh1ErrorExist && (
									<Text
										style={{
											fontSize: 20,
											fontWeight: '500',
											color: '#ee6055',
										}}>
										*
									</Text>
								)}
							</View>
						) : (
							<View
								style={{
									flexDirection: 'row',
									justifyContent: 'space-between',
									margin: 0,
								}}>
								<TouchableOpacity
									onPress={() => {
										ChannelTappedCommand(1);
									}}
									style={[
										Channel === 1
											? {
													borderRadius: 0,
													borderBottomWidth: 3,
													borderColor: commonColors.backgroundColor_Blue,
											  }
											: {},
										{
											flex: 1,
											alignItems: 'center',
											justifyContent: 'center',
											paddingVertical: 10,
										},
									]}>
									<View
										style={{
											flexDirection: 'row',
											alignItems: 'center',
										}}>
										<Text
											style={{
												fontSize: 20,
												fontWeight: '500',
											}}>
											{t('Channel1')}
										</Text>
										{IsCh1ErrorExist && (
											<Text
												style={{
													fontSize: 20,
													fontWeight: '500',
													color: '#ee6055',
												}}>
												*
											</Text>
										)}
									</View>
								</TouchableOpacity>
								<View
									style={{
										width: 1,
										backgroundColor: '#ccc',
										marginVertical: 5,
									}}
								/>
								<TouchableOpacity
									onPress={() => {
										ChannelTappedCommand(2);
									}}
									style={[
										Channel === 2
											? {
													borderRadius: 0,
													borderBottomWidth: 3,
													borderColor: commonColors.backgroundColor_Blue,
											  }
											: {},
										{
											flex: 1,
											alignItems: 'center',
											justifyContent: 'center',
											paddingVertical: 10,
										},
									]}>
									<View
										style={{
											flexDirection: 'row',
											alignItems: 'center',
										}}>
										<Text
											style={{
												fontSize: 20,
												fontWeight: '500',
											}}>
											{t('Channel2')}
										</Text>
										{IsCh2ErrorExist && (
											<Text
												style={{
													fontSize: 20,
													fontWeight: '500',
													color: '#ee6055',
												}}>
												*
											</Text>
										)}
									</View>
								</TouchableOpacity>
							</View>
						)}

						{Channel === 1 ? (
							<View style={{ flex: 1 }}>
								{/* Bar Graph */}
								<View
									style={{
										elevation: 2,
										marginHorizontal: BARPLOT_MARGIN_HORIZONTAL,
										borderBottomWidth: SmokeLevelVisible ? 1 : 0,
										borderColor: '#000',
										backgroundColor: '#fff',
									}}>
									{/* Small Description box */}
									{ch1ChartErrorList?.length > 0 && (
										<View
											style={{
												paddingLeft: 10,
												borderWidth: 1,
												borderRadius: 4,
												borderColor: '#ccc',
												backgroundColor: '#ffcad4',
												height: 30,
											}}>
											<FlatList
												data={ch1ChartErrorList}
												keyExtractor={(_item: string, index: number) =>
													index.toString()
												}
												renderItem={({ item }: { item: string }) => (
													<View>
														<Text
															style={{
																fontSize: 11,
																color: '#ee6055',
															}}>
															{item}
														</Text>
													</View>
												)}
												scrollEnabled={false}
											/>
										</View>
									)}
									<View
										style={{
											paddingVertical: SmokeLevelVisible ? 35 : 80,
											paddingHorizontal: BARPLOT_PADDING_HORIZONTAL,
										}}>
										<Text
											style={{
												fontSize: SmokeLevelVisible ? 19 : 24,
												color: '#7f7f7f',
												fontWeight: '500',
											}}>
											{t('airFlowRateAndTemperature')}
										</Text>
										<View
											style={{
												flexDirection: 'row',
												justifyContent: 'space-between',
												marginTop: SmokeLevelVisible ? 10 : 25,
												marginBottom: SmokeLevelVisible ? 10 : 25,
											}}>
											<View>
												<Text
													style={{
														fontSize: SmokeLevelVisible ? 12 : 18,
														color: '#7f7f7f',
													}}>
													{t('Rate')}
												</Text>
												<Text
													style={{
														fontSize: SmokeLevelVisible ? 12 : 18,
														color: '#7f7f7f',
													}}>
													<Text
														style={{
															fontSize: 25,
														}}>
														{ch1FlowRate}
													</Text>{' '}
													{t('litrepermin')}
												</Text>
											</View>
											<View>
												<Text
													style={{
														fontSize: SmokeLevelVisible ? 12 : 18,
														color: '#7f7f7f',
													}}>
													{t('Temperature')} (-40/+55°C)
												</Text>
												<Text
													style={{
														fontSize: SmokeLevelVisible ? 12 : 18,
														color: '#7f7f7f',
													}}>
													<Text
														style={{
															fontSize: 25,
														}}>
														{ch1Temperature}°{' '}
													</Text>
													{t('Celsius')}
												</Text>
											</View>
										</View>

										{/* // Bar Plot Labels */}
										<View style={styles.labelContainer}>
											<Text style={styles.label}>Min {ch1MinFlow} L/Min</Text>
											<Text style={styles.label}>Max {ch1MaxFlow} L/Min</Text>
										</View>
										<View style={{ marginTop: 1 }}>
											<View style={styles.barPlot}>
												<View style={styles.barContainer}>
													{ch1FlowRate <= ch1RefFlow && (
														<View
															style={{
																width: Width1(ch1FlowRate),
																backgroundColor: colorPicker1(ch1FlowRate),
																marginLeft: Marigin1(ch1FlowRate),
																borderRightWidth: 1,
															}}
														/>
													)}
													{ch1FlowRate > ch1RefFlow && (
														<View
															style={{
																width: Width1(ch1FlowRate),
																backgroundColor: colorPicker1(ch1FlowRate),
																marginLeft: Marigin1(ch1FlowRate),
																borderLeftWidth: 1,
															}}
														/>
													)}
												</View>
											</View>
											<Text
												style={[
													styles.label,
													{
														marginLeft:
															(ch1RefFlow - ch1MinFlow) *
																EachDataPointWidth1.current -
															5,
													},
												]}>
												Ref {ch1RefFlow} L/Min
											</Text>
										</View>
									</View>
								</View>
								{/* Smoke Level */}
								{SmokeLevelVisible && (
									<View
										style={{
											paddingVertical: 30,
											marginHorizontal: '1%',
											backgroundColor: '#fff',
											paddingHorizontal: '2%',
											flexDirection: 'column',
										}}>
										<View
											style={{
												flexDirection: 'row',
												justifyContent: 'space-between',
												alignItems: 'center',
												marginBottom: 10,
											}}>
											<Text
												style={{
													fontSize: 20,
													fontWeight: '500',
													color: '#7f7f7f',
												}}>
												{t('SmokeLevel')}
											</Text>
											<TouchableOpacity
												onPress={() => {
													ObscurationTableCommand();
												}}>
												<Text
													style={{
														fontSize: 13,
														color: '#188ce0ff',
													}}>
													{t('lblObscurationDetails')}
												</Text>
											</TouchableOpacity>
										</View>
										<View
											style={{
												flexDirection: 'row',
												alignItems: 'center',
											}}>
											<Text
												style={{
													fontSize: 13,
													color: '#7f7f7f',
												}}>
												{t('senstivityLevel')}
											</Text>
											<Text
												style={{
													fontSize: 13,
													color: '#7f7f7f',
												}}>
												{smokeSensitivityLevel1Str}
											</Text>
										</View>

										<View style={{ marginTop: 20 }}></View>

										<Text
											style={{
												fontSize: 9,
												marginLeft: marginLeftForLabel(ch1ActionValue),
												marginBottom: '1%',
												fontWeight: '500',
											}}>
											{t('Action')}
										</Text>

										<View style={[styles.smokebarplot, { borderWidth: 1 }]}>
											<View style={styles.smokebarContainer}>
												{
													<View
														style={{
															width: smokeWidth(ch1SmokeLevel) - 1,
															backgroundColor: smokecolorPicker1(ch1SmokeLevel),
															borderRightWidth: 0,
														}}
													/>
												}
											</View>
										</View>
										<View
											style={{
												flexDirection: 'row',
												marginTop: 0,
											}}>
											<View
												style={{
													width: Const_SmokeEachPointWidth,
													height: 8,
													borderLeftWidth: 1,
													borderRightWidth: 1,
												}}></View>
											<View
												style={{
													width: Const_SmokeEachPointWidth,
													height: 8,
													borderRightWidth: 1,
												}}></View>
											<View
												style={{
													width: Const_SmokeEachPointWidth,
													height: 8,
													borderRightWidth: 1,
												}}></View>
											<View
												style={{
													width: Const_SmokeEachPointWidth,
													height: 8,
													borderRightWidth: 1,
												}}></View>
											<View
												style={{
													width: Const_SmokeEachPointWidth,
													height: 8,
													borderRightWidth: 1,
												}}></View>
											<View
												style={{
													width: Const_SmokeEachPointWidth,
													height: 8,
													borderRightWidth: 1,
												}}></View>
											<View
												style={{
													width: Const_SmokeEachPointWidth,
													height: 8,
													borderRightWidth: 1,
												}}></View>
											<View
												style={{
													width: Const_SmokeEachPointWidth,
													height: 8,
													borderRightWidth: 1,
												}}></View>
											<View
												style={{
													width: Const_SmokeEachPointWidth,
													height: 8,
													borderRightWidth: 1,
												}}></View>
											<View
												style={{
													width: Const_SmokeEachPointWidth,
													height: 8,
													borderRightWidth: 1,
												}}></View>
											<View
												style={{
													width: Const_SmokeEachPointWidth,
													height: 8,
													borderRightWidth: 1,
												}}></View>
										</View>
										<View
											style={{
												flexDirection: 'row',
												marginTop: -33,
											}}>
											<View
												style={{
													width: Const_SmokeEachPointWidth,
													height: 25,
													borderRightWidth: 1,
													borderColor: '#000',
													marginLeft: marginLeftForSlide(ch1AlarmValue),
												}}></View>
										</View>

										<View
											style={{
												flexDirection: 'row',
												marginTop: -49,
											}}>
											<View
												style={{
													width: Const_SmokeEachPointWidth,
													height: 25,
													borderRightWidth: 1,
													borderColor: '#000',
													marginLeft: marginLeftForSlide(ch1ActionValue),
												}}></View>
										</View>

										<View
											style={{
												flexDirection: 'row',
												justifyContent: 'flex-start',
												alignItems: 'center',
												marginTop: 33,
											}}>
											<Text
												style={{
													width: Const_SmokeEachPointWidth - 2.5,
													fontSize: 10,
												}}></Text>
											<Text
												style={{
													width: Const_SmokeEachPointWidth,
													fontSize: 10,
												}}></Text>
											<Text
												style={{
													width: Const_SmokeEachPointWidth,
													fontSize: 9,
												}}>
												0
											</Text>
											<Text
												style={{
													width: Const_SmokeEachPointWidth,
													fontSize: 9,
												}}>
												1
											</Text>
											<Text
												style={{
													width: Const_SmokeEachPointWidth,
													fontSize: 9,
												}}>
												2
											</Text>
											<Text
												style={{
													width: Const_SmokeEachPointWidth,
													fontSize: 9,
												}}>
												3
											</Text>
											<Text
												style={{
													width: Const_SmokeEachPointWidth,
													fontSize: 9,
												}}>
												4
											</Text>
											<Text
												style={{
													width: Const_SmokeEachPointWidth,
													fontSize: 9,
												}}>
												5
											</Text>
											<Text
												style={{
													width: Const_SmokeEachPointWidth,
													fontSize: 9,
												}}>
												6
											</Text>
											<Text
												style={{
													width: Const_SmokeEachPointWidth,
													fontSize: 9,
												}}>
												7
											</Text>
											<Text
												style={{
													width: Const_SmokeEachPointWidth,
													fontSize: 9,
												}}>
												8
											</Text>
											<Text
												style={{
													width: Const_SmokeEachPointWidth,
													fontSize: 9,
												}}>
												9
											</Text>
										</View>
										<Text
											style={{
												fontSize: 9,
												marginLeft: marginLeftForLabel(ch1AlarmValue),
												fontWeight: '500',
											}}>
											{t('Alarm')}
										</Text>
										<Text
											style={{
												fontSize: 9,
												marginTop: -26,
												marginLeft: Const_SmokeEachPointWidth - 20,
											}}>
											{t('lblNoSmoke')}
										</Text>
										{/* Vertical Line at the 0 of the bar */}
										<View
											style={{
												width: Const_SmokeEachPointWidth,
												height: 50,
												borderRightWidth: 1,
												borderColor: '#000',
												marginTop: -72,
												marginLeft: Const_SmokeEachPointWidth,
											}}></View>
									</View>
								)}
							</View>
						) : (
							<View style={{ flex: 1 }}>
								{/* Bar Graph */}
								<View
									style={{
										elevation: 2,
										marginHorizontal: BARPLOT_MARGIN_HORIZONTAL,
										borderBottomWidth: SmokeLevelVisible ? 1 : 0,
										borderColor: '#000',
										backgroundColor: '#fff',
									}}>
									{/* Small Description box */}
									{ch2ChartErrorList?.length > 0 && (
										<View
											style={{
												paddingLeft: 10,
												borderWidth: 1,
												borderRadius: 4,
												borderColor: '#ccc',
												backgroundColor: '#ffcad4',
												height: 30,
											}}>
											<FlatList
												data={ch2ChartErrorList}
												keyExtractor={(_item: string, index: number) =>
													index.toString()
												}
												renderItem={({ item }: { item: string }) => (
													<View>
														<Text
															style={{
																fontSize: 11,
																color: '#ee6055',
															}}>
															{item}
														</Text>
													</View>
												)}
												scrollEnabled={false}
											/>
										</View>
									)}
									<View
										style={{
											paddingVertical: SmokeLevelVisible ? 35 : 80,
											paddingHorizontal: BARPLOT_PADDING_HORIZONTAL,
										}}>
										<Text
											style={{
												fontSize: SmokeLevelVisible ? 19 : 24,
												color: '#7f7f7f',
												fontWeight: '500',
											}}>
											{t('airFlowRateAndTemperature')}
										</Text>
										<View
											style={{
												flexDirection: 'row',
												justifyContent: 'space-between',
												marginTop: SmokeLevelVisible ? 10 : 25,
												marginBottom: SmokeLevelVisible ? 10 : 25,
											}}>
											<View>
												<Text
													style={{
														fontSize: SmokeLevelVisible ? 12 : 18,
														color: '#7f7f7f',
													}}>
													{t('Rate')}
												</Text>
												<Text
													style={{
														fontSize: SmokeLevelVisible ? 12 : 18,
														color: '#7f7f7f',
													}}>
													<Text
														style={{
															fontSize: 25,
														}}>
														{ch2FlowRate}
													</Text>{' '}
													litres / min
												</Text>
											</View>
											<View>
												<Text
													style={{
														fontSize: SmokeLevelVisible ? 12 : 18,
														color: '#7f7f7f',
													}}>
													{t('Temperature')} (-40/+55°C)
												</Text>
												<Text
													style={{
														fontSize: SmokeLevelVisible ? 12 : 18,
														color: '#7f7f7f',
													}}>
													<Text
														style={{
															fontSize: 25,
														}}>
														{ch2Temperature}°{' '}
													</Text>
													Celsius
												</Text>
											</View>
										</View>

										{/* // Bar Plot Labels */}
										<View style={styles.labelContainer}>
											<Text style={styles.label}>Min {ch2MinFlow} L/Min</Text>
											<Text style={styles.label}>Max {ch2MaxFlow} L/Min</Text>
										</View>
										<View style={{ marginTop: 1 }}>
											<View style={styles.barPlot}>
												<View style={styles.barContainer}>
													{ch2FlowRate <= ch2RefFlow && (
														<View
															style={{
																width: Width2(ch2FlowRate),
																backgroundColor: colorPicker2(ch2FlowRate),
																marginLeft: Marigin2(ch2FlowRate),
																borderRightWidth: 1,
															}}
														/>
													)}
													{ch2FlowRate > ch2RefFlow && (
														<View
															style={{
																width: Width2(ch2FlowRate),
																backgroundColor: colorPicker2(ch2FlowRate),
																marginLeft: Marigin2(ch2FlowRate),
																borderLeftWidth: 1,
															}}
														/>
													)}
												</View>
											</View>
											<Text
												style={[
													styles.label,
													{
														marginLeft:
															(ch2RefFlow - ch2MinFlow) *
																EachDataPointWidth2.current -
															5,
													},
												]}>
												Ref {ch2RefFlow} L/Min
											</Text>
										</View>
									</View>
								</View>
								{/* Smoke Level */}
								{SmokeLevelVisible && (
									<View
										style={{
											paddingVertical: 30,
											marginHorizontal: '1%',
											backgroundColor: '#fff',
											paddingHorizontal: '2%',
										}}>
										<View
											style={{
												flexDirection: 'row',
												justifyContent: 'space-between',
												alignItems: 'center',
												marginBottom: 10,
											}}>
											<Text
												style={{
													fontSize: 20,
													fontWeight: '500',
													color: '#7f7f7f',
												}}>
												{t('SmokeLevel')}
											</Text>
											<TouchableOpacity
												onPress={() => {
													ObscurationTableCommand();
												}}>
												<Text
													style={{
														fontSize: 13,
														color: '#188ce0ff',
													}}>
													{t('lblObscurationDetails')}
												</Text>
											</TouchableOpacity>
										</View>
										<View
											style={{
												flexDirection: 'row',
												alignItems: 'center',
											}}>
											<Text
												style={{
													fontSize: 13,
													color: '#7f7f7f',
												}}>
												{t('senstivityLevel')}
											</Text>
											<Text
												style={{
													fontSize: 13,
													color: '#7f7f7f',
												}}>
												{smokeSensitivityLevel2Str}
											</Text>
										</View>
										<View style={{ marginTop: 20 }}></View>

										<Text
											style={{
												fontSize: 9,
												marginLeft: marginLeftForLabel(ch2ActionValue),
												marginBottom: '1%',
												fontWeight: '500',
											}}>
											{t('Action')}
										</Text>

										<View style={[styles.smokebarplot, { borderWidth: 1 }]}>
											<View style={styles.smokebarContainer}>
												{
													<View
														style={{
															width: smokeWidth(ch2SmokeLevel) - 1,
															backgroundColor: smokecolorPicker2(ch2SmokeLevel),
															borderRightWidth: 0,
														}}
													/>
												}
											</View>
										</View>
										<View
											style={{
												flexDirection: 'row',
												marginTop: 0,
											}}>
											<View
												style={{
													width: Const_SmokeEachPointWidth,
													height: 8,
													borderLeftWidth: 1,
													borderRightWidth: 1,
												}}></View>
											<View
												style={{
													width: Const_SmokeEachPointWidth,
													height: 8,
													borderRightWidth: 1,
												}}></View>
											<View
												style={{
													width: Const_SmokeEachPointWidth,
													height: 8,
													borderRightWidth: 1,
												}}></View>
											<View
												style={{
													width: Const_SmokeEachPointWidth,
													height: 8,
													borderRightWidth: 1,
												}}></View>
											<View
												style={{
													width: Const_SmokeEachPointWidth,
													height: 8,
													borderRightWidth: 1,
												}}></View>
											<View
												style={{
													width: Const_SmokeEachPointWidth,
													height: 8,
													borderRightWidth: 1,
												}}></View>
											<View
												style={{
													width: Const_SmokeEachPointWidth,
													height: 8,
													borderRightWidth: 1,
												}}></View>
											<View
												style={{
													width: Const_SmokeEachPointWidth,
													height: 8,
													borderRightWidth: 1,
												}}></View>
											<View
												style={{
													width: Const_SmokeEachPointWidth,
													height: 8,
													borderRightWidth: 1,
												}}></View>
											<View
												style={{
													width: Const_SmokeEachPointWidth,
													height: 8,
													borderRightWidth: 1,
												}}></View>
											<View
												style={{
													width: Const_SmokeEachPointWidth,
													height: 8,
													borderRightWidth: 1,
												}}></View>
										</View>
										<View
											style={{
												flexDirection: 'row',
												marginTop: -33,
											}}>
											<View
												style={{
													width: Const_SmokeEachPointWidth,
													height: 25,
													borderRightWidth: 1,
													borderColor: '#000',
													marginLeft: marginLeftForSlide(ch2AlarmValue),
												}}></View>
										</View>

										<View
											style={{
												flexDirection: 'row',
												marginTop: -49,
											}}>
											<View
												style={{
													width: Const_SmokeEachPointWidth,
													height: 25,
													borderRightWidth: 1,
													borderColor: '#000',
													marginLeft: marginLeftForSlide(ch2ActionValue),
												}}></View>
										</View>

										<View
											style={{
												flexDirection: 'row',
												justifyContent: 'flex-start',
												alignItems: 'center',
												marginTop: 33,
											}}>
											<Text
												style={{
													width: Const_SmokeEachPointWidth - 2.5,
													fontSize: 10,
												}}></Text>
											<Text
												style={{
													width: Const_SmokeEachPointWidth,
													fontSize: 10,
												}}></Text>
											<Text
												style={{
													width: Const_SmokeEachPointWidth,
													fontSize: 9,
												}}>
												0
											</Text>
											<Text
												style={{
													width: Const_SmokeEachPointWidth,
													fontSize: 9,
												}}>
												1
											</Text>
											<Text
												style={{
													width: Const_SmokeEachPointWidth,
													fontSize: 9,
												}}>
												2
											</Text>
											<Text
												style={{
													width: Const_SmokeEachPointWidth,
													fontSize: 9,
												}}>
												3
											</Text>
											<Text
												style={{
													width: Const_SmokeEachPointWidth,
													fontSize: 9,
												}}>
												4
											</Text>
											<Text
												style={{
													width: Const_SmokeEachPointWidth,
													fontSize: 9,
												}}>
												5
											</Text>
											<Text
												style={{
													width: Const_SmokeEachPointWidth,
													fontSize: 9,
												}}>
												6
											</Text>
											<Text
												style={{
													width: Const_SmokeEachPointWidth,
													fontSize: 9,
												}}>
												7
											</Text>
											<Text
												style={{
													width: Const_SmokeEachPointWidth,
													fontSize: 9,
												}}>
												8
											</Text>
											<Text
												style={{
													width: Const_SmokeEachPointWidth,
													fontSize: 9,
												}}>
												9
											</Text>
										</View>
										<Text
											style={{
												fontSize: 9,
												marginLeft: marginLeftForLabel(ch2AlarmValue),
												fontWeight: '500',
											}}>
											{t('Alarm')}
										</Text>
										<Text
											style={{
												fontSize: 9,
												marginTop: -26,
												marginLeft: Const_SmokeEachPointWidth - 20,
											}}>
											{t('lblNoSmoke')}
										</Text>
										<View
											style={{
												flexDirection: 'row',
												marginTop: -33,
											}}>
											{/* Vertical Line at the 0 of the bar */}
											<View
												style={{
													width: Const_SmokeEachPointWidth,
													height: 50,
													borderRightWidth: 1,
													borderColor: '#000',
													marginTop: -40,
													marginLeft: Const_SmokeEachPointWidth,
												}}></View>
										</View>
									</View>
								)}
							</View>
						)}
					</ScrollView>
				</View>
			</>
		);
	};
	//#endregion

	//#endregion

	//#region Password Modal Handle

	async function ConfigureDeviceParamterCommand() {
		IsConfigurePage.current = true;
		if (selectedDeviceRef.current?.isDeviceConnected === false) {
			//Translate
			let page = AppConstants.DeviceParameterScreen;
			if (
				selectedDeviceRef.current.deviceType ===
				getDeviceTypeDescription(DeviceType.eIntelligent)
			) {
				page = AppConstants.FFIDeviceParameterScreen;
			} else {
				page = AppConstants.DeviceParameterScreen;
			}
			setConfigModalVisible(false);
			navigation.navigate(page, {
				selectedItem: selectedDeviceRef.current,
			});
		} else {
			stopTimer();
			setConfigModalVisible(true);
		}
	}

	function PerformDeviceTestCommand() {
		stopTimer();
		setConfigModalVisible(true);
		IsConfigurePage.current = false;
	}

	const handleConfigOption = (option: boolean) => {
		if (option) {
			ValidateL3PasscodeAsync();
		} else {
			CancelPasswordCommandasync();
		}
	};
	const handlePasswordChangeText = (text: string, index: number): void => {
		// Only allow numeric input
		if (!/^\d*$/.test(text)) return;

		// Create a new values array
		const newValues = [...passwordValues];
		newValues[index] = text.slice(0, 1); // Take only first digit
		setPasswordValues(newValues);

		// If a digit was entered and there's a next input, focus it
		if (text && index < 5 && passwordInputRefs.current[index + 1]) {
			passwordInputRefs.current[index + 1]?.focus();
		}
	};

	const handlePasswordKeyPress = (e: any, index: number): void => {
		// Handle backspace
		if (e.nativeEvent.key === 'Backspace') {
			// Clear current value if it exists
			if (passwordValues[index]) {
				const newValues = [...passwordValues];
				newValues[index] = '';
				setPasswordValues(newValues);
				return;
			}

			// If current box is empty and not the first box, move focus left
			if (index > 0 && passwordInputRefs.current[index - 1]) {
				// Create a new values array and clear the previous value
				const newValues = [...passwordValues];
				newValues[index - 1] = '';
				setPasswordValues(newValues);

				// Move focus to previous input
				passwordInputRefs.current[index - 1]?.focus();
			}
		}
	};

	const renderConfigModal = () => {
		return (
			<Modal
				animationType='fade'
				transparent={true}
				visible={configModalVisible}
				onRequestClose={() => setConfigModalVisible(false)}>
				<View style={styles.modalOverlay}>
					<View style={styles.modalContainer}>
						<View style={styles.modalContent}>
							<Text style={styles.modalTitle}>{t('EnterPassword')}</Text>
							<Text style={styles.modalDescription}>
								{t('UnlockConfigPwd')}
							</Text>

							<View style={styles.inputContainer}>
								{[0, 1, 2, 3, 4, 5].map(index => (
									<TextInput
										key={index}
										ref={(ref: TextInput | null) =>
											(passwordInputRefs.current[index] = ref)
										}
										style={styles.inputBox}
										value={passwordValues[index]}
										onChangeText={text => handlePasswordChangeText(text, index)}
										onKeyPress={e => handlePasswordKeyPress(e, index)}
										onFocus={() => {
											// If user tries to focus on a box that shouldn't be active, redirect to correct box
											if (index > 0) {
												const hasAllPreviousFilled = passwordValues
													.slice(0, index)
													.every(value => value !== '');
												if (!hasAllPreviousFilled) {
													const nextEmptyIndex = passwordValues.findIndex(
														value => value === '',
													);
													if (
														nextEmptyIndex >= 0 &&
														nextEmptyIndex < index &&
														passwordInputRefs.current[nextEmptyIndex]
													) {
														passwordInputRefs.current[nextEmptyIndex]?.focus();
													}
												}
											}
										}}
										keyboardType='numeric'
										maxLength={1}
										selectTextOnFocus
										secureTextEntry
									/>
								))}
							</View>
							<Text style={styles.modalDescription}>
								{t('block3attemptsMsg')}
							</Text>
							<View style={styles.modalButtons}>
								<View style={{ flex: 1, marginHorizontal: 5 }}>
									<Button
										title={t('cancel')}
										onPress={() => handleConfigOption(false)}
										color='#1792E5'
									/>
								</View>

								<View style={{ flex: 1, marginHorizontal: 5 }}>
									<Button
										title={t('ok')}
										onPress={() => handleConfigOption(true)}
										color='#1792E5'
									/>
								</View>
							</View>
						</View>
					</View>
				</View>
			</Modal>
		);
	};
	//#endregion

	//#region About Device

	async function AboutDeviceAsync() {
		try {
			stopTimer();
			if (
				selectedDevice.isDeviceConnected &&
				ConnectedDeviceobj.current !== null
			) {
				const deviceMode = await faastflexBluetoothCommunicator.GetDeviceMode();
				if (deviceMode.deviceMode === DeviceStatus.MAIN_FSM_SERVICE) {
					Alert.alert('Error', t('DeviceServiceModeErrorMsg'), [
						{ text: 'ok' },
					]);
					return;
				}

				showLoadingIndicator(t('LoadingDeviceDetails'));

				let notAllowedData: string = '';

				// Get Device Type
				const deviceTypeResult =
					await faastflexBluetoothCommunicator.GetDeviceType();
				setAboutDeviceType(deviceTypeResult.deviceType);
				if (deviceTypeResult.error === ErrorCode.eGCL_NOT_ALLOWED_COMMAND) {
					notAllowedData = 'Device Type';
				} else {
					setSelectedDevice({
						deviceType: deviceTypeResult.deviceType,
					});
				}

				// Get Serial Number
				const serialNumberResult =
					await faastflexBluetoothCommunicator.GetSerialNumber();
				setAboutDeviceSerialNumber(serialNumberResult.serialNumber);
				if (serialNumberResult.error === ErrorCode.eGCL_NOT_ALLOWED_COMMAND) {
					notAllowedData = notAllowedData
						? notAllowedData + ', Serial Number'
						: 'Serial Number';
				} else {
					setSelectedDevice({
						deviceSerialNumber: serialNumberResult.serialNumber,
					});
				}

				// Number of Channels
				setAboutDeviceNumberofChannels(selectedDevice.channels);

				// Get Production Date
				const productionDateResult =
					await faastflexBluetoothCommunicator.GetProductionDate();
				setAboutDeviceProductionDate(productionDateResult.productionDate);
				if (productionDateResult.error === ErrorCode.eGCL_NOT_ALLOWED_COMMAND) {
					notAllowedData = notAllowedData
						? notAllowedData + ', Production Date'
						: 'Production Date';
				} else {
					setSelectedDevice({
						productionDate: productionDateResult.productionDate,
					});
				}

				// Get Firmware Version
				const firmwareResult =
					await faastflexBluetoothCommunicator.GetFirmwareVersion();
				setAboutDeviceFirmwareVersion(firmwareResult.firmwareVersion);
				if (firmwareResult.error === ErrorCode.eGCL_NOT_ALLOWED_COMMAND) {
					notAllowedData = notAllowedData
						? notAllowedData + ', Firmware Version'
						: 'Firmware Version';
				}

				// Get Model Number
				const modelTypeResult =
					await faastflexBluetoothCommunicator.GetModelType();
				setAboutDeviceModelNumber(modelTypeResult.modelType);
				if (modelTypeResult.error === ErrorCode.eGCL_NOT_ALLOWED_COMMAND) {
					notAllowedData = notAllowedData
						? notAllowedData + ', Model Number'
						: 'Model Number';
				} else {
					setSelectedDevice({
						deviceModelNumber: modelTypeResult.modelType,
					});
				}

				// Set device country
				setDeviceCountry(selectedDevice.deviceCountryCode);

				hideLoadingIndicator();
				setIsAboutDeviceVisible(true);

				// Show warning for data that couldn't be retrieved
				if (notAllowedData) {
					Alert.alert('Error', `notallowedtoget: ${notAllowedData}`, [
						{ text: 'ok' },
					]);
				}
			} else {
				Toast.show({
					type: 'error',
					text2: 'PlsConnectDevice',
					position: 'bottom',
				});
			}
		} catch (error) {
			hideLoadingIndicator();
		}
	}
	async function closeAboutDeviceModal() {
		stopTimer();
		setIsAboutDeviceVisible(false);
	}

	const renderAboutDevice = () => {
		return (
			<Modal
				animationType='fade'
				transparent={true}
				visible={isAboutDeviceVisible}
				onRequestClose={() => closeAboutDeviceModal()}>
				<TouchableOpacity
					style={styles.modalOverlay}
					activeOpacity={1}
					onPress={() => closeAboutDeviceModal()}>
					<View
						style={styles.aboutDeviceContainer}
						// This prevents touches on the modal content from closing the modal
						onStartShouldSetResponder={() => true}
						onTouchEnd={e => e.stopPropagation()}>
						<Text style={styles.aboutDeviceTitle}>
							{t('DeviceInformation')}
						</Text>

						<View style={styles.aboutDeviceRow}>
							<Text style={styles.aboutDeviceLabel}>{t('DeviceType')}</Text>
							<Text style={styles.aboutDeviceValue}>
								{selectedDevice.deviceType}
							</Text>
						</View>
						<View style={styles.aboutDeviceRow}>
							<Text style={styles.aboutDeviceLabel}>{t('ModelNumber')}</Text>
							<Text style={styles.aboutDeviceValue}>
								{aboutDeviceModelNumber}
							</Text>
						</View>
						<View style={styles.aboutDeviceRow}>
							<Text style={styles.aboutDeviceLabel}>{t('realconfig')}</Text>
							<Text style={styles.aboutDeviceValue}>
								{selectedDevice.deviceConfigStr}
							</Text>
						</View>
						<View style={styles.aboutDeviceRow}>
							<Text style={styles.aboutDeviceLabel}>{t('country')}</Text>
							<Text style={styles.aboutDeviceValue}>{DeviceCountry}</Text>
						</View>
						<View style={styles.aboutDeviceRow}>
							<Text style={styles.aboutDeviceLabel}>{t('SerialNumber')}</Text>
							<Text style={styles.aboutDeviceValue}>
								{aboutDeviceSerialNumber}
							</Text>
						</View>
						<View style={styles.aboutDeviceRow}>
							<Text style={styles.aboutDeviceLabel}>
								{t('NumberOfChannels')}
							</Text>
							<Text style={styles.aboutDeviceValue}>
								{aboutDeviceNumberofChannels}
							</Text>
						</View>
						<View style={styles.aboutDeviceRow}>
							<Text style={styles.aboutDeviceLabel}>
								{t('FirmwareVersion')}
							</Text>
							<Text style={styles.aboutDeviceValue}>
								{aboutDeviceFirmwareVersion}
							</Text>
						</View>
						<View style={styles.aboutDeviceRow}>
							<Text style={styles.aboutDeviceLabel}>{t('ProductionDate')}</Text>
							<Text style={styles.aboutDeviceValue}>
								{aboutDeviceProductionDate}
							</Text>
						</View>
					</View>
				</TouchableOpacity>
			</Modal>
		);
	};

	//#endregion

	//#region Mirror HMI

	async function OpenMirrorHMI() {
		try {
			stopTimer();
			showLoadingIndicator(t('ReadingDeviceStatus'));

			const deviceModeResult =
				await faastflexBluetoothCommunicator.GetDeviceMode();
			if (deviceModeResult.deviceMode === DeviceStatus.MAIN_FSM_SERVICE) {
				hideLoadingIndicator();
				Alert.alert('Error', t('DeviceServiceModeErrorMsg'), [{ text: 'OK' }]);
				return;
			}
			if (
				selectedDevice.authenticatedStatus !==
				DeviceAuthenticated.eAuthenticated
			) {
				await GetDeviceStatus();
				// Enable self-test for China only for firmware version 4.0 and above
				const isSelfTestEnabled = await GetDeviceFirmware();
				setIsSelfTestChinaEnabled(isSelfTestEnabled);
				setIsMirrorHMIVisible(true);
			} else {
				let uniqueIdentifier = '';
				await EncryptedStorage.getItem('UniqueIdentifier').then(value => {
					if (value) {
						uniqueIdentifier = value;
					}
				});
				const authResult =
					await faastflexBluetoothCommunicator.checkAuthenticated(
						uniqueIdentifier,
					);
				setSelectedDevice({ authenticatedStatus: authResult.isValid });
				if (authResult.isValid == DeviceAuthenticated.eAuthenticated) {
					await GetDeviceStatus();
					const isSelfTestEnabled = await GetDeviceFirmware();
					setIsSelfTestChinaEnabled(isSelfTestEnabled);
					setIsMirrorHMIVisible(true);
				} else {
					Alert.alert('retry', 'msgPleaseTryAgain', [{ text: 'OK' }]);
					hideLoadingIndicator();
				}
			}
			hideLoadingIndicator();
		} catch (error) {
			hideLoadingIndicator();
		}
	}

	async function CloseMirrorHMI() {
		if (IsAutoRefreshEnabledRef.current) {
			startTimer();
		}
		setIsMirrorHMIVisible(false);
	}
	//TODO : Translation
	const renderMirrorHMI = () => {
		return (
			<Modal
				animationType='slide'
				transparent={true}
				visible={isMirrorHMIVisible}
				onRequestClose={() => {
					setIsMirrorHMIVisible(!isMirrorHMIVisible);
				}}>
				<View style={[styles.mirrorHmiCenteredView]}>
					<View style={styles.mirrorHmiModalView}>
						<ScrollView style={{ flexGrow: 1 }}>
							<View
								style={{
									backgroundColor: '#F2F2F2',
									padding: 10,
								}}>
								<View
									style={{
										flexDirection: 'row',
										alignItems: 'center',
										justifyContent: 'space-between',
									}}>
									<Text
										style={[
											styles.mirrorHmiModalText,
											,
											{ fontWeight: 'bold' },
										]}>
										{selectedDevice.deviceName}
									</Text>
									<TouchableOpacity
										style={styles.mirrorHmiCloseButton}
										onPress={() => setIsMirrorHMIVisible(false)}>
										<CloseIconGray height={20} width={20} />
									</TouchableOpacity>
								</View>
								<Text style={styles.mirrorHmiModalText}>
									{selectedDevice.deviceLocation}
								</Text>
								<Text style={styles.mirrorHmiModalText}>
									{selectedDevice.deviceMacAddress}
								</Text>

								<View
									style={{
										flexDirection: 'row',
										alignItems: 'center',
										justifyContent: 'flex-start',
									}}>
									<Text style={styles.mirrorHmiInlineText}>
										{t('workingmode')}
									</Text>
									{getStatusIcon(selectedDevice.deviceStatus)}
									<Text
										style={[styles.mirrorHmiInlineText, { marginStart: 4 }]}>
										{selectedDevice.deviceStatusStr}
									</Text>
								</View>

								<View
									style={{
										flexDirection: 'row',
										alignItems: 'center',
										justifyContent: 'flex-start',
									}}>
									<Text style={styles.mirrorHmiInlineText}>
										{t('DeviceStatusColon')}
									</Text>
									{getStateIcon(selectedDevice.deviceState)}
									<Text
										style={[styles.mirrorHmiInlineText, { marginStart: 4 }]}>
										{selectedDevice.deviceStateString}
									</Text>
									<TouchableOpacity
										style={styles.mirrorHmiCloseButton}
										onPress={() => RefreshDeviceStatusCommand()}>
										<SyncBlue height={20} width={20} />
									</TouchableOpacity>
								</View>
								<View
									style={{
										paddingBottom: isLedStatusVisible ? 0 : 10,
									}}
								/>
							</View>

							{isLedStatusVisible && (
								<View style={styles.mirrorHmiInfoSection}>
									<Text
										style={[styles.mirrorHmiModalText, { fontWeight: 'bold' }]}>
										{t('ledStatus')}
									</Text>

									<View
										style={{
											flexDirection: 'row',
											alignItems: 'center',
											justifyContent: 'space-between',
											marginVertical: 6,
										}}>
										<Text style={styles.mirrorHmiInlineText}>
											{t('Alarm1')}
										</Text>
										<Text style={styles.mirrorHmiInlineText}>
											{AlarmLEDStatus1}
										</Text>
									</View>
									<View
										style={{
											height: 1,
											backgroundColor: '#E9E9E9',
										}}
									/>

									<View
										style={{
											flexDirection: 'row',
											alignItems: 'center',
											justifyContent: 'space-between',
											marginVertical: 6,
										}}>
										<Text style={styles.mirrorHmiInlineText}>
											{t('Action1')}
										</Text>
										<Text style={styles.mirrorHmiInlineText}>
											{PreAlarmLEDStatus1}
										</Text>
									</View>
									<View
										style={{
											height: 1,
											backgroundColor: '#E9E9E9',
										}}
									/>

									{isDualChannelDevice && (
										<View
											style={{
												flexDirection: 'row',
												alignItems: 'center',
												justifyContent: 'space-between',
												marginVertical: 6,
											}}>
											<Text style={styles.mirrorHmiInlineText}>
												{t('Alarm2')}
											</Text>
											<Text style={styles.mirrorHmiInlineText}>
												{AlarmLEDStatus2}
											</Text>
										</View>
									)}
									{isDualChannelDevice && (
										<View
											style={{
												height: 1,
												backgroundColor: '#E9E9E9',
											}}
										/>
									)}

									{isDualChannelDevice && (
										<View
											style={{
												flexDirection: 'row',
												alignItems: 'center',
												justifyContent: 'space-between',
												marginVertical: 6,
											}}>
											<Text style={styles.mirrorHmiInlineText}>
												{t('Action2')}
											</Text>
											<Text style={styles.mirrorHmiInlineText}>
												{PreAlarmLEDStatus2}
											</Text>
										</View>
									)}
									{isDualChannelDevice && (
										<View
											style={{
												height: 1,
												backgroundColor: '#E9E9E9',
											}}
										/>
									)}

									<View
										style={{
											flexDirection: 'row',
											alignItems: 'center',
											justifyContent: 'space-between',
											marginVertical: 6,
										}}>
										<Text style={styles.mirrorHmiInlineText}>{t('Fault')}</Text>
										<Text style={styles.mirrorHmiInlineText}>
											{FaultLEDStatus}
										</Text>
									</View>

									<View
										style={{
											height: 1,
											backgroundColor: '#E9E9E9',
										}}
									/>
								</View>
							)}
						</ScrollView>

						<View style={styles.mirrorHmiFooter}>
							<TouchableOpacity
								style={[
									styles.mirrorHmiFooterButton,
									styles.mirrorHmiFooterButtonDark,
								]}
								onPress={() => ResetCommand()}>
								<View style={styles.mirrorHmiFooterButtonContent}>
									<ResetWhite width={16} height={16} />
									<Text style={styles.mirrorHmiFooterButtonText}>
										{t('reset')}
									</Text>
								</View>
							</TouchableOpacity>

							{IsDeviceCountryCodeChina && (
								<>
									{IsSelfTestChinaEnabled && (
										<TouchableOpacity
											style={[
												styles.mirrorHmiFooterButton,
												styles.mirrorHmiFooterButtonDarker,
											]}
											onPress={() => ValidateChinaSelfTestCommand()}>
											<View style={styles.mirrorHmiFooterButtonContent}>
												<Log width={16} height={16} />
												<Text style={styles.mirrorHmiFooterButtonText}>
													{t('selfTest')}
												</Text>
											</View>
										</TouchableOpacity>
									)}
									<TouchableOpacity
										style={[
											styles.mirrorHmiFooterButton,
											styles.mirrorHmiFooterButtonDark,
										]}
										onPress={() => SilenceCommand()}>
										<View style={styles.mirrorHmiFooterButtonContent}>
											<Silenced width={16} height={16} />
											<Text style={styles.mirrorHmiFooterButtonText}>
												{t('silence')}
											</Text>
										</View>
									</TouchableOpacity>
								</>
							)}
						</View>
					</View>
					<ModalLoadingIndicator
						visible={mirrorHMILoadingIndicator}
						message={mirrorHMILoadingMessage}></ModalLoadingIndicator>
				</View>
			</Modal>
		);
	};
	//#endregion

	//#region More Tab
	function MoreTabCommandAsync() {
		stopTimer();
		SheetManager.show('DeviceDetailsMoreMenuSheet', {
			payload: {
				t,
				isENSelfTestAvailable,
				ConfigureDeviceParamterCommand,
				PerformDeviceTestCommand,
			} as any,
		});
	}
	//#endregion

	//#region Render Header

	const getAutoRefreshIcon = (autoRefreshIcon: string) => {
		switch (autoRefreshIcon) {
			case 'Sync_Active.png':
				return <SyncBlue width={24} height={24} />;
			case 'Sync.png':
				return <SyncWhite width={24} height={24} />;
			default:
				return <SyncWhite width={24} height={24} />;
		}
	};

	const renderHeader = () => {
		return (
			<SafeAreaView edges={['top']} style={styles.safeHeader}>
				<View
					style={[
						styles.headerSection,
						{
							backgroundColor: '#000',
							alignItems: 'center',
						},
					]}>
					<View style={{ flex: 1, flexDirection: 'column' }}>
						<View
							style={{
								flexDirection: 'row',
								alignItems: 'center',
								paddingHorizontal: 10,
								height: '100%',
								width: '100%',
								backgroundColor: '#000',
							}}>
							<TouchableOpacity
								onPress={() => handleBackPress()}
								style={{
									padding: 0,
									margin: 0,
									justifyContent: 'center',
								}}>
								<LeftArrowWhite height={30} width={30} />
							</TouchableOpacity>

							<View style={[{ flex: 2 }]}>
								<Text
									style={{
										color: '#fff',
										fontSize: 18,
										fontWeight: 'bold',
										textAlign: 'center',
									}}>
									{DeviceName}
								</Text>
							</View>
							{activeScreen === Const_GraphContent && (
								<TouchableOpacity
									disabled={DeviceConnected ? false : true}
									onPress={() => ManualDataSync()}
									style={{
										height: '100%',
										padding: 0,
										margin: 0,
										marginEnd: 20,
										justifyContent: 'center',
										opacity: DeviceConnected ? 1 : 0.5,
									}}>
									{getAutoRefreshIcon(SyncImage)}
								</TouchableOpacity>
							)}

							{activeScreen === Const_LogsContent && (
								<DropdownMenu
									triggerText=''
									menuOptions={[
										{
											label: t('lblGenerateReports'),
											onSelect: () => StartReportGeneration(),
										},
										{
											label: t('lblClearLogs'),
											onSelect: async () => await DeleteLogsAsync(),
										},
									]}
									triggerTextStyle={styles.log_buttonText}
									touchDisabled={DeviceConnected ? false : true}
								/>
							)}

							{activeScreen === Const_GraphContent && (
								<DropdownMenu
									key={IsAutoRefreshEnabled ? 'enabled' : 'disabled'}
									triggerText=''
									menuOptions={[
										{
											label: t('DeviceInformation'),
											onSelect: async () => AboutDeviceAsync(),
										},
										{
											label: t('MirrorHMI'),
											onSelect: async () => OpenMirrorHMI(),
										},
										{
											label: IsAutoRefreshEnabled
												? t('lblDisableAutoRefresh')
												: t('lblEnableAutoRefresh'),
											onSelect: async () => await AutoRefreshAsync(),
										},
									]}
									triggerTextStyle={styles.log_buttonText}
									touchDisabled={DeviceConnected ? false : true}
								/>
							)}
						</View>
						<View
							style={{
								height: 10,
								backgroundColor: '#15c029ff',
								alignContent: 'stretch',
							}}
						/>
					</View>
				</View>
			</SafeAreaView>
		);
	};
	//#endregion

	async function StatusTabCommandAsync() {
		setActiveScreen(Const_GraphContent);
		FilteredLogs.current = [];
		setEventLogs([]);
	}

	//#region  Render footer
	const renderFooter = () => {
		return (
			<View style={styles.footer}>
				<ImageButtonSVG
					svgComponent={
						activeScreen === Const_GraphContent ? (
							<DashboardEnabled />
						) : (
							<Dashboard />
						)
					}
					svgHeight={30}
					svgWidth={30}
					text={t('status')}
					onPress={() => {
						StatusTabCommandAsync();
					}}
					style={styles.button}
					textStyle={
						activeScreen === Const_GraphContent
							? styles.buttonTextBlue
							: styles.buttonText
					}></ImageButtonSVG>

				<ImageButtonSVG
					svgComponent={
						activeScreen === Const_LogsContent ? <LogEnabled /> : <Log />
					}
					svgHeight={30}
					svgWidth={30}
					text={t('logs')}
					onPress={() => {
						LogTabCommandAsync();
					}}
					style={styles.button}
					textStyle={
						activeScreen === Const_LogsContent
							? styles.buttonTextBlue
							: styles.buttonText
					}
					touchDisabled={DeviceConnected ? false : true}></ImageButtonSVG>

				{/* {<ImageButtonSVG
              svgComponent={
                <TripleDotIconGrey/>
              }
              svgHeight={30}
              svgWidth={30}
              text={t('logs')}
              onPress={() => {
                MoreTabCommandAsync() 
              }}
              style={styles.button}
              textStyle={
               styles.buttonText
            }
            >
            </ImageButtonSVG>} */}
				<DropdownMenu
					triggerText={t('more')}
					menuOptions={moreMenuOptions}
					triggerTextStyle={styles.log_buttonText}
					grayIcon={true}
				/>
			</View>
		);
	};
	//#endregion

	return (
		<View style={styles.mainContainer}>
			{/* Header - 10% of height */}
			{renderHeader()}

			{/* Main content area*/}
			<View style={{ flex: 1 }}>
				{activeScreen === Const_GraphContent
					? renderGraphScreen()
					: renderLogScreen()}
			</View>

			{/* Footer */}
			<View style={styles.footerSection}>{renderFooter()}</View>

			{/* Modal PopUp*/}
			{configModalVisible && renderConfigModal()}
			{isGenerateReportVisible && generateReportFilterModal()}
			{isAboutDeviceVisible && renderAboutDevice()}
			{isMirrorHMIVisible && renderMirrorHMI()}
			{showObscurationTable && renderObscurationTable()}
		</View>
	);
}

const styles = StyleSheet.create({
	// Bar Plot Section
	mainContainer: {
		flex: 1,
		backgroundColor: '#f5f5f5',
	},
	headerSection: {
		height: 56,
		width: '100%',
	},
	safeHeader: {
		backgroundColor: '#000',
	},
	footerSection: {
		width: '100%',
		backgroundColor: '#ffffff',
	},
	barPlot: {
		borderWidth: 1,
		height: 48,
		alignContent: 'center',
		justifyContent: 'center',
	},
	barContainer: {
		flexDirection: 'row',
		height: 46,
		backgroundColor: 'white',
		overflow: 'hidden',
	},
	labelContainer: {
		flexDirection: 'row',
		justifyContent: 'space-between',
		marginBottom: -2,
		marginTop: 10,
	},
	label: {
		fontSize: 10,
	},
	smokebarplot: {
		height: 50,
	},
	smokebarContainer: {
		flexDirection: 'row',
		height: 48,
		backgroundColor: 'white',
		overflow: 'hidden',
	},
	footer: {
		height: 60,
		backgroundColor: '#ffffffff',
		borderTopWidth: 1,
		borderTopColor: '#e0e0e0',
		flexDirection: 'row',
		justifyContent: 'space-around',
		alignItems: 'center',
	},
	footerButton: {
		flex: 1,
		height: '100%',
		justifyContent: 'center',
		alignItems: 'center',
	},
	footerButtonTextInActive: {
		color: '#1792E5',
	},
	footerButtonTextActive: {
		color: '#1792E5',
	},
	log_button: {
		marginTop: 10,
		backgroundColor: '#ffffff',
	},
	log_buttonText: {
		color: '#000000',
		fontSize: 14,
		textAlign: 'center',
	},
	buttonTextBlue: {
		color: '#1792E5',
		fontSize: 14,
		textAlign: 'center',
	},

	button: {
		marginTop: 10,
		backgroundColor: '#ffffff',
	},

	buttonFooter: {
		borderTopWidth: 1,
		borderTopColor: '#e0e0e0',
		backgroundColor: '#fff',
	},

	buttonText: {
		color: '#000000',
		fontSize: 14,
		textAlign: 'center',
	},

	passwordContainer: {
		flex: 1,
		backgroundColor: '#fff',
		justifyContent: 'center',
		alignItems: 'center',
		padding: 20,
	},
	passwordTitle: {
		fontSize: 24,
		fontWeight: '600',
		color: '#333',
		marginBottom: 10,
	},
	passwordSubtitle: {
		fontSize: 16,
		color: '#7f7f7f',
		marginBottom: 30,
	},
	inputContainer: {
		flexDirection: 'row',
		justifyContent: 'space-between',
		alignItems: 'center',
		marginBottom: 30,
		paddingHorizontal: 10,
	},
	inputBox: {
		flex: 1,
		height: 55,
		borderWidth: 1,
		borderColor: '#ccc',
		borderRadius: 8,
		textAlign: 'center',
		fontSize: 24,
		marginHorizontal: 3,
		backgroundColor: '#f9f9f9',
		color: '#333',
		maxWidth: 45,
		minWidth: 35,
	},
	submitButton: {
		backgroundColor: '#1792E5',
		paddingVertical: 12,
		paddingHorizontal: 30,
		borderRadius: 8,
		marginTop: 20,
	},
	submitButtonText: {
		color: '#fff',
		fontSize: 16,
		fontWeight: '600',
	},

	modalOverlay: {
		flex: 1,
		backgroundColor: 'rgba(0, 0, 0, 0.5)',
		justifyContent: 'center',
		alignItems: 'center',
	},
	modalContainer: {
		width: '90%',
		maxWidth: 400,
		minWidth: 320,
		backgroundColor: 'white',
		borderRadius: 12,
		overflow: 'hidden',
		elevation: 5,
		shadowColor: '#000',
		shadowOffset: { width: 0, height: 2 },
	},
	modalContent: {
		backgroundColor: 'white',
		padding: 20,
	},
	modalTitle: {
		fontSize: 20,
		fontWeight: '600',
		color: '#333',
		marginBottom: 10,
		textAlign: 'center',
	},
	modalDescription: {
		fontSize: 16,
		color: '#666',
		marginBottom: 20,
		textAlign: 'center',
	},
	modalButtons: {
		flexDirection: 'row',
		justifyContent: 'space-between',
	},
	configButton: {
		flex: 1,
		backgroundColor: '#1792E5',
		padding: 12,
		borderRadius: 5,
		marginHorizontal: 5,
		alignItems: 'center',
	},
	configButtonText: {
		color: 'white',
		fontSize: 16,
		fontWeight: '500',
	},

	//#region Log screen
	logScreenContainer: {
		flex: 1,
		backgroundColor: '#F2F2F2',
	},
	logContainer: {
		flexDirection: 'row',
		marginVertical: 10,
		marginHorizontal: 5,
	},
	tabContainer: {
		flex: 1,
		paddingVertical: 5,
		paddingHorizontal: 10,
		justifyContent: 'center',
		alignItems: 'center',
		borderRadius: 4,
	},
	selectedTabContainer: {
		backgroundColor: '#1792E5', // Blue background for selected tab
		elevation: 3,
		shadowColor: '#000',
		shadowOffset: { width: 0, height: 1 },
		shadowOpacity: 0.2,
		shadowRadius: 1.5,
	},
	notSelectedTabContainer: {
		backgroundColor: '#f0f0f0', // Light grey for unselected tabs
		borderWidth: 1,
		borderColor: '#ddd',
	},
	overlappingTab: {
		marginLeft: -10, // Creates the overlapping effect
	},
	tabText: {
		textAlign: 'center',
		fontSize: 14,
	},
	selectedTabText: {
		color: '#FFFFFF',
		fontWeight: '500',
	},
	notSelectedTabText: {
		color: '#7f7f7f',
	},
	logList: {
		flex: 1,
	},
	logListContent: {
		paddingBottom: 10,
	},
	logItemContainer: {
		flexDirection: 'row',
		marginHorizontal: 5,
		marginVertical: 5,
		backgroundColor: 'white',
		borderRadius: 5,
		elevation: 2,
		shadowColor: '#000',
		shadowOffset: { width: 0, height: 1 },
		shadowOpacity: 0.2,
		shadowRadius: 1.5,
		overflow: 'hidden',
	},
	logItemBar: {
		width: 8,
		borderTopLeftRadius: 5,
		borderBottomLeftRadius: 5,
	},
	logItemContent: {
		flex: 1,
		padding: 10,
	},
	logItemTopRow: {
		flexDirection: 'row',
		justifyContent: 'space-between',
		marginBottom: 5,
	},
	logItemMiddleRow: {
		flexDirection: 'row',
		justifyContent: 'space-between',
		marginBottom: 5,
	},
	logItemBottomRow: {
		flexDirection: 'row',
	},
	logItemTitle: {
		fontSize: 12,
		fontWeight: 'bold',
		color: '#101010',
		flex: 1,
	},
	logItemTime: {
		fontSize: 12,
		fontWeight: 'bold',
		color: '#101010',
	},
	logItemIdInfo: {
		fontSize: 12,
		color: '#606060',
	},
	logItemDate: {
		fontSize: 12,
		color: '#101010',
	},
	logItemAdditionalInfo: {
		fontSize: 12,
		color: '#606060',
		flexWrap: 'wrap',
	},
	logErrorText: {
		fontSize: 12,
		fontWeight: 'bold',
		color: '#101010',
	},
	downloadButton: {
		backgroundColor: '#1792E5',
		padding: 12,
		margin: 10,
		borderRadius: 5,
		alignItems: 'center',
	},
	downloadButtonText: {
		color: 'white',
		fontWeight: '500',
	},
	//#endregion

	//#region Logs Filter Style
	log_filterContainer: {
		backgroundColor: 'white',
		borderRadius: 8,
		padding: 16,
		width: '80%',
		maxWidth: 400,
		elevation: 5,
		shadowColor: '#000',
		shadowOffset: { width: 0, height: 2 },
		shadowOpacity: 0.25,
		shadowRadius: 3.84,
	},
	log_filterTitle: {
		fontSize: 18,
		fontWeight: 'bold',
		marginBottom: 16,
		textAlign: 'center',
	},
	log_filterOption: {
		paddingVertical: 12,
		borderBottomWidth: 1,
		borderBottomColor: '#f0f0f0',
	},
	log_filterRow: {
		flexDirection: 'row',
		alignItems: 'center',
	},
	log_radioButton: {
		height: 20,
		width: 20,
		borderRadius: 10,
		borderWidth: 2,
		borderColor: '#1792E5',
		alignItems: 'center',
		justifyContent: 'center',
		marginRight: 10,
	},
	log_radioButtonSelected: {
		borderColor: '#1792E5',
	},
	log_radioButtonInner: {
		height: 10,
		width: 10,
		borderRadius: 5,
		backgroundColor: '#1792E5',
	},
	log_filterLabel: {
		fontSize: 16,
	},
	log_buttonContainer: {
		flexDirection: 'row',
		justifyContent: 'space-between',
		marginTop: 20,
	},
	log_cancelButton: {
		padding: 12,
		backgroundColor: '#f0f0f0',
	},
	log_applyButton: {
		padding: 12,
		backgroundColor: '#1792E5',
	},
	log_applyButtonText: {
		color: 'white',
	},
	//#endregion

	//#region About Device
	// Add to the existing styles object
	aboutDeviceContainer: {
		backgroundColor: 'white',
		borderRadius: 8,
		padding: 20,
		width: '80%',
		maxWidth: 400,
		elevation: 5,
		shadowColor: '#000',
		shadowOffset: { width: 0, height: 2 },
		shadowOpacity: 0.25,
		shadowRadius: 3.84,
	},
	aboutDeviceTitle: {
		fontSize: 18,
		fontWeight: 'bold',
		marginBottom: 16,
		textAlign: 'center',
		color: '#333',
	},
	aboutDeviceRow: {
		flexDirection: 'row',
		justifyContent: 'space-between',
		paddingVertical: 10,
		borderBottomWidth: 1,
		borderBottomColor: '#f0f0f0',
	},
	aboutDeviceLabel: {
		fontSize: 16,
		color: '#666',
		flex: 1,
	},
	aboutDeviceValue: {
		fontSize: 16,
		color: '#333',
		fontWeight: '500',
		flex: 1,
		textAlign: 'right',
	},
	//#region

	//#region Mirror HMI Modal Styles
	mirrorHmiContainer: {
		flex: 1,
		justifyContent: 'center',
		alignItems: 'center',
		marginTop: 22,
	},
	mirrorHmiCenteredView: {
		flex: 1,
		justifyContent: 'center',
		alignItems: 'center',
		marginTop: 22,
	},
	mirrorHmiModalView: {
		width: '90%',
		backgroundColor: 'white',
		padding: 0,
		shadowOpacity: 0.25,
		shadowRadius: 4,
		elevation: 5,
		paddingBottom: 70,
	},
	mirrorHmiCloseButton: {
		position: 'absolute',
		top: 0,
		right: 0,
		padding: 5,
		zIndex: 0,
	},
	mirrorHmiCloseButtonText: {
		fontSize: 34,
		lineHeight: 34,
		fontWeight: '300',
	},
	mirrorHmiButton: {
		borderRadius: 20,
		padding: 10,
		elevation: 2,
	},
	mirrorHmiButtonOpen: {
		backgroundColor: '#F194FF',
	},
	mirrorHmiButtonClose: {
		backgroundColor: '#2196F3',
	},
	mirrorHmiTextStyle: {
		color: 'white',
		fontWeight: 'bold',
	},
	mirrorHmiModalText: {
		fontSize: 16,
		marginBottom: 6,
		lineHeight: 18,
	},
	mirrorHmiInlineText: {
		fontSize: 16,
		marginBottom: 0,
		marginRight: 4,
		lineHeight: 18,
	},
	mirrorHmiBold: {
		fontWeight: 'bold',
	},
	mirrorHmiStatusDot: {
		color: 'red',
		fontSize: 16,
		lineHeight: 18,
		marginRight: 4,
	},
	mirrorHmiStatusRow: {
		flexDirection: 'row',
		alignItems: 'center',
		justifyContent: 'space-between',
		marginBottom: 6,
	},

	mirrorHmiTable: { marginTop: 4 },
	mirrorHmiTableRow: {
		flexDirection: 'row',
		borderBottomWidth: 1,
		borderBottomColor: '#bbb',
		paddingVertical: 4,
	},
	mirrorHmiTableRowLast: { borderBottomWidth: 0 },
	mirrorHmiTableCell: { flex: 1, paddingHorizontal: 4, lineHeight: 18 },
	mirrorHmiTableCellRight: { textAlign: 'right' },
	mirrorHmiInfoSection: {
		backgroundColor: '#fff',
		padding: 10,
		borderBottomWidth: 1,
		borderBottomColor: '#000',
		zIndex: 0,
	},
	mirrorHmiFooter: {
		position: 'absolute',
		left: 0,
		right: 0,
		bottom: 0,
		flexDirection: 'row',
		borderWidth: 1,
		borderColor: '#000',
		backgroundColor: '#fafafa',
	},
	mirrorHmiFooterButton: {
		flex: 1,
		paddingVertical: 14,
		minHeight: 56,
		alignItems: 'center',
		justifyContent: 'center',
		borderRightWidth: 2,
		borderRightColor: '#000',
	},
	mirrorHmiFooterButtonLast: {
		borderRightWidth: 0,
	},
	mirrorHmiFooterButtonDark: { backgroundColor: '#444' },
	mirrorHmiFooterButtonDarker: { backgroundColor: '#2f2f2f' },
	mirrorHmiFooterButtonContent: {
		alignItems: 'center',
		justifyContent: 'center',
	},
	mirrorHmiFooterIcon: {
		fontSize: 20,
		marginBottom: 4,
		color: '#fff',
	},
	mirrorHmiFooterButtonText: {
		fontSize: 16,
		fontWeight: '600',
		color: '#fff',
	},
	//#endregion

	//#region Obscuration Table
	modalHeader: {
		flexDirection: 'row',
		alignItems: 'center',
		justifyContent: 'space-between',
		height: responsiveHeight(8),
		backgroundColor: '#F0F0F0',
		marginBottom: commonSizes.heightM_Pixel,
		marginHorizontal: -commonSizes.widthXL_Pixel,
		marginTop: -commonSizes.widthXL_Pixel,
		paddingHorizontal: commonSizes.widthXL_Pixel,
		paddingTop: commonSizes.widthXL_Pixel,
	},
	closeButton: {
		justifyContent: 'center',
		alignItems: 'center',
	},
	tableHeader: {
		flexDirection: 'row',
		width: responsiveWidth(75), // Responsive instead of hardcoded 291
		height: responsiveHeight(4.5), // Responsive instead of hardcoded 35
		alignItems: 'center',
		borderBottomWidth: commonSizes.lineThickness,
		borderBottomColor: commonColors.lineColorLight,
		marginBottom: commonSizes.heightS_Pixel,
	},
	headerText: {
		flex: 1,
		fontSize: commonSizes.textSizeS,
		fontWeight: 500,
		textAlign: 'center',
		color: commonColors.textColor_Black,
	},
	tableContainer: {
		width: '100%',
		maxHeight: responsiveHeight(40), // Responsive instead of hardcoded 300
	},
	cellText: {
		flex: 1,
		fontWeight: 500,
		textAlign: 'center',
		color: '#303030',
	},
	tableRow: {
		flexDirection: 'row',
		width: responsiveWidth(75), // Responsive instead of hardcoded 291
		height: responsiveHeight(4.5), // Responsive instead of hardcoded 35
		alignItems: 'center',
		borderBottomWidth: commonSizes.lineThicknessXS,
		borderBottomColor: commonColors.lineColorLight,
		marginBottom: commonSizes.heightXS_Pixel,
	},
	evenrow: {
		backgroundColor: '#F8F8F8', // Light gray background for evenrow rows
	},
	//#endregion
});
