import React, { useEffect, useRef, useState } from 'react';
import {
	View,
	Text,
	StyleSheet,
	TouchableOpacity,
	SafeAreaView,
	Dimensions,
	BackHandler,
	ScrollView,
} from 'react-native';
import { SafeAreaView as SafeAreaContextView } from 'react-native-safe-area-context';
import { CircularProgress } from 'react-native-circular-progress';
import { TestsModel } from '@ff_model/testModel.ts';
import { useDatabase } from '../../../global/DatabaseContext.tsx';
import { useAppDispatch } from '../../../global/hooks.ts';
import {
	fetchTestHistory,
	updateExistingTestHistory,
	fetchOneTestHistory,
} from '@ff_redux/testHistoryRedux/testHistoryThunk.ts';
import { TestsHistoryModel } from '@ff_model/testHistoryModel.ts';
import { delay } from '@ff_utils/timeDelay.ts';
import { useTranslation } from 'react-i18next';
import { BluetoothDevice } from 'bleCommunicator/bleService.ts';
import faastflexBluetoothCommunicator from '@faastflexCommunicator/faastflexBluetoothCommunicator.ts';
import stringFormat from '@ff_utils/stringFormat.ts';
import LeftArrowWhite from '@assets/images/LeftArrowWhite.svg';

const { width } = Dimensions.get('window');

export default function PerformDeviceTestScreen({ route, navigation }: any) {
	//Database
	const dispatch = useAppDispatch();
	const { dataSource } = useDatabase();
	const { t } = useTranslation();

	//Properties
	// const [currentTest, setCurrentTest] = useState<TestsModel>();
	// const [remainingTests, setRemainingTests] = useState(0);
	const [testName, setTestName] = useState('');
	const [testDescription, setTestDescription] = useState('');
	const [testStatustext, setTestStatustext] = useState('');
	const [passButtonText, setPassButtonText] = useState('Pass');
	const [isButtonsEnabled, setIsButtonsEnabled] = useState(true);
	const [testStatus, setTestStatus] = useState('');
	const [testProgress, setTestProgress] = useState(0);
	const [totalSeconds, setTotalSeconds] = useState(0);
	const [stopButton, setStopButton] = useState(t('btnStoptest'));
	const [timeLeft, setTimeLeft] = useState(30);
	const timerRef = useRef<NodeJS.Timeout | null>(null);

	const [isTestFailedMethodCompleted, setIsTestFailedMethodCompleted] =
		useState(false);
	const [isTestPassedMethodCompleted, setIsTestPassedMethodCompleted] =
		useState(false);
	const [isStopTestMethodCompleted, setIsStopTestMethodCompleted] =
		useState(false);

	const ConnectedDeviceobj = useRef<BluetoothDevice | null>();

	const remainingTestRef = useRef<number>(0);
	const currentTestRef = useRef<TestsModel | null>(null);
	const isStopTestMethodCompletedRef = useRef<boolean>(false);
	const isTestPassedMethodCompletedRef = useRef<boolean>(false);
	const isTestFailedMethodCompletedRef = useRef<boolean>(false);
	const currentDeviceId = useRef<number>(0);
	const allTests = useRef<TestsModel[]>([]);
	const testsHistoryModels = useRef<TestsHistoryModel[]>([]);
	const nextCmd = useRef<number>(0);

	//#region  On Screen Appeared
	useEffect(() => {
		InitializeAsync();
		return () => {
			// Clean up timer when component unmounts
			if (timerRef.current) {
				clearInterval(timerRef.current);
			}
		};
	}, []);

	useEffect(() => {
		const unsubscribe = navigation.addListener('focus', () => {
			OnPageAppeared();
		});
		return unsubscribe;
	}, [navigation]);
	//#endregion

	// Value Updates based on Test Status
	useEffect(() => {
		if (timeLeft > -1) {
			setPassButtonText(stringFormat(t('PassBtnTextWithTimer'), timeLeft));
		}
	}, [timeLeft, currentTestRef.current]);

	//#region Prevent Device Back Functionality
	useEffect(() => {
		const backHandler = BackHandler.addEventListener(
			'hardwareBackPress',
			() => {
				return true; // Return true to prevent default back behavior
			},
		);

		return () => backHandler.remove();
	}, []);

	//iOS
	useEffect(() => {
		navigation.setOptions({
			gestureEnabled: false, // Disable swipe back gesture
		});
	}, [navigation]);
	//#endregion

	async function InitializeAsync() {
		if (
			route.params !== null &&
			route.params !== undefined &&
			route.params.connectedDevice !== null
		) {
			ConnectedDeviceobj.current = route.params
				.connectedDevice as BluetoothDevice;
		}
		if (
			route.params !== null &&
			route.params !== undefined &&
			route.params.deviceId !== null
		) {
			let deviceId = route.params.deviceId as number;
			currentDeviceId.current = deviceId;
		}
		if (
			route.params !== null &&
			route.params !== undefined &&
			route.params.tests !== null
		) {
			let tests = route.params.tests as TestsModel[];
			allTests.current = tests;
			remainingTestRef.current = tests.length;
			currentTestRef.current = tests[tests.length - remainingTestRef.current];
			DeserializeObjectForUI(currentTestRef.current);
			nextCmd.current = 0;
			const selfTestResult = faastflexBluetoothCommunicator.StartSelftestEurope(
				nextCmd.current,
			);
			await startTimer(currentTestRef.current);
			setTestProgress((0 / allTests.current.length) * 100);
			setTestStatus(0 + '/' + allTests.current.length);
			var testHistory = await dispatch(
				fetchTestHistory({
					dataSource,
					deviceId: currentDeviceId.current,
				}),
			).unwrap();
			testsHistoryModels.current = testHistory;
			setStopButton(t('btnStoptest'));
		}
	}

	async function OnPageAppeared() {
		setStopButton(t('btnStoptest'));
	}

	async function DeserializeObjectForUI(test: TestsModel) {
		setTestName(test.testNameKey);
		console.log(testName);
		setTestDescription(test.testDescriptionKey);
		console.log(testDescription);
		setIsButtonsEnabled(true);
		setPassButtonText(stringFormat(t('PassBtnTextWithTimer'), timeLeft));
	}

	async function testFailed() {
		if (isTestFailedMethodCompletedRef.current) return;

		isTestFailedMethodCompletedRef.current = true;

		if (remainingTestRef.current > 0 && currentTestRef.current) {
			const updatedTests = [...allTests.current];
			const failedTestIndex = updatedTests.findIndex(
				i => i.testNameKey === currentTestRef.current?.testNameKey,
			);
			if (failedTestIndex !== -1) {
				updatedTests[failedTestIndex] = {
					...updatedTests[failedTestIndex],
					isTestFailed: true,
					isTestPassed: false,
					isTested: true,
					isVisibleTestStatus: true,
					testStatustext: 'Test Failed',
					isButtonsEnable: false,
				};
				allTests.current = updatedTests;
				const testedTests = updatedTests.filter(x => x.isTested).length;
				setTestProgress((testedTests / allTests.current.length) * 100);
				setTestStatus(testedTests + '/' + allTests.current.length);
				UpdateFailedHistoryTest(currentTestRef.current);

				//Stop Timer
				handleTimeout();
				nextCmd.current = 2;
				if (testedTests <= allTests.current.length) {
					const selfTestResult =
						faastflexBluetoothCommunicator.StartSelftestEurope(nextCmd.current);
				}
			}
		}
		await delay(300);
		isTestFailedMethodCompletedRef.current = false;
	}
	async function UpdateFailedHistoryTest(test: TestsModel) {
		var id = 0;
		id =
			testsHistoryModels.current?.filter(
				x => x.deviceId === test.deviceId && x.testHistoryId === test.testId,
			)[0]?.id || 0;
		var testHistory = await dispatch(
			fetchOneTestHistory({ dataSource, testId: id }),
		);
		const fetchedTestHistory = testHistory?.payload as TestsHistoryModel;
		if (fetchedTestHistory) {
			//Update Test History
			const updatedHistoryTest: TestsHistoryModel = {
				...fetchedTestHistory,
				isTestTested: true,
				isTestPassed: false,
				isTestFailed: true,
				isVisibleTestStatus: true,
				testStatustext: 'Fail.png',
			};
			await dispatch(
				updateExistingTestHistory({
					dataSource,
					testHistoryId: updatedHistoryTest.testHistoryId,
					deviceId: updatedHistoryTest.deviceId,
					updates: updatedHistoryTest,
				}),
			);
		}
	}

	async function testPassed() {
		if (isTestPassedMethodCompletedRef.current) return;
		isTestPassedMethodCompletedRef.current = true;

		console.log('Test Passed Clicked', allTests.current);

		if (remainingTestRef.current > 0 && currentTestRef.current) {
			const updatedTests = [...allTests.current];
			const failedTestIndex = updatedTests.findIndex(
				i => i.testNameKey === currentTestRef.current?.testNameKey,
			);
			if (failedTestIndex !== -1) {
				updatedTests[failedTestIndex] = {
					...updatedTests[failedTestIndex],
					isTestFailed: false,
					isTestPassed: true,
					isTested: true,
					isVisibleTestStatus: true,
					testStatustext: 'Pass.png',
					isButtonsEnable: false,
					passButtonText: t('Pass'),
				};
				allTests.current = updatedTests;
				const testedTests = updatedTests.filter(x => x.isTested).length;
				setTestProgress((testedTests / allTests.current.length) * 100);
				setTestStatus(testedTests + '/' + allTests.current.length);
				UpdatePassedHistoryTest(currentTestRef.current);

				//Stop Timer
				handleTimeout();
				nextCmd.current = 1;
				if (testedTests <= allTests.current.length) {
					const selfTestResult =
						faastflexBluetoothCommunicator.StartSelftestEurope(nextCmd.current);
				}
			}
		}
		await delay(300);
		isTestPassedMethodCompletedRef.current = false;
	}
	async function UpdatePassedHistoryTest(test: TestsModel) {
		var id = 0;
		id =
			testsHistoryModels.current?.filter(
				x => x.deviceId === test.deviceId && x.testHistoryId === test.testId,
			)[0]?.id || 0;
		var testHistory = await dispatch(
			fetchOneTestHistory({ dataSource, testId: id }),
		);
		const fetchedTestHistory = testHistory?.payload as TestsHistoryModel;
		if (fetchedTestHistory) {
			//Update Test History
			const updatedHistoryTest: TestsHistoryModel = {
				...fetchedTestHistory,
				isTestTested: true,
				isTestPassed: true,
				isTestFailed: false,
				isVisibleTestStatus: true,
				testStatustext: 'Pass.png',
			};
			await dispatch(
				updateExistingTestHistory({
					dataSource,
					testHistoryId: updatedHistoryTest.testHistoryId,
					deviceId: updatedHistoryTest.deviceId,
					updates: updatedHistoryTest,
				}),
			);
		}
	}

	async function StopTest() {
		if (isStopTestMethodCompleted) return;
		setIsStopTestMethodCompleted(true);
		var nxtCmd = stopButton === t('btnStoptest') ? 4 : 3; //4 is for abort, 3 is for Exit Test Command
		const selfTestResult =
			faastflexBluetoothCommunicator.StartSelftestEurope(nxtCmd);
		remainingTestRef.current = 0;
		navigation.goBack();
	}
	async function startTimer(currentTests: TestsModel) {
		if (currentTests) {
			currentTestRef.current = currentTests;
			DeserializeObjectForUI(currentTests);
		}
		setTimeLeft(30);
		if (timerRef.current) {
			clearInterval(timerRef.current);
		}

		timerRef.current = setInterval(() => {
			setTimeLeft(prev => {
				if (prev <= 0) {
					testFailed();
					return 0;
				}
				return prev - 1;
			});
		}, 1000);
	}

	async function handleTimeout() {
		remainingTestRef.current -= 1;
		if (timerRef.current) {
			clearInterval(timerRef.current);
		}
		rerunTimer();
		//TODO: Move to next Test
	}

	function rerunTimer() {
		if (remainingTestRef.current === 0) {
			setPassButtonText(t('Pass'));
			setStopButton(t('Done_Pascal'));
			setIsButtonsEnabled(false);
			return;
		} else {
			var currentTest =
				allTests.current[allTests.current.length - remainingTestRef.current];
			startTimer(currentTest);
		}
	}

	const BackButtonCommand = () => {
		navigation.goBack();
	};

	const renderHeader = () => {
		return (
			<SafeAreaContextView edges={['top']} style={styles.safeHeader}>
				<View
					style={[
						styles.headerSection,
						{
							backgroundColor: '#000',
							alignItems: 'center',
						},
					]}>
					<View
						style={{
							flexDirection: 'row',
							alignItems: 'center',
							paddingHorizontal: 10,
							height: '100%',
							backgroundColor: '#000',
						}}>
						{false && (
							<TouchableOpacity
								onPress={() => BackButtonCommand()}
								style={{
									height: '100%',
									padding: 0,
									margin: 0,
									justifyContent: 'center',
								}}>
								<LeftArrowWhite height={30} width={30} />
							</TouchableOpacity>
						)}

						<View style={[{ flex: 2 }]}>
							<Text
								style={{
									color: '#fff',
									fontSize: 18,
									fontWeight: 'bold',
									textAlign: 'center',
								}}>
								{t('PerformingDeviceTesting')}
							</Text>
						</View>
					</View>
				</View>
			</SafeAreaContextView>
		);
	};

	return (
		<View style={styles.container}>
			{renderHeader()}
			<ScrollView>
				<View style={styles.contentContainer}>
					{/* Circle with test state */}
					<View style={styles.circleContainer}>
						<CircularProgress
							size={CIRCLE_SIZE}
							width={CIRCLE_SIZE * 0.025}
							fill={testProgress}
							tintColor='green'
							backgroundColor='#e0e0e0'
							rotation={180}
							lineCap='square'>
							{() => (
								<View style={styles.circle}>
									<Text style={[styles.circleText]}>
										{t('InitializingTest')}
									</Text>
									<Text style={[styles.circleText]}>{testStatus}</Text>
									<Text style={styles.circleStatus}>{t('TestCompleted')}</Text>
								</View>
							)}
						</CircularProgress>
					</View>

					<View style={styles.separator} />

					{/* Note */}
					<Text style={styles.note}>{t('PerformTestWarningMsg')}</Text>

					{/* Pass/Fail Buttons */}
					<View style={styles.buttonCard}>
						<View style={styles.testItem}>
							<Text style={styles.testTitle}>{t(testName)}</Text>
							<Text style={styles.testDesc}>{t(testDescription)}</Text>
						</View>
						<View
							style={{
								flexDirection: 'row',
								justifyContent: 'center',
								marginTop: 20,
							}}>
							<TouchableOpacity
								style={[
									styles.failButton,
									{ opacity: isButtonsEnabled ? 1 : 0.5 },
								]}
								disabled={!isButtonsEnabled}
								onPress={testFailed}>
								<Text style={styles.failButtonText}>{t('Fail')}</Text>
							</TouchableOpacity>
							<TouchableOpacity
								style={[
									styles.passButton,
									{ opacity: isButtonsEnabled ? 1 : 0.5 },
								]}
								disabled={!isButtonsEnabled}
								onPress={testPassed}>
								<Text style={styles.passButtonText}>{passButtonText}</Text>
							</TouchableOpacity>
						</View>
					</View>
				</View>

				{/* Stop Button */}
			</ScrollView>
			<View style={styles.stopButtonContainer}>
				<TouchableOpacity style={styles.stopButton} onPress={StopTest}>
					<Text style={styles.stopButtonText}>{stopButton}</Text>
				</TouchableOpacity>
			</View>
		</View>
	);
}

const CIRCLE_SIZE = width * 0.65;

const styles = StyleSheet.create({
	container: {
		flex: 1,
		backgroundColor: '#fff',
	},
	contentContainer: {
		flex: 1,
	},
	header: {
		backgroundColor: '#393939',
		paddingVertical: 18,
		alignItems: 'center',
	},
	headerText: {
		color: '#fff',
		fontSize: 28,
		fontWeight: '400',
		letterSpacing: 1,
	},
	circleContainer: {
		alignItems: 'center',
		marginVertical: 20,
	},
	circle: {
		width: CIRCLE_SIZE,
		height: CIRCLE_SIZE,
		borderRadius: CIRCLE_SIZE / 2,
		borderWidth: 4,
		borderColor: '#d2f9f1',
		justifyContent: 'center',
		alignItems: 'center',
		backgroundColor: '#fff',
	},
	circleText: {
		fontSize: 22,
		color: '#999',
		marginBottom: 12,
	},
	circleStatus: {
		fontSize: 20,
		color: '#1897ec',
		fontWeight: '400',
	},
	separator: {
		borderBottomWidth: 2,
		borderColor: '#aaa',
		marginHorizontal: 0,
		marginBottom: 10,
	},
	note: {
		color: '#888',
		fontSize: 18,
		marginHorizontal: 16,
		marginBottom: 20,
	},
	buttonCard: {
		flexDirection: 'column',
		justifyContent: 'center',
		backgroundColor: '#fff',
		marginHorizontal: 10,
		borderRadius: 4,
		elevation: 3,
		paddingVertical: 16,
		marginTop: 0,
		marginBottom: 10,
		shadowColor: '#000',
		shadowOpacity: 0.1,
		shadowOffset: { width: 1, height: 2 },
		shadowRadius: 5,
	},
	failButton: {
		borderColor: '#1897ec',
		borderWidth: 2,
		borderRadius: 2,
		width: 120,
		height: 50,
		justifyContent: 'center',
		alignItems: 'center',
		marginRight: 24,
		backgroundColor: '#fff',
	},
	failButtonText: {
		color: '#1897ec',
		fontSize: 20,
		fontWeight: '400',
	},
	passButton: {
		flexDirection: 'row',
		backgroundColor: '#1897ec',
		borderRadius: 2,
		width: 160,
		height: 50,
		justifyContent: 'center',
		alignItems: 'center',
	},
	passButtonText: {
		color: '#fff',
		fontSize: 20,
		fontWeight: '500',
	},
	stopButtonContainer: {
		justifyContent: 'center',
		alignItems: 'center',
		paddingVertical: 16,
		paddingBottom: 24,
	},
	stopButton: {
		borderColor: '#1897ec',
		borderWidth: 2,
		borderRadius: 2,
		width: 260,
		height: 56,
		justifyContent: 'center',
		alignItems: 'center',
	},
	stopButtonText: {
		color: '#1897ec',
		fontSize: 22,
		fontWeight: '400',
	},

	testItem: {
		padding: 16,
		borderBottomWidth: 1,
		borderBottomColor: '#e6e6e6',
		backgroundColor: '#fff',
	},
	testTitle: {
		fontSize: 22,
		fontWeight: '500',
		color: '#222',
		marginBottom: 4,
	},
	testDesc: {
		fontSize: 16,
		color: '#888',
	},
	headerSection: {
		height: 56,
		width: '100%',
	},
	safeHeader: {
		backgroundColor: '#000',
	},
});
