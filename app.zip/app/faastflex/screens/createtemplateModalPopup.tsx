import RadioButton from '@components/RadioButton';
import React, { useEffect } from 'react';
import {
	View,
	StyleSheet,
	Text,
	Alert,
	TouchableOpacity,
	BackHandler,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import * as yup from 'yup';
import CustomInput from '@ff_controllers/customInputField';
import { Controller, useForm } from 'react-hook-form';
import { yupResolver } from '@hookform/resolvers/yup';
import { commonColors, commonSizes } from '@styles/base';
import DoubleButtonFooter from '@components/doubleButtonFooter';
import { useTranslation } from 'react-i18next';
import LeftArrowWhite from '@assets/images/LeftArrowWhite.svg';
import { AppConstants } from '@global/GlobalConstants/globalConstants';
import { DeviceType } from '@faastflexCommands/commandEnum';

interface FormData {
	TemplateName: string;
	selectedChannel: number;
	selectedDeviceType: DeviceType;
}

export const CreatetemplateModalPopup = ({
	navigation,
}: {
	navigation: any;
}) => {
	const { t } = useTranslation();
	const validationSchema = yup.object().shape({
		TemplateName: yup
			.string()
			.required(t('templateNameEmptyError'))
			.min(1, t('templateNameEmptyError'))
			.trim(t('templateNameEmptyError'))
			.matches(/^[a-zA-Z0-9 _-]*$/, t('templateNameInvalidError')),
		selectedChannel: yup.number().required(),
	});
	const {
		control,
		handleSubmit,
		formState: { errors },
		getValues,
	} = useForm<FormData>({
		resolver: yupResolver(validationSchema as any),
		defaultValues: {
			TemplateName: '',
			selectedChannel: 1,
			selectedDeviceType: DeviceType.eStandAlone,
		},
	});

	//#region Prevent Device Back Functionality
	useEffect(() => {
		const backHandler = BackHandler.addEventListener(
			'hardwareBackPress',
			() => {
				return true; // Return true to prevent default back behavior
			},
		);

		return () => backHandler.remove();
	}, []);

	//iOS
	useEffect(() => {
		navigation.setOptions({
			gestureEnabled: false, // Disable swipe back gesture
		});
	}, [navigation]);
	//#endregion

	const cancel = () => {
		console.log('cancelling...');
		navigation.goBack();
	};

	const handleProceed = () => {
		const currentValues = getValues();

		// Check if Template Name is empty or contains only whitespace
		if (!currentValues.TemplateName || !currentValues.TemplateName.trim()) {
			Alert.alert('Error', t('templateNameEmptyError'), [{ text: 'ok' }]);
			return;
		}

		// Check if Template Name matches the allowed pattern (alphanumeric, spaces, underscores, hyphens)
		const templateNameRegex = /^[a-zA-Z0-9 _-]+$/;
		if (!templateNameRegex.test(currentValues.TemplateName)) {
			Alert.alert('Error', t('templateNameInvalidError'), [{ text: 'ok' }]);
			return;
		}

		// Pass the selected channel to CreateTemplate screen
		// selectedChannel: 1 means show 1 channel, selectedChannel: 2 means show 2 channels
		navigation.navigate(AppConstants.CreateTemplateScreen, {
			templateName: currentValues.TemplateName,
			selectedChannelCount: currentValues.selectedChannel,
			deviceType: currentValues.selectedDeviceType,
		});
	};

	return (
		<View style={{ flex: 1 }}>
			<SafeAreaView edges={['top']} style={styles.safeHeader}>
				<View
					style={[
						styles.headerSection,
						{
							backgroundColor: '#000',
							alignItems: 'center',
						},
					]}>
					<View
						style={{
							flexDirection: 'row',
							alignItems: 'center',
							paddingHorizontal: 10,
							height: '100%',
						}}>
						<TouchableOpacity
							onPress={() => cancel()}
							style={{
								height: '100%',
								padding: 0,
								margin: 0,
								justifyContent: 'center',
							}}>
							<LeftArrowWhite height={30} width={30} />
						</TouchableOpacity>

						<View style={[{ flex: 2 }]}>
							<Text
								style={{
									color: '#fff',
									fontSize: 18,
									fontWeight: 'bold',
									textAlign: 'center',
								}}>
								{t('createTemplate')}
							</Text>
						</View>
					</View>
				</View>
			</SafeAreaView>
			<View style={styles.container}>
				{/* Trend Log Interval */}
				<View style={styles.section}>
					{/* Heading */}
					<View
						style={{
							paddingVertical: 10,
							borderBottomWidth: 1,
							borderColor: '#e0e0e0',
							marginBottom: 10,
						}}>
						<Text style={{ fontSize: 17, fontWeight: '500' }}>
							{t('createTemplatePageTopText')}
						</Text>
					</View>

					<View style={{ marginVertical: 0 }}>
						<CustomInput
							name='TemplateName'
							control={control}
							placeholder={t('templateNamePlaceHolder')}
							title={t('templateName')}
							isRequired={true}
							errorMessage={undefined}
						/>
					</View>
				</View>

				<View style={styles.section}>
					{/* Heading */}
					<View
						style={{
							paddingVertical: 10,
							borderBottomWidth: 1,
							borderColor: '#e0e0e0',
							marginBottom: 10,
						}}>
						<Text style={{ fontSize: 17, fontWeight: '500' }}>
							{t('SelectDeviceType')}
						</Text>
					</View>

					<Controller
						key='selectedDeviceType'
						name='selectedDeviceType'
						control={control}
						render={({ field: { onChange, value } }) => (
							<View style={styles.GeneralParameterradioContainerVertical}>
								<View>
									<RadioButton
										option={{ id: 1, text: 'Standalone' }}
										isSelected={value === 1}
										onOptionChange={onChange}
									/>
								</View>
								<View
									style={{
										borderBottomWidth: 1,
										borderColor: '#e0e0e0',
										marginBottom: 20,
										marginTop: 20,
									}}
								/>
								<View>
									<RadioButton
										option={{ id: 2, text: 'Addressable' }}
										isSelected={value === 2}
										onOptionChange={onChange}
									/>
								</View>
							</View>
						)}
					/>
				</View>

				<View style={styles.section}>
					<View
						style={{
							paddingVertical: 10,
							borderBottomWidth: 1,
							borderColor: '#e0e0e0',
							marginBottom: 10,
						}}>
						<Text style={styles.sectionTitle}>{t('configureChannel')}</Text>
					</View>
					<Controller
						name='selectedChannel'
						control={control}
						render={({ field: { onChange, value } }) => (
							<View style={styles.GeneralParameterradioContainer}>
								<View style={styles.radiospacebetween}>
									<RadioButton
										option={{ id: 1, text: '01' }}
										isSelected={value === 1}
										onOptionChange={onChange}
									/>
								</View>
								<View style={styles.radiospacebetween}>
									<RadioButton
										option={{ id: 2, text: '02' }}
										isSelected={value === 2}
										onOptionChange={onChange}
									/>
								</View>
							</View>
						)}
					/>
				</View>
			</View>
			<View
				style={{
					borderTopColor: commonColors.lineColor,
					borderTopWidth: commonSizes.lineThicknessS,
					backgroundColor: commonColors.backgroundColor_White,
				}}>
				<View style={{ marginHorizontal: '2%' }}>
					<DoubleButtonFooter
						leftButtonText={t('cancel')}
						rightButtonText={t('proceed')}
						onLeftButtonPress={() => cancel()}
						onRightButtonPress={handleProceed}
					/>
				</View>
			</View>
		</View>
	);
};
const styles = StyleSheet.create({
	container: {
		flex: 1,
		marginHorizontal: 14,
		marginTop: 10,
	},
	section: {
		backgroundColor: '#fff',
		borderRadius: 5,
		paddingHorizontal: 16,
		paddingTop: 16,
		marginBottom: 16,
		borderWidth: 1,
		borderColor: '#e0e0e0',
		elevation: 5,
	},
	sectionTitle: {
		fontSize: 17,
		fontWeight: '500',
		color: commonColors.textColor_Black,
	},
	GeneralParameterradioContainer: {
		flexDirection: 'row',
		justifyContent: 'flex-start',
		alignItems: 'center',
		marginVertical: 8,
		paddingBottom: 10,
	},
	GeneralParameterradioContainerVertical: {
		flexDirection: 'column',
		marginVertical: 8,
		paddingBottom: 10,
	},
	radiospacebetween: {
		flex: 1,
	},
	headerSection: {
		backgroundColor: '#000',
		height: 56,
		width: '100%',
	},
	safeHeader: {
		backgroundColor: '#000',
	},
});
