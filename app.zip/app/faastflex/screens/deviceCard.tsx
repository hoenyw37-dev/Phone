import React from 'react';
import { Text, View, TouchableOpacity, StyleSheet } from 'react-native';
import { DeviceModel } from '@ff_model/deviceModel';
import TripleDotIconGrey from '@assets/images/TripleDotIconGrey.svg';
import DeleteIconBlack from '@assets/images/DeleteIconBlack.svg';
import EditIcon from '@assets/images/EditIcon.svg';

import {
	Menu,
	MenuOptions,
	MenuOption,
	MenuTrigger,
	renderers,
} from 'react-native-popup-menu';
import { commonSizes, commonStyles } from '@styles/base';

interface DeviceCardProps {
	device: DeviceModel;
	currentDevice?: DeviceModel;
	onPress: () => void;
	onOpenMirrorHMI: () => void;
	onDisconnect: () => void;
	onConnectPaired: () => void;
	onPair: () => void;
	onReassign: () => void;
	onDelete: () => void;
	onEdit: () => void;
	onAssign: () => void;
}

export default function DeviceCard({
	device,
	currentDevice,
	onPress,
	onOpenMirrorHMI,
	onDisconnect,
	onConnectPaired,
	onPair,
	onReassign,
	onDelete,
	onEdit,
	onAssign,
}: DeviceCardProps) {
	const OnOpenMirrorHMI = () => {
		onOpenMirrorHMI();
	};
	const OnDisconnect = () => {
		onDisconnect();
	};
	const OnConnectPairedDevice = () => {
		onConnectPaired();
	};
	const OnPairDevice = () => {
		onPair();
	};
	const OnReassignDevice = () => {
		onReassign();
	};
	const OnDeleteDevice = () => {
		onDelete();
	};
	const OnEditDevice = () => {
		onEdit();
	};
	const OnAssignDevice = () => {
		onAssign();
	};
	return (
		<View style={{ flex: 1 }}>
			<TouchableOpacity style={styles.box} onPress={onPress}>
				<View style={styles.content}>
					<Text style={styles.heading}>{device.deviceName}</Text>
					<Text style={styles.description}>
						{device.deviceLocation} | {device.pipeConfiguration}
					</Text>
				</View>
				<View style={styles.verticalLine} />
				<Menu renderer={renderers.Popover}>
					<MenuTrigger>
						<View style={styles.clickableMenu}>
							<TripleDotIconGrey
								width={commonSizes.iconWidthM_Pixel}
								height={commonSizes.iconHeightM_Pixel}
							/>
						</View>
					</MenuTrigger>
					<MenuOptions>
						<MenuOption
							onSelect={OnOpenMirrorHMI}
							style={{ backgroundColor: '#F6F6F6' }}>
							<View style={styles.popUp}>
								<Text style={styles.popUpText}>MirrorHMI</Text>
							</View>
						</MenuOption>
						<MenuOption
							onSelect={OnDisconnect}
							style={{ backgroundColor: '#F6F6F6' }}>
							<View style={styles.popUp}>
								<Text style={styles.popUpText}>Disconnect</Text>
							</View>
						</MenuOption>
						<MenuOption
							onSelect={OnConnectPairedDevice}
							style={{ backgroundColor: '#F6F6F6' }}>
							<View style={styles.popUp}>
								<Text style={styles.popUpText}>Connect_PascalCase</Text>
							</View>
						</MenuOption>
						<MenuOption
							onSelect={OnPairDevice}
							style={{ backgroundColor: '#F6F6F6' }}>
							<View style={styles.popUp}>
								<Text style={styles.popUpText}>PairDevice</Text>
							</View>
						</MenuOption>
						<MenuOption
							onSelect={OnReassignDevice}
							style={{ backgroundColor: '#F6F6F6' }}>
							<View style={styles.popUp}>
								<Text style={styles.popUpText}>ReassignDevice</Text>
							</View>
						</MenuOption>
						<MenuOption
							onSelect={OnAssignDevice}
							style={{ backgroundColor: '#F6F6F6' }}>
							<View style={styles.popUp}>
								<Text style={styles.popUpText}>AssignDevice</Text>
							</View>
						</MenuOption>
						<MenuOption
							onSelect={OnEditDevice}
							style={{ backgroundColor: '#F6F6F6' }}>
							<View style={styles.popUp}>
								<Text style={styles.popUpText}>editdevice</Text>
							</View>
						</MenuOption>
						<MenuOption
							onSelect={OnDeleteDevice}
							style={{ backgroundColor: '#F6F6F6' }}>
							<View style={styles.popUp}>
								<Text style={styles.popUpText}>DeleteDevice</Text>
							</View>
						</MenuOption>
						{/* Add more options here if needed */}
					</MenuOptions>
				</Menu>
			</TouchableOpacity>
		</View>
	);
}

const styles = StyleSheet.create({
	box: { ...commonStyles.box },
	content: {
		...commonStyles.boxContent,
		marginLeft: commonSizes.widthL_Pixel,
	},
	heading: { ...commonStyles.boxHeading },
	description: { ...commonStyles.boxDescription },
	popUp: { ...commonStyles.boxMenuPopUp },
	popUpText: { ...commonStyles.boxMenuText },
	verticalLine: { ...commonStyles.verticalLine },
	clickableMenu: {
		...commonStyles.boxClickableMenu,
		marginHorizontal: commonSizes.widthM_Pixel,
	},
});
