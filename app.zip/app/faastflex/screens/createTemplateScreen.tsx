import React, { useEffect, useState, useRef } from 'react';
import {
	View,
	StyleSheet,
	SafeAreaView,
	ScrollView,
	Text,
	TextInput,
	TouchableOpacity,
	Image,
	BackHandler,
	Platform,
	Alert,
} from 'react-native';
import { SafeAreaView as SafeAreaContextView } from 'react-native-safe-area-context';
import { MenuProvider } from 'react-native-popup-menu';
import RNPickerSelect from 'react-native-picker-select';
import * as yup from 'yup';
import { yupResolver } from '@hookform/resolvers/yup';
import { Controller, useForm } from 'react-hook-form';
import CryptoJS from 'crypto-js';
import DropDown from '@ff_controllers/dropdown.tsx';
import SingleButtonFooter from '@components/singleButtonFooter';
import RadioButton from '@components/RadioButton';
import CustomInput from '@ff_controllers/customInputField.tsx';
import PasswordModal from '@ff_controllers/passwordModal.tsx';
import { commonColors, commonSizes } from '@styles/base';
import IncrementDecrement from '@ff_controllers/incrementAndDecrement.tsx';

import { DeviceModel } from '@ff_model/deviceModel.ts';
//import { TimeSpan } from '../Utils/timeSpan.ts';
import { DeviceParametersModel } from '@ff_model/deviceParametersModel.ts';
import { confirmAlert } from '@ff_utils/confirmAlert.ts';
import Toast from 'react-native-toast-message';
import { useTranslation } from 'react-i18next';
import RNFS from 'react-native-fs';
import {
	DeviceType,
	ExternalInputAction,
	ExternalInputNormalState,
	getExternalInputActionDescription,
	getExternalInputNormalStateDescription,
} from '@faastflexCommands/commandEnum.ts';
import { encryptAndSerializeConfigFile } from '@ff_utils/fileDecryption';
import GeneralEnabled from '@assets/images/GeneralEnabled.svg';
import General from '@assets/images/General.svg';
import Dashboard from '@assets/images/Dashboard.svg';
import DashboardEnabled from '@assets/images/DashboardEnabled.svg';
import DropDownIcon from '@assets/images/DropDownIcon.svg';
import ImageButtonSVG from '@ff_controllers/imageButtonSVG.tsx';
import ResetButton from '@assets/images/ResetButton.svg';
import stringFormat from '@ff_utils/stringFormat.ts';
import LeftArrowWhite from '@assets/images/LeftArrowWhite.svg';
import { AppConstants } from '@global/GlobalConstants/globalConstants.ts';
import Share from 'react-native-share';

interface GeneralParametersData {
	Password: string;
	Orientation: string;
	selectedDate: Date;
	selectedTime: Date;
	TrendLogInterval: number;
	isTemparatureFaultSetRelays: number;
	isLowPowerFaultSetRelays: number;
	CheckedSpeed: number;
	AspiratorCorrection: number;
}

interface ChannelsAndSensorsData {
	ActionDelay: number;
	AlarmDelay: number;
	FlowFaultDelay: number;
	AlarmConfiguration: number;
	ActionConfiguration: number;
	FaultConfiguration: number;
	AlarmMode: number;
	ActionLevel1: number;
	AlarmLevel1: number;
	Referenceflow1: number;
	FlowFaultThreshold1: number;
	UseEN54Limit1: number;
	SetFlowLimit1: number;
	ActionLevel2?: number;
	AlarmLevel2?: number;
	Referenceflow2?: number;
	FlowFaultThreshold2?: number;
	UseEN54Limit2?: number;
	SetFlowLimit2?: number;
	Alarm1Configuration: number;
	Alarm2Configuration: number;
	GeneralFaultConfiguration: number;
	AuxFaultConfiguration: number;
	FlowFaultThresholdValue: number;
	FlowFaultThreshold: number;
}

export default function CreateTemplateScreen({ route, navigation }: any) {
	// Get the selected channel count from navigation params
	const { t } = useTranslation();

	const [NoOfChannels, setNoOfChannels] = useState(1);
	const [isChannel, setIsChannel] = useState(2);
	const [isGeneralParameterVisible, setIsGeneralParameterVisible] =
		useState<boolean>(true);
	const [IsChannel2Available, setIsChannel2Available] =
		useState<boolean>(false);
	const [selectedDevice, setSelectedDevice] = useState<DeviceModel>(
		new DeviceModel(),
	);
	const [isChannelsAndSensorsVisible, setIsChannelsAndSensorsVisible] =
		useState<boolean>(false);
	const [currentField, setCurrentField] = useState<string>('');
	const [isGPIDropDownModalVisible, setGPIDropDownModalVisible] =
		useState<boolean>(false);
	const [isPasswordModalVisible, setPasswordModalVisible] = useState(false);
	const [tempSelectedItem, setTempSelectedItem] = useState<string | null>(null);
	const [RealConfiguration, setRealConfiguration] =
		useState<string>('Extented');
	const [password, setPassword] = useState<string>('');
	const deviceParameters = useRef<DeviceParametersModel>(
		new DeviceParametersModel(),
	);
	const templateName = useRef<string>('');
	const selectedChannelCount = useRef<number>(1);
	const [isIntelligentDevice, setIsIntelligentDevice] =
		useState<boolean>(false);
	const deviceTypeRef = useRef<DeviceType>(DeviceType.eUnknown);

	// GPI state variables using enum types
	const [gpiInputState, setGpiInputState] = useState<number>(1);
	const [gpiNormalState, setGpiNormalState] =
		useState<ExternalInputNormalState>(ExternalInputNormalState.eShort);
	const [unbalancedEventTriggered, setUnbalancedEventTriggered] =
		useState<ExternalInputAction>(ExternalInputAction.eResetAlarmAndFault);
	const [eventTriggerOnClose, setEventTriggerOnClose] =
		useState<ExternalInputAction>(ExternalInputAction.eResetAlarmAndFault);
	const [eventTriggerOnOpen, setEventTriggerOnOpen] =
		useState<ExternalInputAction>(ExternalInputAction.eResetAlarmAndFault);

	// Helper functions for GPI dropdowns
	function getExternalInputActionItems(): Array<{
		label: string;
		value: ExternalInputAction;
	}> {
		return [
			{
				label: getExternalInputActionDescription(ExternalInputAction.eNone),
				value: ExternalInputAction.eNone,
			},
			{
				label: getExternalInputActionDescription(
					ExternalInputAction.eResetDevice,
				),
				value: ExternalInputAction.eResetDevice,
			},
			{
				label: getExternalInputActionDescription(
					ExternalInputAction.eTriggerExtFault,
				),
				value: ExternalInputAction.eTriggerExtFault,
			},
			{
				label: getExternalInputActionDescription(
					ExternalInputAction.ePerformADisableAction,
				),
				value: ExternalInputAction.ePerformADisableAction,
			},
			{
				label: getExternalInputActionDescription(
					ExternalInputAction.eResetAlarmAndFault,
				),
				value: ExternalInputAction.eResetAlarmAndFault,
			},
		];
	}

	function getExternalInputNormalStateItems(): Array<{
		label: string;
		value: ExternalInputNormalState;
	}> {
		return [
			{
				label: getExternalInputNormalStateDescription(
					ExternalInputNormalState.eOpen,
				),
				value: ExternalInputNormalState.eOpen,
			},
			{
				label: getExternalInputNormalStateDescription(
					ExternalInputNormalState.eShort,
				),
				value: ExternalInputNormalState.eShort,
			},
		];
	}
	//#region  Removed Header to Have Custom Header

	// Update NoOfChannels when route params change
	useEffect(() => {
		InitializeAsync();
	}, []);
	async function InitializeAsync() {
		if (
			route.params !== null &&
			route.params !== undefined &&
			route.params.templateName !== null
		) {
			templateName.current = route.params.templateName;
		}
		if (
			route.params !== null &&
			route.params !== undefined &&
			route.params.selectedChannelCount !== null
		) {
			selectedChannelCount.current = route.params.selectedChannelCount;
			setNoOfChannels(selectedChannelCount.current);
		}
		if (
			route.params !== null &&
			route.params !== undefined &&
			route.params.deviceType !== null
		) {
			deviceTypeRef.current = route.params.deviceType;
			setIsIntelligentDevice(
				route.params.deviceType === DeviceType.eIntelligent,
			);
		}
	}

	//#endregion

	//#region Prevent Device Back Functionality
	useEffect(() => {
		const backHandler = BackHandler.addEventListener(
			'hardwareBackPress',
			() => {
				return true; // Return true to prevent default back behavior
			},
		);

		return () => backHandler.remove();
	}, []);

	//iOS
	useEffect(() => {
		navigation.setOptions({
			gestureEnabled: false, // Disable swipe back gesture
		});
	}, [navigation]);
	//#endregion

	//#region General Parameters Form

	const GeneralSchema = yup.object().shape({
		TrendLogInterval: yup
			.number()
			.transform((value, originalValue) => {
				// Convert empty string to undefined for proper validation
				return originalValue === '' ? undefined : value;
			})
			.nullable()
			.optional()
			.integer(t('positiveNumberValidationErrorMsg'))
			.min(0, stringFormat(t('rangeValidationErrorMsg'), '0', '240'))
			.max(240, stringFormat(t('rangeValidationErrorMsg'), '0', '240')),
	});
	const {
		control: generalControl,
		handleSubmit: generalHandleSubmit,
		formState: { errors: generalErrors },
		setValue: generalSetValue,
		watch: generalWatch,
		clearErrors: generalClearErrors,
		trigger: generalTrigger,
	} = useForm<GeneralParametersData>({
		resolver: yupResolver(GeneralSchema as any),
		mode: 'onChange', // Enable real-time validation
		defaultValues: {
			Password: '',
			Orientation: '',
			selectedDate: new Date(),
			selectedTime: new Date(),
			TrendLogInterval: 0,
			isTemparatureFaultSetRelays: 1,
			isLowPowerFaultSetRelays: 1,
			CheckedSpeed: 0,
			AspiratorCorrection: undefined,
		},
	});

	//#endregion

	//#region Channels and Sensors Form
	const ChannelAndSensorsSchema = yup.object().shape({
		ActionDelay: yup
			.number()
			.transform((value, originalValue) => {
				// Convert empty string to undefined for proper validation
				return originalValue === '' ? undefined : value;
			})
			.nullable()
			.optional()
			// .required('Action Delay is required')
			.typeError(t('positiveNumberValidationErrorMsg'))
			.integer(t('positiveNumberValidationErrorMsg'))
			.min(0, stringFormat(t('rangeValidationErrorMsg'), '0', '240'))
			.max(240, stringFormat(t('rangeValidationErrorMsg'), '0', '240')),
		AlarmDelay: yup
			.number()
			.transform((value, originalValue) => {
				// Convert empty string to undefined for proper validation
				return originalValue === '' ? undefined : value;
			})
			.nullable()
			.optional()
			// .required('Alarm Delay is required')
			.typeError(t('positiveNumberValidationErrorMsg'))
			.integer(t('positiveNumberValidationErrorMsg'))
			.min(0, stringFormat(t('rangeValidationErrorMsg'), '0', '240'))
			.max(240, stringFormat(t('rangeValidationErrorMsg'), '0', '240')),
		FlowFaultDelay: yup
			.number()
			.transform((value, originalValue) => {
				// Convert empty string to undefined for proper validation
				return originalValue === '' ? undefined : value;
			})
			.nullable()
			.optional()
			// .required('Flow Fault Delay is required')
			.typeError(t('positiveNumberValidationErrorMsg'))
			.integer(t('positiveNumberValidationErrorMsg'))
			.min(0, stringFormat(t('rangeValidationErrorMsg'), '0', '250'))
			.max(250, stringFormat(t('rangeValidationErrorMsg'), '0', '250')),
		ActionLevel1: yup
			.number()
			.required(t('positiveNumberValidationErrorMsg'))
			.min(0, stringFormat(t('rangeValidationErrorMsg'), '0', '8'))
			.max(8, stringFormat(t('rangeValidationErrorMsg'), '0', '8')),
		AlarmLevel1: yup
			.number()
			.required(t('positiveNumberValidationErrorMsg'))
			.min(0, stringFormat(t('rangeValidationErrorMsg'), '0', '9'))
			.max(9, stringFormat(t('rangeValidationErrorMsg'), '0', '9'))
			.test(
				'greaterThanActionLevel',
				t('AlarmLevelActionLevelValidation'),
				function (value) {
					const actionLevel = this.parent.ActionLevel1;
					return !value || !actionLevel || value >= actionLevel;
				},
			),
		Referenceflow1: yup
			.number()
			.required(t('positiveNumberValidationErrorMsg')),
		FlowFaultThreshold1: yup
			.number()
			.required(t('positiveNumberValidationErrorMsg')),
		UseEN54Limit1: yup
			.number()
			.required(t('positiveNumberValidationErrorMsg'))
			.min(0, stringFormat(t('rangeValidationErrorMsg'), 10, 80))
			.max(80, stringFormat(t('rangeValidationErrorMsg'), 10, 80)),
		SetFlowLimit1: yup
			.number()
			.required(t('positiveNumberValidationErrorMsg'))
			.min(0, stringFormat(t('rangeValidationErrorMsg'), 10, 80))
			.max(80, stringFormat(t('rangeValidationErrorMsg'), 10, 80)),
		ActionLevel2: yup.number().when([], (fields, schema, context: any) => {
			return context && context.NoOfChannels === 2
				? schema
						.required(t('positiveNumberValidationErrorMsg'))
						.min(0, stringFormat(t('rangeValidationErrorMsg'), 0, 8))
						.max(8, stringFormat(t('rangeValidationErrorMsg'), 0, 8))
				: schema.notRequired();
		}),
		AlarmLevel2: yup.number().when([], (fields, schema, context: any) => {
			return context && context.NoOfChannels === 2
				? schema
						.required(t('positiveNumberValidationErrorMsg'))
						.min(0, stringFormat(t('rangeValidationErrorMsg'), 0, 9))
						.max(9, stringFormat(t('rangeValidationErrorMsg'), 0, 9))
						.test(
							'greaterThanActionLevel',
							t('AlarmLevelActionLevelValidation'),
							function (value) {
								const actionLevel = this.parent.ActionLevel2;
								return !value || !actionLevel || value >= actionLevel;
							},
						)
				: schema.notRequired();
		}),
		FlowFaultThreshold2: yup
			.number()
			.when([], (fields, schema, context: any) => {
				return context && context.NoOfChannels === 2
					? schema.required(t('positiveNumberValidationErrorMsg'))
					: schema.notRequired();
			}),
		UseEN54Limit2: yup.number().when([], (fields, schema, context: any) => {
			return context && context.NoOfChannels === 2
				? schema
						.min(0, stringFormat(t('rangeValidationErrorMsg'), 10, 80))
						.max(80, stringFormat(t('rangeValidationErrorMsg'), 10, 80))
				: schema.notRequired();
		}),
		SetFlowLimit2: yup.number().when([], (fields, schema, context: any) => {
			return context && context.NoOfChannels === 2
				? schema
						.min(0, stringFormat(t('rangeValidationErrorMsg'), 10, 80))
						.max(80, stringFormat(t('rangeValidationErrorMsg'), 10, 80))
				: schema.notRequired();
		}),
	});
	const {
		control: csControl,
		handleSubmit: csHandleSubmit,
		formState: { errors: csErrors },
		setValue: csSetValue,
		watch: csWatch,
		clearErrors: csClearErrors,
		trigger: csTrigger,
		setError: csSetError,
	} = useForm<ChannelsAndSensorsData>({
		resolver: yupResolver(ChannelAndSensorsSchema as any),
		mode: 'onChange',
		defaultValues: {
			ActionDelay: 0,
			AlarmDelay: 0,
			FlowFaultDelay: 30,
			AlarmConfiguration: 0,
			ActionConfiguration: 0,
			FaultConfiguration: 0,
			AlarmMode: 0,
			ActionLevel1: 0,
			AlarmLevel1: 0,
			Referenceflow1: 0,
			FlowFaultThreshold1: 0,
			UseEN54Limit1: 15,
			SetFlowLimit1: 0,
			ActionLevel2: 0,
			AlarmLevel2: 0,
			Referenceflow2: 0,
			FlowFaultThreshold2: 0,
			UseEN54Limit2: 15,
			SetFlowLimit2: 0,
			Alarm1Configuration: 0,
			Alarm2Configuration: 0,
			GeneralFaultConfiguration: 0,
			AuxFaultConfiguration: 0,
			FlowFaultThresholdValue: 15,
			FlowFaultThreshold: 0,
		},
	});

	//#endregion

	const exportDeviceParameters = async () => {
		try {
			// Fetch current device parameters
			deviceParameters.current = FetchValuesFromYup();
			const deviceParametersObjectData = deviceParameters.current;
			console.log('DeviceParameter value', deviceParametersObjectData);

			// Use the encryption function to create encrypted XML data
			const encryptedData = encryptAndSerializeConfigFile(
				deviceParametersObjectData,
			);

			// Write encrypted data to file
			const fileName = `${templateName.current}_${Date.now()}.sfc`;
			const directoryPath =
				Platform.OS === 'ios'
					? RNFS.DocumentDirectoryPath
					: RNFS.DownloadDirectoryPath;
			const filePath = `${directoryPath}/${fileName}`;

			// Write the encrypted data as base64 to the file
			await RNFS.writeFile(filePath, encryptedData, 'base64');

			const answer = await confirmAlert(
				stringFormat(t('DeviceExportedAndShareConfirmation'), filePath),
				t('lblExported'),
				t('Share'),
				t('Cancel_PascalCase'),
			);
			if (answer) {
				try {
					const shareOptions = {
						title: fileName,
						url: Platform.OS === 'ios' ? filePath : `file://${filePath}`,
						type: 'text/plain',
						filename: fileName,
						failOnCancel: false,
					};
					// const result = await Share.share(shareOptions);
					await Share.open(shareOptions)
						.then(res => {
							console.log('Share result:', res);
							Toast.show({
								type: 'success',
								text1: stringFormat(t('DeviceExported'), filePath),
								text2: fileName,
								position: 'bottom',
							});
						})
						.catch(error => {
							console.log('Share error:', error);
							if (
								error.message &&
								error.message.includes('User did not share')
							) {
								console.log('User cancelled share');
							} else {
								Alert.alert(t('warning'), t('msgPleaseTryAgain'), [
									{ text: t('ok') },
								]);
							}
						});
				} catch (error) {
					Alert.alert(t('warning'), t('msgPleaseTryAgain'), [
						{ text: t('ok') },
					]);
				}
			} else {
				navigation.pop(2);
			}
		} catch (error) {
			Toast.show({
				type: 'error',
				text1: 'Export Failed',
				text2: 'Could not export device parameters.',
				position: 'bottom',
			});
			console.error('Error exporting device parameters:', error);
		}
	};

	function FetchValuesFromYup(): DeviceParametersModel {
		let devParams = new DeviceParametersModel();

		devParams.channels = NoOfChannels;
		devParams.deviceType = deviceTypeRef.current;

		const trendLogInterval = generalWatch('TrendLogInterval');
		devParams.trendLogDisabled = trendLogInterval;

		const isTemparatureFaultSetRelays = generalWatch(
			'isTemparatureFaultSetRelays',
		);
		devParams.temperatureFaultRelay = isTemparatureFaultSetRelays;

		const isLowPowerFaultSetRelays = generalWatch('isLowPowerFaultSetRelays');
		devParams.lowPowerFaultRelay = isLowPowerFaultSetRelays;

		// Assign GPI values using enum state variables (no casting needed)
		devParams.gpiState = gpiInputState === 1;
		devParams.gpInputState = gpiInputState;
		// Only assign values based on current mode
		if (gpiInputState === 1) {
			// Supervised mode - only assign supervised values
			devParams.externalTriggerOnClosed = eventTriggerOnClose;
			devParams.externalTriggerOnOpen = eventTriggerOnOpen;
		} else {
			// Unsupervised mode - only assign unsupervised values
			devParams.externalInputNormalState = gpiNormalState;
			devParams.unbalancedEventTriggered = unbalancedEventTriggered;
		}

		const blowerSpeed = generalWatch('CheckedSpeed');
		devParams.blowerSpeed = blowerSpeed;

		devParams.blowerCorrection = AppConstants.NA;

		const actionDelay = csWatch('ActionDelay');
		devParams.actionDelay = actionDelay;

		const alarmDelay = csWatch('AlarmDelay');
		devParams.alarmDelay = alarmDelay;

		const flowFaultDelay = csWatch('FlowFaultDelay');
		devParams.flowFaultDelay = flowFaultDelay;

		const alarmConfig = csWatch('AlarmConfiguration');
		devParams.alarmLatched = alarmConfig;

		const actionConfig = csWatch('ActionConfiguration');
		devParams.actionLatched = actionConfig;

		const faultConfig = csWatch('FaultConfiguration');
		devParams.faultLatched = faultConfig;

		const alarmMode = csWatch('AlarmMode');
		devParams.deviceAlarmMode = alarmMode;

		const actionLevel1 = csWatch('ActionLevel1');
		devParams.channel1ActionLevel = actionLevel1;

		const alarmLevel1 = csWatch('AlarmLevel1');
		devParams.channel1AlarmLevel = alarmLevel1;

		devParams.referenceFlowCh1 = 0;

		const flowFaultThreshold1 = csWatch('FlowFaultThreshold1');
		if (flowFaultThreshold1 === 0) {
			const useEN54Limit1 = csWatch('UseEN54Limit1');
			devParams.flowFaultThresholdCh1 = useEN54Limit1 || 15;
		} else {
			const setFlowLimit1 = csWatch('SetFlowLimit1');
			devParams.flowFaultThresholdCh1 = setFlowLimit1 || 0;
		}

		if (NoOfChannels === 2) {
			const actionLevel2 = csWatch('ActionLevel2');
			devParams.channel2ActionLevel = actionLevel2 ?? 0;

			const alarmLevel2 = csWatch('AlarmLevel2');
			devParams.channel2AlarmLevel = alarmLevel2 ?? 0;

			devParams.referenceFlowCh2 = 0;

			const flowFaultThreshold2 = csWatch('FlowFaultThreshold2');
			if (flowFaultThreshold2 === 0) {
				const useEN54Limit2 = csWatch('UseEN54Limit2');
				devParams.flowFaultThresholdCh2 = useEN54Limit2 || 15;
			} else {
				const setFlowLimit2 = csWatch('SetFlowLimit2');
				devParams.flowFaultThresholdCh2 = setFlowLimit2 || 0;
			}
		}

		if (isIntelligentDevice) {
			const generalFaultConfig = csWatch('GeneralFaultConfiguration');
			devParams.generalFaultLatched = generalFaultConfig;
			const auxFaultConfig = csWatch('AuxFaultConfiguration');
			devParams.auxFaultLatched = auxFaultConfig;

			const flowFaultThreshold = csWatch('FlowFaultThreshold');
			const flowFaultThresholdValue = csWatch('FlowFaultThresholdValue');

			devParams.flowFaultThresholdCh1 =
				flowFaultThreshold === 0 ? 15 : flowFaultThresholdValue;

			const alarmConfig = csWatch('Alarm1Configuration');
			devParams.alarmLatched = alarmConfig;

			if (NoOfChannels === 2) {
				const alarm2Config = csWatch('Alarm2Configuration');
				devParams.alarm2Latched = alarm2Config;
			}
		}
		return devParams;
	}

	function handleGeneralParametersPress() {
		setIsGeneralParameterVisible(true);
		setIsChannelsAndSensorsVisible(false);
	}

	function handleChannelAndSensorsPress() {
		setIsGeneralParameterVisible(false);
		setIsChannelsAndSensorsVisible(true);
		setIsChannel2Available(selectedDevice.channels > 1);
	}

	function handleBackPress() {
		navigation.goBack();
	}

	const renderChannelsandSensors = () => {
		const flowFaultThresholdValue1 = csWatch('FlowFaultThreshold1');
		const flowFaultThresholdValue2 = csWatch('FlowFaultThreshold2');
		const handleSave = (data: ChannelsAndSensorsData) => {};
		const onExportChannelAndSensorsTemplatePress = () => {
			csHandleSubmit(handleSave)();
		};

		return (
			<SafeAreaView style={{ flex: 1 }}>
				<ScrollView style={{ flex: 1 }}>
					<View style={styles.container}>
						{/* Temperature Fault Sets Relays */}
						<View style={styles.section}>
							<Text style={styles.ActionCongigsectionTitle}>
								{t('ActionConfiguration')}
							</Text>
							{!isIntelligentDevice && (
								<View style={{ marginVertical: 0 }}>
									<CustomInput
										name='ActionDelay'
										control={csControl}
										placeholder={t('EnterActionDelay')}
										title={t('ActionDelay')}
										isRequired={false}
										errorMessage={csErrors.ActionDelay?.message}
										belowText={t('max240secondsRange')}
										minValue={0}
										maxValue={240}
										unit={t('seconds')}
										keyboardType='numeric'
										maxLength={3}
									/>
								</View>
							)}
							{!isIntelligentDevice && (
								<View style={{ marginVertical: 0 }}>
									<CustomInput
										name='AlarmDelay'
										control={csControl}
										placeholder={t('EnterAlarmDelay')}
										title={t('AlarmDelay')}
										isRequired={false}
										errorMessage={csErrors.AlarmDelay?.message}
										belowText={t('max240secondsRange')}
										minValue={0}
										maxValue={240}
										unit={t('seconds')}
										keyboardType='numeric'
										maxLength={3}
									/>
								</View>
							)}
							<View style={{ marginVertical: 0 }}>
								<CustomInput
									name='FlowFaultDelay'
									control={csControl}
									placeholder={t('EnterFlowFaultDelay')}
									title={t('FlowFaultDelay')}
									isRequired={false}
									errorMessage={csErrors.FlowFaultDelay?.message}
									belowText={t('max250secondsRange')}
									minValue={1}
									maxValue={250}
									unit={t('seconds')}
									keyboardType='numeric'
									maxLength={3}
								/>
							</View>

							{!isIntelligentDevice ? (
								<>
									<Text style={styles.radioTitle}>
										{t('AlarmConfiguration')}
									</Text>
									<Controller
										name='AlarmConfiguration'
										control={csControl}
										render={({ field: { onChange, value } }) => (
											<View style={styles.radioContainer}>
												<View style={styles.radiospacebetween}>
													<RadioButton
														option={{
															id: 1,
															text: t('Latched'),
														}}
														isSelected={value === 1}
														onOptionChange={onChange}
													/>
												</View>
												<View style={styles.radiospacebetween}>
													<RadioButton
														option={{
															id: 0,
															text: t('Unlatched'),
														}}
														isSelected={value === 0}
														onOptionChange={onChange}
													/>
												</View>
											</View>
										)}
									/>
									<Text style={styles.radioTitle}>
										{t('ActionConfiguration')}
									</Text>
									<Controller
										name='ActionConfiguration'
										control={csControl}
										render={({ field: { onChange, value } }) => (
											<View style={styles.radioContainer}>
												<View style={styles.radiospacebetween}>
													<RadioButton
														option={{
															id: 1,
															text: t('Latched'),
														}}
														isSelected={value === 1}
														onOptionChange={onChange}
													/>
												</View>
												<View style={styles.radiospacebetween}>
													<RadioButton
														option={{
															id: 0,
															text: t('Unlatched'),
														}}
														isSelected={value === 0}
														onOptionChange={onChange}
													/>
												</View>
											</View>
										)}
									/>
									<Text style={styles.radioTitle}>
										{t('FaultConfiguration')}
									</Text>
									<Controller
										name='FaultConfiguration'
										control={csControl}
										render={({ field: { onChange, value } }) => (
											<View style={styles.radioContainer}>
												<View style={styles.radiospacebetween}>
													<RadioButton
														option={{
															id: 1,
															text: t('Latched'),
														}}
														isSelected={value === 1}
														onOptionChange={onChange}
													/>
												</View>
												<View style={styles.radiospacebetween}>
													<RadioButton
														option={{
															id: 0,
															text: t('Unlatched'),
														}}
														isSelected={value === 0}
														onOptionChange={onChange}
													/>
												</View>
											</View>
										)}
									/>
									<Text style={styles.radioTitle}>{t('AlarmMode')}</Text>
									<Controller
										name='AlarmMode'
										control={csControl}
										render={({ field: { onChange, value } }) => (
											<View style={styles.radioContainer}>
												<View style={styles.radiospacebetween}>
													<RadioButton
														option={{
															id: 1,
															text: t('Instant'),
														}}
														isSelected={value === 1}
														onOptionChange={onChange}
													/>
												</View>
												<View style={styles.radiospacebetween}>
													<RadioButton
														option={{
															id: 0,
															text: t('Cumulative'),
														}}
														isSelected={value === 0}
														onOptionChange={onChange}
													/>
												</View>
											</View>
										)}
									/>
								</>
							) : (
								<>
									<Text style={styles.radioTitle}>
										{t('lblGeneralFaultConfig')}
									</Text>
									<Controller
										name='GeneralFaultConfiguration'
										control={csControl}
										render={({ field: { onChange, value } }) => (
											<View style={styles.radioContainer}>
												<View style={styles.radiospacebetween}>
													<RadioButton
														option={{
															id: 1,
															text: t('Latched'),
														}}
														isSelected={value === 1}
														onOptionChange={onChange}
													/>
												</View>
												<View style={styles.radiospacebetween}>
													<RadioButton
														option={{
															id: 0,
															text: t('Unlatched'),
														}}
														isSelected={value === 0}
														onOptionChange={onChange}
													/>
												</View>
											</View>
										)}
									/>
									<Text style={styles.radioTitle}>
										{t('lblAuxFaultConfig')}
									</Text>
									<Controller
										name='AuxFaultConfiguration'
										control={csControl}
										render={({ field: { onChange, value } }) => (
											<View style={styles.radioContainer}>
												<View style={styles.radiospacebetween}>
													<RadioButton
														option={{
															id: 1,
															text: t('Latched'),
														}}
														isSelected={value === 1}
														onOptionChange={onChange}
													/>
												</View>
												<View style={styles.radiospacebetween}>
													<RadioButton
														option={{
															id: 0,
															text: t('Unlatched'),
														}}
														isSelected={value === 0}
														onOptionChange={onChange}
													/>
												</View>
											</View>
										)}
									/>
								</>
							)}
						</View>

						<View style={styles.section}>
							{NoOfChannels === 1 ? (
								<View
									style={{
										alignItems: 'center',
										justifyContent: 'center',
										padding: 8,
										borderBottomWidth: 3,
										borderColor: '#1792E5',
										marginBottom: 10,
										flexDirection: 'row',
									}}>
									<Text
										style={{
											fontSize: 20,
											fontWeight: '500',
										}}>
										{t('Channel1')}
									</Text>
								</View>
							) : (
								<View
									style={{
										flexDirection: 'row',
										justifyContent: 'space-between',
										margin: 0,
									}}>
									<TouchableOpacity
										onPress={() => {
											setIsChannel(1);
										}}
										style={[
											isChannel === 1
												? {
														borderColor: commonColors.backgroundColor_Blue,
														borderRadius: 0,
														borderBottomWidth: 3,
												  }
												: {},
											{
												flex: 1,
												alignItems: 'center',
												justifyContent: 'center',
												paddingVertical: 10,
											},
										]}>
										<View
											style={{
												flexDirection: 'row',
												alignItems: 'center',
											}}>
											<Text
												style={{
													fontSize: 20,
													fontWeight: '500',
												}}>
												{t('Channel1')}
											</Text>
										</View>
									</TouchableOpacity>
									<View
										style={{
											width: 1,
											backgroundColor: '#ccc',
											marginVertical: 5,
										}}
									/>
									<TouchableOpacity
										onPress={() => {
											setIsChannel(2);
										}}
										style={[
											isChannel === 2
												? {
														borderColor: commonColors.backgroundColor_Blue,
														borderRadius: 0,
														borderBottomWidth: 3,
												  }
												: {},
											{
												flex: 1,
												alignItems: 'center',
												justifyContent: 'center',
												paddingVertical: 10,
											},
										]}>
										<View
											style={{
												flexDirection: 'row',
												alignItems: 'center',
											}}>
											<Text
												style={{
													fontSize: 20,
													fontWeight: '500',
												}}>
												{t('Channel2')}
											</Text>
										</View>
									</TouchableOpacity>
								</View>
							)}

							{isIntelligentDevice ? (
								<View>
									{/* 									Alarm Configuration is removed for Intelligent devices. Keeping the code commented for future reference if needed.
									{isChannel === 1 ? (
										<View>
											<Text style={[styles.radioTitle, { marginTop: 10 }]}>
												{t('AlarmConfiguration')}
											</Text>
											<Controller
												key='Alarm1Configuration'
												name='Alarm1Configuration'
												control={csControl}
												render={({ field: { onChange, value } }) => (
													<View
														style={[
															styles.radioContainer,
															{
																borderBottomWidth: 0,
																marginBottom: 20,
															},
														]}>
														<View style={styles.radiospacebetween}>
															<RadioButton
																option={{
																	id: 1,
																	text: t('Latched'),
																}}
																isSelected={value === 1}
																onOptionChange={onChange}
															/>
														</View>
														<View style={styles.radiospacebetween}>
															<RadioButton
																option={{
																	id: 0,
																	text: t('Unlatched'),
																}}
																isSelected={value === 0}
																onOptionChange={onChange}
															/>
														</View>
													</View>
												)}
											/>
										</View>
									) : (
										<View>
											<Text style={[styles.radioTitle, { marginTop: 10 }]}>
												{t('AlarmConfiguration')}
											</Text>
											<Controller
												key='Alarm2Configuration'
												name='Alarm2Configuration'
												control={csControl}
												render={({ field: { onChange, value } }) => (
													<View
														style={[
															styles.radioContainer,
															{
																borderBottomWidth: 0,
																marginBottom: 20,
															},
														]}>
														<View style={styles.radiospacebetween}>
															<RadioButton
																option={{
																	id: 1,
																	text: t('Latched'),
																}}
																isSelected={value === 1}
																onOptionChange={onChange}
															/>
														</View>
														<View style={styles.radiospacebetween}>
															<RadioButton
																option={{
																	id: 0,
																	text: t('Unlatched'),
																}}
																isSelected={value === 0}
																onOptionChange={onChange}
															/>
														</View>
													</View>
												)}
											/>
										</View>
									)} */}

									<View
										style={{
											flexDirection: 'row',
											flex: 1,
											borderColor: '#ccc',
											borderBottomWidth: 1,
											marginBottom: 10,
										}}
									/>

									<Text style={[styles.radioTitle]}>
										<Text>{t('FlowFaultThreshold')}</Text>
										{t('percentInBrackets')}
									</Text>
									<Controller
										key='FlowFaultThreshold'
										name='FlowFaultThreshold'
										control={csControl}
										render={({ field: { onChange, value } }) => (
											<View
												style={[
													styles.radioContainer,
													{ borderBottomWidth: 0 },
												]}>
												<View style={styles.radiospacebetween}>
													<RadioButton
														option={{
															id: 0,
															text: t('lblen54Limit'),
														}}
														isSelected={value === 0}
														onOptionChange={() => {
															onChange(0);
															csSetValue('FlowFaultThresholdValue', 15);
														}}
													/>
												</View>
												<View style={styles.radiospacebetween}>
													<RadioButton
														option={{
															id: 1,
															text: t('lblotherLimit'),
														}}
														isSelected={value === 1}
														onOptionChange={() => {
															onChange(1);
															csSetValue('FlowFaultThresholdValue', 21);
														}}
													/>
												</View>
											</View>
										)}
									/>
									<View style={{ marginTop: 0 }}>
										<Controller
											key='FlowFaultThresholdValue'
											name='FlowFaultThresholdValue'
											control={csControl}
											render={({ field: { onChange, value } }) => (
												<>
													{csWatch('FlowFaultThreshold') === 1 ? (
														<IncrementDecrement
															label=''
															value={csWatch('FlowFaultThresholdValue')}
															setValue={newValue => {
																csSetValue('FlowFaultThresholdValue', newValue);
															}}
															min={21}
															max={80}
															belowText={t('FlowFaultThresholdRange')}
															isDisabled={false}
														/>
													) : (
														<View
															style={{
																borderWidth: 1,
																padding: 15,
																backgroundColor: '#f0f0f0',
																borderColor: '#d3d3d3',
																marginBottom: 10,
															}}>
															<Text
																style={{
																	color: commonColors.textColor_Grey,
																	fontSize: 18,
																}}>
																{t('msgEN54CompliantLimits')}
															</Text>
														</View>
													)}
												</>
											)}
										/>
									</View>
								</View>
							) : (
								<>
									{isChannel === 1 ? (
										<View>
											{/* Action Level */}
											<Controller
												key='ActionLevel1'
												name='ActionLevel1'
												control={csControl}
												render={({ field: { onChange, value } }) => (
													<View>
														<IncrementDecrement
															label={t('ActionLevel')}
															value={Number(value)}
															setValue={onChange}
															min={0}
															max={8}
															belowText={t('ChannelActionLevelRange')}
															refState={csWatch('AlarmLevel1')}
															referingLabel='Alarm Level1'
														/>
													</View>
												)}
											/>

											<Controller
												key='AlarmLevel1'
												name='AlarmLevel1'
												control={csControl}
												render={({ field: { onChange, value } }) => (
													<View>
														<IncrementDecrement
															label={t('AlarmLevel')}
															value={Number(value)}
															setValue={onChange}
															min={0}
															max={9}
															belowText={t('ChannelAlarmLevelRange')}
															referencingState={csWatch('ActionLevel1')}
															referingLabel={t('ActionLevel')}
														/>
													</View>
												)}
											/>

											<Text style={styles.radioTitle}>
												{t('FlowFaultThreshold')} {t('percentInBrackets')}
											</Text>
											<Controller
												key='FlowFaultThreshold1'
												name='FlowFaultThreshold1'
												control={csControl}
												render={({ field: { onChange, value } }) => (
													<View
														style={[
															styles.radioContainer,
															{
																borderBottomWidth: 0,
															},
														]}>
														<View style={styles.radiospacebetween}>
															<RadioButton
																option={{
																	id: 0,
																	text: t('lblen54Limit'),
																}}
																isSelected={value === 0}
																onOptionChange={() => {
																	onChange(0);
																	csSetValue('UseEN54Limit1', 15);
																}}
															/>
														</View>
														<View style={styles.radiospacebetween}>
															<RadioButton
																option={{
																	id: 1,
																	text: t('lblotherLimit'),
																}}
																isSelected={value === 1}
																onOptionChange={() => {
																	onChange(1);
																	csSetValue('SetFlowLimit1', 20);
																}}
															/>
														</View>
													</View>
												)}
											/>
											<View style={{ marginTop: -20 }}>
												{flowFaultThresholdValue1 === 0 ? (
													<Controller
														key='UseEN54Limit1'
														name='UseEN54Limit1'
														control={csControl}
														render={({ field: { onChange, value } }) => (
															<IncrementDecrement
																label=''
																value={csWatch('UseEN54Limit1')}
																setValue={newValue => {
																	csSetValue('UseEN54Limit1', newValue);
																}}
																min={20}
																max={80}
																belowText={t('FlowFaultThresholdRange')}
																isDisabled={true}
															/>
														)}
													/>
												) : (
													<Controller
														key='SetFlowLimit1'
														name='SetFlowLimit1'
														control={csControl}
														render={({ field: { onChange, value } }) => (
															<IncrementDecrement
																label=''
																value={csWatch('SetFlowLimit1')}
																setValue={newValue => {
																	csSetValue('SetFlowLimit1', newValue);
																}}
																min={20}
																max={80}
																belowText={t('FlowFaultThresholdRange')}
															/>
														)}
													/>
												)}
											</View>
										</View>
									) : (
										<View>
											{/* Action Level */}
											<Controller
												key='ActionLevel2'
												name='ActionLevel2'
												control={csControl}
												render={({ field: { onChange, value } }) => (
													<View>
														<IncrementDecrement
															label={t('ActionLevel')}
															value={Number(value)}
															setValue={onChange}
															min={0}
															max={8}
															belowText={t('ChannelActionLevelRange')}
															refState={csWatch('AlarmLevel2')}
															referingLabel='Alarm Level2'
														/>
													</View>
												)}
											/>

											<Controller
												key='AlarmLevel2'
												name='AlarmLevel2'
												control={csControl}
												render={({ field: { onChange, value } }) => (
													<View>
														<IncrementDecrement
															label={t('AlarmLevel')}
															value={Number(value)}
															setValue={onChange}
															min={0}
															max={9}
															belowText={t('ChannelAlarmLevelRange')}
															referencingState={csWatch('ActionLevel2')}
															referingLabel={t('ActionLevel')}
														/>
													</View>
												)}
											/>

											<Text style={styles.radioTitle}>
												{t('FlowFaultThreshold')} {t('percentInBrackets')}
											</Text>
											<Controller
												key='FlowFaultThreshold2'
												name='FlowFaultThreshold2'
												control={csControl}
												render={({ field: { onChange, value } }) => (
													<View
														style={[
															styles.radioContainer,
															{
																borderBottomWidth: 0,
															},
														]}>
														<View style={styles.radiospacebetween}>
															<RadioButton
																option={{
																	id: 0,
																	text: t('lblen54Limit'),
																}}
																isSelected={value === 0}
																onOptionChange={() => {
																	onChange(0);
																	csSetValue('UseEN54Limit1', 15);
																}}
															/>
														</View>
														<View style={styles.radiospacebetween}>
															<RadioButton
																option={{
																	id: 1,
																	text: t('lblotherLimit'),
																}}
																isSelected={value === 1}
																onOptionChange={() => {
																	onChange(1);
																	csSetValue('SetFlowLimit2', 20);
																}}
															/>
														</View>
													</View>
												)}
											/>
											<View style={{ marginTop: -20 }}>
												{flowFaultThresholdValue2 === 0 ? (
													<Controller
														key='UseEN54Limit2'
														name='UseEN54Limit2'
														control={csControl}
														render={({ field: { onChange, value } }) => (
															<IncrementDecrement
																label=''
																value={Number(value)}
																setValue={onChange}
																min={20}
																max={80}
																belowText={t('FlowFaultThresholdRange')}
																isDisabled={true}
															/>
														)}
													/>
												) : (
													<Controller
														key='SetFlowLimit2'
														name='SetFlowLimit2'
														control={csControl}
														render={({ field: { onChange, value } }) => (
															<IncrementDecrement
																label=''
																value={Number(value)}
																setValue={onChange}
																min={20}
																max={80}
																belowText={t('FlowFaultThresholdRange')}
															/>
														)}
													/>
												)}
											</View>
										</View>
									)}
								</>
							)}
						</View>
					</View>
				</ScrollView>
			</SafeAreaView>
		);
	};
	const renderGeneralParameter = () => {
		const setGPITypeDefaults = (gpiState: number) => {
			if (gpiState === 1) {
				setGpiNormalState(ExternalInputNormalState.eShort);
				setUnbalancedEventTriggered(ExternalInputAction.eResetAlarmAndFault);
			}
			if (gpiState === 0) {
				setEventTriggerOnClose(ExternalInputAction.eResetAlarmAndFault);
				setEventTriggerOnOpen(ExternalInputAction.eResetAlarmAndFault);
			}
			setGpiInputState(gpiState);
		};

		const handleSave = (data: {
			selectedDate: string | number | Date;
			selectedTime: string | number | Date;
		}) => {
			// Format date as DD-MM-YYYY
			const formattedDate = data.selectedDate
				? new Date(data.selectedDate).toLocaleDateString('en-GB')
				: '';
			// Format time as HH:MM AM/PM
			const formattedTime = data.selectedTime
				? new Date(data.selectedTime).toLocaleTimeString('en-US', {
						hour: '2-digit',
						minute: '2-digit',
						hour12: true,
				  })
				: '';

			const printData = {
				...data,
				selectedDate: formattedDate,
				selectedTime: formattedTime,
			};
			console.log('Form Data:', printData);
		};

		return (
			<SafeAreaView style={{ flex: 1 }}>
				<ScrollView>
					<View style={styles.container}>
						{/* Trend Log Inrterval */}
						<View style={styles.section}>
							{/* Heading */}
							<View
								style={{
									paddingVertical: 10,
									borderBottomWidth: 1,
									borderColor: '#e0e0e0',
									marginBottom: 10,
								}}>
								<Text style={{ fontSize: 17, fontWeight: '600' }}>
									{t('GeneralParams')}
								</Text>
							</View>
							<View style={{ marginVertical: 0 }}>
								<CustomInput
									name='TrendLogInterval'
									control={generalControl}
									placeholder='Enter Trend Log Interval'
									title={t('TrendLogInterval')}
									isRequired={false}
									errorMessage={generalErrors.TrendLogInterval?.message}
									belowText={t('TrendLogIntervalRangeInfo')}
									minValue={0}
									maxValue={240}
									unit={t('minutes')}
									keyboardType='numeric'
									maxLength={3}
								/>
							</View>

							<Text style={styles.GeneralParameterradioTitle}>
								{t('TemperatureFaultSetsRelays')}
							</Text>
							<Controller
								name='isTemparatureFaultSetRelays'
								control={generalControl}
								render={({ field: { onChange, value } }) => (
									<View style={styles.GeneralParameterradioContainer}>
										<View style={styles.radiospacebetween}>
											<RadioButton
												option={{
													id: 1,
													text: t('Yes'),
												}}
												isSelected={value === 1}
												onOptionChange={onChange}
											/>
										</View>
										<View style={styles.radiospacebetween}>
											<RadioButton
												option={{
													id: 0,
													text: t('no'),
												}}
												isSelected={value === 0}
												onOptionChange={onChange}
											/>
										</View>
									</View>
								)}
							/>
							{!isIntelligentDevice && (
								<View>
									<Text style={styles.GeneralParameterradioTitle}>
										{t('LowPowerFaultsetsRelays')}
									</Text>
									<Controller
										name='isLowPowerFaultSetRelays'
										control={generalControl}
										render={({ field: { onChange, value } }) => (
											<View style={styles.GeneralParameterradioContainer}>
												<View style={styles.radiospacebetween}>
													<RadioButton
														option={{
															id: 1,
															text: t('Yes'),
														}}
														isSelected={value === 1}
														onOptionChange={onChange}
													/>
												</View>
												<View style={styles.radiospacebetween}>
													<RadioButton
														option={{
															id: 0,
															text: t('no'),
														}}
														isSelected={value === 0}
														onOptionChange={onChange}
													/>
												</View>
											</View>
										)}
									/>
								</View>
							)}
						</View>

						{/* GPI Input */}
						<View style={styles.section}>
							<Text style={styles.sectionTitle}>{t('GPIInput')}</Text>
							<Text style={styles.dropdownLabel}>{t('State')}</Text>
							<View style={styles.radioContainer}>
								<View style={styles.radiospacebetween}>
									<RadioButton
										option={{
											id: 1,
											text: t('lblSupervised'),
										}}
										isSelected={gpiInputState === 1}
										onOptionChange={(value: any) => setGPITypeDefaults(value)}
									/>
								</View>
								<View style={styles.radiospacebetween}>
									<RadioButton
										option={{
											id: 0,
											text: t('lblUnSupervised'),
										}}
										isSelected={gpiInputState === 0}
										onOptionChange={(value: any) => setGPITypeDefaults(value)}
									/>
								</View>
							</View>

							{gpiInputState === 1 ? (
								<View style={styles.dropdownSection}>
									<Text style={styles.dropdownLabel}>
										{t('EventTriggeredOnClose')}
									</Text>
									<RNPickerSelect
										onValueChange={selectedValue => {
											if (selectedValue !== null) {
												setEventTriggerOnClose(selectedValue);
											}
										}}
										items={getExternalInputActionItems()}
										value={eventTriggerOnClose}
										style={pickerSelectStyles}
										useNativeAndroidPickerStyle={false}
										Icon={() => <DropDownIcon height={20} width={20} />}
									/>
									<Text style={styles.dropdownLabel}>
										{t('EventTriggeredOnOpen')}
									</Text>
									<RNPickerSelect
										onValueChange={selectedValue => {
											if (selectedValue !== null) {
												setEventTriggerOnOpen(selectedValue);
											}
										}}
										items={getExternalInputActionItems()}
										value={eventTriggerOnOpen}
										style={pickerSelectStyles}
										useNativeAndroidPickerStyle={false}
										Icon={() => <DropDownIcon height={20} width={20} />}
									/>
								</View>
							) : (
								<View style={styles.dropdownSection}>
									<Text style={styles.dropdownLabel}>
										{t('GPINormalState')}
									</Text>
									<RNPickerSelect
										onValueChange={selectedValue => {
											if (selectedValue !== null) {
												setGpiNormalState(selectedValue);
											}
										}}
										items={getExternalInputNormalStateItems()}
										value={gpiNormalState}
										style={pickerSelectStyles}
										useNativeAndroidPickerStyle={false}
										Icon={() => <DropDownIcon height={20} width={20} />}
									/>
									<Text style={[styles.dropdownLabel, { paddingTop: 5 }]}>
										{t('unbalancedaction')}
									</Text>
									<RNPickerSelect
										onValueChange={selectedValue => {
											if (selectedValue !== null) {
												setUnbalancedEventTriggered(selectedValue);
											}
										}}
										items={getExternalInputActionItems()}
										value={unbalancedEventTriggered}
										style={pickerSelectStyles}
										useNativeAndroidPickerStyle={false}
										Icon={() => <DropDownIcon height={20} width={20} />}
									/>
								</View>
							)}
						</View>

						{/* Aspirator Speed */}
						<View style={styles.section}>
							<Text style={styles.sectionTitle}>{t('Blower')}</Text>
							<Text style={styles.radioTitle}>{t('Speed')}</Text>
							<Controller
								name='CheckedSpeed'
								control={generalControl}
								render={({ field: { onChange, value } }) => (
									<View style={styles.radioContainer}>
										<View style={styles.radiospacebetween}>
											<RadioButton
												option={{
													id: 0,
													text: t('Low'),
												}}
												isSelected={value === 0}
												onOptionChange={onChange}
											/>
										</View>
										<View style={styles.radiospacebetween}>
											<RadioButton
												option={{
													id: 1,
													text: t('High'),
												}}
												isSelected={value === 1}
												onOptionChange={onChange}
											/>
										</View>
									</View>
								)}
							/>
						</View>
					</View>
				</ScrollView>

				{/* Dropdown Modal */}
				{/* <DropDown
          isVisible={isGPIDropDownModalVisible}
          items={getDropdownItems()}
          tempSelectedItem={tempSelectedItem}
          onItemPress={handleItemPress}
          onCancel={handleCancel}
          onConfirm={handleOk}
        /> */}

				{/* Password Modal */}
				{isPasswordModalVisible && (
					<PasswordModal
						onClose={() => {
							setPasswordModalVisible(false);
							generalSetValue('Password', password); // Do not validate immediately
						}}
						password={password}
						setPassword={setPassword}
						maximumLength={6}
					/>
				)}
			</SafeAreaView>
		);
	};
	const renderFooter = () => {
		return (
			<View>
				<View style={styles.buttonFooter}>
					<SingleButtonFooter
						buttonText={t('exportTemplate')}
						onButtonPress={exportDeviceParameters}
						buttonDisabled={false}
						buttonStyle={{ backgroundColor: '#007BFF' }}
						buttonTextStyle={{ color: '#fff' }}
					/>
				</View>
				<View style={styles.footer}>
					<ImageButtonSVG
						svgComponent={<GeneralEnabled />}
						disabledSvgComponent={<General />}
						disabled={!isGeneralParameterVisible}
						svgHeight={30}
						svgWidth={30}
						text='General'
						onPress={() => {
							handleGeneralParametersPress();
						}}
						style={styles.button}
						textStyle={
							isGeneralParameterVisible
								? styles.buttonTextBlue
								: styles.buttonText
						}></ImageButtonSVG>

					<ImageButtonSVG
						svgComponent={<DashboardEnabled />}
						disabledSvgComponent={<Dashboard />}
						disabled={!isChannelsAndSensorsVisible}
						svgHeight={30}
						svgWidth={30}
						text='ChannelandSensors'
						onPress={() => {
							handleChannelAndSensorsPress();
						}}
						style={styles.button}
						textStyle={
							isChannelsAndSensorsVisible
								? styles.buttonTextBlue
								: styles.buttonText
						}></ImageButtonSVG>
				</View>
			</View>
		);
	};

	return (
		<View style={styles.mainContainer}>
			{/* Header - 10% of height */}
			<SafeAreaContextView edges={['top']} style={styles.safeHeader}>
				<View
					style={[
						styles.headerSection,
						{
							backgroundColor: '#000',
							alignItems: 'center',
						},
					]}>
					<View
						style={{
							flexDirection: 'row',
							alignItems: 'center',
							paddingHorizontal: 10,
							height: '100%',
						}}>
						<TouchableOpacity
							onPress={() => handleBackPress()}
							style={{
								height: '100%',
								padding: 0,
								margin: 0,
								justifyContent: 'center',
							}}>
							<LeftArrowWhite height={30} width={30} />
						</TouchableOpacity>

						<View style={[{ flex: 2 }]}>
							<Text
								style={{
									color: '#fff',
									fontSize: 18,
									fontWeight: 'bold',
									textAlign: 'center',
								}}>
								{t('createTemplate')}
							</Text>
						</View>
						<TouchableOpacity onPress={() => handleBackPress()}>
							<ResetButton />
						</TouchableOpacity>
					</View>
				</View>
			</SafeAreaContextView>

			<View style={styles.contentSection}>
				<MenuProvider>
					<View style={{ flex: 1 }}>
						{/* Main content area - conditionally render based on active screen */}
						{isGeneralParameterVisible && renderGeneralParameter()}
						{isChannelsAndSensorsVisible && renderChannelsandSensors()}
					</View>
				</MenuProvider>
			</View>

			{/* Footer */}
			<View style={styles.footerSection}>{renderFooter()}</View>
		</View>
	);
}

// Picker styles for RNPickerSelect (matches deviceParameterScreen)
const pickerSelectStyles = StyleSheet.create({
	inputIOS: {
		fontSize: 15,
		paddingVertical: 12,
		paddingHorizontal: 10,
		borderWidth: 1,
		borderColor: commonColors.textBoxBorderColor,
		borderRadius: commonSizes.cornerRadius,
		color: 'black',
		paddingRight: 30,
		marginTop: commonSizes.heightS_Pixel,
		marginBottom: 10,
	},
	inputAndroid: {
		fontSize: 15,
		paddingHorizontal: 10,
		paddingVertical: 8,
		borderWidth: 1,
		borderColor: commonColors.textBoxBorderColor,
		borderRadius: commonSizes.cornerRadius,
		color: 'black',
		paddingRight: 30,
		marginTop: commonSizes.heightS_Pixel,
		marginBottom: 10,
	},
	iconContainer: {
		top: 20,
		right: 12,
	},
});

const styles = StyleSheet.create({
	container: {
		flex: 1,
		marginHorizontal: 14,
		marginTop: 10,
	},

	mainContainer: {
		flex: 1,
		backgroundColor: '#f5f5f5',
	},

	ActionCongigsectionTitle: {
		fontSize: 16,
		fontWeight: '600',
		marginBottom: 15,
		paddingBottom: 10,
		borderBottomWidth: 1,
		borderBottomColor: '#e0e0e0',
	},

	radioTitle: {
		fontSize: 15,
		fontWeight: '400',
		marginBottom: 5,
	},

	radioContainer: {
		flexDirection: 'row',
		justifyContent: 'flex-start',
		alignItems: 'center',
		marginVertical: 8,
		paddingBottom: 20,
		borderBottomWidth: 1,
		borderBottomColor: '#e0e0e0',
	},

	radiospacebetween: {
		flex: 1,
	},

	section: {
		backgroundColor: '#fff',
		borderRadius: 5,
		paddingHorizontal: 16,
		paddingTop: 16,
		marginBottom: 16,
		borderWidth: 1,
		borderColor: '#e0e0e0',
		elevation: 5,
	},

	sectionTitle: {
		fontSize: 16,
		fontWeight: '600',
		marginBottom: 10,
		paddingBottom: 10,
		borderBottomWidth: 1,
		borderBottomColor: '#e0e0e0ff',
	},

	sectionTitleHeading: {
		fontSize: 16,
		fontWeight: '600',
	},

	GeneralParameterradioTitle: {
		color: commonColors.textColor_Black,
		fontSize: 15,
		fontWeight: '500',
	},

	GeneralParameterradioContainer: {
		flexDirection: 'row',
		justifyContent: 'flex-start',
		alignItems: 'center',
		marginVertical: 8,
		paddingBottom: 10,
	},

	dropdownSection: {
		marginTop: 10,
	},

	dropdownLabel: {
		color: commonColors.textColor_Black,
		fontSize: 15,
		fontWeight: '500',
	},

	dropdownButton: {
		flexDirection: 'row',
		alignItems: 'center',
		justifyContent: 'space-between',
		marginBottom: 10,
		height: commonSizes.textBoxHeight_L,
		borderColor: commonColors.textBoxBorderColor,
		borderWidth: commonSizes.textBoXBorderWidthXS,
		borderRadius: commonSizes.cornerRadius,
		paddingHorizontal: commonSizes.paddingM_Percent,
		marginTop: commonSizes.heightS_Pixel,
	},

	dropdownText: {
		flex: 1,
		fontSize: 15,
		color: '#000',
	},

	dropdownIcon: {
		width: 15,
		height: 15,
		marginRight: 10,
	},

	footer: {
		height: 60,
		backgroundColor: '#ffffffff',
		borderTopWidth: 1,
		borderTopColor: '#e0e0e0',
		flexDirection: 'row',
		justifyContent: 'space-around',
		alignItems: 'center',
	},

	footerSection: {
		width: '100%',
		backgroundColor: '#ffffff',
	},

	button: {
		marginTop: 10,
		backgroundColor: '#ffffff',
	},

	buttonFooter: {
		borderTopWidth: 1,
		borderTopColor: '#e0e0e0',
		backgroundColor: '#fff',
	},

	buttonText: {
		color: '#000000',
		fontSize: 14,
		textAlign: 'center',
	},

	buttonTextBlue: {
		color: '#1792E5',
		fontSize: 14,
		textAlign: 'center',
	},

	headerSection: {
		backgroundColor: '#000',
		height: 56,
		width: '100%',
	},
	safeHeader: {
		backgroundColor: '#000',
	},

	contentSection: {
		flex: 1,
		width: '100%',
	},
});
