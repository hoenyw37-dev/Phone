import {
	createEntityAdapter,
	createSlice,
	EntityState,
} from '@reduxjs/toolkit';
import { RootState } from '../../../../global/store';
import { DeviceParametersModel } from '@ff_model/deviceParametersModel';
import {
	fetchAllDeviceParameters,
	fetchDeviceParameter,
	addAllNewDeviceParameters,
	addNewDeviceParameter,
	deleteDeviceParameterWithId,
	updateExistingDeviceParameter,
} from '@ff_redux/deviceParameterRedux/deviceParameterThunk';

interface DeviceParameterState
	extends EntityState<DeviceParametersModel, number> {
	status: 'idle' | 'pending' | 'succeeded' | 'rejected';
	error: string | null;
}

const deviceParametersAdapter = createEntityAdapter({
	selectId: (deviceParameter: DeviceParametersModel) =>
		deviceParameter.deviceId,
});

const initialState: DeviceParameterState =
	deviceParametersAdapter.getInitialState({
		status: 'idle',
		error: null,
	});

export const deviceParameterSlice = createSlice({
	name: 'deviceParameters',
	initialState,
	reducers: {
		deviceParameterAdded: deviceParametersAdapter.addOne,
		deviceParametersReceived(state, action) {
			deviceParametersAdapter.setAll(state, action.payload.deviceParameters);
		},
	},
	extraReducers: builder => {
		builder
			.addCase(fetchAllDeviceParameters.pending, state => {
				state.status = 'pending';
			})
			.addCase(fetchAllDeviceParameters.fulfilled, (state, action) => {
				state.status = 'succeeded';
				deviceParametersAdapter.setAll(state, action.payload);
				console.log('tests fetching completed');
			})
			.addCase(fetchAllDeviceParameters.rejected, (state, action) => {
				state.status = 'rejected';
				state.error = action.error.message ?? 'Unknown Error';
			})
			.addCase(fetchDeviceParameter.pending, state => {
				state.status = 'pending';
			})
			.addCase(fetchDeviceParameter.fulfilled, (state, action) => {
				state.status = 'succeeded';
				deviceParametersAdapter.setOne(state, action.payload);
			})
			.addCase(fetchDeviceParameter.rejected, (state, action) => {
				state.status = 'rejected';
				state.error = action.error.message ?? 'Unknown Error';
			})
			.addCase(addNewDeviceParameter.pending, state => {
				state.status = 'pending';
			})
			.addCase(addNewDeviceParameter.fulfilled, (state, action) => {
				state.status = 'succeeded';
				deviceParametersAdapter.addOne(state, action.payload);
			})
			.addCase(addNewDeviceParameter.rejected, (state, action) => {
				state.status = 'rejected';
				state.error = action.error.message ?? 'Unknown Error';
			})
			.addCase(addAllNewDeviceParameters.pending, state => {
				state.status = 'pending';
			})
			.addCase(addAllNewDeviceParameters.fulfilled, (state, action) => {
				state.status = 'succeeded';
				deviceParametersAdapter.addMany(state, action.payload);
				console.log('tests fetching completed');
			})
			.addCase(addAllNewDeviceParameters.rejected, (state, action) => {
				state.status = 'rejected';
				state.error = action.error.message ?? 'Unknown Error';
			})
			.addCase(deleteDeviceParameterWithId.pending, state => {
				state.status = 'pending';
			})
			.addCase(deleteDeviceParameterWithId.fulfilled, (state, action) => {
				state.status = 'succeeded';
				deviceParametersAdapter.removeOne(state, action.payload);
			})
			.addCase(deleteDeviceParameterWithId.rejected, (state, action) => {
				state.status = 'rejected';
				state.error = action.error.message ?? 'Unknown Error';
			})
			.addCase(updateExistingDeviceParameter.pending, state => {
				state.status = 'pending';
			})
			.addCase(updateExistingDeviceParameter.fulfilled, (state, action) => {
				state.status = 'succeeded';
				const { deviceId, updates } = action.payload;
				deviceParametersAdapter.updateOne(state, {
					id: deviceId,
					changes: updates,
				});
			})
			.addCase(updateExistingDeviceParameter.rejected, (state, action) => {
				state.status = 'rejected';
				state.error = action.error.message ?? 'Unknown Error';
			});
	},
});

export const {
	selectAll: selectAllDeviceParameters,
	selectById: selectDeviceParameterById,
} = deviceParametersAdapter.getSelectors(
	(state: RootState) => state.deviceParameter,
);

export const { deviceParametersReceived, deviceParameterAdded } =
	deviceParameterSlice.actions;

export const selectDeviceParametersStatus = (state: RootState) =>
	state.deviceParameter.status;
export const selectDeviceParametersError = (state: RootState) =>
	state.deviceParameter.error;

export default deviceParameterSlice.reducer;
