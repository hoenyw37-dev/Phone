//import { createAppAsyncThunk } from '../../../../global/store';
import { createAsyncThunk } from '@reduxjs/toolkit';
import {
	getAllDeviceParameters,
	getDeviceParameter,
	addAllDeviceParameters,
	addDeviceParameter,
	updateDeviceParameter,
	deleteDeviceParameter,
} from '@ff_dataAccess/deviceParametersDataAccess/deviceParametersAccess';
import { DataSource } from 'typeorm/browser';
import { DeviceParametersModel } from '@ff_model/deviceParametersModel';

export const fetchAllDeviceParameters = createAsyncThunk(
	'deviceParameters/fetchAllDeviceParameters',
	async (dataSource: DataSource) => {
		//console.log('fetching thunks...', dataSource);
		const result = await getAllDeviceParameters(dataSource);
		console.log('fetched device parameters');
		console.log(result);
		return result;
	},
);

export const fetchDeviceParameter = createAsyncThunk(
	'deviceParameters/fetchDeviceParameter',
	async (
		{ dataSource, deviceId }: { dataSource: DataSource; deviceId: number },
		{ rejectWithValue },
	) => {
		try {
			const result = await getDeviceParameter(dataSource, deviceId);
			console.log('fetched device parameter');
			console.log(result);
			return result;
		} catch (error: any) {
			console.log('device parameter validation error........', error);
			return rejectWithValue({
				message: error.message,
				code: error.code,
			});
		}
	},
);

export const addNewDeviceParameter = createAsyncThunk(
	'deviceParameters/addNewDeviceParameter',
	async (
		{
			dataSource,
			deviceParameter,
		}: { dataSource: DataSource; deviceParameter: DeviceParametersModel },
		{ rejectWithValue },
	) => {
		try {
			const result = await addDeviceParameter(dataSource, deviceParameter);
			console.log('added device parameter');
			console.log(result);
			return result;
		} catch (error: any) {
			console.log('device parameter validation error........', error);
			return rejectWithValue({
				message: error.message,
				code: error.code,
			});
		}
	},
);

export const addAllNewDeviceParameters = createAsyncThunk(
	'deviceParameters/addAllNewDeviceParameters',
	async (
		{
			dataSource,
			deviceParameter,
		}: { dataSource: DataSource; deviceParameter: DeviceParametersModel[] },
		{ rejectWithValue },
	) => {
		try {
			const result = await addAllDeviceParameters(dataSource, deviceParameter);
			console.log('added device parameters');
			console.log(result);
			return result;
		} catch (error: any) {
			console.log('device parameters validation error........', error);
			return rejectWithValue({
				message: error.message,
				code: error.code,
			});
		}
	},
);

export const updateExistingDeviceParameter = createAsyncThunk(
	'deviceParameters/updateExistingDeviceParameter',
	async (
		{
			dataSource,
			deviceId,
			updates,
		}: {
			dataSource: DataSource;
			deviceId: number;
			updates: Partial<DeviceParametersModel>;
		},
		{ rejectWithValue },
	) => {
		//console.log('doing device updates', deviceId, updates);
		try {
			const result = await updateDeviceParameter(dataSource, deviceId, updates);
			console.log('updated device complete...', result);
			if (result) {
				return { deviceId, updates };
			} else {
				throw new Error(`Failed to update device with ID: ${deviceId}`);
			}
		} catch (error: any) {
			console.log('device validation error........', error);
			return rejectWithValue({
				message: error.message,
				code: error.code,
			});
		}
	},
);

export const deleteDeviceParameterWithId = createAsyncThunk(
	'deviceParameters/deleteDeviceParameterWithId',
	async ({
		dataSource,
		deviceId,
	}: {
		dataSource: DataSource;
		deviceId: number;
	}) => {
		const deleteResult = await deleteDeviceParameter(dataSource, deviceId);
		if (deleteResult.success) {
			return deviceId;
		} else {
			throw new Error(`Failed to delete device with ID: ${deviceId}`);
		}
	},
);
