import { createAsyncThunk } from '@reduxjs/toolkit';
import { DataSource } from 'typeorm/browser';
import {
	addDevice,
	getAllDevices,
	updateDevice,
	deleteDevice,
	getDeviceById,
	getDevicesByProjectId,
	deleteDeviceByProjectId,
} from '@ff_dataAccess/deviceAccess/deviceDataAccess';
import { DeviceModel } from '@ff_model/deviceModel';

export const fetchDevices = createAsyncThunk(
	'devices/fetchDevices',
	async (dataSource: DataSource) => {
		const result = await getAllDevices(dataSource);
		console.log('fetched projects');
		console.log(result);
		return result;
	},
);

export const fetchDeviceById = createAsyncThunk(
	'devices/fetchDeviceById',
	async (
		{ dataSource, deviceId }: { dataSource: DataSource; deviceId: number },
		{ rejectWithValue },
	) => {
		try {
			const result = await getDeviceById(dataSource, deviceId);
			console.log('fetched projects');
			console.log(result);
			return result;
		} catch (error) {
			console.error('Failed to fetch device by ID', error);
			return rejectWithValue('Failed to fetch device by ID');
		}
	},
);

export const fetchDevicesByProjectId = createAsyncThunk(
	'devices/fetchDevicesByProjectId',
	async (
		{ dataSource, projectId }: { dataSource: DataSource; projectId: number },
		{ rejectWithValue },
	) => {
		try {
			const result = await getDevicesByProjectId(dataSource, projectId);
			console.log('fetched projects');
			console.log(result);
			return result;
		} catch (error) {
			console.error('Failed to fetch device by ID', error);
			return rejectWithValue('Failed to fetch device by ID');
		}
	},
);

export const addNewDevice = createAsyncThunk(
	'devices/addNewDevice',
	async (
		{ dataSource, device }: { dataSource: DataSource; device: DeviceModel },
		{ rejectWithValue },
	) => {
		try {
			const result = await addDevice(dataSource, device);
			if (result) {
				// Return the device with the new ID
				return result;
			} else {
				return rejectWithValue('Failed to add device');
			}
		} catch (error) {
			console.error('Failed to add new device', error);
		}
	},
);

export const updateExistingDevice = createAsyncThunk(
	'devices/updateExistingDevice',
	async (
		{
			dataSource,
			deviceId,
			updates,
		}: {
			dataSource: DataSource;
			deviceId: number;
			updates: Partial<DeviceModel>;
		},
		{ rejectWithValue },
	) => {
		//console.log('doing project updates', projectId, updates);
		try {
			const result = await updateDevice(dataSource, deviceId, updates);
			console.log('updated device complete...', result);
			if (result) {
				return { deviceId, updates };
			} else {
				return rejectWithValue('Failed to update device');
			}
		} catch (error) {
			console.error('Failed to update new device', error);
		}
	},
);

export const deleteDeviceWithId = createAsyncThunk(
	'devices/deleteDeviceWithId',
	async (
		{ dataSource, deviceId }: { dataSource: DataSource; deviceId: number },
		{ rejectWithValue },
	) => {
		const deleteResult = await deleteDevice(dataSource, deviceId);
		if (deleteResult.success) {
			return deviceId;
		} else {
			return rejectWithValue(`Failed to delete project with ID: ${deviceId}`);
		}
	},
);

export const deleteDevicesWithProjectId = createAsyncThunk(
	'devices/deleteDevicesWithProjectId',
	async (
		{ dataSource, projectId }: { dataSource: DataSource; projectId: number },
		{ rejectWithValue },
	) => {
		const deleteResult = await deleteDeviceByProjectId(dataSource, projectId);
		if (deleteResult.success) {
			return projectId;
		} else {
			return rejectWithValue(
				`Failed to delete devices with Project ID: ${projectId}`,
			);
		}
	},
);
