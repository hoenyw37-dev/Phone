import {
	createEntityAdapter,
	createSlice,
	EntityState,
} from '@reduxjs/toolkit';
import { RootState } from '../../../../global/store';
import { DeviceModel } from '@ff_model/deviceModel';
import {
	fetchDevices,
	addNewDevice,
	deleteDeviceWithId,
	updateExistingDevice,
	fetchDeviceById,
	fetchDevicesByProjectId,
	deleteDevicesWithProjectId,
} from '@ff_redux/deviceRedux/devicesThunk';

interface DeviceState extends EntityState<DeviceModel, number> {
	//shape of the state inside our slice i.e managed by reducer - type of the state
	status: 'idle' | 'pending' | 'succeeded' | 'rejected';
	error: string | null;
}
//interface with entitystate extended to get status and error

const devicesAdapter = createEntityAdapter({
	//entity adapter for managing the state (devices)
	selectId: (device: DeviceModel) => device.deviceId,
	sortComparer: (a, b) => a.deviceName.localeCompare(b.deviceName),
});

const initialState: DeviceState = devicesAdapter.getInitialState({
	//initial state for the slice - initial value
	status: 'idle',
	error: null,
});

export const devicesSlice = createSlice({
	// slice to perform actions on the state
	name: 'devices', //name of the slice - should be same as thunk name ex: 'devices/fetchDevicess',
	initialState,
	reducers: {
		// Synchronous actions that directly modify the state.
		deviceAdded: devicesAdapter.addOne,
		devicesReceived(state, action) {
			devicesAdapter.setAll(state, action.payload.books);
		},
	},
	extraReducers: builder => {
		// extraReducers Handles asynchronous actions (thunks).
		builder
			//Fetch All Devices
			.addCase(fetchDevices.pending, state => {
				state.status = 'pending';
			})
			.addCase(fetchDevices.fulfilled, (state, action) => {
				state.status = 'succeeded';
				devicesAdapter.setAll(state, action.payload);
				console.log('device fecthing completed');
			})
			.addCase(fetchDevices.rejected, (state, action) => {
				state.status = 'rejected';
				state.error = action.error.message ?? 'Unknown Error';
			})
			// Fetch Device By ID
			.addCase(fetchDeviceById.pending, state => {
				state.status = 'pending';
			})
			.addCase(fetchDeviceById.fulfilled, (state, action) => {
				state.status = 'succeeded';
				if (action.payload) devicesAdapter.upsertOne(state, action.payload);
			})
			.addCase(fetchDeviceById.rejected, (state, action) => {
				state.status = 'rejected';
				state.error = action.error.message ?? 'Unknown Error';
			})
			// Fetch Devices By projectId
			.addCase(fetchDevicesByProjectId.pending, state => {
				state.status = 'pending';
			})
			.addCase(fetchDevicesByProjectId.fulfilled, (state, action) => {
				state.status = 'succeeded';
				if (action.payload) devicesAdapter.setAll(state, action.payload);
			})
			.addCase(fetchDevicesByProjectId.rejected, (state, action) => {
				state.status = 'rejected';
				state.error = action.error.message ?? 'Unknown Error';
			})
			// Add New Device
			.addCase(addNewDevice.pending, state => {
				state.status = 'pending';
			})
			.addCase(addNewDevice.fulfilled, (state, action) => {
				state.status = 'succeeded';
				if (action.payload) devicesAdapter.addOne(state, action.payload);
			})
			.addCase(addNewDevice.rejected, (state, action) => {
				state.status = 'rejected';
				state.error = action.error.message ?? 'Unknown Error';
			})
			// Update Existing Device
			.addCase(updateExistingDevice.pending, state => {
				state.status = 'pending';
			})
			.addCase(updateExistingDevice.fulfilled, (state, action) => {
				state.status = 'succeeded';
				const updatedResult = action.payload;
				if (updatedResult) {
					devicesAdapter.updateOne(state, {
						id: updatedResult.deviceId,
						changes: updatedResult.updates,
					});
				}
			})
			.addCase(updateExistingDevice.rejected, (state, action) => {
				state.status = 'rejected';
				state.error = action.error.message ?? 'Unknown Error';
			})
			// Delete Device By ID
			.addCase(deleteDeviceWithId.pending, state => {
				state.status = 'pending';
			})
			.addCase(deleteDeviceWithId.fulfilled, (state, action) => {
				state.status = 'succeeded';
				devicesAdapter.removeOne(state, action.payload);
			})
			.addCase(deleteDeviceWithId.rejected, (state, action) => {
				state.status = 'rejected';
				state.error = action.error.message ?? 'Unknown Error';
			})
			// Delete Devices By ProjectId
			.addCase(deleteDevicesWithProjectId.pending, state => {
				state.status = 'pending';
			})
			.addCase(deleteDevicesWithProjectId.fulfilled, (state, action) => {
				state.status = 'succeeded';
				// TODO: Add this if remove all the projects related devices
				const projectId = action.payload;
				const devicesToRemove = Object.values(state.entities)
					.filter(device => device?.projectId === projectId)
					.map(device => device!.deviceId);
				devicesAdapter.removeMany(state, devicesToRemove);
				// devicesAdapter.removeMany(state, action.payload);
			})
			.addCase(deleteDevicesWithProjectId.rejected, (state, action) => {
				state.status = 'rejected';
				state.error = action.error.message ?? 'Unknown Error';
			});
	},
});
//Selectors-Functions to select data from the state.
export const { selectAll: selectAllDevices, selectById: selectDeviceById } =
	devicesAdapter.getSelectors((state: RootState) => state.devices);
//Actions
export const { devicesReceived, deviceAdded } = devicesSlice.actions;
//Need to add devicesslice reducer under store.ts file to make it available to the store.
//Functions to select the status and error from the state.
export const selectDevicesStatus = (state: RootState) => state.devices.status;
export const selectDevicesError = (state: RootState) => state.devices.error;

export default devicesSlice.reducer;
