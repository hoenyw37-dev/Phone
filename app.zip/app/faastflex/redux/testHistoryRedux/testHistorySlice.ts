import {
	createEntityAdapter,
	createSlice,
	EntityState,
} from '@reduxjs/toolkit';
import { RootState } from '../../../../global/store';
import { TestsHistoryModel } from '@ff_model/testHistoryModel';
import {
	fetchTestHistory,
	fetchOneTestHistory,
	updateExistingTestHistory,
	addAllNewTestHistory,
	deleteTestHistoryByDevice,
} from '@ff_redux/testHistoryRedux/testHistoryThunk';

interface TestHistoryState extends EntityState<TestsHistoryModel, number> {
	status: 'idle' | 'pending' | 'succeeded' | 'rejected';
	error: string | null;
}

const testsAdapter = createEntityAdapter({
	selectId: (test: TestsHistoryModel) => test.testHistoryId,
});

const initialState: TestHistoryState = testsAdapter.getInitialState({
	status: 'idle',
	error: null,
});

export const testHistorySlice = createSlice({
	name: 'tests',
	initialState,
	reducers: {
		testAdded: testsAdapter.addOne,
		testsReceived(state, action) {
			testsAdapter.setAll(state, action.payload.tests);
		},
	},
	extraReducers: builder => {
		builder
			.addCase(fetchTestHistory.pending, state => {
				state.status = 'pending';
			})
			.addCase(fetchTestHistory.fulfilled, (state, action) => {
				state.status = 'succeeded';
				testsAdapter.setAll(state, action.payload);
				console.log('tests fetching completed');
			})
			.addCase(fetchTestHistory.rejected, (state, action) => {
				state.status = 'rejected';
				state.error = action.error.message ?? 'Unknown Error';
			})
			.addCase(fetchOneTestHistory.pending, state => {
				state.status = 'pending';
			})
			.addCase(fetchOneTestHistory.fulfilled, (state, action) => {
				state.status = 'succeeded';
				testsAdapter.setOne(state, action.payload);
				console.log('test fetching completed');
			})
			.addCase(fetchOneTestHistory.rejected, (state, action) => {
				state.status = 'rejected';
				state.error = action.error.message ?? 'Unknown Error';
			})
			.addCase(addAllNewTestHistory.pending, state => {
				state.status = 'pending';
			})
			.addCase(addAllNewTestHistory.fulfilled, (state, action) => {
				state.status = 'succeeded';
				testsAdapter.addMany(state, action.payload);
				console.log('test fetching completed');
			})
			.addCase(addAllNewTestHistory.rejected, (state, action) => {
				state.status = 'rejected';
				state.error = action.error.message ?? 'Unknown Error';
			})
			.addCase(updateExistingTestHistory.pending, state => {
				state.status = 'pending';
			})
			.addCase(updateExistingTestHistory.fulfilled, (state, action) => {
				state.status = 'succeeded';
				const updatedResult = action.payload;
				if (updatedResult) {
					testsAdapter.updateOne(state, {
						id: updatedResult.testId,
						changes: updatedResult.updates,
					});
				}
				console.log('test fetching completed');
			})
			.addCase(updateExistingTestHistory.rejected, (state, action) => {
				state.status = 'rejected';
				state.error = action.error.message ?? 'Unknown Error';
			})
			// Delete Test History By DeviceId
			.addCase(deleteTestHistoryByDevice.pending, state => {
				state.status = 'pending';
			})
			.addCase(deleteTestHistoryByDevice.fulfilled, (state, action) => {
				state.status = 'succeeded';
				// TODO: Add this to remove all the Device related Test Histories
				const deviceId = action.payload;
				const testHistoriesToRemove = Object.values(state.entities)
					.filter(testHistory => testHistory?.deviceId === deviceId)
					.map(testHistory => testHistory!.testHistoryId);
				testsAdapter.removeMany(state, testHistoriesToRemove);
			})
			.addCase(deleteTestHistoryByDevice.rejected, (state, action) => {
				state.status = 'rejected';
				state.error = action.error.message ?? 'Unknown Error';
			});
	},
});

export const { selectAll: selectAllTests, selectById: selectTestById } =
	testsAdapter.getSelectors((state: RootState) => state.testHistory);

export const { testsReceived, testAdded } = testHistorySlice.actions;

export const selectTestsStatus = (state: RootState) => state.testHistory.status;
export const selectTestsError = (state: RootState) => state.testHistory.error;

export default testHistorySlice.reducer;
