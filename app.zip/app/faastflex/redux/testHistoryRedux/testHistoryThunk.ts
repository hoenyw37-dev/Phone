//import { createAppAsyncThunk } from '../../../../global/store';
import { createAsyncThunk } from '@reduxjs/toolkit';
import {
	getAllTestHistory,
	getTestHistory,
	addTestHistory,
	deleteTestHistory,
	updateTestHistory,
	addAllTestHistory,
	deleteTestHistoryByDeviceId,
} from '@ff_dataAccess/testHistoryAccess/testHistoryDataAccess';
import { DataSource } from 'typeorm/browser';
import { TestsHistoryModel } from '@ff_model/testHistoryModel';

export const fetchTestHistory = createAsyncThunk(
	'testHistory/fetchTestHistory',
	async (
		{ dataSource, deviceId }: { dataSource: DataSource; deviceId: number },
		{ rejectWithValue },
	) => {
		try {
			const result = await getAllTestHistory(dataSource, deviceId);
			console.log('fetched test');
			console.log(result);
			return result;
		} catch (error: any) {
			console.log('tests validation error........', error);
			return rejectWithValue({
				message: error.message,
				code: error.code,
			});
		}
	},
);

export const fetchOneTestHistory = createAsyncThunk(
	'testHistory/fetchOneTestHistory',
	async (
		{ dataSource, testId }: { dataSource: DataSource; testId: number },
		{ rejectWithValue },
	) => {
		try {
			const result = await getTestHistory(dataSource, testId);
			console.log('fetched test');
			console.log(result);
			return result;
		} catch (error: any) {
			console.log('tests validation error........', error);
			return rejectWithValue({
				message: error.message,
				code: error.code,
			});
		}
	},
);

// export const addNewTestHistory = createAsyncThunk(
//     'testHistory/addNewTestHistory',
//     async ({ dataSource, test }: { dataSource: DataSource, test: TestsHistoryModel }, { rejectWithValue }) => {
//         try{
//             const result = await addTestHistory(dataSource, test);
//             console.log('added tests');
//             console.log(result);
//             return result;
//         } catch (error: any) {
//             console.log('tests validation error........', error);
//             return rejectWithValue({
//                 message: error.message,
//                 code: error.code,
//             });

//         }
//     },
// );

export const addAllNewTestHistory = createAsyncThunk(
	'testHistory/addAllNewTestHistory',
	async (
		{
			dataSource,
			testHistoryArray,
		}: { dataSource: DataSource; testHistoryArray: TestsHistoryModel[] },
		{ rejectWithValue },
	) => {
		try {
			const result = await addAllTestHistory(dataSource, testHistoryArray);
			console.log('added tests');
			console.log(result);
			return result;
		} catch (error: any) {
			console.log('tests validation error........', error);
			return rejectWithValue({
				message: error.message,
				code: error.code,
			});
		}
	},
);

export const updateExistingTestHistory = createAsyncThunk(
	'testHistory/updateExistingTestHistory',
	async (
		{
			dataSource,
			testHistoryId,
			deviceId,
			updates,
		}: {
			dataSource: DataSource;
			testHistoryId: number;
			deviceId: number;
			updates: TestsHistoryModel;
		},
		{ rejectWithValue },
	) => {
		//console.log('doing test updates', testId, updates);
		try {
			const result = await updateTestHistory(
				dataSource,
				testHistoryId,
				deviceId,
				updates,
			);
			console.log('updated test complete...', result);
			if (result) {
				return { testId: testHistoryId, updates };
			} else {
				return rejectWithValue('Failed to update Test History');
			}
		} catch (error: any) {
			console.log('tests validation error........', error);
			return rejectWithValue({
				message: error.message,
				code: error.code,
			});
		}
	},
);

export const deleteTestHistoryByDevice = createAsyncThunk(
	'testHistory/deleteTestHistoryByDevice',
	async (
		{ dataSource, deviceId }: { dataSource: DataSource; deviceId: number },
		{ rejectWithValue },
	) => {
		try {
			const deleteResult = await deleteTestHistoryByDeviceId(
				dataSource,
				deviceId,
			);
			if (deleteResult.success) {
				console.log(
					`Deleted ${deleteResult.deletedCount} test history records for device ID: ${deviceId}`,
				);
				return deviceId;
			} else {
				return rejectWithValue(
					`No test history records found for device ID: ${deviceId}`,
				);
			}
		} catch (error: any) {
			console.log('Delete test history error:', error);
			return rejectWithValue({
				message: error.message,
				code: error.code,
			});
		}
	},
);
