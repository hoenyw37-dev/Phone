//import { createAppAsyncThunk } from '../../../../global/store';
import { createAsyncThunk } from '@reduxjs/toolkit';
import {
	getAllTests,
	addTest,
	addAllTests,
	deleteTest,
	updateTest,
	getAllTestsByID,
} from '@ff_dataAccess/testAccess/testDataAccess';
import { DataSource } from 'typeorm/browser';
import { TestsModel } from '@ff_model/testModel';

// export const fetchTests = createAsyncThunk(
//     'tests/fetchTests',
//     async (dataSource: DataSource) => {
//         //console.log('fetching thunks...', dataSource);
//         const result = await getAllTests(dataSource);
//         console.log('fetched tests');
//         console.log(result);
//         return result;
//     },
// );

export const fetchTestsById = createAsyncThunk(
	'tests/fetchTestsById',
	async ({
		dataSource,
		currentDeviceId,
	}: {
		dataSource: DataSource;
		currentDeviceId: number;
	}) => {
		//console.log('fetching thunks...', dataSource);
		const result = await getAllTestsByID(dataSource, currentDeviceId);
		console.log('fetched test');
		console.log(result);
		return result;
	},
);
// export const addNewTest = createAsyncThunk(
//     'tests/addNewTest',
//     async ({ dataSource, test }: { dataSource: DataSource, test: TestsModel }, { rejectWithValue }) => {
//         try{
//             const result = await addTest(dataSource, test);
//             console.log('added tests');
//             console.log(result);
//             return result;
//         } catch (error: any) {
//             console.log('tests validation error........', error);
//             return rejectWithValue({
//                 message: error.message,
//                 code: error.code,
//             });

//         }
//     },
// );

export const addAllNewTests = createAsyncThunk(
	'tests/addAllNewTests',
	async (
		{ dataSource, tests }: { dataSource: DataSource; tests: TestsModel[] },
		{ rejectWithValue },
	) => {
		try {
			const result = await addAllTests(dataSource, tests);
			console.log('added tests');
			console.log(result);
			return result;
		} catch (error: any) {
			console.log('tests validation error........', error);
			return rejectWithValue({
				message: error.message,
				code: error.code,
			});
		}
	},
);

// export const updateExistingTest = createAsyncThunk(
//     'tests/updateExistingTest',
//     async ({ dataSource, testId, updates }: { dataSource: DataSource, testId: number, updates: Partial<TestsModel> }, { rejectWithValue }) => {
//         //console.log('doing test updates', testId, updates);
//         try{
//             const result = await updateTest(dataSource, testId, updates);
//             console.log('updated test complete...', result);
//             if (result) {
//                 return { testId, updates };
//             } else {
//                 throw new Error(`Failed to update test with ID: ${testId}`);
//             }
//         }
//         catch (error: any) {
//                 console.log('tests validation error........', error);
//                 return rejectWithValue({
//                     message: error.message,
//                     code: error.code,
//                 });
//         }
//     },
// );

// export const deleteTestWithId = createAsyncThunk(
//     'tests/deleteTestWithId',
//     async ({ dataSource, testId }: { dataSource: DataSource, testId: number }) => {
//         const deleteResult = await deleteTest(dataSource, testId);
//         if (deleteResult.success) {
//             return testId;
//         } else {
//             throw new Error(`Failed to delete test with ID: ${testId}`);
//         }
//     },
// );
