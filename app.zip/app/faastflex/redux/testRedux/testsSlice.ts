import {
	createEntityAdapter,
	createSlice,
	EntityState,
} from '@reduxjs/toolkit';
import { RootState } from '../../../../global/store';
import { TestsModel } from '@ff_model/testModel';
import { addAllNewTests, fetchTestsById } from '@ff_redux/testRedux/testsThunk';

interface TestsState extends EntityState<TestsModel, number> {
	status: 'idle' | 'pending' | 'succeeded' | 'rejected';
	error: string | null;
}

const testsAdapter = createEntityAdapter({
	selectId: (test: TestsModel) => test.testId,
});

const initialState: TestsState = testsAdapter.getInitialState({
	status: 'idle',
	error: null,
});

export const testsSlice = createSlice({
	name: 'tests',
	initialState,
	reducers: {
		testAdded: testsAdapter.addOne,
		testsReceived(state, action) {
			testsAdapter.setAll(state, action.payload.tests);
		},
	},
	extraReducers: builder => {
		builder
			.addCase(fetchTestsById.pending, state => {
				state.status = 'pending';
			})
			.addCase(fetchTestsById.fulfilled, (state, action) => {
				state.status = 'succeeded';
				testsAdapter.setAll(state, action.payload);
				console.log('tests fetching completed');
			})
			.addCase(fetchTestsById.rejected, (state, action) => {
				state.status = 'rejected';
				state.error = action.error.message ?? 'Unknown Error';
			})
			.addCase(addAllNewTests.pending, state => {
				state.status = 'pending';
			})
			.addCase(addAllNewTests.fulfilled, (state, action) => {
				state.status = 'succeeded';
				testsAdapter.addMany(state, action.payload);
			})
			.addCase(addAllNewTests.rejected, (state, action) => {
				state.status = 'rejected';
				state.error = action.error.message ?? 'Unknown Error';
			});
	},
});

export const { selectAll: selectAllTests, selectById: selectTestById } =
	testsAdapter.getSelectors((state: RootState) => state.tests);

export const { testsReceived, testAdded } = testsSlice.actions;

export const selectTestsStatus = (state: RootState) => state.tests.status;
export const selectTestsError = (state: RootState) => state.tests.error;

export default testsSlice.reducer;
