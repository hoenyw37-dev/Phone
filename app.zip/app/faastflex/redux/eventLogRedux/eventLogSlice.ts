import {
	createEntityAdapter,
	createSlice,
	EntityState,
} from '@reduxjs/toolkit';
import { RootState } from '../../../../global/store';
import { EventLogModel } from '@ff_model/eventLogModel';
import {
	fetchAllEventLogs,
	addNewEventLog,
	addAllNewEventLogs,
	deleteEventLogs,
	fetchAllLogsWithMAC,
	deleteAllEventLogs,
} from '@ff_redux/eventLogRedux/eventLogThunk';

interface EventLogState extends EntityState<EventLogModel, number> {
	//shape of the state inside our slice i.e managed by reducer - type of the state
	status: 'idle' | 'pending' | 'succeeded' | 'rejected';
	error: string | null;
}
//interface with entitystate extended to get status and error

const eventLogAdapter = createEntityAdapter({
	//entity adapter for managing the state (devices)
	selectId: (log: EventLogModel) => log.logId,
});

const initialState: EventLogState = eventLogAdapter.getInitialState({
	//initial state for the slice - initial value
	status: 'idle',
	error: null,
});

export const eventLogSlice = createSlice({
	// slice to perform actions on the state
	name: 'eventLogs', //name of the slice - should be same as thunk name ex: 'devices/fetchDevicess',
	initialState,
	reducers: {
		// Synchronous actions that directly modify the state.
		eventLogAdded: eventLogAdapter.addOne,
		eventLogsReceived(state, action) {
			eventLogAdapter.setAll(state, action.payload.books);
		},
	},
	extraReducers: builder => {
		// extraReducers Handles asynchronous actions (thunks).
		builder
			//Fetch All EventLogs
			.addCase(fetchAllEventLogs.pending, state => {
				state.status = 'pending';
			})
			.addCase(fetchAllEventLogs.fulfilled, (state, action) => {
				state.status = 'succeeded';
				eventLogAdapter.setAll(state, action.payload);
				console.log('device fecthing completed');
			})
			.addCase(fetchAllEventLogs.rejected, (state, action) => {
				state.status = 'rejected';
				state.error = action.error.message ?? 'Unknown Error';
			})
			//Fetch All EventLogs with MAC Address
			.addCase(fetchAllLogsWithMAC.pending, state => {
				state.status = 'pending';
			})
			.addCase(fetchAllLogsWithMAC.fulfilled, (state, action) => {
				state.status = 'succeeded';
				eventLogAdapter.setAll(state, action.payload);
				console.log('device fecthing completed');
			})
			.addCase(fetchAllLogsWithMAC.rejected, (state, action) => {
				state.status = 'rejected';
				state.error = action.error.message ?? 'Unknown Error';
			})
			//Add New EventLog
			.addCase(addNewEventLog.pending, state => {
				state.status = 'pending';
			})
			.addCase(addNewEventLog.fulfilled, (state, action) => {
				state.status = 'succeeded';
				if (action.payload) eventLogAdapter.addOne(state, action.payload);
			})
			.addCase(addNewEventLog.rejected, (state, action) => {
				state.status = 'rejected';
				state.error = action.error.message ?? 'Unknown Error';
			})
			//Add All New EventLogs
			.addCase(addAllNewEventLogs.pending, state => {
				state.status = 'pending';
			})
			.addCase(addAllNewEventLogs.fulfilled, (state, action) => {
				state.status = 'succeeded';
				if (action.payload) eventLogAdapter.addMany(state, action.payload);
			})
			.addCase(addAllNewEventLogs.rejected, (state, action) => {
				state.status = 'rejected';
				state.error = action.error.message ?? 'Unknown Error';
			})
			//Delete EventLogs
			.addCase(deleteAllEventLogs.pending, state => {
				state.status = 'pending';
			})
			.addCase(deleteAllEventLogs.fulfilled, (state, action) => {
				state.status = 'succeeded';
				if (action.payload) {
					const macAddress = action.payload;
					const logsToRemove = Object.values(state.entities)
						.filter(log => log?.deviceMacAddress === macAddress)
						.map(log => log!.logId);
					eventLogAdapter.removeMany(state, logsToRemove);
				}
			})
			.addCase(deleteAllEventLogs.rejected, (state, action) => {
				state.status = 'rejected';
				state.error = action.error.message ?? 'Unknown Error';
			});
	},
});
//Selectors-Functions to select data from the state.
export const { selectAll: selectAllLogs, selectById: selectLogById } =
	eventLogAdapter.getSelectors((state: RootState) => state.eventLog);
//Actions
export const { eventLogsReceived, eventLogAdded } = eventLogSlice.actions;
//Need to add devicesslice reducer under store.ts file to make it available to the store.
//Functions to select the status and error from the state.
export const selectLogsStatus = (state: RootState) => state.eventLog.status;
export const selectLogsError = (state: RootState) => state.eventLog.error;

export default eventLogSlice.reducer;
