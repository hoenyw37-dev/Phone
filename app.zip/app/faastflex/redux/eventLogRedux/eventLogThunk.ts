import { createAsyncThunk } from '@reduxjs/toolkit';
import { DataSource } from 'typeorm/browser';
import {
	addAllEventLogs,
	addEventLog,
	deleteLogs,
	getAllEventLogs,
	getAllEventLogsByMACAddress,
	deleteAllLogs,
} from '@ff_dataAccess/logsAccess/logDataAccess';
import { EventLogModel } from '@ff_model/eventLogModel';

export const addNewEventLog = createAsyncThunk(
	'eventLogs/addNewEventLog',
	async (
		{
			dataSource,
			eventLog,
		}: { dataSource: DataSource; eventLog: EventLogModel },
		{ rejectWithValue },
	) => {
		try {
			const result = await addEventLog(dataSource, eventLog);
			console.log('added Log');
			console.log(result);
			return result;
		} catch (error) {
			console.error('Failed to add new Log', error);
		}
	},
);
export const addAllNewEventLogs = createAsyncThunk(
	'testHistory/addAllNewEventLog',
	async (
		{
			dataSource,
			EventLogs,
		}: { dataSource: DataSource; EventLogs: EventLogModel[] },
		{ rejectWithValue },
	) => {
		try {
			const result = await addAllEventLogs(dataSource, EventLogs);
			console.log('added Logs');
			console.log(result);
			return result;
		} catch (error: any) {
			console.log('Logs validation error........', error);
			return rejectWithValue({
				message: error.message,
				code: error.code,
			});
		}
	},
);
export const fetchAllEventLogs = createAsyncThunk(
	'eventLogs/fetchAllEventLogs',
	async ({
		dataSource,
		deviceMacAddress,
	}: {
		dataSource: DataSource;
		deviceMacAddress: string;
	}) => {
		const result = await getAllEventLogs(dataSource);
		console.log('fetched projects');
		console.log(result);
		return result;
	},
);

export const fetchAllLogsWithMAC = createAsyncThunk(
	'eventLogs/fetchAllLogsWithMAC',
	async ({
		dataSource,
		deviceMacAddress,
	}: {
		dataSource: DataSource;
		deviceMacAddress: string;
	}) => {
		const result = await getAllEventLogsByMACAddress(
			dataSource,
			deviceMacAddress,
		);
		console.log('fetched logs');
		console.log(result);
		return result;
	},
);

export const deleteEventLogs = createAsyncThunk(
	'eventLogs/deleteEventLogs',
	async ({
		dataSource,
		deviceId: logId,
	}: {
		dataSource: DataSource;
		deviceId: number;
	}) => {
		const deleteResult = await deleteLogs(dataSource, logId);
		if (deleteResult.success) {
			return logId;
		} else {
			throw new Error(`Failed to delete project with ID: ${logId}`);
		}
	},
);

export const deleteAllEventLogs = createAsyncThunk(
	'eventLogs/deleteAllEventLogs',
	async ({
		dataSource,
		deviceMacAddress,
	}: {
		dataSource: DataSource;
		deviceMacAddress: string;
	}) => {
		const deleteResult = await deleteAllLogs(dataSource, deviceMacAddress);
		if (deleteResult.success) {
			return deviceMacAddress;
		} else {
			throw new Error(`Failed to delete project with ID: ${deviceMacAddress}`);
		}
	},
);
