import React from 'react';
//import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import PanelsList from './features/panels/screens/panelsList';
import SwitchesList from './features/panels/screens/switchesList';
import FormIndex from './features/panels/screens/formIndex';
import TemplatesList from './features/switches/screens/templatesList';

const Stack = createNativeStackNavigator();

export const Powerstrike = () => {
	return (
		<Stack.Group>
			<Stack.Screen
				name='PanelsList'
				component={PanelsList}
				options={{ title: 'Power Supply', headerShown: false }}
			/>
			<Stack.Screen
				name='SwitchesList'
				component={SwitchesList}
				options={{ title: 'Switch Settings', headerShown: false }}
			/>
			<Stack.Screen
				name='FormIndex'
				component={FormIndex}
				options={{ title: 'Form', headerShown: false }}
			/>
			<Stack.Screen
				name='TemplatesList'
				component={TemplatesList}
				options={{ title: 'Templates', headerShown: false }}
			/>
		</Stack.Group>
	);
};
