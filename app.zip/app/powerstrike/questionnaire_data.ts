export const formData = [
	{
		id: '1',
		text: 'Master Switch Data',
		disableText: true,
		numPages: 3,
		questions: [
			{
				id: '2',
				text: 'Debounce Setting',
				childDisplay: 'points',
				page: 1,
				options: [
					{
						id: '3',
						text: 'Temporal (for ANSI temporal signals)',
						code: '1100000000',
					},
					{
						id: '4',
						text: '50Hz (20 msec, for full wave rectified signals)',
						code: '2100000000',
					},
					{
						id: '5',
						text: '6 msec (for strobe sync signals, control/relay modules)',
						code: '1200000000',
					},
					{
						id: '6',
						text: '1 msec (for strobe sync signals, control/relay modules)',
						code: '2200000000',
					},
				],
			},
			{
				id: '7',
				text: 'Command Input #1 Function',
				childDisplay: 'points',
				page: 2,
				options: [
					{
						id: '8',
						text: 'Sync Configuration',
						code: '0010000000',
					},
					{
						id: '9',
						text: 'Normal Configuration ',
						code: '0020000000',
					},
				],
			},
			{
				id: '10',
				text: 'Internal Battery Charger Enabled',
				childDisplay: 'points',
				page: 2,
				options: [
					{
						id: '11',
						text: 'Yes',
						code: '0002000000',
					},
					{
						id: '12',
						text: 'No',
						code: '0001000000',
					},
				],
			},
			{
				id: '13',
				text: 'Door Holder dropout delay after AC Power loss',
				childDisplay: 'points',
				page: 2,
				options: [
					{
						id: '14',
						text: "Power doesn't drop out",
						code: '0000110000',
					},
					{
						id: '15',
						text: '5 minutes',
						code: '0000210000',
					},
					{
						id: '16',
						text: '60 seconds',
						code: '0000120000',
					},
					{
						id: '17',
						text: '15 seconds',
						code: '0000220000',
					},
				],
			},
			{
				id: '18',
				heading: 'Mode Of Operation',
				childDisplay: 'points',
				page: 3,
				options: [
					{
						id: '19',
						text: 'Default',
						disableText: true,
						numPages: 3,
						questions: [
							{
								id: '20',
								text: 'AC Loss Delay Timer',
								childDisplay: 'points',
								page: 3,
								options: [
									{
										id: '21',
										text: '30 Hours',
										code: '0000001122',
									},
									{
										id: '22',
										text: '12 Hours',
										code: '0000002122',
									},
									{
										id: '23',
										text: '2 Hours',
										code: '0000001222',
									},
									{
										id: '24',
										text: 'None',
										code: '0000002222',
									},
								],
							},
						],
					},
					{
						id: '25',
						text: 'Retrofit',
						disableText: true,
						numPages: 3,
						questions: [
							{
								id: '26',
								text: 'AC Loss Delay Timer',
								childDisplay: 'points',
								page: 3,
								options: [
									{
										id: '27',
										text: '2 Hours',
										code: '0000001011',
									},
									{
										id: '28',
										text: 'None',
										code: '0000002011',
									},
								],
							},
							{
								id: '29',
								text: 'Trouble Relay Function',
								childDisplay: 'points',
								page: 3,
								options: [
									{
										id: '30',
										text: 'AC fault and ground fault reported by the Input #1/Input #2 trouble relay and the General Trouble relay',
										code: '0000000111',
									},
									{
										id: '31',
										text: 'AC fault is reported only by the AC trouble relay',
										code: '0000000211',
									},
								],
							},
						],
					},
				],
			},
		],
	},
	{
		id: '32',
		text: 'Output Switch Data',
		disableText: true,
		numPages: 2,
		childDisplay: 'points',
		page: 1,
		options: [
			{
				id: '33',
				text: 'Unused',
				code: '33333333',
				numPages: 1,
			},
			{
				id: '35',
				text: 'Non-resettable Aux Power',
				disableText: true,
				code: '11121101',
				numPages: 2,
				questions: [
					{
						id: '36',
						heading: 'Non-resettable Aux Power',
						text: 'Wiring Supervision Type',
						childDisplay: 'points',
						page: 2,
						options: [
							{
								id: '37',
								text: 'CLASS A',
								code: '00000020',
							},
							{
								id: '38',
								text: 'CLASS B',
								code: '00000010',
							},
						],
					},
				],
			},
			{
				id: '39',
				text: 'Resettable Aux Power',
				disableText: true,
				code: '00112101',
				numPages: 2,
				questions: [
					{
						id: '40',
						heading: 'Resettable Aux Power',
						text: 'Operation Type',
						childDisplay: 'points',
						page: 2,
						options: [
							{
								id: '41',
								text: 'Output will reset when Command Input #1 receives a negative pulse trigger signal from FACP or control module.',
								code: '11000000',
							},
							{
								id: '42',
								text: 'Output will reset when Command Input #2 receives a negative pulse trigger signal from FACP or control module.',
								code: '21000000',
							},
							{
								id: '43',
								text: 'Output will reset when Command Input #3 receives a negative pulse trigger signal from FACP or control module, if available.',
								code: '12000000',
							},
							{
								id: '44',
								text: 'Output will reset when any Command Input receives a negative pulse trigger signal from FACP or control module.',
								code: '22000000',
							},
						],
					},
					{
						id: '45',
						text: 'Wiring Supervision Type',
						childDisplay: 'points',
						page: 2,
						options: [
							{
								id: '46',
								text: 'CLASS A',
								code: '00000020',
							},
							{
								id: '47',
								text: 'CLASS B',
								code: '00000010',
							},
						],
					},
				],
			},
			{
				id: '48',
				text: 'Door Holder Power',
				disableText: true,
				code: '00221101',
				numPages: 2,
				questions: [
					{
						id: '49',
						heading: 'Door Holder Power',
						text: 'Operation Type',
						childDisplay: 'points',
						page: 2,
						options: [
							{
								id: '50',
								text: 'Output will Drop power when Command Input #1 is activated.',
								code: '11000000',
							},
							{
								id: '51',
								text: 'Output will Drop power when Command Input #2 is activated.',
								code: '21000000',
							},
							{
								id: '52',
								text: 'Output will Drop power when Command Input #3 is activated, if available.',
								code: '12000000',
							},
							{
								id: '53',
								text: 'Output will Drop power when ANY Command Input is activated.',
								code: '22000000',
							},
						],
					},
					{
						id: '54',
						text: 'Wiring Supervision Type',
						childDisplay: 'points',
						page: 2,
						options: [
							{
								id: '55',
								text: 'CLASS A',
								code: '00000020',
							},
							{
								id: '56',
								text: 'CLASS B',
								code: '00000010',
							},
						],
					},
				],
			},
			{
				id: '57',
				text: 'NAC Follower',
				disableText: true,
				code: '00212101',
				numPages: 2,
				questions: [
					{
						id: '58',
						heading: 'NAC Follower',
						text: 'Operation Type',
						childDisplay: 'points',
						page: 2,
						options: [
							{
								id: '59',
								text: 'NAC output will activate when Command Input #2 is activated.',
								code: '21000000',
							},
							{
								id: '60',
								text: 'NAC output will activate when Command Input #3 is activated, if available.',
								code: '12000000',
							},
							{
								id: '61',
								text: 'NAC output will activate when ANY Command Input is activated.',
								code: '22000000',
							},
						],
					},
					{
						id: '62',
						text: 'Wiring Supervision Type',
						childDisplay: 'points',
						page: 2,
						options: [
							{
								id: '63',
								text: 'CLASS A',
								code: '00000020',
							},
							{
								id: '64',
								text: 'CLASS B',
								code: '00000010',
							},
						],
					},
				],
			},
			{
				id: '65',
				text: 'NAC Master Sync',
				disableText: true,
				code: '00000000',
				numPages: 3,
				questions: [
					{
						id: '66',
						heading: 'NAC Master Sync',
						text: 'Dynamic Signaling With Magnet Test',
						childDisplay: 'points',
						page: 2,
						options: [
							{
								id: '67',
								text: 'YES',
								disableText: true,
								questions: [],
							},
							{
								id: '81',
								text: 'NO',
								disableText: true,
								questions: [
									{
										id: '82',
										text: 'Operation Type',
										childDisplay: 'points',
										page: 2,
										options: [
											{
												id: '83',
												text: 'NAC output will activate when Command Input #1 is activated.',
												code: '11000000',
											},
											{
												id: '84',
												text: 'NAC output will activate when Command Input #2 is activated.',
												code: '21000000',
											},
											{
												id: '85',
												text: 'NAC output will activate when Command Input #3 is activated, if available.',
												code: '12000000',
											},
											{
												id: '86',
												text: 'NAC output will activate when ANY Command Input is activated.',
												code: '22000000',
											},
										],
									},
									{
										id: '87',
										text: 'Synchronization Type',
										childDisplay: 'points',
										page: 3,
										options: [
											{
												id: '88',
												text: 'ANSI Temporal (Temporal 3)',
												code: '00122101',
											},
											{
												id: '89',
												text: 'CO Temporal (Temporal 4)',
												code: '00222101',
											},
											{
												id: '90',
												text: 'Amseco/Potter',
												code: '00111201',
											},
											{
												id: '91',
												text: 'Gentex',
												code: '00121201',
											},
											{
												id: '92',
												text: 'System Sensor',
												code: '00112201',
											},
											{
												id: '93',
												text: 'Wheelock',
												code: '00122201',
											},
										],
									},
									{
										id: '94',
										text: 'Wiring Supervision Type',
										childDisplay: 'points',
										page: 3,
										options: [
											{
												id: '95',
												text: 'CLASS A',
												code: '00000020',
											},
											{
												id: '96',
												text: 'CLASS B',
												code: '00000010',
											},
										],
									},
								],
							},
						],
					},
				],
			},
		],
	},
];

export const responseData = [
	{
		switchName: 'S1',
		switchSetting: '1000000001',
		response: {
			'2': '4',
			'7': '9',
			'10': '11',
			'13': '16',
			'18': '25',
			'26': '27',
			'29': '30',
		},
	},
	{
		switchName: 'S2',
		switchSetting: '00000000',
		response: {},
	},
	{
		switchName: 'S3',
		switchSetting: '00000000',
		response: {},
	},
	{
		switchName: 'S4',
		switchSetting: '00000000',
		response: {},
	},
	{
		switchName: 'S5',
		switchSetting: '00000000',
		response: {},
	},
	{
		switchName: 'S6',
		switchSetting: '00000000',
		response: {},
	},
	{
		switchName: 'S7',
		switchSetting: '00000000',
		response: {},
	},
	{
		switchName: 'S8',
		switchSetting: '00000000',
		response: {},
	},
];

// Add these questions for dynamic signaling if response to question 66 is YES (id: 67)
/*
                                           {
                                            'id': '68',
                                            'text': 'Operation Type',
                                            'childDisplay': 'points',
                                            'page': 2,
                                            'options': [
                                                {
                                                    'id': '69',
                                                    'text': 'NAC output will activate when Command Input #1 is activated.',
                                                    'code': '11000000',
                                                },
                                                {
                                                    'id': '70',
                                                    'text': 'NAC output will activate when Command Input #2 is activated.',
                                                    'code': '21000000',
                                                },
                                                {
                                                    'id': '71',
                                                    'text': 'NAC output will activate when Command Input #3 is activated, if available.',
                                                    'code': '12000000',
                                                },
                                                {
                                                    'id': '72',
                                                    'text': 'NAC output will activate when ANY Command Input is activated.',
                                                    'code': '22000000',
                                                },
                                            ],
                                        },
                                        {
                                            'id': '73',
                                            'text': 'Synchronization Type',
                                            'childDisplay': 'points',
                                            'page': 3,
                                            'options': [
                                                {
                                                    'id': '74',
                                                    'text': 'Amseco/Potter',
                                                    'code': '00211201',
                                                },
                                                {
                                                    'id': '75',
                                                    'text': 'Gentex',
                                                    'code': '00221201',
                                                },
                                                {
                                                    'id': '76',
                                                    'text': 'System Sensor',
                                                    'code': '00212201',
                                                },
                                                {
                                                    'id': '77',
                                                    'text': 'Wheelock',
                                                    'code': '00222201',
                                                },
                                            ],
                                        },
                                        {
                                            'id': '78',
                                            'text': 'Wiring Supervision Type',
                                            'childDisplay': 'points',
                                            'page': 3,
                                            'options': [
                                                {
                                                    'id': '79',
                                                    'text': 'CLASS A',
                                                    'code': '00000020',
                                                },
                                                {
                                                    'id': '80',
                                                    'text': 'CLASS B',
                                                    'code': '00000010',
                                                },
                                            ],
                                        },

                                        */
