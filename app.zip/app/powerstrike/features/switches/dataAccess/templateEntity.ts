import { Entity, PrimaryGeneratedColumn, Column } from 'typeorm';

@Entity('templatesTest')
export class TemplateEntity {
	@PrimaryGeneratedColumn()
	templateId: number;

	@Column({ type: 'varchar' })
	templateName: string;

	@Column({ type: 'varchar' })
	templateType: string;

	@Column({ type: 'varchar', nullable: true })
	templateDescription?: string;

	@Column({ type: 'varchar' })
	templatePanelType: string;

	@Column({ type: 'simple-json' })
	templateSetting: {
		switchName: string;
		switchDisplay: string;
		switchDescription: string;
		response: { [key: string]: string };
	}[];
}
