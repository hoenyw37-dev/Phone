import { DataSource } from 'typeorm';
import { TemplateEntity } from './templateEntity';
import {
	convertTemplateEntityToTemplate,
	convertTemplateToTemplateEntity,
} from './templateConversion';
import { Template } from '../types/template';

export const getAllTemplates = async (
	dataSource: DataSource,
): Promise<Template[]> => {
	//console.log('.............................');
	const rawresult = await dataSource.manager.find(TemplateEntity);
	const result = rawresult.map(convertTemplateEntityToTemplate);
	return result;
};

export const addTemplate = async (
	dataSource: DataSource,
	template: Template,
): Promise<Template> => {
	const templateEntity = convertTemplateToTemplateEntity(template);
	//console.log(templateEntity);
	const newTemplateEnt = await dataSource.manager.save(
		TemplateEntity,
		templateEntity,
	);
	const newTemplate = convertTemplateEntityToTemplate(newTemplateEnt);
	console.log(newTemplate);
	return newTemplate;
};

export const updateTemplate = async (
	dataSource: DataSource,
	templateId: number,
	updates: Partial<Template>,
): Promise<Boolean> => {
	const templateEntity = convertTemplateToTemplateEntity(updates);
	//console.log(templateEntity);
	const result = await dataSource.manager.update(
		TemplateEntity,
		templateId,
		templateEntity,
	);
	if (result.affected && result.affected > 0) {
		console.log(`Successfully updated template with ID: ${templateId}`);
		return true;
	} else {
		console.log(`Failed to update template with ID: ${templateId}`);
		return false;
	}
};

export const deleteTemplate = async (
	dataSource: DataSource,
	templateId: number,
): Promise<{ success: boolean }> => {
	//console.log(templateEntity);
	const result = await dataSource.manager.delete(TemplateEntity, templateId);
	if (result.affected && result.affected > 0) {
		console.log(`Successfully deleted template with ID: ${templateId}`);
		return { success: true };
	} else {
		console.log(`Failed to delete template with ID: ${templateId}`);
		return { success: false };
	}
};
