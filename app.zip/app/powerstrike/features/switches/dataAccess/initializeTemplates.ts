import { DataSource } from 'typeorm';
import { TemplateEntity } from './templateEntity';
import { standardTemplates } from '../../../standardTemplates';

const initializeTemplates = async (dataSource: DataSource) => {
	const templateRepository = dataSource.getRepository(TemplateEntity);

	// Check if 'standard' templates already exist
	const count = await templateRepository.count({
		where: { templateType: 'standard' },
	});

	if (count === 0) {
		console.log('adding new standard templates...');
		await templateRepository.save(standardTemplates);
	}
};

export default initializeTemplates;
