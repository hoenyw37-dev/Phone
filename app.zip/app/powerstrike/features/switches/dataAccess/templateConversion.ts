import { TemplateEntity } from './templateEntity';
import { Template } from '../types/template';

export const convertTemplateEntityToTemplate = (
	entity: TemplateEntity,
): Template => {
	return {
		templateId: entity.templateId,
		templateName: entity.templateName,
		templateType: entity.templateType,
		templateDescription: entity.templateDescription || undefined,
		templatePanelType: entity.templatePanelType,
		templateSetting: entity.templateSetting,
	};
};

export const convertTemplateToTemplateEntity = (
	template: Template,
): TemplateEntity => {
	const entity = new TemplateEntity();
	if (template.templateId) {
		entity.templateId = template.templateId;
	}
	entity.templateName = template.templateName;
	entity.templateType = template.templateType;
	entity.templateDescription = template.templateDescription || undefined;
	entity.templatePanelType = template.templatePanelType;
	entity.templateSetting = template.templateSetting;
	return entity;
};
