import { Switch } from '../../panels/types/panel';

export type Template = {
	templateId: number;
	templateName: string;
	templateType: string;
	templateDescription?: string;
	templatePanelType: string;
	templateSetting: Switch[];
};
