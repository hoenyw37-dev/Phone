import React, { useEffect, useState } from 'react';
import { Modal, Text, View, Button } from 'react-native';
import { CopySwitchModalStyles } from '@powerstrike/features/switches/styles/CopySwitchModalStyles';
import { Switch } from '@powerstrike/features/panels/types/panel';
import DoubleButtonFooter from '@components/doubleButtonFooter';
import { Picker } from '@react-native-picker/picker';
import { set } from 'react-hook-form';
import { commonColors, commonSizes } from '@styles/base';
import CommonModalUI from '@components/CommonModalUI';

type CopySwitchModalModalProps = {
	modalVisible: boolean;
	selectedSwitchId: number;
	allSwitchesInfo: Switch[];
	closeModal: () => void;
	onSubmit: (switchNumbers: number[]) => void;
};
const CopySwitchModal = (props: CopySwitchModalModalProps) => {
	const [selectedValue, setSelectedValue] = useState(-1);

	const availableOptions = props.allSwitchesInfo
		.map((switchInfo, index) => ({
			label: index === 0 ? 'All Outputs' : switchInfo.switchName,
			value: index === 0 ? -1 : index, // dont use 0 value in picker, represents falsy value
		}))
		.filter(option => option.value !== props.selectedSwitchId);

	const onSave = () => {
		let switchNumbers: number[] = [];
		console.log('Selected Value', selectedValue);
		if (selectedValue === -1) {
			switchNumbers = props.allSwitchesInfo
				.map((_, index) => index)
				.filter(index => index !== 0);
		} else {
			switchNumbers = [selectedValue];
		}
		//console.log('Selected Switches', switchNumbers);
		props.onSubmit(switchNumbers);
		props.closeModal();
		setSelectedValue(-1);
	};

	const handleOptionChange = val => {
		setSelectedValue(val);
		//console.log('Selected Value', val);
	};

	return (
		<CommonModalUI
			modalVisible={props.modalVisible}
			closeModal={props.closeModal}
			leftButtonText='CANCEL'
			rightButtonText='SAVE'
			onLeftButtonPress={props.closeModal}
			onRightButtonPress={onSave}
			titleText='Copy to'
			titleTextExtraStyle={CopySwitchModalStyles.titleStyle}>
			<View style={{ marginTop: '5%', marginBottom: '5%' }}>
				<Picker
					selectedValue={selectedValue}
					onValueChange={val => handleOptionChange(val)}
					style={[CopySwitchModalStyles.picker]}
					dropdownIconColor={commonColors.textColor_Black}
					mode={'dialog'}
					itemStyle={CopySwitchModalStyles.picker}>
					{availableOptions.map((option, index) => (
						<Picker.Item
							key={index}
							label={option.label}
							value={option.value}
							style={CopySwitchModalStyles.pickerItems}
						/>
					))}
				</Picker>
			</View>
		</CommonModalUI>
	);
};

export { CopySwitchModal };
