import React from 'react';
import { View, Text, TextInput, StyleSheet } from 'react-native';
import { useForm, Controller } from 'react-hook-form';
import { yupResolver } from '@hookform/resolvers/yup';
import * as yup from 'yup';

import { commonColors, commonSizes } from '@styles/base';
import CommonModalUI from '@components/CommonModalUI';

type TemplateFormData = {
	templateName: string;
	templateDescription: string;
};

type TemplateModalProps = {
	visible: boolean;
	onClose: () => void;
	onSubmit: (data: TemplateFormData) => void;
};

const schema = yup.object().shape({
	templateName: yup
		.string()
		.required('Template name is required')
		.max(50, 'Template name cannot exceed 50 characters'),
	templateDescription: yup
		.string()
		.required('Template Description is required')
		.max(50, 'Template Description cannot exceed 50 characters'),
});

export default function AddTemplateModal(props: TemplateModalProps) {
	const {
		control,
		handleSubmit,
		formState: { errors },
		reset,
	} = useForm<TemplateFormData>({
		resolver: yupResolver(schema),
	});

	const handleFormSubmit = (data: TemplateFormData) => {
		props.onSubmit(data);
		reset();
		props.onClose();
	};

	return (
		<CommonModalUI
			modalVisible={props.visible}
			closeModal={props.onClose}
			leftButtonText='CANCEL'
			rightButtonText='SAVE'
			onLeftButtonPress={props.onClose}
			onRightButtonPress={handleSubmit(handleFormSubmit)}
			titleText='Save New Template'
			titleTextExtraStyle={styles.titleStyle}>
			<View style={{ marginTop: '5%' }}>
				<Text>
					<Text
						style={{
							color: '#373737',
							fontSize: commonSizes.textSizeM,
						}}>
						Template Name
					</Text>
					<Text style={{ color: commonColors.warningColor }}>*</Text>
				</Text>
				<Controller
					control={control}
					name='templateName'
					defaultValue=''
					render={({ field: { onChange, value } }) => (
						<TextInput
							style={[styles.input, errors.templateName && styles.errorInput]}
							placeholder='Enter Template Name'
							placeholderTextColor='#808080'
							value={value}
							onChangeText={onChange}
							maxLength={50}
						/>
					)}
				/>
				{errors.templateName && (
					<Text style={styles.errorText}>{errors.templateName.message}</Text>
				)}
			</View>
			<View style={{ marginTop: '5%', marginBottom: '5%' }}>
				<Text>
					<Text
						style={{
							color: commonColors.textColor_Black,
							fontSize: commonSizes.textSizeM,
						}}>
						Template Description
					</Text>
					<Text style={{ color: commonColors.warningColor }}>*</Text>
				</Text>
				<Controller
					control={control}
					name='templateDescription'
					defaultValue=''
					render={({ field: { onChange, value } }) => (
						<TextInput
							style={[
								styles.input,
								errors.templateDescription && styles.errorInput,
							]}
							placeholder='Enter Template Description'
							placeholderTextColor='#808080'
							value={value}
							onChangeText={onChange}
							maxLength={50}
						/>
					)}
				/>
				{errors.templateDescription && (
					<Text style={styles.errorText}>
						{errors.templateDescription.message}
					</Text>
				)}
			</View>
		</CommonModalUI>
	);
}

const styles = StyleSheet.create({
	titleStyle: {
		alignSelf: 'flex-start',
		fontSize: commonSizes.textSizeL1,
	},
	input: {
		height: commonSizes.textBoxHeight_L,
		borderColor: commonColors.textBoxBorderColor,
		borderWidth: commonSizes.textBoXBorderWidthXS,
		borderRadius: commonSizes.cornerRadius,
		paddingHorizontal: commonSizes.paddingM_Percent,
		color: commonColors.textColor_Black,
		fontSize: commonSizes.textSizeM,
	},
	errorInput: {
		borderColor: commonColors.warningColor,
	},
	errorText: {
		color: commonColors.warningColor,
		fontSize: commonSizes.textSizeS,
	},
});
