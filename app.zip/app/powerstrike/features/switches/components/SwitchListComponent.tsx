import {
	View,
	FlatList,
	Text,
	TouchableOpacity,
	Image,
	Dimensions,
} from 'react-native';
import React, { useEffect, useState } from 'react';
import {
	Menu,
	MenuOption,
	MenuOptions,
	MenuTrigger,
	renderers,
} from 'react-native-popup-menu';

import { SwitchListComponentStyles } from '@powerstrike/features/switches/styles/SwitchListComponentStyles';
import { Panel, Switch } from '@powerstrike/features/panels/types/panel';
import { CopySwitchModal } from './CopySwitchModal';
import Image_switch_off from '@powerstrike/features/switches/images/switch_off.png';
import Image_switch_on from '@powerstrike/features/switches/images/switch_on.png';
import Image_switch_disabled from '@powerstrike/features/switches/images/switch_disabled.png';
// import Image_copy from '@powerstrike/features/switches/images/Copy.png';
// import Image_edit from '@powerstrike/features/switches/images/Edit.png';
// import Image_reset from '@powerstrike/features/switches/images/Reset.png';
import EditIcon from '@assets/images/EditIcon.svg';
import CopyIcon from '@assets/images/CopyIcon.svg';
import ResetButton from '@assets/images/ResetButton.svg';
import TripleDotIconGrey from '@assets/images/TripleDotIconGrey.svg';
import { getFontSize } from '@global/dynamicFont';
import { useAppDispatch } from '@global/hooks';
import { updateExistingPanel } from '@powerstrike/features/panels/redux/panelsThunk';
import { useDatabase } from '@global/DatabaseContext';
import { commonSizes } from '@styles/base';

const SwitchListComponent = (props: {
	allSwitchesInfo: Switch[];
	navigation: any;
	panelID: number;
}) => {
	const dispatch = useAppDispatch();
	const { dataSource } = useDatabase();

	const [copySwitchModalVisible, setCopySwitchModalVisible] = useState(false); // Manage modal visibility state
	const [selectedSwitchId, setSelectedSwitchId] = useState(0);

	const openModal = (switchIndex: number) => {
		setSelectedSwitchId(switchIndex);
		setCopySwitchModalVisible(true);
	};
	const closeModal = () => {
		setSelectedSwitchId(0);
		setCopySwitchModalVisible(false);
	};

	const onSubmit = async (switchNumbers: number[]) => {
		console.log('saving switch data...');
		const switchData = props.allSwitchesInfo[selectedSwitchId];
		const updatedPanelSetting = [...props.allSwitchesInfo];
		switchNumbers.forEach(switchNumber => {
			updatedPanelSetting[switchNumber] = {
				...updatedPanelSetting[switchNumber],
				switchSetting: switchData.switchSetting,
				response: switchData.response,
			};
		});
		const updates: Partial<Panel> = {
			panelSetting: updatedPanelSetting,
			updatedAt: new Date().toISOString(),
		};
		const result = await dispatch(
			updateExistingPanel({
				dataSource,
				panelId: props.panelID,
				updates,
			}),
		);
		console.log('...........................', result);
		closeModal();
	};
	const onResetSwitch = async (switchNumber: number) => {
		console.log('saving switch data...');
		const updatedPanelSetting = [...props.allSwitchesInfo];
		updatedPanelSetting[switchNumber] = {
			...updatedPanelSetting[switchNumber],
			switchSetting: switchNumber === 0 ? '0000000000' : '00000000',
			response: {},
		};
		const updates: Partial<Panel> = {
			panelSetting: updatedPanelSetting,
			updatedAt: new Date().toISOString(),
		};
		const result = await dispatch(
			updateExistingPanel({
				dataSource,
				panelId: props.panelID,
				updates,
			}),
		);
		console.log('...........................', result);
		closeModal();
	};
	return (
		<View style={SwitchListComponentStyles.switchListContainer}>
			<FlatList
				data={props.allSwitchesInfo}
				renderItem={({ item, index }) => (
					<SwitchComponent
						singleSwitchInfo={item}
						switchIndex={index}
						panelID={props.panelID}
						navigation={props.navigation}
						openModal={openModal}
						onResetSwitch={onResetSwitch}
					/>
				)}
				keyExtractor={item => item.switchName}
			/>
			{copySwitchModalVisible && (
				<CopySwitchModal
					modalVisible={copySwitchModalVisible}
					selectedSwitchId={selectedSwitchId}
					allSwitchesInfo={props.allSwitchesInfo}
					closeModal={closeModal}
					onSubmit={onSubmit}
				/>
			)}
		</View>
	);
};

const SwitchComponent = (props: {
	singleSwitchInfo: Switch;
	switchIndex: number;
	panelID: number;
	navigation: any;
	openModal: (a1: number) => void;
	onResetSwitch: (a1: number) => void;
}) => {
	return (
		<View style={SwitchListComponentStyles.box}>
			<BitsDisplay
				singleSwitchInfo={props.singleSwitchInfo}
				switchIndex={props.switchIndex}
				panelID={props.panelID}
				navigation={props.navigation}
			/>
			<View style={SwitchListComponentStyles.verticleLine} />
			<PopUpMenu
				singleSwitchInfo={props.singleSwitchInfo}
				switchIndex={props.switchIndex}
				panelID={props.panelID}
				navigation={props.navigation}
				openModal={props.openModal}
				onResetSwitch={props.onResetSwitch}
			/>
		</View>
	);
};

const BitsDisplay = (props: {
	singleSwitchInfo: Switch;
	switchIndex: number;
	panelID: number;
	navigation: any;
}) => {
	const [fontSizes, setFontSizes] = useState({
		switchNameSize: getFontSize(16),
		switchDescriptionSize: getFontSize(16),
		configureTextSize: getFontSize(16),
		onTextSize: getFontSize(15),
		bitLabelSize: getFontSize(15),
		// Add other font sizes as needed
	});
	useEffect(() => {
		const handleDimensionsChange = () => {
			setFontSizes({
				switchNameSize: getFontSize(16),
				switchDescriptionSize: getFontSize(16),
				configureTextSize: getFontSize(16),
				onTextSize: getFontSize(15),
				bitLabelSize: getFontSize(15),
				// Update other font sizes as needed
			});
		};

		const subscription = Dimensions.addEventListener(
			'change',
			handleDimensionsChange,
		);

		return () => {
			subscription?.remove();
		};
	}, []);
	return (
		<View style={SwitchListComponentStyles.switchInfo}>
			<View style={SwitchListComponentStyles.switchFirstRow}>
				<Text
					style={[
						SwitchListComponentStyles.switchName,
						{ fontSize: fontSizes.switchNameSize },
					]}>
					{props.singleSwitchInfo.switchName} -{' '}
					<Text
						style={[
							SwitchListComponentStyles.switchDescription,
							{ fontSize: fontSizes.switchDescriptionSize },
						]}>
						{props.singleSwitchInfo.switchDescription}
					</Text>
				</Text>
				<Text
					style={[
						SwitchListComponentStyles.configureText,
						{ fontSize: fontSizes.configureTextSize },
					]}
					onPress={() =>
						ConfigureSwitch({
							switchIndex: props.switchIndex,
							switchName: props.singleSwitchInfo.switchName,
							panelID: props.panelID,
							navigation: props.navigation,
						})
					}>
					CONFIGURE
				</Text>
			</View>
			<TouchableOpacity
				style={SwitchListComponentStyles.switchSecondRow}
				onPress={() =>
					ConfigureSwitch({
						switchIndex: props.switchIndex,
						switchName: props.singleSwitchInfo.switchName,
						panelID: props.panelID,
						navigation: props.navigation,
					})
				}>
				<Text
					style={[
						SwitchListComponentStyles.onText,
						{ fontSize: fontSizes.onTextSize },
					]}>
					ON
				</Text>
				<View style={[SwitchListComponentStyles.bitsRow]}>
					{props.singleSwitchInfo.switchSetting
						.split('')
						.map((bit: string, index: number) => (
							<View key={index} style={SwitchListComponentStyles.bitWrapper}>
								<Image
									source={
										bit === '1'
											? Image_switch_off
											: bit === '2'
											? Image_switch_on
											: Image_switch_disabled
									}
									style={SwitchListComponentStyles.bitImage}
								/>
								<Text
									style={[
										SwitchListComponentStyles.bitLabel,
										{ fontSize: fontSizes.bitLabelSize },
									]}>
									{index + 1}
								</Text>
							</View>
						))}
				</View>
			</TouchableOpacity>
		</View>
	);
};

const PopUpMenu = (props: {
	singleSwitchInfo: Switch;
	switchIndex: number;
	panelID: number;
	navigation: any;
	openModal: (a1: number) => void;
	onResetSwitch: (a1: number) => void;
}) => {
	return (
		<Menu renderer={renderers.Popover}>
			<MenuTrigger testID='menuTrigger'>
				<View style={SwitchListComponentStyles.tripleDotMenuArea}>
					<TripleDotIconGrey
						width={commonSizes.iconWidthM_Pixel}
						height={commonSizes.iconHeightM_Pixel}
					/>
				</View>
			</MenuTrigger>
			<MenuOptions>
				<View>
					<PopUpMenuOptions
						text='Edit'
						iconName={EditIcon}
						singleSwitchInfo={props.singleSwitchInfo}
						switchIndex={props.switchIndex}
						panelID={props.panelID}
						navigation={props.navigation}
					/>
					{props.switchIndex !== 0 && (
						<PopUpMenuOptions
							text='Copy to'
							iconName={CopyIcon}
							singleSwitchInfo={props.singleSwitchInfo}
							switchIndex={props.switchIndex}
							panelID={props.panelID}
							navigation={props.navigation}
							openModal={props.openModal}
						/>
					)}
					{(props.singleSwitchInfo.switchSetting.includes('1') ||
						props.singleSwitchInfo.switchSetting.includes('2')) && (
						<PopUpMenuOptions
							text='Reset'
							iconName={ResetButton}
							singleSwitchInfo={props.singleSwitchInfo}
							switchIndex={props.switchIndex}
							panelID={props.panelID}
							navigation={props.navigation}
							onResetSwitch={props.onResetSwitch}
						/>
					)}
				</View>
			</MenuOptions>
		</Menu>
	);
};

const PopUpMenuOptions = (props: {
	singleSwitchInfo: Switch;
	switchIndex: number;
	panelID: number;
	navigation: any;
	text: string;
	// iconName: ImageSourcePropType;
	iconName: React.ComponentType<{ width: number; height: number }>;
	openModal?: (a1: number) => void;
	onResetSwitch?: (a1: number) => void;
}) => {
	return (
		<MenuOption
			style={SwitchListComponentStyles.popUp}
			onSelect={() => {
				switch (props.text) {
					case 'Edit':
						ConfigureSwitch({
							switchIndex: props.switchIndex,
							switchName: props.singleSwitchInfo.switchName,
							panelID: props.panelID,
							navigation: props.navigation,
						});
						break;
					case 'Copy to':
						if (props.openModal) {
							CopyTo({
								switchIndex: props.switchIndex,
								openModal: props.openModal,
							});
						}
						break;
					case 'Reset':
						if (props.onResetSwitch) {
							ResetSwitch({
								switchIndex: props.switchIndex,
								onResetSwitch: props.onResetSwitch,
							});
						}
						break;
					default:
						break;
				}
			}}>
			<props.iconName
				width={commonSizes.iconWidthL_Pixel}
				height={commonSizes.iconHeightL_Pixel}
			/>
			<Text style={SwitchListComponentStyles.popUpText}>{props.text}</Text>
		</MenuOption>
	);
};

const ConfigureSwitch = (props: {
	switchIndex: number;
	switchName: string;
	panelID: number;
	navigation: any;
}) => {
	props.navigation.navigate('FormIndex', {
		switchNumber: props.switchIndex,
		switchName: props.switchName,
		panelId: props.panelID,
	});
};

const CopyTo = (props: {
	switchIndex: number;
	openModal: (a1: number) => void;
}) => {
	props.openModal(props.switchIndex);
};

const ResetSwitch = (props: {
	switchIndex: number;
	onResetSwitch: (a1: number) => void;
}) => {
	props.onResetSwitch(props.switchIndex);
};

export { SwitchListComponent };
