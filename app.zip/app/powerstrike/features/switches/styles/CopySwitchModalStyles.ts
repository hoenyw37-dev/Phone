import { StyleSheet } from 'react-native';
import { commonColors, commonSizes, commonStyles } from '@styles/base';

const CopySwitchModalStyles = StyleSheet.create({
	titleStyle: {
		alignSelf: 'flex-start',
		fontSize: commonSizes.textSizeL1,
	},
	picker: {
		...commonStyles.picker,
	},
	pickerItems: {
		...commonStyles.pickerItems,
		fontSize: commonSizes.textSizeM,
		backgroundColor: commonColors.backgroundColor_White,
	},
});

export { CopySwitchModalStyles };
