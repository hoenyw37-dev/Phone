import { commonColors, commonSizes, commonStyles } from '@styles/base';
import { StyleSheet } from 'react-native';

const SwitchListComponentStyles = StyleSheet.create({
	switchListContainer: {
		flex: 1,
	},
	box: {
		flex: 1,
		...commonStyles.box,
	},
	switchInfo: {
		flex: 1,
	},
	switchFirstRow: {
		flexDirection: 'row',
		flexWrap: 'wrap',
		flex: 1,
		marginTop: commonSizes.heightS_Pixel,
		marginLeft: commonSizes.widthM_Pixel,
		justifyContent: 'space-between',
	},
	switchName: {
		fontWeight: '900',
		color: commonColors.textColor_Black,
	},
	switchDescription: {
		fontWeight: 'normal',
		color: commonColors.textColor_Black,
	},
	configureText: {
		fontWeight: '900',
		color: commonColors.textColor_Blue,
	},
	switchSecondRow: {
		backgroundColor: commonColors.switchColor,
		borderRadius: commonSizes.cornerRadius,
		position: 'relative',
		marginLeft: commonSizes.widthM_Pixel,
		marginBottom: commonSizes.heightS_Pixel,
	},
	onText: {
		textAlign: 'left',
		color: 'white',
		fontWeight: 'bold',
		marginLeft: '1%',
	},
	bitsRow: {
		flexDirection: 'row',
		marginBottom: commonSizes.heightXS_Pixel,
	},
	bitWrapper: {
		alignItems: 'center',
		flex: 1,
	},
	bitImage: {
		height: commonSizes.iconHeightL_Pixel,
		resizeMode: 'contain',
	},
	bitLabel: {
		color: 'white',
	},
	verticleLine: {
		...commonStyles.verticalLine,
		marginLeft: '2%',
	},
	tripleDotMenuArea: {
		...commonStyles.boxClickableMenu,
		marginHorizontal: commonSizes.widthS_Pixel,
	},
	popUp: { ...commonStyles.boxMenuPopUp },
	popUpText: { ...commonStyles.boxMenuText },
});

export { SwitchListComponentStyles };
