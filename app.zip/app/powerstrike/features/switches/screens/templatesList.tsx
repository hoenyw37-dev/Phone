﻿import React, { useCallback, useEffect, useState } from 'react';
import {
	View,
	Text,
	StyleSheet,
	TouchableOpacity,
	ScrollView,
} from 'react-native';
import { useAppDispatch, useAppSelector } from '../../../../../global/hooks';
import { useDatabase } from '../../../../../global/DatabaseContext';
import initializeTemplates from '../dataAccess/initializeTemplates';
import { fetchTemplates, deleteTemplateWithId } from '../redux/templatesThunk';
import { Template } from '../types/template';
import { Panel, Switch } from '../../panels/types/panel';
import { selectTemplatesByTypeAndPanelType } from '../redux/templatesSlice';
import { addNewPanel } from '../../panels/redux/panelsThunk';
import { RadioButton } from '@components/RadioButton';
import DoubleButtonFooter from '@components/doubleButtonFooter';
import DeleteIconBlue from '@assets/images/DeleteIconBlue.svg';
import InfoCard from '@components/InfoCard';
import ConfirmationModal from '@components/confirmationModal';
import { commonColors, commonSizes } from '@styles/base';
import Toast from 'react-native-toast-message';
import { SafeAreaView } from 'react-native-safe-area-context';
import LeftArrowWhite from '@assets/images/LeftArrowWhite.svg';

export default function TemplatesList({ route, navigation }: any) {
	const dispatch = useAppDispatch();
	const { dataSource } = useDatabase();

	const { projectId, panelName, panelType, allowUse } = route.params;

	const [selectedValue, setSelectedValue] = useState('');
	const [confirmationModal, setConfirmationModal] = useState(false);
	const [confirmationId, setConfirmationId] = useState(-1);
	const [confirmationName, setConfirmationName] = useState('');

	const handleOptionChange = (val: any) => {
		setSelectedValue(val);
	};

	const standardTemplates = useAppSelector(state =>
		selectTemplatesByTypeAndPanelType(state, 'standard', panelType),
	);
	const customTemplates = useAppSelector(state =>
		selectTemplatesByTypeAndPanelType(state, 'custom', panelType),
	);

	const handleBackButtonPress = () => {
		navigation.goBack();
	};

	const loadData = useCallback(async () => {
		try {
			console.log('!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!');
			if (standardTemplates?.length === 0) {
				console.log('checking and initializing standard templates!');
				await initializeTemplates(dataSource);
			}
			await dispatch(fetchTemplates(dataSource));
		} catch (error) {
			console.error('Error while fetching projects:', error);
		}
	}, [dataSource, dispatch, standardTemplates?.length]);

	useEffect(() => {
		if (dataSource) {
			loadData(); // Call loadData when the component mounts
		}
	}, [loadData, dataSource]);

	const onTemplatePress = async (templateSetting: Switch[]) => {
		console.log('loading template data into panel...');
		const panel: Panel = {
			projectId,
			panelId: 0,
			panelName,
			panelType,
			panelSetting: templateSetting,
			updatedAt: new Date().toISOString(),
		};
		const resultAction = await dispatch(addNewPanel({ dataSource, panel }));
		console.log('result :', resultAction);
		if (addNewPanel.fulfilled.match(resultAction)) {
			const newPanel = resultAction.payload;
			navigation.navigate('SwitchesList', { panelId: newPanel.panelId });
		} else {
			console.error('Failed to add the panel:', resultAction.error);
		}
	};

	const onTemplateLoad = async () => {
		console.log('loading template...', selectedValue);
		const template =
			standardTemplates.find(
				template => template.templateId === Number(selectedValue),
			) ||
			customTemplates.find(
				template => template.templateId === Number(selectedValue),
			);
		if (template) {
			console.log('template found...', template);
			await onTemplatePress(template.templateSetting);
		}
	};

	const handleDeleteRequest = (templateId: number, templateName: string) => {
		setConfirmationId(templateId);
		setConfirmationModal(true);
		setConfirmationName(templateName);
	};

	const confirmDelete = () => {
		if (confirmationId === -1) {
			console.log('No template selected for deletion');
			return;
		} else {
			setConfirmationModal(false);
			onTemplateDelete(confirmationId);
		}
	};

	const cancelDelete = () => {
		setConfirmationModal(false);
		setConfirmationId(-1);
		setConfirmationName('');
	};

	const onTemplateDelete = async (templateId: number) => {
		console.log('deleting template...', templateId);

		const resultAction = await dispatch(
			deleteTemplateWithId({ dataSource, templateId }),
		);

		if (deleteTemplateWithId.fulfilled.match(resultAction)) {
			Toast.show({
				type: 'success',
				text1: 'Template deleted successfully',
				visibilityTime: 2500,
			});
		} else {
			console.error('Failed to delete the template:', resultAction.error);
			Toast.show({
				type: 'error',
				text1: 'Failed to delete the template',
				visibilityTime: 2500,
			});
		}
	};
	const renderStandardTemplate = (template: Template) => (
		<TouchableOpacity
			activeOpacity={1}
			key={template.templateId}
			onPress={() => handleOptionChange(template.templateId.toString())}>
			<View style={styles.templateItem}>
				{allowUse && (
					<RadioButton
						key={template.templateId}
						option={template}
						isSelected={selectedValue === template.templateId.toString()}
						onOptionChange={() =>
							handleOptionChange(template.templateId.toString())
						}
					/>
				)}
				<View>
					<Text style={styles.templateName}>
						{template.templateName}
						{!allowUse ? ' - ' + template.templatePanelType : null}
					</Text>
					{template.templateDescription && (
						<Text style={styles.templateDescription}>
							{template.templateDescription}
						</Text>
					)}
				</View>
			</View>
		</TouchableOpacity>
	);

	const renderCustomTemplate = (template: Template) => (
		<TouchableOpacity
			activeOpacity={1}
			key={template.templateId}
			onPress={() => handleOptionChange(template.templateId.toString())}>
			<View style={styles.templateItem}>
				{allowUse && (
					<RadioButton
						key={template.templateId}
						option={template}
						isSelected={selectedValue === template.templateId.toString()}
						onOptionChange={() =>
							handleOptionChange(template.templateId.toString())
						}
					/>
				)}
				<View>
					<Text style={styles.templateName}>
						{template.templateName}
						{!allowUse ? ' - ' + template.templatePanelType : null}
					</Text>
					{template.templateDescription && (
						<Text style={styles.templateDescription}>
							{template.templateDescription}
						</Text>
					)}
				</View>
				{!allowUse && (
					<View style={styles.delete}>
						<TouchableOpacity
							onPress={() =>
								handleDeleteRequest(template.templateId, template.templateName)
							}>
							<DeleteIconBlue
								width={commonSizes.iconHeightL_Pixel}
								height={commonSizes.iconWidthL_Pixel}
							/>
						</TouchableOpacity>
					</View>
				)}
			</View>
		</TouchableOpacity>
	);

	const renderSection = (
		title: string,
		data: Template[],
		renderItem: (template: Template) => JSX.Element,
	) => (
		<View style={styles.section}>
			<Text style={styles.sectionTitle}>{title}</Text>
			{data.length > 0 ? (
				data.map((item, index) => (
					<View
						key={index}
						style={
							index === data.length - 1
								? styles.lastRadioItem
								: styles.radioItemSeparatorLine
						}>
						{renderItem(item)}
					</View>
				))
			) : (
				<Text style={styles.noTemplateText}>No templates available</Text>
			)}
		</View>
	);

	const msg: string = 'Select a Template for Panel ' + panelType;

	return (
		<View style={styles.mainContainer}>
			<SafeAreaView edges={['top']} style={styles.safeHeader}>
				<View
					style={[
						styles.headerSection,
						{
							backgroundColor: '#000',
							alignItems: 'center',
						},
					]}>
					<View
						style={{
							flexDirection: 'row',
							alignItems: 'center',
							paddingHorizontal: 10,
							height: '100%',
						}}>
						<TouchableOpacity
							onPress={() => handleBackButtonPress()}
							style={{
								height: '100%',
								padding: 0,
								margin: 0,
								justifyContent: 'center',
							}}>
							<LeftArrowWhite height={30} width={30} />
						</TouchableOpacity>
						<View style={[{ flex: 2 }]}>
							<Text
								style={{
									color: '#fff',
									fontSize: 18,
									fontWeight: 'bold',
									textAlign: 'center',
								}}>
								Templates
							</Text>
						</View>
					</View>
				</View>
			</SafeAreaView>
			<View style={styles.contentSection}>
				<ConfirmationModal
					visible={confirmationModal}
					onClose={cancelDelete}
					onProceed={confirmDelete}
					title='Delete Template'
					description={
						"Are you sure you want to delete '" + confirmationName + "'?"
					}
					leftButtonText='CANCEL'
					rightButtonText='DELETE'
				/>
				{allowUse && <InfoCard description={msg} />}
				<ScrollView contentContainerStyle={styles.container}>
					{renderSection(
						'Standard Templates',
						standardTemplates,
						renderStandardTemplate,
					)}
					{renderSection(
						'Custom Templates',
						customTemplates,
						renderCustomTemplate,
					)}
				</ScrollView>
				{allowUse && (
					<DoubleButtonFooter
						leftButtonText='BACK'
						rightButtonText={'DONE'}
						onLeftButtonPress={() => {
							navigation.goBack();
						}}
						onRightButtonPress={onTemplateLoad}
						rightButtonDisabled={selectedValue === ''}
						containerStyle={{
							paddingHorizontal: commonSizes.paddingM_Percent,
						}}
					/>
				)}
			</View>
		</View>
	);
}

const styles = StyleSheet.create({
	mainContainer: {
		flex: 1,
		backgroundColor: '#f5f5f5',
	},
	safeHeader: {
		backgroundColor: '#000',
	},
	headerSection: {
		backgroundColor: '#000',
		height: 56,
		width: '100%',
	},
	contentSection: {
		flex: 1,
		width: '100%',
	},
	container: {
		padding: commonSizes.paddingM_Percent,
	},
	section: {
		backgroundColor: commonColors.backgroundColor_White,
		marginBottom: commonSizes.heightS_Pixel,
		paddingTop: commonSizes.paddingXL_Percent,
		paddingHorizontal: commonSizes.paddingXL_Percent,
	},
	sectionTitle: {
		fontSize: commonSizes.textSizeL1,
		fontWeight: '500',
		color: commonColors.textColor_Black,
		marginBottom: commonSizes.heightM_Pixel,
	},
	templateItem: {
		flex: 1,
		flexDirection: 'row',
		backgroundColor: commonColors.backgroundColor_White,
		marginVertical: commonSizes.heightM_Pixel,
		marginHorizontal: commonSizes.paddingM_Percent,
	},
	templateName: {
		fontSize: commonSizes.textSizeM,
		fontWeight: '500',
		color: commonColors.textColor_Black,
	},
	templateDescription: {
		fontSize: commonSizes.textSizeS,
		color: commonColors.textColor_Grey,
		marginTop: commonSizes.heightXS_Pixel,
	},
	noTemplateText: {
		marginBottom: commonSizes.heightS_Pixel,
		color: commonColors.textColor_Grey,
		fontSize: commonSizes.textSizeS,
		marginLeft: commonSizes.widthXS_Pixel,
	},
	delete: {
		flex: 1,
		justifyContent: 'center',
		alignItems: 'flex-end',
	},
	radioItemSeparatorLine: {
		borderBottomWidth: commonSizes.lineThicknessS,
		borderBottomColor: commonColors.lineColorLight,
	},
	lastRadioItem: {},
});
