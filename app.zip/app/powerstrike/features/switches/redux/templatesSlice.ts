import {
	createEntityAdapter,
	createSlice,
	createSelector,
	EntityState,
} from '@reduxjs/toolkit';
import { RootState } from '../../../../../global/store';
import { Template } from '../types/template';
import {
	fetchTemplates,
	addNewTemplate,
	fetchTemplatesByProject,
	updateExistingTemplate,
	deleteTemplateWithId,
} from './templatesThunk';

interface TemplatesState extends EntityState<Template, number> {
	status: 'idle' | 'pending' | 'succeeded' | 'rejected';
	error: string | null;
}

const templatesAdapter = createEntityAdapter({
	selectId: (template: Template) => template.templateId,
	sortComparer: (a, b) => a.templateName.localeCompare(b.templateName),
});

const initialState: TemplatesState = templatesAdapter.getInitialState({
	status: 'idle',
	error: null,
});

export const templatesSlice = createSlice({
	name: 'templates',
	initialState,
	reducers: {
		templateAdded: templatesAdapter.addOne,
		templatesReceived(state, action) {
			templatesAdapter.setAll(state, action.payload.books);
		},
		templatesResetStatus(state) {
			state.status = 'idle';
			state.error = null;
		},
	},
	extraReducers: builder => {
		builder
			.addCase(fetchTemplates.fulfilled, (state, action) => {
				state.status = 'succeeded';
				templatesAdapter.setAll(state, action.payload);
				console.log('template fecthing completed');
			})
			.addCase(addNewTemplate.fulfilled, templatesAdapter.addOne)
			.addCase(deleteTemplateWithId.fulfilled, templatesAdapter.removeOne)
			.addCase(updateExistingTemplate.fulfilled, (state, action) => {
				const { templateId, updates } = action.payload;
				templatesAdapter.updateOne(state, {
					id: templateId,
					changes: updates,
				});
			});
		/*.addCase(fetchTemplatesByProject.pending, (state) => {
            state.loading = true;
            state.error = null;
        })
        .addCase(fetchTemplatesByProject.rejected, (state, action) => {
            state.loading = false;
            state.error = action.payload?.error || 'Failed to load templates';
        });*/
	},
});

export const { selectAll: selectAllTemplates, selectById: selectTemplateById } =
	templatesAdapter.getSelectors((state: RootState) => state.templates);

export const selectTemplatesByType = createSelector(
	[
		selectAllTemplates,
		(state: RootState, templateType: string) => templateType,
	],
	(templates, templateType) =>
		templates.filter(template => template.templateType === templateType),
);

export const selectTemplatesByTypeAndPanelType = createSelector(
	[
		selectAllTemplates,
		(state: RootState, templateType: string) => templateType,
		(state: RootState, templateType: string, templatePanelType: string) =>
			templatePanelType,
	],
	(templates: Template[], templateType: string, templatePanelType: string) =>
		templates
			.filter(template => template.templateType === templateType)
			.filter(
				template =>
					templatePanelType === '' ||
					template.templatePanelType === templatePanelType,
			),
);

export const { templatesReceived, templateAdded, templatesResetStatus } =
	templatesSlice.actions;

export const selectTemplatesStatus = (state: RootState) =>
	state.templates.status;
export const selectTemplatesError = (state: RootState) => state.templates.error;

export default templatesSlice.reducer;
