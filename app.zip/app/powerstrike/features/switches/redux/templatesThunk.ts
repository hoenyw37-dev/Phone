import { createAsyncThunk } from '@reduxjs/toolkit';
import {
	getAllTemplates,
	addTemplate,
	updateTemplate,
	deleteTemplate,
} from '../dataAccess/templateRepo';
import { DataSource } from 'typeorm/browser';
import { Template } from '../types/template';

export const fetchTemplates = createAsyncThunk(
	'templates/fetchTemplates',
	async (dataSource: DataSource) => {
		//console.log('fetching thunks...', dataSource);
		const result = await getAllTemplates(dataSource);
		console.log('fetched templates');
		console.log(result);
		return result;
	},
);

export const addNewTemplate = createAsyncThunk(
	'templates/addNewTemplate',
	async ({
		dataSource,
		template,
	}: {
		dataSource: DataSource;
		template: Template;
	}) => {
		console.log('adding new template', template);
		const result = await addTemplate(dataSource, template);
		console.log('added templates..........');
		console.log(result);
		return result;
	},
);

export const updateExistingTemplate = createAsyncThunk(
	'templates/updateExistingTemplate',
	async ({
		dataSource,
		templateId,
		updates,
	}: {
		dataSource: DataSource;
		templateId: number;
		updates: Partial<Template>;
	}) => {
		console.log('updating template updates', templateId, updates);
		const result = await updateTemplate(dataSource, templateId, updates);
		if (result) {
			return { templateId, updates };
		} else {
			throw new Error(`Failed to update template with ID: ${templateId}`);
		}
	},
);

export const deleteTemplateWithId = createAsyncThunk(
	'templates/deleteTemplateWithId',
	async ({
		dataSource,
		templateId,
	}: {
		dataSource: DataSource;
		templateId: number;
	}) => {
		const deleteResult = await deleteTemplate(dataSource, templateId);
		if (deleteResult.success) {
			return templateId;
		} else {
			throw new Error(`Failed to delete project with ID: ${templateId}`);
		}
	},
);
