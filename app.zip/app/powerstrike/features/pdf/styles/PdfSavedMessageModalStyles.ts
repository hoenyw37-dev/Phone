import { StyleSheet } from 'react-native';
import { commonColors, commonSizes } from '@styles/base';

const PdfSavedMessageModalStyles = StyleSheet.create({
	titleStyle: {
		alignSelf: 'center',
		fontSize: commonSizes.textSizeL1,
	},
	pdfSavedModalContent: {
		marginVertical: '5%',
		textAlign: 'center',
		color: commonColors.textColor_Black,
		fontSize: commonSizes.textSizeM,
	},
});

export { PdfSavedMessageModalStyles };
