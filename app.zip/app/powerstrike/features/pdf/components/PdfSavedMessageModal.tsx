import React from 'react';
import { Text, PermissionsAndroid, Platform } from 'react-native';
import { PdfSavedMessageModalStyles } from '@powerstrike/features/pdf/styles/PdfSavedMessageModalStyles';
import DeviceInfo from 'react-native-device-info';
import FileViewer from 'react-native-file-viewer';
import CommonModalUI from '@components/CommonModalUI';
import RNFS from 'react-native-fs';

const PdfSavedMessageModal = (props: {
	path: string;
	modalVisible: boolean;
	closeModal: () => void;
	navigation: any;
}) => {
	const showPDF = async () => {
		props.closeModal();
		// props.navigation.navigate('ShowPDF', { filePath: props.path });
		if (Platform.OS === 'android') {
			let deviceVersion = DeviceInfo.getSystemVersion();
			console.log('Permission denied. PERMISSION is : ', deviceVersion);
			let granted = PermissionsAndroid.RESULTS.DENIED;
			if (Number(deviceVersion) >= 13) {
				granted = PermissionsAndroid.RESULTS.GRANTED;
			} else {
				granted = await PermissionsAndroid.request(
					PermissionsAndroid.PERMISSIONS.READ_EXTERNAL_STORAGE,
				);
			}
			if (granted === PermissionsAndroid.RESULTS.GRANTED) {
				FileViewer.open(props.path, { showOpenWithDialog: true })
					.then(() => {
						// something useful here
					})
					.catch(err => {
						console.log('err: ', err);
					});
			} else {
				console.log('Permission denied. PERMISSION is : ', granted);
			}
		} else if (Platform.OS === 'ios') {
			const filePath = 'file://' + props.path;
			console.log('ios filepath: ', filePath);
			FileViewer.open(filePath)
				.then(() => {
					console.log('File opened in iOS');
				})
				.catch(err => {
					console.log('Error opening file: ', err);
				});
		}
	};
	return (
		<CommonModalUI
			modalVisible={props.modalVisible}
			closeModal={props.closeModal}
			leftButtonText='Close'
			rightButtonText='Open PDF'
			onLeftButtonPress={props.closeModal}
			onRightButtonPress={showPDF}
			titleText='PDF SAVED'
			titleTextExtraStyle={PdfSavedMessageModalStyles.titleStyle}>
			<Text style={PdfSavedMessageModalStyles.pdfSavedModalContent}>
				PDF has been saved to {props.path}
			</Text>
		</CommonModalUI>
	);
};

export { PdfSavedMessageModal };
