import RNHTMLtoPDF from 'react-native-html-to-pdf';
import { Panel } from '@powerstrike/features/panels/types/panel';
import { Project } from '@base/projects/types/project';
import RNFS from 'react-native-fs';
import { Alert } from 'react-native';

// Main component to generate and print PDF
const generatePDF = async (props: {
	panelData?: Panel;
	projectData?: Project;
	getData: (data: string, flag: boolean) => void;
}) => {
	try {
		console.log('props.getData : ', props.getData);
		// Generate the HTML content
		const htmlContent = generateHTMLContent({
			panelData: props.panelData,
			projectData: props.projectData,
		});

		const sanitizeFileName = (name: string) => {
			return name.replace(/[^a-zA-Z0-9-_]/g, '_'); // Replace invalid characters with '_'
		};
		// Construct the PDF file name based on project name and panel name
		const projectName = sanitizeFileName(
			props.projectData?.projectName || 'UnknownProject',
		);
		const panelName = sanitizeFileName(
			props.panelData?.panelName || 'UnknownPanel',
		);
		// const fileName = `${projectName}_${panelName}.pdf`; // Adjust this as needed for formatting
		// const fileName = `${projectName}_${panelName}_${Date.now()}.pdf`; // Adjust this as needed for formatting

		var date = new Date().getDate(); //Current Date
		var month = new Date().getMonth() + 1; //Current Month
		var year = new Date().getFullYear(); //Current Year
		var hours = new Date().getHours(); //Current Hours
		var min = new Date().getMinutes(); //Current Minutes
		var sec = new Date().getSeconds(); //Current Seconds
		// var miliSec = new Date().getMilliseconds(); //Current miliSeconds
		var dateTime =
			date + '_' + month + '_' + year + '_' + hours + '_' + min + '_' + sec; // + '_' + miliSec;
		const fileName = `${projectName}_${panelName}_${dateTime}.pdf`; // Adjust this as needed for formatting

		// Define the path for the file in the download directory
		const downloadDir = RNFS.DocumentDirectoryPath;
		const filePath = `${downloadDir}/${fileName}`;

		// Create the PDF using RNHTMLtoPDF
		let options = {
			html: htmlContent,
			fileName: fileName,
			base64: true,
		};

		const pdf = await RNHTMLtoPDF.convert(options);

		// Save the PDF file to the download directory
		await RNFS.writeFile(filePath, pdf.base64, 'base64');

		const sendDataToParent = () => {
			props.getData(filePath, true);
		};

		// Verify if the file exists after writing
		const fileExists = await RNFS.exists(filePath);
		if (fileExists) {
			// Show a notification if the file was saved successfully
			//Alert.alert('PDF saved', `PDF has been saved in ${filePath}`);
			sendDataToParent();
			console.log('props.getData : ', props.getData);
		} else {
			console.error('Failed to save PDF. File not found at', filePath);
			Alert.alert('Failed to save PDF at', filePath);
		}
	} catch (error) {
		console.error('Error generating PDF: ', error);
		Alert.alert('Error generating PDF: ', error);
	}
};

// Convert the image to base64 format (replace with your actual base64 string)
const imageBase64 =
	'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAANwAAAASCAYAAAAwuLBFAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAp9SURBVHgB7VtLchtHEs0sALJ3BqSJiZiVWzFixOwEnkDQCUSdgOQJSC1lmWRBNKWlqBMQOoHBExC8wBDcTVhSCFzNYuwBtBubQOe8rP5VN5okQNkyafNFNNFd36zqysqXWU0eNhc+kIcJhU/+0n/f1fsfm39fqpB55ec3+m/v0g0uxLD5jwCzeZClhL1G//1qfr5l0Oi/e0hzwLa/OyAO39jNzc7MdexOE3WWiunCPOJQ+tZu9OgGF8K2ty3JZNdaO6JLwhBTkLuI6l52vST/BrPCmzdhc7eYRswBfQ4YauLPcjGZRepkKnu2vfMBiyigPyjmHRvK1+3zne+tfb6Sy2CzRTn9mB9VusGfA0wndnPDluRYKNwu8a093M9lba8DrH0ZkAmVVTDNhwaqXNqSnYVPVrhhM6hPqNJy1hAQ0KQqjfuN/iAn7L+bQeA//60/GPh1Q6L+X/tv+2V9aN0a1VrRUzgKyQz8smVtn9e34kuikS+jX8bPUxn/h12tmDamapOJg/PGfG0gZheL8ohu4BBTxhb9BvgkhRs2722BFq1XIjMbLzbGfQ3KdK8D/6QdlYM/wxPfVxz81Lz3GnW34rpUceUWUOftata++kHjPZRr6bMQHTOZ+67s4sKA5PQhFvngC77VY5Kvk3pou32n/84W+h7gCjwZVGEXozIL8HEoW3ASdvDXyTGh2tKXTHtI0+cO2l5XuavpmN0uiHZrOh82GfN1grVPB6BQdaVeuAZZ+nYL89JyDyID9UOTfKVdZGpLdvNZZ7q97VaZX4g+Vvzy2oaY6opS28ifHHf9/lMZaDLQdHdvTJBvY3sJMjYjGUn90a6fJ2YSYGN0fbvEMBwlZeK2+6pg0T3VvTz4vJPeLP6aazs87fpl83OXyWXoksAifYWFZylaeLr4F0kquoCjBYg8p5DlqBssWiE+xIIdpKlMK25BU6Io4UGibPht3z5628SLT2gP8mtHqiwSKUgKtL2W3Ic0XqFo0I8p3RQcmsPYqoUkrZx0bNIAgyGJ7yc9HQ/afuWPuXH0g/pmvVhG6+blmsHRLvebKNPLADTzCBOJzcUM4gsLqHbQbn+3HJcdiftxC9VryynFQWm60Jr3vETm1hELNmhDEVsxt9D+Tn7NMK+gvZZLNwZBi+xdRTKaR04+bYN5KfZHIz/LmDraD9y9hIFeYuLnrO0lKMyea1vHGEMMrH6l0qSL5k7rCjUTZXP+nwa2DHzmErmmLFyFzR6sx955nWj0EsqxngpHcnw7pnGoq5PXigekSgelctYlDyxWrfNjc2GlohYkBhb4ff0NaWKNb5FCcTsELEgPfejg6u5iemVkDGWq+S+qjn5bWtawWRYK92/33/Vzsrk+qqpMu+jnUUG6tD4zPyBnDUEqeWLLxhyKHJp0Y6B11N0vHfMVhchkid3mF8ONk/ft5rfWK9ZRpcFCRDDB7usCY93omHQOe1ldLGLhXlm6sLzR28ivklcU/vIwb1FfdsXIEdJe5yyLVNag3JDnWSsr6yzIR6StejJ27fb2kt2IFz8soeuLwzW7Veq/ou3qsnC43978dpXmhG4CAtNst75Zz8ZZ3cWfQ/Rtc3I5P7myXmLheIDBHepFRKU+FUKbK/6zSFYuFDrx88LUQuSg/tCAzoHhohKcpi8AlvGjl9GKf3u54rCgqswoHbDQbiSb7Of74Efqj6VWtCD3f6B0uK2HEh6mljJpXmToPY6KdekaQHdcXTRcYbgGoU0zmJexIXamy4MmCuNdq99N+iKgWCb/ntg8QJlV/C4X05UyRg9jMJXweJo+PgVrkH2lmYWu63Yrt4BdGvoRKsq4kVHKmQATCGXbpTnhlI3pIZRtJd+ejn967jDers7JlIWbyKSNczhXoWh90jaJvqIZwRr6FpoL8RlWPZ9aOwBdi+8zfy3OQx/SLihOM/YP9ayrpwmGxh2U9SlfS4M2leheN42UQhhdSCKjqB53w8Imo7QT8rSi+3yo+DJj/gy4v/V8Z+AnOBFFehQyLM2G2zQjeql+Tl4ZMoQnCS1TBUSbnPhsdgfnfRM5sfabgW2/6OfSx5K1qT4X87BIO6M8aICEhXcf7k/LMenhzWwprVTLySHD33pWaiDOhYQ9mhNO2YjUb1v00yMqKwE2pABjC3KV4Hvib/AZjgX4k84tEmBSjyUL0x76eWqmC1STKKKbzTjY4aBRRJTpkUcrlUJHHYRQWHef1A+gaMsUt/2Ts5Y5jELOy5HKw+rf0VXDcdujZBfg3ECBO79L7x2tbJEyjDEO10U6mq40jSlJp5ROphCndNOhetAlkilmNSVPTDkXlUJyiH4MKG975ys02NnaejZ74Io1GDQPqkpvl9wmK9jocyzwi7ryG0erixC3IN5cSuGw25/MGm1BQKPPVKF50Oj/a1BQHszLeP32BTQUlPG1BmPyqboT5spk/lYEF21s9N93/9u8t4I1kFEkPbBOlVtfjLc+sDPe6b8/k/dHVvo64ueRYwxnAQtN/PMppZXGbVQWWw3m7vSxKxZWQKEkYUdKJ1Pa5iKSoOnwq9bpExFTyDiy+DKAouuBNazs7F/izAUEQDQ6Dr8SvqHzZxczf9PNHQY4Xj8runmpKCUCG53C89dl99HzZG5+rFDluagMKJ1GKQ+yvsb5vpg6RV/RFH09cgEQp1TYSKb4v4jE4dxqhy6AUnD9dGsY+X7XEm6hMPVL6Z6Dua/0LSu/0cOmxHF4/mMW6Xw6gFW7m7TjU1T9nGzKx0vbUxp68ZchLhqYRCPTNPiATK+xATzIUn9Oo4f0awDR7uiIwh17vCG+9b0n08gFjKg8uqlfrlxK4ZRihTqwBM6fCYIolO9ZD5S5KDhyFiLl8Y4MqJaGlDXQER1LgJaYLLoWHzz30iphgcbEslOBonCsVBU67U7LES0utbp6NJFVisacPGqApaLW1RnB8YCuMwTvFvTaX/jRAn8B/1emfKWIVhr4NdItSd8r0skk+FI8Aogij2a2YxVE/HAOOCUjMh7hrO3QS3NKIDIViLkksuBdEsjJjQMxkDPnjivNS5/D3fnn23VvAdb1jAbh5OTwGLukPGlomUvCKY+Yh3iJkcOs4fbFhaH7+JdrQz2zi/r4weYqSphsBGmwpAhEUguKaPppn3kLiDayL1pcX27MbiPQMX9wFg1yVZkPIOtJchhPVwkcjpIA0CxwB8tMbTLVLs6ZPuilZ2aY748IFDyZqgBaiYhdw7d8Xjpn0Uk/75fHmK+79vmLD1kfes5Gq/mADY+Ugk7JqGF+oWM9u9NzL1xHKiOOgA6n6KTIE66YNfQxdP2lyoB2w/LPt7jkWAeW/KR0HCyPM0u+0Ttr7qCg6zyc/uwp9wkTFT7WLC6myFc5hQnluB31dSa94mdOxX6Sdkr6GE3XdVHLFsLtGsgYRH1En1LF9G0t+uJDF0MtcF+NIFjSiKOtRRT79Md0Xl6+jIbGkzG7vruzjPmseZgVCTWyn/DF+g1+PzBdc8C6qFV1nHkCJcOGWndfmlxFS3ODPz3+UP8tgN2jafTQlvl14+hG2W5w9XBpH+7KQCqPk9A9cwWRMmlP+XU3uMEVwf8BTlp+veEuygkAAAAASUVORK5CYII='; // Your base64 string here

// Function to generate the full HTML content with sections in two columns layout
const generateHTMLContent = (props: {
	panelData?: Panel;
	projectData?: Project;
}) => {
	const switchesAll = props.panelData?.panelSetting || [];
	const switchesAllCount = switchesAll.length; // Count the sections

	let firstColumnHTML = '';
	let secondColumnHTML = '';

	// Generate HTML for each section and split between two columns
	for (let i = 0; i < switchesAllCount; i++) {
		const sectionName = switchesAll[i].switchName; // `S${i + 1}`;
		const sectionTitle = switchesAll[i].switchDescription; //`Output ${sectionCount - i}`; // Customize titles as needed
		const switchSettings = switchesAll[i].switchSetting; //sections.find(switchItem => switchItem.switchName === sectionName)?.switchSetting || 'N/A';

		const sectionHTML = `
      <div style="padding: 10px; margin-bottom: 5px;">
        <h4 style="font-size: 14px; margin: 0;">${sectionName} <span style="font-size: 12px; font-weight: normal;">${sectionTitle}</span></h4>
        <div style="-webkit-print-color-adjust: exact !important; background-color: #E5E4E2  !important; padding: 5px;">
          ${generateSwitchesHTML({ switchValues: switchSettings })}
        </div>
      </div>
    `;

		if (i < 6) {
			firstColumnHTML += sectionHTML;
		} else {
			secondColumnHTML += sectionHTML;
		}
	}

	// Insert dynamically generated sections into the main HTML template with the original column alignment
	return `
    <html>
      <body style="font-family: Arial, sans-serif; padding: 20px;">
        <!-- Include the image at the top left -->
        <div style="margin-bottom: 20px;">
          <img src="${imageBase64}" alt="Honeywell Powerstrike" style="width: 300px; height: auto;">
        </div>

        <!-- Flexbox container to create two columns for options -->
        <div style="display: flex; justify-content: space-between; margin-bottom: 20px;">
          <!-- First Column for customer information -->
          <div style="width: 45%;">
            <div style="margin-bottom: 15px;">
              <strong>Project Name:</strong> ${
								props.projectData?.projectName || 'N/A'
							}
            </div>
            <div style="margin-bottom: 15px;">
              <strong>Panel Name:</strong> ${
								props.panelData?.panelName || 'N/A'
							}
            </div>
            <div style="margin-bottom: 15px;">
              <strong>Pane Type:</strong> ${props.panelData?.panelType || 'N/A'}
            </div>
          </div>

          <!-- Second Column for project information -->
          <div style="width: 45%;">
            <div style="margin-bottom: 15px;">
              <strong>Site:</strong> ${props.projectData?.site || 'N/A'}
            </div>
            <div style="margin-bottom: 15px;">
              <strong>Building:</strong> ${props.projectData?.building || 'N/A'}
            </div>
          </div>
        </div>

        <!-- Flexbox container for sections in two columns -->
        <div style="display: flex; justify-content: space-between;">
          <!-- First Column for up to 6 sections -->
          <div style="width: 45%;">
            ${firstColumnHTML}
          </div>

          <!-- Second Column for remaining sections -->
          <div style="width: 45%;">
            ${secondColumnHTML}
          </div>
        </div>
      </body>
    </html>
  `;
};

// Function to generate the HTML for switches with "ON" label inside the container
const generateSwitchesHTML = (props: { switchValues?: string }) => {
	if (!props.switchValues) {
		console.warn('panelData or projectData is missing. Stopping execution.');
		return; // Stop further execution
	}
	const switchValueArray = props.switchValues?.split('');
	const switchWidth = '15px'; // Set a fixed pixel width for each switch
	return `
    <div style="display: flex; flex-direction: column; align-items: flex-start;">
      <!-- "ON" label inside the switch container, left-aligned above switches -->
      <div style="font-weight: bold; margin-bottom: 5px; align-self: flex-start;">ON</div>
      <div style="display: flex; justify-content: space-evenly; width: 100%;">
        ${switchValueArray
					?.map((val, index) => {
						const color = val === '2' ? 'green' : val === '1' ? 'red' : 'grey';
						return `
              <div style="text-align: center; display: inline-block; width: ${switchWidth};">
                <div style="width: 100%; height: 25px; background-color: white; position: relative; border: 0.001px solid black;">
                  <div style="width: 100%; height: 50%; background-color: ${color}; position: absolute; ${
							val === '2' ? 'top: 0;' : 'bottom: 0;'
						}"></div>
                </div>
                <div style="font-size: 15px; margin-top: 3px;">${
									index + 1
								}</div>
              </div>`;
					})
					.join('')}
      </div>
    </div>`;
};

export { generatePDF };
