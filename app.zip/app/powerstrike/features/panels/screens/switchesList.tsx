import React, { useState, useEffect, useMemo } from 'react';
import {
	View,
	BackHandler,
	StyleSheet,
	TouchableOpacity,
	Text,
} from 'react-native';
import { useSelector } from 'react-redux';
import Toast from 'react-native-toast-message';
import { useAppDispatch } from '../../../../../global/hooks';
import { useDatabase } from '../../../../../global/DatabaseContext';
import { selectPanelById } from '../redux/panelsSlice';
import { Panel } from '../types/panel';
import { AppStore } from '../../../../../global/store';
import { SwitchListComponent } from '../../switches/components/SwitchListComponent';
import DoubleButtonFooter from '../../../../../components/doubleButtonFooter';
import AddTemplateModal from '../../switches/components/addTemplateModal';
import { PdfSavedMessageModal } from '@powerstrike/features/pdf/components/PdfSavedMessageModal';
import { Template } from '../../switches/types/template';
import { addNewTemplate } from '../../switches/redux/templatesThunk';
import { HeaderBackButton } from '@react-navigation/elements';
import { generatePDF } from '@powerstrike/features/pdf/components/generatePDF';
import { Project } from '@base/projects/types/project';
import { selectProjectById } from '@base/projects/redux/projectsSlice';
import { CustomActivityIndicator } from '@components/CustomActivityIndicator';
import InfoCard from '@components/InfoCard';
import { commonColors, commonSizes } from '@styles/base';
import { SafeAreaView } from 'react-native-safe-area-context';
import LeftArrowWhite from '@assets/images/LeftArrowWhite.svg';

export default function SwitchesList({ route, navigation }: any) {
	const [isLoading, setIsLoading] = useState(false);
	const [pageTitle, setPageTitle] = useState('');

	const dispatch = useAppDispatch();
	const { dataSource } = useDatabase();

	const { panelId } = route.params;
	const panel: Panel = useSelector((state: AppStore) =>
		selectPanelById(state, panelId),
	);

	const isButtonDisabled = useMemo(() => {
		const regex = /^0+$/;
		const flag = panel.panelSetting.every(sw => regex.test(sw.switchSetting));
		return flag;
	}, [panel]);

	const project: Project = useSelector((state: AppStore) =>
		selectProjectById(state, panel.projectId),
	);

	React.useLayoutEffect(() => {
		setPageTitle(panel.panelName);
	}, [navigation, panel]);

	useEffect(() => {
		// Set custom back button behavior
		navigation.setOptions({
			headerLeft: props => (
				<HeaderBackButton {...props} onPress={handleBackButtonPress} />
			),
		});

		const backHandler = BackHandler.addEventListener(
			'hardwareBackPress',
			handleBackButtonPress,
		);

		// Clean up the hardware back button listener when the component unmounts
		return () => backHandler.remove();
	}, [navigation]);

	const handleBackButtonPress = () => {
		const { routes, index: currentIndex } = navigation.getState();

		const previousRoute = routes[currentIndex - 1];
		console.log(previousRoute);
		if (previousRoute?.name === 'TemplatesList') {
			navigation.pop(2);
		} else {
			navigation.goBack();
		}

		return true;
	};

	const [addDisplayModal, setAddDisplayModal] = useState(false);

	const saveTemplate = () => {
		console.log('saving template...');
		setAddDisplayModal(true);
	};

	const [pdfSavedMessageModalVisiable, setPdfSavedMessageModalVisiable] =
		useState(false);
	const closePdfSavedMessageModal = () => {
		setPdfSavedMessageModalVisiable(false);
	};
	const [pdfSavedPath, setpdfSavedPath] = useState('');
	const handleDataFromChild = (data: string, flag: boolean) => {
		setpdfSavedPath(data);
		setPdfSavedMessageModalVisiable(flag);
	};

	const download = async () => {
		setIsLoading(true); // Start loading indicator
		await generatePDF({
			panelData: panel,
			projectData: project,
			getData: handleDataFromChild,
		});
		console.log('pdfSavedMessageModalVisiable :', pdfSavedMessageModalVisiable);
		setIsLoading(false); // Stop loading indicator
	};

	const handleModalClose = () => {
		setAddDisplayModal(false);
	};

	const handleTemplateSubmit = async ({
		templateName,
		templateDescription,
	}: {
		templateName: string;
		templateDescription: string;
	}) => {
		const template: Template = {
			templateId: 0,
			templateName: templateName,
			templateDescription: templateDescription,
			templateType: 'custom',
			templatePanelType: panel.panelType,
			templateSetting: panel.panelSetting,
		};

		const resultAction = await dispatch(
			addNewTemplate({ dataSource, template }),
		);
		console.log('result :', resultAction);
		if (addNewTemplate.fulfilled.match(resultAction)) {
			//const newPanel = resultAction.payload;
			Toast.show({
				type: 'success',
				text1: 'New template saved successfully',
				visibilityTime: 2500,
			});
			//navigation.navigate('SwitchesList', { panelId: newPanel.panelId });
		} else {
			console.error('Failed to add the panel:', resultAction.error);
			Toast.show({
				type: 'error',
				text1: 'Failed to add new template',
				visibilityTime: 2500,
			});
		}
	};

	return (
		<View style={styles.mainContainer}>
			<SafeAreaView edges={['top']} style={styles.safeHeader}>
				<View
					style={[
						styles.headerSection,
						{
							backgroundColor: '#000',
							alignItems: 'center',
						},
					]}>
					<View
						style={{
							flexDirection: 'row',
							alignItems: 'center',
							paddingHorizontal: 10,
							height: '100%',
						}}>
						<TouchableOpacity
							onPress={() => handleBackButtonPress()}
							style={{
								height: '100%',
								padding: 0,
								margin: 0,
								justifyContent: 'center',
							}}>
							<LeftArrowWhite height={30} width={30} />
						</TouchableOpacity>

						<View style={[{ flex: 2 }]}>
							<Text
								style={{
									color: '#fff',
									fontSize: 18,
									fontWeight: 'bold',
									textAlign: 'center',
								}}>
								{pageTitle}
							</Text>
						</View>
					</View>
				</View>
			</SafeAreaView>
			<View style={{ flex: 1 }}>
				<InfoCard description='Select the PowerStrike DIP Switch for configuration' />
				{pdfSavedMessageModalVisiable && (
					<PdfSavedMessageModal
						path={pdfSavedPath}
						modalVisible={pdfSavedMessageModalVisiable}
						closeModal={closePdfSavedMessageModal}
						navigation={navigation}
					/>
				)}
				{addDisplayModal && (
					<AddTemplateModal
						visible={addDisplayModal}
						onClose={handleModalClose}
						onSubmit={handleTemplateSubmit}
					/>
				)}
				<View style={{ flex: 1 }}>
					<SwitchListComponent
						allSwitchesInfo={panel.panelSetting}
						navigation={navigation}
						panelID={panelId}
					/>
				</View>
				<View
					style={{
						borderTopColor: commonColors.lineColor,
						borderTopWidth: commonSizes.lineThicknessS,
						backgroundColor: commonColors.backgroundColor_White,
					}}>
					<View style={{ marginHorizontal: '2%' }}>
						<DoubleButtonFooter
							leftButtonText='Save As Template'
							rightButtonText='Download'
							onLeftButtonPress={() => saveTemplate()}
							onRightButtonPress={() => download()}
							leftButtonDisabled={isButtonDisabled}
							rightButtonDisabled={isButtonDisabled}
						/>
					</View>
				</View>
				{isLoading && <CustomActivityIndicator />}
			</View>
		</View>
	);
}

const styles = StyleSheet.create({
	//#region Main Content Styles
	mainContainer: {
		flex: 1,
		backgroundColor: '#f5f5f5',
	},
	safeHeader: {
		backgroundColor: '#000',
	},
	headerSection: {
		backgroundColor: '#000',
		height: 56,
		width: '100%',
	},
	contentSection: {
		flex: 1,
		width: '100%',
	},
});
