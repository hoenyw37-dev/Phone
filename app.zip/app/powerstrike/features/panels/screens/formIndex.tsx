import React, { useEffect, useState } from 'react';
import {
	BackHandler,
	StyleSheet,
	Text,
	TouchableOpacity,
	View,
} from 'react-native';
import { useSelector } from 'react-redux';
import { HeaderBackButton } from '@react-navigation/elements';
import { SafeAreaView } from 'react-native-safe-area-context';

import { useAppDispatch } from '../../../../../global/hooks';
import { selectPanelById } from '../redux/panelsSlice';
import { updateExistingPanel } from '../redux/panelsThunk';
import { Switch, Panel } from '../types/panel';
import { formData } from '../../../questionnaire_data';
import Form from '../components/form';
import { useDatabase } from '../../../../../global/DatabaseContext';
import { AppStore } from '@global/store';
import InfoCard from '@components/InfoCard';
import ConfirmationModal from '@components/confirmationModal';
import LeftArrowWhite from '@assets/images/LeftArrowWhite.svg';

export default function FormIndex({ route, navigation }: any) {
	const dispatch = useAppDispatch();
	const { dataSource } = useDatabase();
	const [pageTitle, setPageTitle] = useState('');

	const { switchNumber, switchName, panelId } = route.params;
	const panel: Panel = useSelector((state: AppStore) =>
		selectPanelById(state, panelId),
	);

	const [switchData, setSwitchData] = useState({
		...panel.panelSetting[switchNumber],
	});
	const [confirmationModal, setConfirmationModal] = useState(false);

	React.useLayoutEffect(() => {
		setPageTitle(switchName);
	}, [switchName]);

	useEffect(() => {
		const backHandler = BackHandler.addEventListener(
			'hardwareBackPress',
			handleBackButtonPress,
		);

		// Clean up the hardware back button listener when the component unmounts
		return () => backHandler.remove();
	}, [navigation]);

	const handleBackButtonPress = () => {
		setConfirmationModal(true);
		return true; // Indicate that the back button press has been handled
	};

	const cancelBack = () => {
		setConfirmationModal(false);
	};

	const confirmBack = () => {
		navigation.goBack();
	};

	const [numPages, setNumPages] = useState(() => {
		return formData[0].numPages;
	});

	const handleResponseChange = (
		questionId: string,
		newResponse: string,
		newCode: string,
		totalPages: number,
	) => {
		if (totalPages) {
			setNumPages(totalPages);
		}

		//TODO: Convert this to a more scalable structure if there are more such dynamic signaling questions [With Empty options] in the future
		// This Logic is used only for NAC Master Async option currently (Question id: 66, YES option id: 67, NO option id: 81)
		if (questionId === '66') {
			if (newResponse === '67') {
				// YES option
				setNumPages(2); // Make current page the last page
			} else if (newResponse === '81') {
				// NO option
				setNumPages(formData[0].numPages); // Reset to original number of pages
			}
		}

		console.log('ON RESPONSE CHANGE.....', questionId, newResponse);
		setSwitchData(prevSwitchData => {
			console.log(newCode);
			const updatedSwitchData = {
				...prevSwitchData,
				response: {
					...prevSwitchData.response,
					[questionId]: newResponse,
				},
			};
			if (newCode) {
				let updatedBits = '';
				for (let i = 0; i < newCode.length; i++) {
					if (newCode[i] === '1' || newCode[i] === '2') {
						updatedBits += newCode[i];
					} else if (newCode[i] === '0') {
						updatedBits += prevSwitchData.switchSetting[i];
					} else {
						updatedBits += '0';
					}
				}
				return {
					...updatedSwitchData,
					switchSetting: updatedBits,
				};
			}
			return updatedSwitchData;
		});
	};

	//#region Try This logic If any configure Question has zero options to select
	/*
   
  
  const findSelectedOption = (data, responseId) => {
    if (data.options) {
      for (const option of data.options) {
        if (option.id === responseId) {
          return option;
        }
        if (option.questions) {
          const found = option.questions.find(q => findSelectedOption(q, responseId));
          if (found) return found;
        }
      }
    }
    if (data.questions) {
      for (const question of data.questions) {
        const found = findSelectedOption(question, responseId);
        if (found) return found;
      }
    }
    return null;
  };

  const selectedOption = findSelectedOption(formData[switchNumber === 0 ? 0 : 1], newResponse);
  
  // If selected option has empty questions array, make current page the last page
  if (selectedOption && selectedOption.questions && selectedOption.questions.length === 0) {
    // Get current page from the question's page property
    const currentFormData = formData[switchNumber === 0 ? 0 : 1];
    const findQuestionPage = (data, qId) => {
      if (data.id === qId && data.page) return data.page;
      if (data.questions) {
        for (const q of data.questions) {
          const page = findQuestionPage(q, qId);
          if (page) return page;
        }
      }
      if (data.options) {
        for (const opt of data.options) {
          const page = findQuestionPage(opt, qId);
          if (page) return page;
        }
      }
      return null;
    };
    
    const questionPage = findQuestionPage(currentFormData, questionId);
    if (questionPage) {
      setNumPages(questionPage);
    }
  } else if (selectedOption && (!selectedOption.questions || selectedOption.questions.length > 0)) {
    // Reset to original number of pages if option has questions
    setNumPages(formData[switchNumber === 0 ? 0 : 1].numPages);
  }
 */
	//#endregion

	const onSubmit = async () => {
		console.log('saving switch data...');
		const updatedPanelSetting = [...panel.panelSetting];
		updatedPanelSetting[switchNumber] = switchData;
		const updates: Partial<Panel> = {
			panelSetting: updatedPanelSetting,
			updatedAt: new Date().toISOString(),
		};
		const result = await dispatch(
			updateExistingPanel({ dataSource, panelId, updates }),
		);
		console.log('...........................', result);
		navigation.navigate('SwitchesList', { panelId: panelId });
	};

	return (
		<View style={styles.mainContainer}>
			<SafeAreaView edges={['top']} style={styles.safeHeader}>
				<View
					style={[
						styles.headerSection,
						{
							backgroundColor: '#000',
							alignItems: 'center',
						},
					]}>
					<View
						style={{
							flexDirection: 'row',
							alignItems: 'center',
							paddingHorizontal: 10,
							height: '100%',
						}}>
						<TouchableOpacity
							onPress={() => handleBackButtonPress()}
							style={{
								height: '100%',
								padding: 0,
								margin: 0,
								justifyContent: 'center',
							}}>
							<LeftArrowWhite height={30} width={30} />
						</TouchableOpacity>

						<View style={[{ flex: 2 }]}>
							<Text
								style={{
									color: '#fff',
									fontSize: 18,
									fontWeight: 'bold',
									textAlign: 'center',
								}}>
								{pageTitle}
							</Text>
						</View>
					</View>
				</View>
			</SafeAreaView>
			<View style={styles.contentSection}>
				<ConfirmationModal
					visible={confirmationModal}
					onClose={cancelBack}
					onProceed={confirmBack}
					title='Unsaved Progress'
					description='Progress will be lost if you leave this page'
					leftButtonText='CANCEL'
					rightButtonText='ACCEPT'
				/>
				{switchNumber === 0 ? (
					<InfoCard description='Configure Master DIP Switch' />
				) : (
					<InfoCard description='Configure Output DIP Switch' />
				)}
				{switchNumber === 0 && (
					<Form
						data={formData[0]}
						responseData={switchData}
						handleResponseChange={handleResponseChange}
						onSubmit={onSubmit}
						numPages={numPages}
					/>
				)}
				{switchNumber > 0 && (
					<Form
						data={formData[1]}
						responseData={switchData}
						handleResponseChange={handleResponseChange}
						onSubmit={onSubmit}
						numPages={numPages}
					/>
				)}
			</View>
		</View>
	);
}

const styles = StyleSheet.create({
	//#region Main Content Styles
	mainContainer: {
		flex: 1,
		backgroundColor: '#f5f5f5',
	},
	safeHeader: {
		backgroundColor: '#000',
	},
	headerSection: {
		backgroundColor: '#000',
		height: 56,
		width: '100%',
	},
	contentSection: {
		flex: 1,
		width: '100%',
	},
});
