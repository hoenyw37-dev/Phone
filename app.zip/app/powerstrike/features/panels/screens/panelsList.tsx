import React, { useState, useEffect } from 'react';
import {
	View,
	ScrollView,
	StyleSheet,
	ActivityIndicator,
	TouchableOpacity,
	Text,
} from 'react-native';
import SingleButtonFooter from '../../../../../components/singleButtonFooter';
import PanelCard from '../components/panelCard';
import AddPanelModal from '../components/addPanelModal';
import { Panel } from '../types/panel';
import {
	addNewPanel,
	deletePanelWithId,
	validateNewPanel,
} from '../redux/panelsThunk';
import { useDatabase } from '../../../../../global/DatabaseContext';
import { useAppDispatch, useAppSelector } from '../../../../../global/hooks';
import {
	selectPanelsByProject,
	selectPanelsStatus,
	selectPanelsError,
} from '../redux/panelsSlice';
import InfoCard from '@components/InfoCard';
import HeaderRight from '@global/navigation/RightHeaderButtons';
import ConfirmationModal from '@components/confirmationModal';
import Toast from 'react-native-toast-message';
import { commonColors, commonSizes } from '@styles/base';
import { SafeAreaView } from 'react-native-safe-area-context';
import LeftArrowWhite from '@assets/images/LeftArrowWhite.svg';
import DropdownMenu, {
	MenuOptionItem,
} from '@app/faastflex/controllers/dropdownController';

export default function PanelsList({ route, navigation }: any) {
	const dispatch = useAppDispatch();
	const { dataSource } = useDatabase();

	const { projectId, addNew } = route.params;

	const [displayModal, setDisplayModal] = useState(addNew);
	const [confirmationModal, setConfirmationModal] = useState(false);
	const [confirmationId, setConfirmationId] = useState(-1);
	const [confirmationName, setConfirmationName] = useState('');

	const panelsByProject = useAppSelector(state =>
		selectPanelsByProject(state, projectId!),
	);
	//console.log('panels by project:::::::::::::::::::::::::::::::::::::::::::::::::', panelsByProject);
	const panelsStatus = useAppSelector(selectPanelsStatus);
	const panelsError = useAppSelector(selectPanelsError);
	//const panels = useSelector(selectAllPanels);

	/*if (panelsByProject?.length === 0) {
        dispatch(panelsReFetching());
    }*/

	const handleBackButtonPress = () => {
		navigation.goBack();
	};

	const PanelsListButtons: MenuOptionItem[] = [
		{
			label: 'View Templates',
			onSelect: () => viewTemplates(),
		},
	];

	const viewTemplates = () => {
		navigation.navigate('TemplatesList', {
			projectId: projectId,
			panelName: '',
			panelType: '',
			allowUse: false,
		});
	};

	/*const loadData = useCallback(async () => {
        try {
            //dispatch(panelsResetStatus());
            const result = await dispatch(fetchPanelsByProject({ dataSource, projectId }));
            console.log('panels by project...........', result);
        } catch (error) {
            console.error('Error while fetching projects:', error);
        }
    }, []);

    useEffect(() => {
        if (dataSource) {
            loadData(); // Call loadData when the component mounts
        }
    }, [loadData, projectId, dataSource]);*/

	const openModal = () => {
		setDisplayModal(true);
		console.log('adding panel');
		//navigation.navigate('AddProject');
	};

	const handleModalClose = () => {
		setDisplayModal(false);
	};

	const handlePanelSubmit = async ({
		panelName,
		panelType,
		configType,
	}: {
		panelName: string;
		panelType: string;
		configType: string;
	}) => {
		const panel: Panel = {
			projectId,
			panelId: 0,
			panelName,
			panelType,
			panelSetting:
				panelType === 'HPF-PS10'
					? defaultSwitchSettingPS10
					: defaultSwitchSettingPS6,
			updatedAt: new Date().toISOString(),
		};

		const validatePanel = await dispatch(
			validateNewPanel({ dataSource, panel }),
		);

		if (validateNewPanel.fulfilled.match(validatePanel)) {
			if (configType === 'manual') {
				const resultAction = await dispatch(addNewPanel({ dataSource, panel }));
				console.log('result :', resultAction);
				if (addNewPanel.fulfilled.match(resultAction)) {
					const newPanel = resultAction.payload;
					navigation.navigate('SwitchesList', {
						panelId: newPanel.panelId,
					});
				} else {
					console.error('Failed to add the panel:', resultAction.error);
				}
			} else {
				navigation.navigate('TemplatesList', {
					projectId: projectId,
					panelName: panelName,
					panelType: panelType,
					allowUse: true,
				});
			}
		} else if (validateNewPanel.rejected.match(validatePanel)) {
			//console.error('Failed to validate the panel:', validatePanel.error);
			const error = validatePanel.payload as {
				code?: string;
				message?: string;
			};
			if (error.code) {
				Toast.show({
					type: 'error',
					text1: error.message,
					visibilityTime: 2500,
				});
			} else {
				Toast.show({
					type: 'error',
					text1: 'An unexpected error occurred while validating the panel.',
					visibilityTime: 2500,
				});
			}
		}
	};

	const openPanel = (panelId: number) => {
		console.log('opening panel...', panelId);
		navigation.navigate('SwitchesList', { panelId: panelId });
	};

	const handleDeleteRequest = (panelId: number, panelName: string) => {
		setConfirmationId(panelId);
		setConfirmationModal(true);
		setConfirmationName(panelName);
	};

	const confirmDelete = () => {
		if (confirmationId === -1) {
			console.log('No panel selected for deletion');
			return;
		} else {
			setConfirmationModal(false);
			deletePanel(confirmationId);
		}
	};

	const cancelDelete = () => {
		setConfirmationModal(false);
		setConfirmationId(-1);
		setConfirmationName('');
	};

	const deletePanel = async (panelId: number) => {
		console.log('deleting panel...', panelId);

		const resultAction = await dispatch(
			deletePanelWithId({ dataSource, panelId }),
		);

		if (deletePanelWithId.fulfilled.match(resultAction)) {
			Toast.show({
				type: 'success',
				text1: 'Panel deleted successfully',
				visibilityTime: 2500,
			});
		} else {
			console.error('Failed to delete the Panel:', resultAction.error);
			Toast.show({
				type: 'error',
				text1: 'Failed to delete the Panel',
				visibilityTime: 2500,
			});
		}
	};

	const renderContent = () => {
		switch (panelsStatus) {
			case 'pending':
				return <ActivityIndicator size='large' color='#0000ff' />;

			case 'succeeded':
				return (
					<ScrollView>
						{panelsByProject?.length > 0 ? (
							panelsByProject.map(element => (
								<View key={element.panelId}>
									<PanelCard
										panel={element}
										onPress={() => openPanel(element.panelId)}
										onDelete={() =>
											handleDeleteRequest(element.panelId, element.panelName)
										}
									/>
								</View>
							))
						) : (
							<InfoCard
								heading='No Panels Found.'
								description="Tap 'ADD NEW PANEL' to create a new panel"
							/>
						)}
					</ScrollView>
				);

			case 'rejected':
				return <div>{panelsError}</div>;

			default:
				return null;
		}
	};

	return (
		<View style={styles.mainContainer}>
			<SafeAreaView edges={['top']} style={styles.safeHeader}>
				<View
					style={[
						styles.headerSection,
						{
							backgroundColor: '#000',
							alignItems: 'center',
						},
					]}>
					<View
						style={{
							flexDirection: 'row',
							alignItems: 'center',
							paddingHorizontal: 10,
							height: '100%',
						}}>
						<TouchableOpacity
							onPress={() => handleBackButtonPress()}
							style={{
								height: '100%',
								padding: 0,
								margin: 0,
								justifyContent: 'center',
							}}>
							<LeftArrowWhite height={30} width={30} />
						</TouchableOpacity>

						<View style={[{ flex: 2 }]}>
							<Text
								style={{
									color: '#fff',
									fontSize: 18,
									fontWeight: 'bold',
									textAlign: 'center',
								}}>
								Power Supply
							</Text>
						</View>
						<View style={{ paddingHorizontal: 8 }}>
							<DropdownMenu
								menuOptions={PanelsListButtons}
								cancelLabel={'Cancel'}
							/>
						</View>
					</View>
				</View>
			</SafeAreaView>
			<View style={styles.contentSection}>
				{panelsByProject?.length > 0 && (
					<InfoCard description='Select the PowerStrike panel for configuration' />
				)}
				<ConfirmationModal
					visible={confirmationModal}
					onClose={cancelDelete}
					onProceed={confirmDelete}
					title='Delete Panel'
					description={
						"Are you sure you want to delete '" + confirmationName + "'?"
					}
					leftButtonText='CANCEL'
					rightButtonText='DELETE'
				/>
				{displayModal && (
					<AddPanelModal
						visible={displayModal}
						onClose={handleModalClose}
						onSubmit={handlePanelSubmit}
					/>
				)}
				<View style={styles.content}>{renderContent()}</View>
				<View
					style={{
						borderTopColor: commonColors.lineColor,
						borderTopWidth: commonSizes.lineThicknessS,
						backgroundColor: commonColors.backgroundColor_White,
					}}>
					<View style={{ marginHorizontal: '2%' }}>
						<SingleButtonFooter
							buttonText='ADD NEW PANEL'
							onButtonPress={openModal}
						/>
					</View>
				</View>
			</View>
		</View>
	);
}

const defaultSwitchSettingPS10 = [
	{
		switchName: 'S1',
		switchDescription: 'Global Options',
		switchSetting: '0000000000',
		response: {},
	},
	{
		switchName: 'S8',
		switchDescription: 'Output 7',
		switchSetting: '00000000',
		response: {},
	},
	{
		switchName: 'S7',
		switchDescription: 'Output 6',
		switchSetting: '00000000',
		response: {},
	},
	{
		switchName: 'S6',
		switchDescription: 'Output 5',
		switchSetting: '00000000',
		response: {},
	},
	{
		switchName: 'S5',
		switchDescription: 'Output 4',
		switchSetting: '00000000',
		response: {},
	},
	{
		switchName: 'S4',
		switchDescription: 'Output3',
		switchSetting: '00000000',
		response: {},
	},
	{
		switchName: 'S3',
		switchDescription: 'Output 2',
		switchSetting: '00000000',
		response: {},
	},
	{
		switchName: 'S2',
		switchDescription: 'Output 1',
		switchSetting: '00000000',
		response: {},
	},
];

const defaultSwitchSettingPS6 = [
	{
		switchName: 'S1',
		switchDescription: 'Global Options',
		switchSetting: '0000000000',
		response: {},
	},
	{
		switchName: 'S6',
		switchDescription: 'Output 5',
		switchSetting: '00000000',
		response: {},
	},
	{
		switchName: 'S5',
		switchDescription: 'Output 4',
		switchSetting: '00000000',
		response: {},
	},
	{
		switchName: 'S4',
		switchDescription: 'Output 3',
		switchSetting: '00000000',
		response: {},
	},
	{
		switchName: 'S3',
		switchDescription: 'Output 2',
		switchSetting: '00000000',
		response: {},
	},
	{
		switchName: 'S2',
		switchDescription: 'Output 1',
		switchSetting: '00000000',
		response: {},
	},
];

const styles = StyleSheet.create({
	content: {
		flex: 1,
		justifyContent: 'center',
		// paddingHorizontal: '2%',
		// padding: 8,
	},
	mainContainer: {
		flex: 1,
		backgroundColor: '#f5f5f5',
	},
	safeHeader: {
		backgroundColor: '#000',
	},
	headerSection: {
		backgroundColor: '#000',
		height: 56,
		width: '100%',
	},
	contentSection: {
		flex: 1,
		width: '100%',
	},
});
