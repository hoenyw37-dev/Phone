import { DataSource } from 'typeorm';
import { PanelEntity } from './panelEntity';
import { PanelValidationError } from '../types/panel.errors';

const MAX_PANELS_PER_PROJECT = 20;

export const validatePanelCount = async (
	dataSource: DataSource,
	projectId: number,
): Promise<void> => {
	const panelCount = await dataSource.manager.count(PanelEntity, {
		where: { projectId: projectId },
	});
	if (panelCount >= MAX_PANELS_PER_PROJECT) {
		throw new PanelValidationError(
			`Maximum limit of ${MAX_PANELS_PER_PROJECT} panels reached for this project`,
			'MAX_PANELS_EXCEEDED',
		);
	}
};

export const validatePanelNameDistinct = async (
	dataSource: DataSource,
	panelName: string,
	projectId: number,
): Promise<void> => {
	const existingPanel = await dataSource.manager.findOne(PanelEntity, {
		where: { panelName: panelName, projectId: projectId },
	});
	if (existingPanel) {
		throw new PanelValidationError(
			`Panel with name "${panelName}" already exists in this project.`,
			'DUPLICATE_PANEL_NAME',
		);
	}
};
