import { PanelEntity } from './panelEntity';
import { Panel } from '../types/panel';

export const convertPanelEntityToPanel = (entity: PanelEntity): Panel => {
	return {
		projectId: entity.projectId,
		panelId: entity.panelId,
		panelName: entity.panelName,
		panelType: entity.panelType,
		panelSetting: entity.panelSetting,
		updatedAt: entity.updatedAt ? entity.updatedAt.toISOString() : undefined, // Ensure updatedAt is a Date object
	};
};

export const convertPanelToPanelEntity = (panel: Panel): PanelEntity => {
	const entity = new PanelEntity();
	if (panel.projectId) {
		entity.projectId = panel.projectId;
	}
	if (panel.panelId) {
		entity.panelId = panel.panelId;
	}
	entity.panelName = panel.panelName;
	entity.panelType = panel.panelType;
	entity.updatedAt = panel.updatedAt ? new Date(panel.updatedAt) : undefined;
	entity.panelSetting = panel.panelSetting;
	return entity;
};
