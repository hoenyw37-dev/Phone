import { DataSource } from 'typeorm';
import { PanelEntity } from './panelEntity';
import {
	convertPanelEntityToPanel,
	convertPanelToPanelEntity,
} from './panelConversion';
import { Panel } from '../types/panel';
import {
	validatePanelCount,
	validatePanelNameDistinct,
} from './panelsValidation';

export const getAllPanels = async (
	dataSource: DataSource,
): Promise<Panel[]> => {
	//console.log('.............................');
	const rawresult = await dataSource.manager.find(PanelEntity);
	const result = rawresult.map(convertPanelEntityToPanel);
	return result;
};

export const getAllPanelsbyProject = async (
	dataSource: DataSource,
	projectId: number,
): Promise<Panel[]> => {
	const rawresult = await dataSource.manager.find(PanelEntity, {
		where: {
			projectId: projectId,
		},
	});
	const result = rawresult.map(convertPanelEntityToPanel);
	return result;
};

export const validatePanelAddition = async (
	dataSource: DataSource,
	panel: Panel,
): Promise<void> => {
	await validatePanelCount(dataSource, panel.projectId);
	await validatePanelNameDistinct(dataSource, panel.panelName, panel.projectId);
};

export const addPanel = async (
	dataSource: DataSource,
	panel: Panel,
): Promise<Panel> => {
	const panelEntity = convertPanelToPanelEntity(panel);
	//console.log(panelEntity);
	const newPanelEnt = await dataSource.manager.save(PanelEntity, panelEntity);
	const newPanel = convertPanelEntityToPanel(newPanelEnt);
	console.log(newPanel);
	return newPanel;
};

export const updatePanel = async (
	dataSource: DataSource,
	panelId: number,
	updates: Partial<Panel>,
): Promise<Boolean> => {
	const panelEntity = convertPanelToPanelEntity(updates);
	//console.log(panelEntity);
	const result = await dataSource.manager.update(
		PanelEntity,
		panelId,
		panelEntity,
	);
	if (result.affected && result.affected > 0) {
		console.log(`Successfully updated panel with ID: ${panelId}`);
		return true;
	} else {
		console.log(`Failed to update panel with ID: ${panelId}`);
		return false;
	}
};

export const deletePanel = async (
	dataSource: DataSource,
	panelId: number,
): Promise<{ success: boolean }> => {
	//console.log(panelEntity);
	const result = await dataSource.manager.delete(PanelEntity, panelId);
	if (result.affected && result.affected > 0) {
		console.log(`Successfully deleted panel with ID: ${panelId}`);
		return { success: true };
	} else {
		console.log(`Failed to delete panel with ID: ${panelId}`);
		return { success: false };
	}
};
