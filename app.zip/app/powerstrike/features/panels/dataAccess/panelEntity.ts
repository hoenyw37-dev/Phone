import {
	Entity,
	PrimaryGeneratedColumn,
	Column,
	ManyToOne,
	JoinColumn,
	Index,
} from 'typeorm';
import { ProjectEntity } from '../../../../base/projects/dataAccess/projectEntity';

@Entity('panelsTest')
export class PanelEntity {
	@PrimaryGeneratedColumn()
	panelId: number;

	@Column({ type: 'varchar' })
	panelName: string;

	@Column({ type: 'varchar' })
	panelType: string;

	@Column({ type: 'simple-json' })
	panelSetting?: {
		switchName: string;
		switchDisplay: string;
		switchDescription: string;
		response: { [key: string]: string };
	}[];

	@Column({ type: 'datetime', nullable: true })
	updatedAt?: Date;

	//@Column()
	//projectId: number;

	// Many-to-one relationship with ProjectEntity with cascade delete
	@ManyToOne(() => ProjectEntity, project => project.panels, {
		onDelete: 'CASCADE',
	})
	@JoinColumn({ name: 'projectId' })
	project: ProjectEntity;

	@Column()
	@Index()
	projectId: number;
}
