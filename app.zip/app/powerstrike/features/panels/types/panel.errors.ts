export class PanelValidationError extends Error {
	constructor(
		message: string,
		public code: 'MAX_PANELS_EXCEEDED' | 'DUPLICATE_PANEL_NAME',
	) {
		super(message);
		this.name = 'PanelValidationError';
		Object.setPrototypeOf(this, PanelValidationError.prototype);
	}
}
