export type Switch = {
	switchName: string;
	switchSetting: string;
	switchDescription: string;
	response: {
		[key: string]: string;
	};
};

export type Panel = {
	projectId: number;
	panelId: number;
	panelName: string;
	panelType: string;
	updatedAt?: string;
	panelSetting: Switch[];
};
