import { Text, View, StyleSheet } from 'react-native';
import React, { useEffect, useState } from 'react';
import { commonColors, commonSizes, commonStyles } from '@styles/base';
import { RadioButton } from '@components/RadioButton'; // Adjust the import path as needed

export default function Question({
	data,
	responses,
	onResponseChange,
	currentPage,
}) {
	const [Enable, setEnable] = useState(() => {
		if (data.childDisplay) {
			if (responses?.response[data.id]) {
				return responses.response[data.id];
			} else {
				return data.options[0].id;
			}
		} else {
			return false;
		}
	});

	useEffect(() => {
		const initialVal = Enable;
		const selectedOption = data.options?.find(
			option => option.id === initialVal,
		);
		if (selectedOption) {
			onResponseChange(
				data.id,
				initialVal,
				selectedOption.code,
				selectedOption.numPages,
			);
		}
	}, [Enable]);

	const handleOptionChange = val => {
		setEnable(val);
	};

	return (
		<View style={{ flex: 1 }}>
			{data.page === currentPage &&
				(!data.disableText || data.childDisplay) && (
					<View style={styles.box}>
						{data.heading && (
							<View>
								<Text style={styles.heading}>{data.heading}</Text>
								<View style={styles.horizontalLine} />
							</View>
						)}
						{!data.disableText && data.text && (
							<Text style={styles.title}>{data.text}</Text>
						)}

						{data.childDisplay &&
							data.options.map((option, index) => (
								<View
									style={{
										paddingHorizontal: commonSizes.paddingS_Percent,
									}}>
									<RadioButton
										key={index}
										option={option}
										isSelected={Enable === option.id}
										onOptionChange={handleOptionChange}
									/>
									{index === data.options.length - 1 ? null : (
										<View style={styles.horizontalLine} />
									)}
								</View>
							))}
					</View>
				)}

			{data.options &&
				(!data.options[0].code || data.id === '32') &&
				data.options.map(subOption => {
					const responseId = responses?.response[data.id];
					if (responseId === subOption.id) {
						return (
							<View key={subOption.id}>
								<Question
									key={subOption.id}
									data={subOption}
									responses={responses}
									onResponseChange={onResponseChange}
									currentPage={currentPage}
								/>
							</View>
						);
					}
				})}

			{data.questions?.map(subQuestion => (
				<View key={subQuestion.id}>
					<Question
						key={subQuestion.id}
						data={subQuestion}
						responses={responses}
						onResponseChange={onResponseChange}
						currentPage={currentPage}
					/>
				</View>
			))}
		</View>
	);
}

const styles = StyleSheet.create({
	box: {
		backgroundColor: commonColors.backgroundColor_White,
		padding: commonSizes.paddingXXL_Percent,
		marginBottom: commonSizes.heightS_Pixel,
		borderRadius: commonSizes.cornerRadius,
	},
	heading: {
		fontSize: commonSizes.textSizeL1,
		fontWeight: '500',
		color: commonColors.textColor_Black,
	},
	title: {
		fontSize: commonSizes.textSizeM1,
		fontWeight: '500',
		color: commonColors.textColor_Black,
		marginBottom: commonSizes.heightM_Pixel,
	},
	horizontalLine: {
		...commonStyles.horizontalLine,
		height: commonSizes.lineThicknessS,
		marginVertical: commonSizes.heightM_Pixel,
		backgroundColor: commonColors.lineColorLight,
	},
});
