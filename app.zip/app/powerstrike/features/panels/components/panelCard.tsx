import React, { useState } from 'react';
import {
	Text,
	View,
	TouchableOpacity,
	ScrollView,
	StyleSheet,
	Button,
	Pressable,
} from 'react-native';
import { Panel } from '../types/panel';
import PanelIcon from '@powerstrike/assets/PanelIcon.svg';
import TripleDotIconGrey from '@assets/images/TripleDotIconGrey.svg';
import DeleteIconBlack from '@assets/images/DeleteIconBlack.svg';
import {
	Menu,
	MenuOptions,
	MenuOption,
	MenuTrigger,
	renderers,
} from 'react-native-popup-menu';
import { commonColors, commonSizes, commonStyles } from '@styles/base';

export default function PanelCard({ panel, onPress, onDelete }) {
	const onDeletePanel = () => {
		onDelete();
	};

	return (
		<View style={{ flex: 1 }}>
			<TouchableOpacity style={styles.box} onPress={onPress}>
				<View style={styles.panelIcon}>
					<PanelIcon
						width={commonSizes.iconWidthXL_Pixel}
						height={commonSizes.iconHeightXL_Pixel}
					/>
				</View>
				<View style={styles.content}>
					<Text style={styles.heading}>{panel.panelName}</Text>
					<Text style={styles.description}>{panel.panelType}</Text>
				</View>
				<View style={styles.verticalLine} />
				<Menu renderer={renderers.Popover}>
					<MenuTrigger>
						<View style={styles.clickableMenu}>
							<TripleDotIconGrey
								width={commonSizes.iconWidthM_Pixel}
								height={commonSizes.iconHeightM_Pixel}
							/>
						</View>
					</MenuTrigger>
					<MenuOptions>
						<MenuOption
							onSelect={onDeletePanel}
							style={{ backgroundColor: '#F6F6F6' }}>
							<View style={styles.popUp}>
								<DeleteIconBlack
									width={commonSizes.iconWidthM_Pixel}
									height={commonSizes.iconHeightM_Pixel}
								/>
								<Text style={styles.popUpText}>Delete</Text>
							</View>
						</MenuOption>
						{/* Add more options here if needed */}
					</MenuOptions>
				</Menu>
			</TouchableOpacity>
		</View>
	);
}

const styles = StyleSheet.create({
	box: { ...commonStyles.box },
	heading: { ...commonStyles.boxHeading },
	description: { ...commonStyles.boxDescription },
	content: {
		...commonStyles.boxContent,
		marginLeft: commonSizes.widthM_Pixel,
	},
	verticalLine: { ...commonStyles.verticalLine },
	clickableMenu: {
		...commonStyles.boxClickableMenu,
		marginHorizontal: commonSizes.widthM_Pixel,
	},
	popUp: {
		...commonStyles.boxMenuPopUp,
		marginTop: commonSizes.heightXS_Pixel,
		marginBottom: commonSizes.heightXS_Pixel,
	},
	popUpText: { ...commonStyles.boxMenuText },
	panelIcon: {
		...commonStyles.boxIcon,
		marginLeft: commonSizes.widthXL_Pixel,
	},
});
