import {
	Text,
	View,
	TouchableOpacity,
	ScrollView,
	StyleSheet,
	Button,
} from 'react-native';
import { Switch } from '../types/panel';
import { commonColors, commonSizes } from '@styles/base';
export default function SwitchCard({ element, onPress }) {
	console.log(element);
	return (
		<TouchableOpacity style={styles.box} onPress={onPress}>
			<Text style={styles.heading}>{element.switchName}</Text>
			<Text style={styles.description}>{element.switchSetting}</Text>
		</TouchableOpacity>
	);
}

const styles = StyleSheet.create({
	container: {
		flex: 1,
		padding: 16,
	},
	box: {
		backgroundColor: '#FFFFFF',
		padding: 32,
		marginBottom: 16,
		borderRadius: commonSizes.cornerRadius,
	},
	heading: {
		fontSize: 18,
		fontWeight: 'bold',
		color: commonColors.textColor_Black,
	},
	description: {
		fontSize: 14,
		marginTop: 4,
		color: commonColors.textColor_Black,
	},
});
