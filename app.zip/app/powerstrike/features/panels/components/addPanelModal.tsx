import React from 'react';
import { View, Text, TextInput, StyleSheet } from 'react-native';
//import {Picker} from '@react-native-picker/picker';
import { useForm, Controller } from 'react-hook-form';
import { yupResolver } from '@hookform/resolvers/yup';
import * as yup from 'yup';
import RNPickerSelect from 'react-native-picker-select';
import DropDownIcon from '@assets/images/DropDownIcon.svg';
import { commonColors, commonSizes } from '@styles/base';
import CommonModalUI from '@components/CommonModalUI';

type PanelFormData = {
	panelName: string;
	panelType: string;
	configType: string;
};

type PanelModalProps = {
	visible: boolean;
	onClose: () => void;
	onSubmit: (data: PanelFormData) => void;
};

const schema = yup.object().shape({
	panelName: yup
		.string()
		.required('Panel name is required')
		.max(50, 'Panel name cannot exceed 50 characters')
		.matches(/^[a-zA-Z0-9-_ ]*$/, 'Panel name cannot have special characters'),
	panelType: yup.string().required('Panel type is required'),
	configType: yup.string().required('Configuration type is required'),
});

export default function AddPanelModal(props: PanelModalProps) {
	const {
		control,
		handleSubmit,
		formState: { errors },
		reset,
	} = useForm<PanelFormData>({
		resolver: yupResolver(schema),
	});

	const handleFormSubmit = (data: PanelFormData) => {
		props.onSubmit(data);
		reset(); // Reset the form after submission
		props.onClose(); // Close the modal
	};

	return (
		<CommonModalUI
			modalVisible={props.visible}
			closeModal={props.onClose}
			leftButtonText='CANCEL'
			rightButtonText='NEXT'
			onLeftButtonPress={props.onClose}
			onRightButtonPress={handleSubmit(handleFormSubmit)}
			titleText='Add New Panel'
			titleTextExtraStyle={styles.titleStyle}>
			<View style={{ marginTop: '5%', marginBottom: '5%' }}>
				<Text>
					<Text style={styles.fieldTitle}>Panel Name</Text>
					<Text style={{ color: commonColors.warningColor }}>*</Text>
				</Text>
				<Controller
					control={control}
					name='panelName'
					defaultValue=''
					render={({ field: { onChange, value } }) => (
						<TextInput
							style={[styles.input, errors.panelName && styles.errorInput]}
							placeholder='Enter Panel Name'
							placeholderTextColor={commonColors.textColor_Grey}
							value={value}
							onChangeText={onChange}
							maxLength={50}
						/>
					)}
				/>
				{errors.panelName && (
					<Text style={styles.errorText}>{errors.panelName.message}</Text>
				)}
			</View>
			<View style={{ marginBottom: '2%' }}>
				<Text style={styles.fieldTitle}>Panel Type :</Text>
				<Controller
					control={control}
					name='panelType'
					defaultValue='HPF-PS6'
					render={({ field: { onChange, value } }) => (
						<RNPickerSelect
							value={value}
							onValueChange={onChange}
							useNativeAndroidPickerStyle={false}
							placeholder={{}}
							style={{
								inputIOS: {
									height: commonSizes.textBoxHeight_L,
									width: '100%',
									color: commonColors.textColor_Black,
									fontSize: commonSizes.textSizeM,
									paddingLeft: commonSizes.paddingL_Percent,
								},
								inputAndroid: {
									height: commonSizes.textBoxHeight_L,
									width: '100%',
									color: commonColors.textColor_Black,
									fontSize: commonSizes.textSizeM,
									paddingLeft: commonSizes.paddingL_Percent,
								},
								inputIOSContainer: {
									borderWidth: commonSizes.textBoXBorderWidthXS,
									borderColor: commonColors.textBoxBorderColor,
									borderRadius: commonSizes.cornerRadius,
									marginBottom: commonSizes.heightS_Pixel,
								},
								inputAndroidContainer: {
									borderWidth: commonSizes.textBoXBorderWidthXS,
									borderColor: commonColors.textBoxBorderColor,
									borderRadius: commonSizes.cornerRadius,
									marginBottom: commonSizes.heightS_Pixel,
								},
							}}
							items={[
								{ label: 'HPF-PS6', value: 'HPF-PS6' },
								{ label: 'HPF-PS10', value: 'HPF-PS10' },
							]}
							Icon={() => {
								return (
									<View style={styles.DropdownImageContainer}>
										<DropDownIcon />
									</View>
								);
							}}
						/>
					)}
				/>
				{errors.panelType && (
					<Text style={styles.errorText}>{errors.panelType.message}</Text>
				)}
			</View>
			<View style={{ marginBottom: '2%' }}>
				<Text style={styles.fieldTitle}>Configuration Type :</Text>
				<Controller
					control={control}
					name='configType'
					defaultValue='manual'
					render={({ field: { onChange, value } }) => (
						<RNPickerSelect
							value={value}
							onValueChange={onChange}
							useNativeAndroidPickerStyle={false}
							placeholder={{}}
							style={{
								inputIOS: {
									height: commonSizes.textBoxHeight_L,
									width: '100%',
									color: commonColors.textColor_Black,
									fontSize: commonSizes.textSizeM,
									paddingLeft: commonSizes.paddingL_Percent,
								},
								inputAndroid: {
									height: commonSizes.textBoxHeight_L,
									width: '100%',
									color: commonColors.textColor_Black,
									fontSize: commonSizes.textSizeM,
									paddingLeft: commonSizes.paddingL_Percent,
								},
								inputIOSContainer: {
									borderWidth: commonSizes.textBoXBorderWidthXS,
									borderColor: commonColors.textBoxBorderColor,
									borderRadius: commonSizes.cornerRadius,
									marginBottom: commonSizes.heightS_Pixel,
								},
								inputAndroidContainer: {
									borderWidth: commonSizes.textBoXBorderWidthXS,
									borderColor: commonColors.textBoxBorderColor,
									borderRadius: commonSizes.cornerRadius,
									marginBottom: commonSizes.heightS_Pixel,
								},
							}}
							items={[
								{
									label: 'Manual Configuration',
									value: 'manual',
								},
								{
									label: 'Select a Template',
									value: 'template',
								},
							]}
							Icon={() => {
								return (
									<View style={styles.DropdownImageContainer}>
										<DropDownIcon />
									</View>
								);
							}}
						/>
					)}
				/>
				{errors.configType && (
					<Text style={styles.errorText}>{errors.configType.message}</Text>
				)}
			</View>
		</CommonModalUI>
	);
}

const styles = StyleSheet.create({
	titleStyle: {
		alignSelf: 'flex-start',
		fontSize: commonSizes.textSizeL1,
	},
	fieldTitle: {
		color: commonColors.textColor_Black,
		fontSize: commonSizes.textSizeM,
	},
	input: {
		height: commonSizes.textBoxHeight_L,
		borderColor: commonColors.textBoxBorderColor,
		borderWidth: commonSizes.textBoXBorderWidthXS,
		borderRadius: commonSizes.cornerRadius,
		paddingHorizontal: commonSizes.paddingM_Percent,
		color: commonColors.textColor_Black,
		fontSize: commonSizes.textSizeM,
	},
	picker: {
		color: commonColors.textColor_Black,
	},
	pickerItems: {
		color: commonColors.textColor_Black,
		fontSize: commonSizes.textSizeM,
		backgroundColor: commonColors.backgroundColor_White,
	},
	errorInput: {
		borderColor: commonColors.warningColor,
	},
	errorText: {
		color: commonColors.warningColor,
		marginTop: commonSizes.heightXS_Pixel,
		marginLeft: commonSizes.widthM_Pixel,
		fontSize: commonSizes.textSizeS,
	},
	DropdownImageContainer: {
		width: commonSizes.iconWidthM_Pixel,
		height: commonSizes.iconHeightM_Pixel,
		marginEnd: commonSizes.widthXS_Pixel,
		marginVertical: commonSizes.widthM_Pixel,
		alignItems: 'center',
	},
});
