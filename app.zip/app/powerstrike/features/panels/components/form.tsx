import React, { useState, useEffect } from 'react';
import { Text, View, StyleSheet, Button, ScrollView } from 'react-native';
import { SafeAreaView, SafeAreaProvider } from 'react-native-safe-area-context';
import Question from './question';
import DoubleButtonFooter from '@components/doubleButtonFooter';
import SingleButtonFooter from '@components/singleButtonFooter';
import { commonColors, commonSizes } from '@styles/base';

export default function Form({
	data,
	responseData,
	handleResponseChange,
	onSubmit,
	numPages,
}) {
	const [currentPage, setCurrentPage] = useState(1);

	useEffect(() => {
		console.log('Responses have changed:', responseData);
		console.log(responseData.response);
	}, [responseData]);

	const handleNextPage = () => {
		if (currentPage < numPages) {
			setCurrentPage(currentPage + 1);
		} else {
			console.log('............');
			onSubmit();
		}
	};

	const handlePreviousPage = () => {
		if (currentPage > 0) {
			setCurrentPage(currentPage - 1);
		}
	};

	return (
		<View style={styles.container}>
			<ScrollView contentContainerStyle={{ padding: '2%' }}>
				<Question
					data={data}
					responses={responseData}
					onResponseChange={handleResponseChange}
					currentPage={currentPage}
				/>
			</ScrollView>
			<View
				style={{
					borderTopColor: commonColors.lineColor,
					borderTopWidth: commonSizes.lineThicknessS,
					backgroundColor: commonColors.backgroundColor_White,
				}}>
				<View style={{ marginHorizontal: '2%' }}>
					{currentPage === 1 ? (
						<View style={{ paddingHorizontal: '2%' }}>
							<SingleButtonFooter
								buttonText={currentPage === numPages ? 'SAVE' : 'NEXT'}
								onButtonPress={handleNextPage}
								buttonStyle={styles.singleNextButton}
								buttonTextStyle={styles.singleNextButtonText}
							/>
						</View>
					) : (
						<DoubleButtonFooter
							leftButtonText='BACK'
							rightButtonText={currentPage === numPages ? 'SAVE' : 'NEXT'}
							onLeftButtonPress={handlePreviousPage}
							onRightButtonPress={handleNextPage}
							leftButtonDisabled={currentPage === 1}
							rightButtonDisabled={false}
							containerStyle={{ paddingHorizontal: '2%' }}
						/>
					)}
				</View>
			</View>
		</View>
	);
}

const styles = StyleSheet.create({
	container: {
		flex: 1,
		justifyContent: 'center',
	},
	footer: {
		flexDirection: 'row',
		justifyContent: 'space-evenly',
		width: '100%',
	},
	singleNextButton: {
		backgroundColor: commonColors.textColor_Blue,
		borderWidth: 1,
		borderColor: commonColors.textColor_Blue,
	},
	singleNextButtonText: {
		color: 'white',
		fontWeight: 'bold',
		textAlign: 'center',
	},
});
