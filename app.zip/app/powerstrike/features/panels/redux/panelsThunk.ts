import { createAsyncThunk } from '@reduxjs/toolkit';
import {
	getAllPanels,
	getAllPanelsbyProject,
	addPanel,
	updatePanel,
	deletePanel,
	validatePanelAddition,
} from '../dataAccess/panelsRepo';
import { DataSource } from 'typeorm/browser';
import { Panel } from '../types/panel';
import { PanelValidationError } from '../types/panel.errors';

export const fetchPanels = createAsyncThunk(
	'panels/fetchPanels',
	async (dataSource: DataSource) => {
		//console.log('fetching thunks...', dataSource);
		const result = await getAllPanels(dataSource);
		console.log('fetched panels');
		console.log(result);
		return result;
	},
	/*{
        condition(arg, thunkApi) {
            const postsStatus = selectPostsStatus(thunkApi.getState())
            if (postsStatus !== 'idle') {
                return false
            }
        },
    },*/
);

export const fetchPanelsByProject = createAsyncThunk(
	'panels/fetchPanelsByProject',
	async ({
		dataSource,
		projectId,
	}: {
		dataSource: DataSource;
		projectId: number;
	}) => {
		//console.log('fetching thunks...', dataSource);
		const result = await getAllPanelsbyProject(dataSource, projectId);
		console.log('fetched panels according to projectId');
		console.log(result);
		return result;
	},
	/*{
        condition(arg, thunkApi) {
            const postsStatus = selectPostsStatus(thunkApi.getState())
            if (postsStatus !== 'idle') {
                return false
            }
        },
    },*/
);

export const validateNewPanel = createAsyncThunk(
	'panels/validateNewPanel',
	async (
		{ dataSource, panel }: { dataSource: DataSource; panel: Panel },
		{ rejectWithValue },
	) => {
		try {
			console.log('validating new panel', panel);
			await validatePanelAddition(dataSource, panel);
			console.log('validated panels..........');
			return panel;
		} catch (error) {
			if (error instanceof PanelValidationError) {
				console.log('panel validation error........', error);
				return rejectWithValue({
					message: error.message,
					code: error.code,
				});
			}
		}
	},
);

export const addNewPanel = createAsyncThunk(
	'panels/addNewPanel',
	async ({ dataSource, panel }: { dataSource: DataSource; panel: Panel }) => {
		console.log('adding new panel', panel);
		const result = await addPanel(dataSource, panel);
		console.log('added panels..........');
		console.log(result);
		return result;
	},
);

export const updateExistingPanel = createAsyncThunk(
	'panels/updateExistingPanel',
	async ({
		dataSource,
		panelId,
		updates,
	}: {
		dataSource: DataSource;
		panelId: number;
		updates: Partial<Panel>;
	}) => {
		console.log('updating panel updates', panelId, updates);
		const result = await updatePanel(dataSource, panelId, updates);
		if (result) {
			return { panelId, updates };
		} else {
			throw new Error(`Failed to update panel with ID: ${panelId}`);
		}
	},
);

export const deletePanelWithId = createAsyncThunk(
	'projects/deletePanelWithId',
	async ({
		dataSource,
		panelId,
	}: {
		dataSource: DataSource;
		panelId: number;
	}) => {
		const deleteResult = await deletePanel(dataSource, panelId);
		if (deleteResult.success) {
			return panelId;
		} else {
			throw new Error(`Failed to delete project with ID: ${panelId}`);
		}
	},
);
