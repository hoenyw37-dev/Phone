import {
	createEntityAdapter,
	createSlice,
	createSelector,
	EntityState,
} from '@reduxjs/toolkit';
import { RootState } from '../../../../../global/store';
import { Panel } from '../types/panel';
import {
	fetchPanels,
	addNewPanel,
	fetchPanelsByProject,
	updateExistingPanel,
	deletePanelWithId,
} from './panelsThunk';

interface PanelsState extends EntityState<Panel, number> {
	status: 'idle' | 'pending' | 'succeeded' | 'rejected';
	error: string | null;
}

const panelsAdapter = createEntityAdapter({
	selectId: (panel: Panel) => panel.panelId,
	sortComparer: (a, b) =>
		new Date(b.updatedAt ?? 0).getTime() - new Date(a.updatedAt ?? 0).getTime(),
});

const initialState: PanelsState = panelsAdapter.getInitialState({
	status: 'idle',
	error: null,
});

export const panelsSlice = createSlice({
	name: 'panels',
	initialState,
	reducers: {
		panelAdded: panelsAdapter.addOne,
		panelsReceived(state, action) {
			panelsAdapter.setAll(state, action.payload.books);
		},
		panelsResetStatus(state) {
			state.status = 'idle';
			state.error = null;
		},
	},
	extraReducers: builder => {
		builder
			.addCase(fetchPanels.fulfilled, (state, action) => {
				state.status = 'succeeded';
				panelsAdapter.setAll(state, action.payload);
				console.log('panel fecthing completed');
			})
			.addCase(addNewPanel.fulfilled, panelsAdapter.addOne)
			.addCase(deletePanelWithId.fulfilled, panelsAdapter.removeOne)
			.addCase(fetchPanelsByProject.pending, (state, action) => {
				console.log('pending panels data!!!!!!!!!!!!!!!!!!!');
				state.status = 'pending';
			})
			.addCase(fetchPanelsByProject.fulfilled, (state, action) => {
				state.status = 'succeeded';
				panelsAdapter.addMany(state, action.payload);
				console.log('PANELS STATE', state);
			})
			.addCase(fetchPanelsByProject.rejected, (state, action) => {
				state.status = 'rejected';
				state.error = action.error.message ?? 'Unknown Error';
			})
			.addCase(updateExistingPanel.fulfilled, (state, action) => {
				const { panelId, updates } = action.payload;
				panelsAdapter.updateOne(state, {
					id: panelId,
					changes: updates,
				});
			});
		/*.addCase(fetchPanelsByProject.pending, (state) => {
            state.loading = true;
            state.error = null;
        })
        .addCase(fetchPanelsByProject.rejected, (state, action) => {
            state.loading = false;
            state.error = action.payload?.error || 'Failed to load panels';
        });*/
	},
});

export const { selectAll: selectAllPanels, selectById: selectPanelById } =
	panelsAdapter.getSelectors((state: RootState) => state.panels);

export const selectPanelsByProject = createSelector(
	[selectAllPanels, (state: RootState, projectId: number) => projectId],
	(panels, projectId) => panels.filter(panel => panel.projectId === projectId),
);

export const selectLatestUpdatedAtByProject = createSelector(
	[selectPanelsByProject],
	panels => {
		if (panels.length === 0) {
			return null;
		}

		return panels.reduce((latest, panel) => {
			const panelDate = new Date(panel.updatedAt || 0);
			return panelDate > latest ? panelDate : latest;
		}, new Date(0));
	},
);

export const { panelsReceived, panelAdded, panelsResetStatus } =
	panelsSlice.actions;

export const selectPanelsStatus = (state: RootState) => state.panels.status;
export const selectPanelsError = (state: RootState) => state.panels.error;

export default panelsSlice.reducer;
