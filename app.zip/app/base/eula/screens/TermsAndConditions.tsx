import React, { useEffect, useState } from 'react';
import {
	Platform,
	StyleSheet,
	Text,
	TouchableOpacity,
	View,
} from 'react-native';
import { WebView } from 'react-native-webview';
import SingleButtonFooter from '@components/singleButtonFooter';
import RNFS from 'react-native-fs';
import { useTranslation } from 'react-i18next';
import { SafeAreaView } from 'react-native-safe-area-context';
import LeftArrowWhite from '@assets/images/LeftArrowWhite.svg';

const TermsAndConditions = ({ route, navigation }: any) => {
	const { fileName } = route.params;
	const { i18n } = useTranslation();
	const [pageTitle, setPageTitle] = useState('');

	// Get the current language and map it to file suffix
	const getLanguageSuffix = () => {
		const currentLanguage = i18n.language;
		const languageMap: { [key: string]: string } = {
			en: '',
			de: '_DE',
			es: '_ES',
			fr: '_FR',
			it: '_IT',
			ko: '_KO',
			pl: '_PL',
			zh: '_ZH',
		};
		return languageMap[currentLanguage] || ''; // Default to English if language not found
	};

	// Get the base filename based on document type
	const getBaseFileName = () => {
		if (fileName === 'EULA') {
			return 'EULA';
		} else if (fileName === 'PrivacyPolicy') {
			return 'PIA'; // Privacy files use 'PIA' prefix for non-English versions
		}
		return fileName;
	};

	// Get the full filename with language suffix
	const getLocalizedFileName = () => {
		const suffix = getLanguageSuffix();
		const baseFileName = getBaseFileName();

		// For PrivacyPolicy in English, use PrivacyPolicy.htm, otherwise use PIA_XX.htm
		if (fileName === 'PrivacyPolicy' && suffix === '') {
			return 'PrivacyPolicy';
		}

		return `${baseFileName}${suffix}`;
	};

	useEffect(() => {
		let title = '';
		if (fileName === 'EULA') {
			title = 'HONEYWELL END USER LICENSE AGREEMENT';
		} else if (fileName === 'PrivacyPolicy') {
			title = 'Honeywell Apps Privacy Notice';
		}
		setPageTitle(title);
	}, [navigation, fileName]);

	const getAndroidSourceUri = () => {
		try {
			const localizedFileName = getLocalizedFileName();
			const uri = `file:///android_asset/${localizedFileName}.htm`;
			console.log('Android loading URI:', uri);
			return uri;
		} catch (error) {
			console.error('Failed to construct file path:', error);
			return `file:///android_asset/EULA.htm`; // Fallback to default EULA
		}
	};

	const [htmlContent, setHtmlContent] = useState('');
	useEffect(() => {
		const loadiOSHtml = async () => {
			try {
				const localizedFileName = getLocalizedFileName();
				const htmlFilePath = RNFS.MainBundlePath
					? `${RNFS.MainBundlePath}/${localizedFileName}.htm`
					: `${localizedFileName}.htm`;

				const html = await RNFS.readFile(htmlFilePath, 'utf8');
				setHtmlContent(html);
			} catch (error) {
				console.error('Failed to load file:', error);
				setHtmlContent('');
			}
		};

		if (Platform.OS === 'ios') {
			loadiOSHtml();
		}
	}, [i18n.language]); // Re-load when language changes

	const handleOkPress = () => {
		console.log('Ok Pressed');
		navigation.goBack(); // Navigate back to the previous screen
	};

	return (
		<View style={styles.mainContainer}>
			<SafeAreaView edges={['top']} style={styles.safeHeader}>
				<View
					style={[
						styles.headerSection,
						{
							backgroundColor: '#000',
							alignItems: 'center',
						},
					]}>
					<View
						style={{
							flexDirection: 'row',
							alignItems: 'center',
							paddingHorizontal: 10,
							height: '100%',
						}}>
						<TouchableOpacity
							onPress={() => navigation.goBack()}
							style={{
								height: '100%',
								padding: 0,
								margin: 0,
								justifyContent: 'center',
							}}>
							<LeftArrowWhite height={30} width={30} />
						</TouchableOpacity>
						<View style={[{ flex: 2 }]}>
							<Text
								style={{
									color: '#fff',
									fontSize: 18,
									fontWeight: 'bold',
									textAlign: 'center',
								}}>
								{pageTitle}
							</Text>
						</View>
					</View>
				</View>
			</SafeAreaView>
			<View style={styles.contentSection}>
				{Platform.OS === 'android' ? (
					<WebView
						source={{ uri: getAndroidSourceUri() }}
						style={styles.webview}
					/>
				) : (
					<WebView originWhitelist={['*']} source={{ html: htmlContent }} />
				)}
				<View style={{ paddingHorizontal: '2%' }}>
					<SingleButtonFooter
						buttonTextStyle={{ color: '#fff' }}
						buttonStyle={{ margin: 5, backgroundColor: '#1791E4' }}
						buttonText='OK'
						onButtonPress={handleOkPress}
					/>
				</View>
			</View>
		</View>
	);
};

const styles = StyleSheet.create({
	mainContainer: {
		flex: 1,
		backgroundColor: '#f5f5f5',
	},
	safeHeader: {
		backgroundColor: '#000',
	},
	headerSection: {
		backgroundColor: '#000',
		height: 56,
		width: '100%',
	},
	contentSection: {
		flex: 1,
		width: '100%',
	},
	container: {
		flex: 1,
	},
	webview: {
		flex: 1,
	},
});

export default TermsAndConditions;
