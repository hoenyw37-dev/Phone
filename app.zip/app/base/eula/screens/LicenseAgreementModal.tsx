import React, { useEffect, useState } from 'react';
import {
	View,
	Text,
	Modal,
	TouchableOpacity,
	ImageBackground,
} from 'react-native';
//import EncryptedStorage from 'react-native-encrypted-storage';
import { useTranslation } from 'react-i18next';
import { LicenseAgreementModalStyles } from '@base/eula/styles/LicenseAgreementModalStyles';
import DoubleButtonFooter from '@components/doubleButtonFooter';
import { useFocusEffect } from '@react-navigation/native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import RNExitApp from 'react-native-exit-app';
import { useAuth } from '@base/auth/authContext';
import EncryptedStorage from 'react-native-encrypted-storage';

const LicenseAgreementModal = ({ navigation }: any) => {
	const [isModalVisible, setIsModalVisible] = useState(false);
	const [isLoading, setIsLoading] = useState(true);
	const [isChecked1, setIsChecked1] = useState(false);

	const [isChecked2, setIsChecked2] = useState(false);

	const { t } = useTranslation();
	const { isAuthenticated } = useAuth();

	useEffect(() => {
		const checkLicense = async () => {
			try {
				const accepted = await EncryptedStorage.getItem('licenseAccepted');
				const privacyAccepted = await EncryptedStorage.getItem('PrivacyPolicy');
				if (accepted && privacyAccepted) {
					navigation.replace('ProjectList');
					// if(!isAuthenticated){
					//   navigation.replace('LoginScreen'); //uncomment for release, comment for testing
					// }else{
					//   navigation.replace('ProjectList'); //uncomment for release, comment for testing
					// }
					//setIsModalVisible(true); //comment for release, uncomment for testing
					//setIsLoading(false); //comment for release, uncomment for testing
				} else {
					setIsModalVisible(true);
					setIsLoading(false);
				}
			} catch (error) {
				console.error('Failed to check license:', error);
			}
		};

		checkLicense();
	}, [isAuthenticated, navigation]);

	useFocusEffect(
		React.useCallback(() => {
			setIsModalVisible(true);
			return () => setIsModalVisible(false);
		}, []),
	);

	const [LabelHoneywellPrivacyStatement, setLabelHoneywellPrivacyStatement] =
		useState<string>('Honeywell' + t('privacystatement'));

	const acceptLicense = async () => {
		try {
			await EncryptedStorage.setItem('licenseAccepted', 'true'); //set to true for release, false for testing
			await EncryptedStorage.setItem('PrivacyPolicy', 'true'); //set to true for release, false for testing
			setIsModalVisible(false);
			//navigation.replace('LoginScreen');
			navigation.replace('ProjectList');
		} catch (error) {
			console.error('Failed to save license acceptance:', error);
		}
	};

	const declineLicense = () => {
		// BackHandler.exitApp(); // Close the app
		RNExitApp.exitApp();
	};

	if (isLoading) {
		return <Text>Loading...</Text>;
	}
	const handleLinkPress = (fileName: string) => {
		navigation.navigate('TermsAndConditions', { fileName: fileName }); // Navigate to TermsAndConditions
	};
	return (
		<Modal
			visible={isModalVisible}
			transparent={true}
			animationType='fade'
			onRequestClose={() => {}}>
			<ImageBackground
				style={LicenseAgreementModalStyles.backgroudImageContainer}
				source={require('@assets/images/BackgroundImage.png')}>
				<View style={LicenseAgreementModalStyles.modalContainer}>
					<View style={[{}, LicenseAgreementModalStyles.modalContent]}>
						<View style={{}}>
							<Text style={LicenseAgreementModalStyles.titleText}>
								{t('txtTERMSANDCONDITIONS')}
							</Text>
						</View>
						<View style={LicenseAgreementModalStyles.horizontalLine} />
						<View style={LicenseAgreementModalStyles.checkboxContainer}>
							<View style={LicenseAgreementModalStyles.main}>
								<TouchableOpacity
									onPress={() =>
										isChecked1 === false
											? setIsChecked1(true)
											: setIsChecked1(false)
									}>
									<View style={LicenseAgreementModalStyles.wrapper}>
										<View style={LicenseAgreementModalStyles.radio}>
											{isChecked1 === true ? (
												<View style={LicenseAgreementModalStyles.radioBG} />
											) : null}
										</View>
									</View>
								</TouchableOpacity>
							</View>
							<Text style={LicenseAgreementModalStyles.checkboxText}>
								{t('txtconfirmReadandAccepted')}{' '}
								<Text
									style={LicenseAgreementModalStyles.linkText}
									onPress={() => handleLinkPress('EULA')}>
									{t('LabelEULA')}
								</Text>
								<Text
									style={LicenseAgreementModalStyles.linkText}
									onPress={() => handleLinkPress('EULA')}>
									{' '}
								</Text>
								<Text
									style={LicenseAgreementModalStyles.linkText}
									onPress={() => handleLinkPress('EULA')}>
									{t('lblagreement')}
								</Text>
							</Text>
						</View>
						{/* <View style={LicenseAgreementModalStyles.checkboxContainer}>
                        <CheckBox tintColors={{ true: '#1792E5', false: commonColors.textColor }} value={isChecked2} onValueChange={setIsChecked2} />
                        <Text style={LicenseAgreementModalStyles.checkboxText}>{t('msgConfirmBluetoothAccess')}</Text>
                    </View> */}
						<View style={LicenseAgreementModalStyles.checkboxContainer}>
							<View style={LicenseAgreementModalStyles.main}>
								<TouchableOpacity
									onPress={() =>
										isChecked2 === false
											? setIsChecked2(true)
											: setIsChecked2(false)
									}>
									<View style={LicenseAgreementModalStyles.wrapper}>
										<View style={LicenseAgreementModalStyles.radio}>
											{isChecked2 === true ? (
												<View style={LicenseAgreementModalStyles.radioBG} />
											) : null}
										</View>
									</View>
								</TouchableOpacity>
							</View>
							<Text style={LicenseAgreementModalStyles.checkboxText}>
								{t('msgPersonalinfoProcessed')}{' '}
								<Text
									style={LicenseAgreementModalStyles.linkText}
									onPress={() => handleLinkPress('PrivacyPolicy')}>
									{LabelHoneywellPrivacyStatement}
								</Text>
							</Text>
						</View>
						{/* <View style={LicenseAgreementModalStyles.horizontalLine} />
                    <View style={LicenseAgreementModalStyles.buttonRow}>
                        <Pressable style={[LicenseAgreementModalStyles.button, LicenseAgreementModalStyles.buttonDECLINE]} onPress={() => declineLicense()}>
                            <Text style={LicenseAgreementModalStyles.buttonDECLINEText}>DECLINE</Text>
                        </Pressable>
                        <Pressable style={[LicenseAgreementModalStyles.button, LicenseAgreementModalStyles.buttonACCEPT, { opacity: isChecked1 && isChecked2 ? 1 : 0.4 }]} onPress={() => acceptLicense()} disabled={!isChecked1 || !isChecked2}>
                            <Text style={LicenseAgreementModalStyles.buttonACCEPTText}>ACCEPT</Text>
                        </Pressable>
                    </View> */}
						<DoubleButtonFooter
							leftButtonText={t('lblDECLINE')}
							rightButtonText={t('ACCEPT')}
							onLeftButtonPress={() => declineLicense()}
							onRightButtonPress={() => acceptLicense()}
							// rightButtonDisabled={isChecked1 && isChecked2 ? false : true}
							rightButtonDisabled={isChecked1 && isChecked2 ? false : true}
						/>
					</View>
				</View>
			</ImageBackground>
		</Modal>
	);
};

export default LicenseAgreementModal;
