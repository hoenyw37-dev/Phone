import { StyleSheet } from 'react-native';
import { commonColors, commonSizes } from '@styles/base';

const LicenseAgreementModalStyles = StyleSheet.create({
	modalContainer: {
		flex: 1,
		justifyContent: 'center',
		alignItems: 'center',
	},
	modalContent: {
		width: '80%',
		flexDirection: 'column',
		alignItems: 'center',
		padding: '2%',
		backgroundColor: 'white',
		borderRadius: commonSizes.cornerRadius,
	},
	titleText: {
		fontSize: commonSizes.textSizeXL,
		fontWeight: '900',
		color: commonColors.textColor_Black,
	},
	horizontalLine: {
		width: '100%',
		height: commonSizes.lineThickness,
		backgroundColor: commonColors.lineColor, // Adjust the color as needed
	},
	checkboxContainer: {
		flexDirection: 'row',
		marginTop: '5%',
		// alignSelf: 'flex-start',
		alignItems: 'center',
	},
	checkboxText: {
		flexShrink: 1,
		color: commonColors.textColor_Black,
		fontSize: commonSizes.textSizeM,
		marginLeft: commonSizes.widthM_Pixel,
	},
	privacyTextContainer: {
		marginTop: '5%',
		marginBottom: '5%',
	},
	privacyText: {
		textAlign: 'center',
		color: commonColors.textColor_Black,
		fontSize: commonSizes.textSizeM,
	},
	linkText: {
		color: 'blue',
		textDecorationLine: 'underline',
		fontSize: commonSizes.textSizeM,
	},
	backgroudImageContainer: {
		flex: 1,
		resizeMode: 'cover',
	},
	main: {
		alignItems: 'center',
		justifyContent: 'center',
	},
	wrapper: {
		flexDirection: 'row',
		alignItems: 'center',
	},
	radio: {
		height: commonSizes.textSizeXL,
		width: commonSizes.textSizeXL,
		// borderRadius: commonSizes.textSizeL,
		borderWidth: commonSizes.lineThickness,
		borderColor: commonColors.lineColor,
		alignItems: 'center',
		justifyContent: 'center',
	},
	radioBG: {
		width: commonSizes.textSizeM,
		height: commonSizes.textSizeM,
		// borderRadius: commonSizes.textSizeS,
		backgroundColor: commonColors.backgroundColor_Blue,
	},
});

export { LicenseAgreementModalStyles };
