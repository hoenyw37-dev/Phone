export class ProjectValidationError extends Error {
	constructor(
		message: string,
		public code: 'MAX_PROJECTS_EXCEEDED' | 'DUPLICATE_PROJECT_NAME',
	) {
		super(message);
		this.name = 'ProjectValidationError';
		Object.setPrototypeOf(this, ProjectValidationError.prototype);
	}
}
