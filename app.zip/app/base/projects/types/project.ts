export type Project = {
	projectId: number;
	projectName: string;
	customer?: string;
	site?: string;
	building?: string;
	primaryContact?: string;
	updatedAt?: Date;
};
