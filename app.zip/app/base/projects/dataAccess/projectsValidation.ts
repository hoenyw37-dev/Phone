import { DataSource } from 'typeorm';
import { ProjectEntity } from './projectEntity';
import { ProjectValidationError } from '../types/project.errors';

const MAX_PROJECTS = 100;

export const validateProjectCount = async (
	dataSource: DataSource,
): Promise<void> => {
	const projectCount = await dataSource.manager.count(ProjectEntity);
	if (projectCount >= MAX_PROJECTS) {
		throw new ProjectValidationError(
			`Maximum limit of ${MAX_PROJECTS} projects reached`,
			'MAX_PROJECTS_EXCEEDED',
		);
	}
};

export const validateProjectNameDistinct = async (
	dataSource: DataSource,
	projectName: string,
): Promise<void> => {
	const existingProject = await dataSource.manager.findOne(ProjectEntity, {
		where: { projectName: projectName },
	});
	if (existingProject) {
		throw new ProjectValidationError(
			`Project with name "${projectName}" already exists.`,
			'DUPLICATE_PROJECT_NAME',
		);
	}
};
