import { DataSource } from 'typeorm';
import { ProjectEntity } from './projectEntity';
import {
	convertProjectEntityToProject,
	convertProjectToProjectEntity,
} from './projectConversion';
import { Project } from '../types/project';
import {
	validateProjectCount,
	validateProjectNameDistinct,
} from './projectsValidation';

export const getAllProjects = async (
	dataSource: DataSource,
): Promise<Project[]> => {
	console.log('LOADING PROJECT');
	const rawresult = await dataSource.manager.find(ProjectEntity);
	const result = rawresult.map(convertProjectEntityToProject);
	return result;
};

export const addProject = async (
	dataSource: DataSource,
	project: Project,
): Promise<Project> => {
	await validateProjectCount(dataSource);
	await validateProjectNameDistinct(dataSource, project.projectName);

	const projectEntity = convertProjectToProjectEntity(project);
	//console.log(projectEntity);
	const newProjEnt = await dataSource.manager.save(
		ProjectEntity,
		projectEntity,
	);
	const newProj = convertProjectEntityToProject(newProjEnt);
	//console.log('........', newProj);
	return newProj;
};

export const updateProject = async (
	dataSource: DataSource,
	projectId: number,
	updates: Partial<Project>,
): Promise<Boolean> => {
	//no need to validate project name distinct here, as we are updating an existing project
	// if (updates.projectName) {
	//     await validateProjectNameDistinct(dataSource, updates.projectName);
	// }

	const projectEntity = convertProjectToProjectEntity(updates);
	console.log('UPDATED PROJECT ENTITIY...', projectEntity);
	const result = await dataSource.manager.update(
		ProjectEntity,
		projectId,
		projectEntity,
	);
	if (result.affected && result.affected > 0) {
		console.log(`Successfully updated project with ID: ${projectId}`);
		return true;
	} else {
		console.log(`Failed to update project with ID: ${projectId}`);
		return false;
	}
};

export const deleteProject = async (
	dataSource: DataSource,
	projectId: number,
): Promise<{ success: boolean }> => {
	//console.log(projectEntity);
	const result = await dataSource.manager.delete(ProjectEntity, projectId);
	if (result.affected && result.affected > 0) {
		console.log(`Successfully deleted project with ID: ${projectId}`);
		return { success: true };
	} else {
		console.log(`Failed to delete project with ID: ${projectId}`);
		return { success: false };
	}
};

/*public async create({ text }: ICreateTodoData): Promise<ProjectEntity> {
    const todo = this.ormRepository.create({
        text,
        is_toggled: false,
    });

    await this.ormRepository.save(todo);

    return todo;
}

public async toggle(id: number): Promise<void> {
    await this.ormRepository.query(
        `
  UPDATE
    todos
  SET
    is_toggled = ((is_toggled | 1) - (is_toggled & 1))
  WHERE
    id = ?;
  `,
        [id],
    );
}

public async delete(id: number): Promise<void> {
    await this.ormRepository.delete(id);
}*/
