import { ProjectEntity } from './projectEntity';
import { Project } from '../types/project';

export const convertProjectEntityToProject = (
	entity: ProjectEntity,
): Project => {
	return {
		projectId: entity.projectId,
		projectName: entity.projectName,
		customer: entity.customer || undefined, // Handling nullable fields
		site: entity.site || undefined,
		building: entity.building || undefined,
		primaryContact: entity.primaryContact || undefined,
		updatedAt: entity.updatedAt ? new Date(entity.updatedAt) : undefined, // Ensure updatedAt is a Date object
	};
};

export const convertProjectToProjectEntity = (
	project: Project,
): ProjectEntity => {
	const entity = new ProjectEntity();
	if (project.projectId) {
		entity.projectId = project.projectId;
	}
	entity.projectName = project.projectName;
	entity.customer = project.customer || null;
	entity.site = project.site || null;
	entity.building = project.building || null;
	entity.primaryContact = project.primaryContact || null;
	entity.updatedAt = project.updatedAt
		? new Date(project.updatedAt)
		: undefined;
	return entity;
};
