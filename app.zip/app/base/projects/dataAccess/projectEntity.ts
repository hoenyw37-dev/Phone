import {
	Entity,
	Column,
	PrimaryGeneratedColumn,
	OneToMany,
} from 'typeorm/browser';
import { PanelEntity } from '../../../powerstrike/features/panels/dataAccess/panelEntity';

@Entity('projectsTest')
export class ProjectEntity {
	@PrimaryGeneratedColumn()
	projectId: number;

	@Column({ type: 'varchar' })
	projectName: string;

	@Column({ type: 'varchar', nullable: true })
	customer?: string | null;

	@Column({ type: 'varchar', nullable: true })
	site?: string | null;

	@Column({ type: 'varchar', nullable: true })
	building?: string | null;

	@Column({ type: 'varchar', nullable: true })
	primaryContact?: string | null;

	@Column({ type: 'datetime', nullable: true })
	updatedAt?: Date;

	// One-to-many relationship with PanelEntity with cascade delete
	@OneToMany(() => PanelEntity, panel => panel.project, {
		cascade: true,
		onDelete: 'CASCADE',
	})
	panels: PanelEntity[];
}
