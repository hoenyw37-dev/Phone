﻿import React, { useRef } from 'react';
import { Text, View, TouchableOpacity, StyleSheet } from 'react-native';
import { Project } from '../types/project';
import TripleDotIconGrey from '@assets/images/TripleDotIconGrey.svg';
import ActionSheet, { ActionSheetRef } from 'react-native-actions-sheet';
import { commonSizes, commonStyles } from '@styles/base';
import DropdownMenu, {
	MenuOptionItem,
} from '../../../faastflex/controllers/dropdownController';
import { t } from 'i18next';

interface ProjectCardProps {
	project: Project;
	onPress: () => void;
	onDelete: () => void;
	onEdit: () => void;
}

export default function ProjectCard({
	project,
	onPress,
	onDelete,
	onEdit,
}: ProjectCardProps) {
	const menuOptions: MenuOptionItem[] = [
		{
			label: t('editproject'),
			onSelect: () => onEdit(),
		},
		{
			label: t('deleteproject'),
			onSelect: () => onDelete(),
		},
	];

	return (
		<View style={{ flex: 1 }}>
			<TouchableOpacity style={styles.box} onPress={onPress}>
				<View style={styles.content}>
					<Text style={styles.heading}>{project.projectName}</Text>
					<Text style={styles.description}>
						{project.site} | {project.building}
					</Text>
				</View>
				<View style={styles.verticalLine} />
				<View style={{ paddingHorizontal: 8 }}>
					<DropdownMenu
						menuOptions={menuOptions}
						cancelLabel={t('cancel')}
						grayIcon={true}
					/>
				</View>
			</TouchableOpacity>
		</View>
	);
}

const styles = StyleSheet.create({
	box: { ...commonStyles.box },
	content: {
		...commonStyles.boxContent,
		marginLeft: commonSizes.widthL_Pixel,
	},
	heading: { ...commonStyles.boxHeading },
	description: { ...commonStyles.boxDescription },
	verticalLine: { ...commonStyles.verticalLine },
	clickableMenu: {
		...commonStyles.boxClickableMenu,
		marginHorizontal: commonSizes.widthM_Pixel,
	},
	actionSheetContainer: {
		padding: 20,
	},
	actionSheetOption: {
		paddingVertical: 8,
		borderBottomColor: '#eee',
	},
	actionSheetText: {
		fontSize: 18,
		textAlign: 'center',
	},
	deleteText: {
		color: 'red',
	},
});
