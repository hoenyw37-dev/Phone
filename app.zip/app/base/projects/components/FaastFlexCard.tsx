import React from 'react';
import { Text, View, TouchableOpacity, StyleSheet } from 'react-native';
import PowerstrikeIcon from '@powerstrike/assets/PowerstrikeIcon.svg';
import AddIconBlue from '@assets/images/AddIconBlue.svg';
import NextArrowIconBlue from '@assets/images/NextArrowIconBlue.svg';
import { commonColors, commonSizes, commonStyles } from '@styles/base';
import { responsiveFontSize } from '@global/responsiveUI';
import PanelIcon from '@assets/images/PanelIcon.svg';
import { useTranslation } from 'react-i18next';

export default function FaastFlexCard({ data, updatedAt, onPress }) {
	const { t } = useTranslation();

	const handlePress = () => {
		onPress(false);
	};

	const handleAddNewpress = () => {
		onPress(true);
	};

	const options = {
		year: 'numeric' as const,
		month: 'long' as const,
		day: 'numeric' as const,
	};

	return (
		<TouchableOpacity style={styles.box} onPress={handlePress}>
			<View
				style={[
					styles.powerstrikeIcon,
					{
						marginRight: commonSizes.widthXS_Pixel,
						marginBottom: commonSizes.heightS_Pixel,
					},
				]}>
				<PanelIcon
					width={responsiveFontSize(5.5)}
					height={responsiveFontSize(5.5)}
				/>
			</View>
			<View style={styles.content}>
				<Text style={styles.heading}>{data}</Text>
				<Text style={styles.description}>
					{t('LastConfigured')}:{' '}
					{updatedAt
						? updatedAt.toLocaleString(undefined, options)
						: t('NotConfiguredYet')}
				</Text>
				<TouchableOpacity style={styles.addNewRow} onPress={handleAddNewpress}>
					<AddIconBlue
						width={commonSizes.iconWidthM_Pixel}
						height={commonSizes.iconHeightM_Pixel}
					/>
					<Text style={styles.addNewText}>{t('Add New')}</Text>
				</TouchableOpacity>
			</View>
			<View style={styles.verticalLine} />
			<View style={{ marginHorizontal: commonSizes.widthM_Pixel }}>
				<NextArrowIconBlue
					width={commonSizes.iconWidthM_Pixel}
					height={commonSizes.iconHeightM_Pixel}
				/>
			</View>
		</TouchableOpacity>
	);
}

const styles = StyleSheet.create({
	box: { ...commonStyles.box },
	content: { ...commonStyles.boxContent },
	heading: { ...commonStyles.boxHeading },
	description: { ...commonStyles.boxDescription, marginTop: 0 },
	verticalLine: { ...commonStyles.verticalLine },
	addNewRow: {
		flexDirection: 'row',
		alignItems: 'center',
		marginLeft: commonSizes.widthM_Pixel,
		marginTop: commonSizes.heightXS_Pixel,
		marginBottom: commonSizes.heightM_Pixel,
	},
	addNewText: {
		fontSize: commonSizes.textSizeM,
		color: commonColors.textColor_Blue,
		fontWeight: '500',
	},
	powerstrikeIcon: {
		...commonStyles.boxIcon,
	},
});
