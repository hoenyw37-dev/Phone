import React from 'react';
import { Text, View, TouchableOpacity, StyleSheet } from 'react-native';
import PowerstrikeIcon from '@powerstrike/assets/PowerstrikeIcon.svg';
import AddIconBlue from '@assets/images/AddIconBlue.svg';
import NextArrowIconBlue from '@assets/images/NextArrowIconBlue.svg';
import { commonColors, commonSizes, commonStyles } from '@styles/base';
import { responsiveFontSize } from '@global/responsiveUI';

export default function AppCard({ data, updatedAt, onPress }) {
	const handlePress = () => {
		onPress(false);
	};

	const handleAddNewpress = () => {
		onPress(true);
	};
	const options = {
		year: 'numeric' as const,
		month: 'long' as const,
		day: 'numeric' as const,
		//hour: '2-digit',
		//minute: '2-digit',
		//second: '2-digit',
	};

	return (
		<TouchableOpacity style={styles.box} onPress={handlePress}>
			<View style={styles.powerstrikeIcon}>
				<PowerstrikeIcon
					width={commonSizes.iconWidthXL_Pixel}
					height={commonSizes.iconHeightXL_Pixel}
				/>
			</View>
			<View style={styles.content}>
				<Text style={styles.heading}>{data}</Text>
				<Text style={styles.description}>
					Last Configured:{' '}
					{updatedAt
						? updatedAt.toLocaleString(undefined, options)
						: 'Not Yet Configured'}
				</Text>
				<TouchableOpacity style={styles.addNewRow} onPress={handleAddNewpress}>
					<AddIconBlue
						width={commonSizes.iconWidthM_Pixel}
						height={commonSizes.iconHeightM_Pixel}
					/>
					<Text style={styles.addNewText}>Add New Panel</Text>
				</TouchableOpacity>
			</View>
			<View style={styles.verticalLine} />
			<View style={{ marginHorizontal: commonSizes.widthM_Pixel }}>
				<NextArrowIconBlue
					width={commonSizes.iconWidthM_Pixel}
					height={commonSizes.iconHeightM_Pixel}
				/>
			</View>
		</TouchableOpacity>
	);
}

const styles = StyleSheet.create({
	box: { ...commonStyles.box },
	content: { ...commonStyles.boxContent },
	heading: { ...commonStyles.boxHeading },
	description: { ...commonStyles.boxDescription, marginTop: 0 },
	verticalLine: { ...commonStyles.verticalLine },
	addNewRow: {
		flexDirection: 'row',
		alignItems: 'center',
		marginLeft: commonSizes.widthM_Pixel,
		marginTop: commonSizes.heightXS_Pixel,
		marginBottom: commonSizes.heightM_Pixel,
	},
	addNewText: {
		fontSize: commonSizes.textSizeM,
		color: commonColors.textColor_Blue,
		fontWeight: '500',
	},
	powerstrikeIcon: {
		...commonStyles.boxIcon,
	},
});
