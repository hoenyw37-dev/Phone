import {
	createEntityAdapter,
	createSlice,
	EntityState,
} from '@reduxjs/toolkit';
import { RootState } from '../../../../global/store';
import { Project } from '../types/project';
import {
	fetchProjects,
	addNewProject,
	deleteProjectWithId,
	updateExistingProject,
} from './projectsThunk';

interface ProjectsState extends EntityState<Project, number> {
	status: 'idle' | 'pending' | 'succeeded' | 'rejected';
	error: string | null;
}

const projectsAdapter = createEntityAdapter({
	selectId: (project: Project) => project.projectId,
	sortComparer: (a, b) => a.projectName.localeCompare(b.projectName),
});

const initialState: ProjectsState = projectsAdapter.getInitialState({
	status: 'idle',
	error: null,
});

export const projectsSlice = createSlice({
	name: 'projects',
	initialState,
	reducers: {
		projectAdded: projectsAdapter.addOne,
		projectsReceived(state, action) {
			projectsAdapter.setAll(state, action.payload.books);
		},
	},
	extraReducers: builder => {
		builder
			.addCase(fetchProjects.pending, state => {
				state.status = 'pending';
			})
			.addCase(fetchProjects.fulfilled, (state, action) => {
				state.status = 'succeeded';
				projectsAdapter.setAll(state, action.payload);
				console.log('project fecthing completed');
			})
			.addCase(fetchProjects.rejected, (state, action) => {
				state.status = 'rejected';
				state.error = action.error.message ?? 'Unknown Error';
			})
			.addCase(addNewProject.fulfilled, projectsAdapter.addOne)
			.addCase(deleteProjectWithId.fulfilled, projectsAdapter.removeOne)
			.addCase(updateExistingProject.fulfilled, (state, action) => {
				const { projectId, updates } = action.payload;
				projectsAdapter.updateOne(state, {
					id: projectId,
					changes: updates,
				});
			});
	},
});

export const { selectAll: selectAllProjects, selectById: selectProjectById } =
	projectsAdapter.getSelectors((state: RootState) => state.projects);

export const { projectsReceived, projectAdded } = projectsSlice.actions;

export const selectProjectsStatus = (state: RootState) => state.projects.status;
export const selectProjectsError = (state: RootState) => state.projects.error;

export default projectsSlice.reducer;
