//import { createAppAsyncThunk } from '../../../../global/store';
import { createAsyncThunk } from '@reduxjs/toolkit';
import {
	getAllProjects,
	addProject,
	deleteProject,
	updateProject,
} from '../dataAccess/projectsRepo';
import { DataSource } from 'typeorm/browser';
import { Project } from '../types/project';
import { ProjectValidationError } from '../types/project.errors';

export const fetchProjects = createAsyncThunk(
	'projects/fetchProjects',
	async (dataSource: DataSource) => {
		//console.log('fetching thunks...', dataSource);
		const result = await getAllProjects(dataSource);
		console.log('fetched projects');
		console.log(result);
		return result;
	},
	/*{
        condition(arg, thunkApi) {
            const postsStatus = selectPostsStatus(thunkApi.getState())
            if (postsStatus !== 'idle') {
                return false
            }
        },
    },*/
);

export const addNewProject = createAsyncThunk(
	'projects/addNewProject',
	async (
		{ dataSource, project }: { dataSource: DataSource; project: Project },
		{ rejectWithValue },
	) => {
		try {
			const result = await addProject(dataSource, project);
			console.log('added projects');
			console.log(result);
			return result;
		} catch (error) {
			if (error instanceof ProjectValidationError) {
				console.log('project validation error........', error);
				return rejectWithValue({
					message: error.message,
					code: error.code,
				});
			}
		}
	},
);

export const updateExistingProject = createAsyncThunk(
	'projects/updateExistingProject',
	async (
		{
			dataSource,
			projectId,
			updates,
		}: {
			dataSource: DataSource;
			projectId: number;
			updates: Partial<Project>;
		},
		{ rejectWithValue },
	) => {
		//console.log('doing project updates', projectId, updates);
		try {
			const result = await updateProject(dataSource, projectId, updates);
			console.log('updated project complete...', result);
			if (result) {
				return { projectId, updates };
			} else {
				throw new Error(`Failed to update project with ID: ${projectId}`);
			}
		} catch (error) {
			if (error instanceof ProjectValidationError) {
				console.log('project validation error........', error);
				return rejectWithValue({
					message: error.message,
					code: error.code,
				});
			}
		}
	},
);

export const deleteProjectWithId = createAsyncThunk(
	'projects/deleteProjectWithId',
	async ({
		dataSource,
		projectId,
	}: {
		dataSource: DataSource;
		projectId: number;
	}) => {
		const deleteResult = await deleteProject(dataSource, projectId);
		if (deleteResult.success) {
			return projectId;
		} else {
			throw new Error(`Failed to delete project with ID: ${projectId}`);
		}
	},
);
