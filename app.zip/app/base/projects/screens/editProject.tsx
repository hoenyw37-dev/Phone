import React, { useEffect } from 'react';
import {
	View,
	StyleSheet,
	ScrollView,
	TouchableOpacity,
	Text,
} from 'react-native';
import { useForm } from 'react-hook-form';
import { yupResolver } from '@hookform/resolvers/yup';
import * as Yup from 'yup';
import { useSelector } from 'react-redux';

import { AppStore } from '../../../../global/store';
import { useAppDispatch } from '../../../../global/hooks';
import { selectProjectById } from '../redux/projectsSlice';
import TextInputField from '../../../../components/textInputField';
import DoubleButtonFooter from '../../../../components/doubleButtonFooter';
import { updateExistingProject } from '../redux/projectsThunk';
import { useDatabase } from '../../../../global/DatabaseContext';
import { Project } from '../types/project';
import { commonColors, commonSizes } from '@styles/base';
import Toast from 'react-native-toast-message';
import { t } from 'i18next';
import { SafeAreaView } from 'react-native-safe-area-context';
import LeftArrowWhite from '@assets/images/LeftArrowWhite.svg';

const maxLength = 50;

// Define Yup validation schema
const projectSchema = Yup.object().shape({
	projectName: Yup.string()
		.required(t('CreateProjectErrorMsg'))
		.max(maxLength, 'Project name cannot exceed 50 characters'),
	//customer: Yup.string().optional().max(maxLength, 'Customer name cannot exceed 50 characters'),
	site: Yup.string()
		.optional()
		.max(maxLength, 'Site name cannot exceed 50 characters'),
	building: Yup.string()
		.optional()
		.max(maxLength, 'Building name cannot exceed 50 characters'),
	//primaryContact: Yup.string().optional().max(maxLength, 'Primary Contact cannot exceed 50 characters'),
});

export default function ProjectForm({ navigation, route }) {
	const { projectId } = route.params;
	const project: Project = useSelector((state: AppStore) =>
		selectProjectById(state, projectId),
	);

	const {
		control,
		handleSubmit,
		formState: { errors },
	} = useForm<Project>({
		resolver: yupResolver(projectSchema),
		defaultValues: {
			projectName: project.projectName || '',
			//customer: project.customer || '',
			site: project.site || '',
			building: project.building || '',
			//primaryContact: project.primaryContact || '',
		},
	});

	const dispatch = useAppDispatch();

	const { dataSource } = useDatabase();

	const cancel = () => {
		console.log('cancelling...');
		navigation.goBack();
	};

	const onSubmit = async (updatedProject: Project) => {
		//console.log('updatedProject...............', updatedProject);
		const resultAction = await dispatch(
			updateExistingProject({
				dataSource,
				projectId: project.projectId,
				updates: updatedProject,
			}),
		);
		console.log('111111111111111111', resultAction);
		if (updateExistingProject.fulfilled.match(resultAction)) {
			const newProject = resultAction.payload;
			//After updating the project, navigate to the ProjectList screen with the updated project
			navigation.navigate('ProjectList');
		} else if (updateExistingProject.rejected.match(resultAction)) {
			//console.error('Failed to add the project:', resultAction.error);
			const error = resultAction.payload as {
				code?: string;
				message?: string;
			};
			if (error.code) {
				Toast.show({
					type: 'error',
					text1: error.message,
					visibilityTime: 2500,
				});
			}
		}
	};

	return (
		<View style={styles.mainContainer}>
			<SafeAreaView edges={['top']} style={styles.safeHeader}>
				<View
					style={[
						styles.headerSection,
						{
							backgroundColor: '#000',
							alignItems: 'center',
						},
					]}>
					<View
						style={{
							flexDirection: 'row',
							alignItems: 'center',
							paddingHorizontal: 10,
							height: '100%',
						}}>
						<TouchableOpacity
							onPress={() => cancel()}
							style={{
								height: '100%',
								padding: 0,
								margin: 0,
								justifyContent: 'center',
							}}>
							<LeftArrowWhite height={30} width={30} />
						</TouchableOpacity>
						<View style={[{ flex: 2 }]}>
							<Text
								style={{
									color: '#fff',
									fontSize: 18,
									fontWeight: 'bold',
									textAlign: 'center',
								}}>
								Edit Project
							</Text>
						</View>
					</View>
				</View>
			</SafeAreaView>
			<View style={styles.contentSection}>
				<ScrollView contentContainerStyle={styles.scrollContainer}>
					<TextInputField
						name='projectName'
						control={control}
						placeholder={t('enterProjectName')}
						title={t('projectName')}
						isRequired={true}
						errorMessage={errors.projectName?.message}
						maxChar={maxLength}
					/>
					{/*<TextInputField
                    name="customer"
                    control={control}
                    placeholder="Enter Customer"
                    title="Customer"
                    errorMessage={errors.customer?.message}
                    maxChar={maxLength}
                />*/}
					<TextInputField
						name='site'
						control={control}
						placeholder={t('Entersitelocation')}
						title={t('SiteLocation')}
						errorMessage={errors.site?.message}
						maxChar={maxLength}
					/>
					<TextInputField
						name='building'
						control={control}
						placeholder={t('EnterBuildingName')}
						title={t('buildingname')}
						errorMessage={errors.building?.message}
						maxChar={maxLength}
					/>
					{/*<TextInputField
                    name="primaryContact"
                    control={control}
                    placeholder="Enter Primary Contact"
                    title="Primary Contact"
                    errorMessage={errors.primaryContact?.message}
                    maxChar={maxLength}
                />*/}
				</ScrollView>
				<View
					style={{
						borderTopColor: commonColors.lineColor,
						borderTopWidth: commonSizes.lineThicknessS,
						backgroundColor: commonColors.backgroundColor_White,
					}}>
					<View style={{ marginHorizontal: '2%' }}>
						<DoubleButtonFooter
							leftButtonText={t('cancel')}
							rightButtonText={t('update')}
							onLeftButtonPress={() => cancel()}
							onRightButtonPress={handleSubmit(onSubmit)}
						/>
					</View>
				</View>
			</View>
		</View>
	);
}

const styles = StyleSheet.create({
	mainContainer: {
		flex: 1,
		backgroundColor: '#f5f5f5',
	},
	safeHeader: {
		backgroundColor: '#000',
	},
	headerSection: {
		backgroundColor: '#000',
		height: 56,
		width: '100%',
	},
	contentSection: {
		flex: 1,
		width: '100%',
	},
	container: {
		flex: 1,
		// justifyContent: 'space-evenly',
		backgroundColor: '#FFFFFF',
	},
	scrollContainer: {
		paddingHorizontal: commonSizes.paddingXL_Percent,
		paddingTop: commonSizes.paddingXL_Percent,
	},
});
