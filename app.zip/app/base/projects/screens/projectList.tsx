import React, {
	View,
	ScrollView,
	StyleSheet,
	ActivityIndicator,
	TouchableOpacity,
	Text,
	BackHandler,
	Alert,
} from 'react-native';
import { useEffect, useCallback, useState } from 'react';
import { SafeAreaView } from 'react-native-safe-area-context';

import ProjectCard from '../components/projectCard';
import {
	selectAllProjects,
	selectProjectsStatus,
	selectProjectsError,
} from '../redux/projectsSlice';
import { useAppDispatch, useAppSelector } from '../../../../global/hooks';
import { fetchProjects, deleteProjectWithId } from '../redux/projectsThunk';
import { useDatabase } from '../../../../global/DatabaseContext';
import InfoCard from '@components/InfoCard';
import HeaderRight from '@global/navigation/RightHeaderButtons';
import ConfirmationModal from '@components/confirmationModal';
//import { commonColors, commonSizes } from '@styles/base';
import Toast from 'react-native-toast-message';
import { useAuth } from '@base/auth/authContext';
import LeftArrowWhite from '@assets/images/LeftArrowWhite.svg';
import DropdownMenu from '@ff_controllers/dropdownController';
import { useTranslation } from 'react-i18next';
import { confirmAlert } from '@app/faastflex/utils/confirmAlert';
import AddIconWhite from '@assets/images/AddIconWhite.svg';
import { useLoading } from '@global/GlobalContext/LoadingContext';
import { fetchDevicesByProjectId } from '@app/faastflex/redux/deviceRedux/devicesThunk';
import { delay } from '@app/faastflex/utils/timeDelay';
import stringFormat from '@app/faastflex/utils/stringFormat';

export default function ProjectList({ navigation }: any) {
	const [confirmationModal, setConfirmationModal] = useState(false);
	const [confirmationId, setConfirmationId] = useState(-1);
	const [confirmationName, setConfirmationName] = useState('');
	const [signOutConfirmation, setSignOutConfirmation] = useState(false);
	const { showLoadingIndicator, hideLoadingIndicator } = useLoading();

	const dispatch = useAppDispatch();
	const { t } = useTranslation();
	const { dataSource } = useDatabase(); // Access the database instance from context
	const { isAuthenticated, logout } = useAuth();
	useEffect(() => {
		if (!isAuthenticated) {
			//navigation.replace('LoginScreen');
		}
	}, [isAuthenticated, navigation]);

	console.log('PROJECTLIST.........');

	const projects = useAppSelector(selectAllProjects);
	const projectsStatus = useAppSelector(selectProjectsStatus);
	const projectsError = useAppSelector(selectProjectsError);

	// Function to load data and fetch projects
	const loadData = useCallback(async () => {
		try {
			await dispatch(fetchProjects(dataSource)); // Pass the DB instance to the Redux thunk
			//await dataSource.dropDatabase(); //IMP - WHOLE DATABASE WILL BE CLEARED
		} catch (error) {
			console.error('Error while fetching projects:', error);
		}
	}, []);

	useEffect(() => {
		if (dataSource) {
			loadData(); // Call loadData when the component mounts
		}
	}, [loadData, dataSource]);

	const addProject = () => {
		console.log('adding project in next screen');
		navigation.navigate('AddProject');
	};

	const editProject = (projectId: number) => {
		console.log('editing project in next screen');
		navigation.navigate('EditProject', { projectId: projectId });
	};

	const openProject = (projectId: number) => {
		console.log('opening project...', projectId);
		navigation.navigate('ProjectHome', { projectId: projectId });
	};

	const handleDeleteRequest = async (
		projectId: number,
		projectName: string,
	) => {
		try {
			showLoadingIndicator();
			const devicesfromdb = await dispatch(
				fetchDevicesByProjectId({ dataSource, projectId }),
			).unwrap();
			await delay(100);
			hideLoadingIndicator();
			if (devicesfromdb && devicesfromdb.length > 0) {
				Alert.alert(t('Error'), t('ProjectDeleteError'), [{ text: t('ok') }]);
			} else {
				setConfirmationId(projectId);
				setConfirmationModal(true);
				setConfirmationName(projectName);
			}
		} catch (error) {
			hideLoadingIndicator();
			console.error('Failed to fetch devices for the project:', error);
		}
	};

	const confirmDelete = () => {
		if (confirmationId === -1) {
			console.log('No project selected for deletion');
			return;
		} else {
			setConfirmationModal(false);
			deleteProject(confirmationId);
		}
	};

	const cancelDelete = () => {
		setConfirmationModal(false);
		setConfirmationId(-1);
		setConfirmationName('');
	};

	const deleteProject = async (projectId: number) => {
		console.log('deleting project...', projectId);

		const resultAction = await dispatch(
			deleteProjectWithId({ dataSource, projectId }),
		);

		if (deleteProjectWithId.fulfilled.match(resultAction)) {
			Toast.show({
				type: 'success',
				position: 'bottom',
				text1: 'Project deleted successfully',
				visibilityTime: 2500,
			});
		} else {
			console.error('Failed to delete the project:', resultAction.error);
			Toast.show({
				type: 'error',
				position: 'bottom',
				text1: 'Failed to delete the project',
				visibilityTime: 2500,
			});
		}
	};

	const renderContent = () => {
		switch (projectsStatus) {
			case 'pending':
				return <ActivityIndicator size='large' color='#0000ff' />;

			case 'succeeded':
				return (
					<ScrollView>
						{projects?.length > 0 ? (
							projects.map(element => (
								<View key={element.projectId}>
									<ProjectCard
										project={element}
										onPress={() => openProject(element.projectId)}
										onDelete={() =>
											handleDeleteRequest(
												element.projectId,
												element.projectName,
											)
										}
										onEdit={() => editProject(element.projectId)}
									/>
								</View>
							))
						) : (
							<InfoCard
								heading='No Projects Found.'
								description="Tap the 'add icon' to start a new project"
							/>
						)}
					</ScrollView>
				);

			case 'rejected':
				return <div>{projectsError}</div>;

			default:
				return null;
		}
	};

	async function handleBackPress() {
		const confirmResult = await confirmAlert(
			t('Closeappquestion'),
			t('CloseApp'),
			t('close'),
			t('cancel'),
		);
		if (confirmResult) {
			BackHandler.exitApp();
		}
	}
	return (
		<View style={styles.container}>
			<ConfirmationModal
				visible={confirmationModal}
				onClose={cancelDelete}
				onProceed={confirmDelete}
				title={t('deleteproject')}
				description={stringFormat(
					t('DeleteProjectConfirmation'),
					confirmationName,
				)}
				leftButtonText={t('cancel')}
				rightButtonText={t('delete')}
			/>
			<ConfirmationModal
				visible={signOutConfirmation}
				onClose={() => setSignOutConfirmation(false)}
				onProceed={logout}
				title='Sign Out'
				description={'Are you sure you want to Sign out of this account?'}
				leftButtonText='CANCEL'
				rightButtonText='SIGN OUT'
			/>
			<SafeAreaView edges={['top']} style={styles.safeHeader}>
				<View
					style={[
						styles.headerSection,
						{
							backgroundColor: '#000',
							alignItems: 'center',
						},
					]}>
					<View
						style={{
							flexDirection: 'row',
							alignItems: 'center',
							paddingHorizontal: 10,
							height: '100%',
						}}>
						<TouchableOpacity
							onPress={() => handleBackPress()}
							style={{
								height: '100%',
								padding: 0,
								margin: 0,
								justifyContent: 'center',
							}}>
							<LeftArrowWhite height={30} width={30} />
						</TouchableOpacity>

						<View style={[{ flex: 2 }]}>
							<Text
								style={{
									color: '#fff',
									fontSize: 18,
									fontWeight: 'bold',
									textAlign: 'center',
								}}>
								{t('yourProjects')}
							</Text>
						</View>

						<TouchableOpacity
							onPress={() => addProject()}
							style={{
								height: '100%',
								padding: 0,
								margin: 0,
								paddingRight: 10,
								justifyContent: 'center',
							}}>
							<AddIconWhite />
						</TouchableOpacity>

						<DropdownMenu
							triggerText=''
							menuOptions={[
								{
									label: t('aboutus'),
									onSelect: () => navigation.navigate('AboutUs'),
								},
								{
									label: t('contactus'),
									onSelect: () => navigation.navigate('ContactUs'),
								},
								{
									label: t('lang'),
									onSelect: () => navigation.navigate('LanguageSelector'),
								},
								{
									label: t('EULA'),
									onSelect: () =>
										navigation.navigate('TermsAndConditions', {
											fileName: 'EULA',
										}),
								},
								{
									label: t('privacystatement'),
									onSelect: () =>
										navigation.navigate('TermsAndConditions', {
											fileName: 'PrivacyPolicy',
										}),
								},
								// { label: t('Sign Out'), onSelect: () => setSignOutConfirmation(true) },
							]}
							triggerTextStyle={styles.buttonText}
						/>
					</View>
				</View>
			</SafeAreaView>
			<View style={styles.content}>{renderContent()}</View>
			{/*<SingleButtonFooter
        buttonText="Add New Project"
        onButtonPress={addProject}
        containerStyle={styles.footer}
        />*/}
		</View>
	);
}

const styles = StyleSheet.create({
	container: {
		flex: 1,
	},
	content: {
		flex: 1,
		justifyContent: 'center',
	},
	camera: {
		flex: 1,
		width: '100%',
		height: 300, // Adjust height as needed
	},
	headerSection: {
		backgroundColor: '#000',
		height: 56,
		width: '100%',
	},
	safeHeader: {
		backgroundColor: '#000',
	},
	buttonText: {
		color: '#000000',
		fontSize: 14,
		textAlign: 'center',
	},
});
