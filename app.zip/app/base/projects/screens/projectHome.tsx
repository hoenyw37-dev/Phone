import React, { useCallback, useEffect } from 'react';
import {
	Text,
	View,
	StyleSheet,
	BackHandler,
	ScrollView,
	TouchableOpacity,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useSelector } from 'react-redux';
import { HeaderBackButton } from '@react-navigation/elements';

import { selectProjectById } from '../redux/projectsSlice';
import { Project } from '../types/project';
import { AppStore } from '../../../../global/store';
import { commonColors, commonSizes, dimensions } from '../../../../styles/base';
import AppCard from '../components/appCard';
import ProjectHomeImage from '@assets/images/ProjectHomeImage.svg';
import Test from '@assets/images/Test.svg';
import { useDatabase } from '@global/DatabaseContext';
import { useAppDispatch, useAppSelector } from '@global/hooks';
import { fetchPanelsByProject } from '@powerstrike/features/panels/redux/panelsThunk';
import {
	selectLatestUpdatedAtByProject,
	selectPanelsError,
	selectPanelsStatus,
} from '@powerstrike/features/panels/redux/panelsSlice';
import { CustomActivityIndicator } from '@components/CustomActivityIndicator';
import {
	responsiveScreenHeight,
	responsiveScreenWidth,
} from '@global/responsiveUI';
import FaastFlexCard from '../components/FaastFlexCard';
import {
	fetchDevices,
	fetchDevicesByProjectId,
} from '@ff_redux/deviceRedux/devicesThunk';
import { AppConstants } from '@global/GlobalConstants/globalConstants';
import LeftArrowWhite from '@assets/images/LeftArrowWhite.svg';

const { fullHeight, fullWidth } = dimensions;
export default function ProjectHome({ route, navigation }: any) {
	const dispatch = useAppDispatch();
	const { dataSource } = useDatabase();
	const [projectTiltle, setProjectTitle] = React.useState('');

	const { projectId } = route.params;
	const project: Project = useSelector((state: AppStore) =>
		selectProjectById(state, projectId),
	);

	const panelsStatus = useAppSelector(selectPanelsStatus);
	const panelsError = useAppSelector(selectPanelsError);
	const latestUpdatedAt = useAppSelector(state =>
		selectLatestUpdatedAtByProject(state, projectId),
	);

	const handleBackButtonPress = useCallback(() => {
		console.log('BACK BUTTON PRESSED!!!!!!!!!!!!!!');
		const { routes, index: currentIndex } = navigation.getState();

		// Get the previous route (the screen right before the current screen)
		const previousRoute = routes[currentIndex - 1];
		console.log(previousRoute);
		if (
			previousRoute?.name === 'AddProject' ||
			previousRoute?.name === 'EditProject'
		) {
			navigation.pop(2);
		} else {
			navigation.goBack();
		}

		return true; // Prevent the default hardware back button behavior (for Android)
	}, [navigation]);

	const renderHeaderLeft = useCallback(
		(props: any) => {
			console.log('rendering header left...', props);
			return <HeaderBackButton {...props} onPress={handleBackButtonPress} />;
		},
		[handleBackButtonPress],
	);

	React.useLayoutEffect(() => {
		setProjectTitle(
			project.projectName.length > 20
				? project.projectName.substring(0, 20) + '...'
				: project.projectName,
		);

		const backHandler = BackHandler.addEventListener(
			'hardwareBackPress',
			handleBackButtonPress,
		);

		// Clean up the hardware back button listener when the component unmounts
		return () => backHandler.remove();
	}, [navigation, project, renderHeaderLeft, handleBackButtonPress]);

	/*useEffect(() => {
    // Set custom back button behavior
    navigation.setOptions({
      headerLeft: (props: any) => (
        <HeaderBackButton {...props} onPress={handleBackButtonPress} />
      ),
    });

    const backHandler = BackHandler.addEventListener(
      'hardwareBackPress',
      handleBackButtonPress,
    );

    // Clean up the hardware back button listener when the component unmounts
    return () => backHandler.remove();
  }, [navigation]);*/

	const loadData = useCallback(async () => {
		try {
			//dispatch(panelsResetStatus());
			const result = await dispatch(
				fetchPanelsByProject({ dataSource, projectId }),
			);
			console.log('panels by project...........', result);
		} catch (error) {
			console.error('Error while fetching projects:', error);
		}
	}, []);

	useEffect(() => {
		if (dataSource) {
			loadData(); // Call loadData when the component mounts
		}
	}, [loadData, projectId, dataSource]);

	const openApp = (addNew: Boolean) => {
		console.log('opening Powerstrike...', addNew);
		navigation.navigate('PanelsList', {
			projectId: projectId,
			addNew: addNew,
		});
	};

	async function openFaastFlexDevices(addNewDevice: Boolean) {
		//     navigation.navigate('DeviceParameters');
		// return;
		if (addNewDevice) {
			navigation.navigate(AppConstants.CreateOrEditDeviceScreen, {
				projectId: projectId,
				isNewDevice: true,
				isFromProjectHome: true,
			});
		} else {
			const devicesfromdb = await dispatch(
				fetchDevicesByProjectId({ dataSource, projectId: projectId }),
			).unwrap();
			if (devicesfromdb && devicesfromdb != null && devicesfromdb.length > 0) {
				navigation.navigate(AppConstants.DeviceListScreen, {
					projectId: projectId,
				});
			} else {
				navigation.navigate(AppConstants.CreateOrEditDeviceScreen, {
					projectId: projectId,
					isNewDevice: true,
					isFromProjectHome: true,
				});
			}
		}
	}

	const renderContent = () => {
		switch (panelsStatus) {
			case 'pending':
				return <CustomActivityIndicator />;

			case 'succeeded':
				return (
					<View style={styles.container}>
						<AppCard
							data='PowerStrike Power Supply'
							updatedAt={latestUpdatedAt}
							onPress={openApp}
						/>
						<FaastFlexCard
							data='Faastflex Detectors'
							updatedAt={latestUpdatedAt}
							onPress={openFaastFlexDevices}
						/>
					</View>
				);

			case 'rejected':
				return <div>{panelsError}</div>;

			default:
				return null;
		}
	};

	const BackButtonCommand = () => {
		navigation.goBack();
	};

	const renderHeader = () => {
		return (
			<SafeAreaView edges={['top']} style={styles.safeHeader}>
				<View
					style={[
						styles.headerSection,
						{
							backgroundColor: '#000',
							alignItems: 'center',
						},
					]}>
					<View
						style={{
							flexDirection: 'row',
							alignItems: 'center',
							paddingHorizontal: 10,
							height: '100%',
							backgroundColor: '#000',
						}}>
						<TouchableOpacity
							onPress={() => BackButtonCommand()}
							style={{
								height: '100%',
								padding: 0,
								margin: 0,
								justifyContent: 'center',
							}}>
							<LeftArrowWhite height={30} width={30} />
						</TouchableOpacity>

						<View style={[{ flex: 2 }]}>
							<Text
								style={{
									color: '#fff',
									fontSize: 18,
									fontWeight: 'bold',
									textAlign: 'center',
								}}>
								{projectTiltle}
							</Text>
						</View>
					</View>
				</View>
			</SafeAreaView>
		);
	};

	return (
		<SafeAreaView edges={['left', 'right', 'bottom']} style={styles.safeArea}>
			{renderHeader()}
			<ScrollView>
				<View style={{ flex: 1 }}>
					<ProjectHomeImage width='100%' preserveAspectRatio='xMaxYMax slice' />
					<View style={styles.overlayText}>
						<Text style={styles.customerText}>{project.customer}</Text>
						<Text style={styles.siteBuildingText}>
							{project.site}
							{project.building ? ', ' + project.building : null}
						</Text>
					</View>
				</View>

				{renderContent()}
			</ScrollView>
		</SafeAreaView>
	);
}

const styles = StyleSheet.create({
	container: {
		flex: 1,
	},
	overlayText: {
		position: 'absolute',
		bottom: commonSizes.heightS_Pixel,
		left: commonSizes.widthM_Pixel,
	},
	customerText: {
		color: commonColors.textColor_White,
		fontWeight: '900',
		fontSize: commonSizes.textSizeM,
	},
	siteBuildingText: {
		color: commonColors.textColor_White,
		fontWeight: '400',
		fontSize: commonSizes.textSizeL,
	},
	headerSection: {
		height: 56,
		width: '100%',
	},
	safeHeader: {
		backgroundColor: '#000',
	},
	safeArea: {
		flex: 1,
		backgroundColor: '#fff',
	},
});
