import React, { useEffect } from 'react';
import {
	View,
	StyleSheet,
	ScrollView,
	TouchableOpacity,
	Text,
} from 'react-native';
import { useForm } from 'react-hook-form';
import { yupResolver } from '@hookform/resolvers/yup';
import * as Yup from 'yup';
import { useAppDispatch } from '../../../../global/hooks';

import TextInputField from '../../../../components/textInputField';
import DoubleButtonFooter from '../../../../components/doubleButtonFooter';
import { addNewProject } from '../redux/projectsThunk';
import { useDatabase } from '../../../../global/DatabaseContext';
import { Project } from '../types/project';
import HeaderRight from '@global/navigation/RightHeaderButtons';
import { commonColors, commonSizes } from '@styles/base';
import Toast from 'react-native-toast-message';
import { t } from 'i18next';
import { SafeAreaView } from 'react-native-safe-area-context';
import LeftArrowWhite from '@assets/images/LeftArrowWhite.svg';

const maxLength = 50;

// Define Yup validation schema
const projectSchema = Yup.object().shape({
	projectName: Yup.string()
		.required(t('CreateProjectErrorMsg'))
		.max(maxLength, 'Project name cannot exceed 50 characters'),
	//customer: Yup.string().optional().max(maxLength, 'Customer name cannot exceed 50 characters'),
	site: Yup.string()
		.optional()
		.max(maxLength, 'Site name cannot exceed 50 characters'),
	building: Yup.string()
		.optional()
		.max(maxLength, 'Building name cannot exceed 50 characters'),
	//primaryContact: Yup.string().optional().max(maxLength, 'Primary Contact cannot exceed 50 characters'),
});

export default function ProjectForm({ navigation }: any) {
	const {
		control,
		handleSubmit,
		formState: { errors },
		reset,
	} = useForm<Project>({
		resolver: yupResolver(projectSchema),
	});

	const dispatch = useAppDispatch();

	const { dataSource } = useDatabase();

	useEffect(() => {
		navigation.setOptions({
			headerRight: () => <HeaderRight buttons={AddProjectButtons} />,
		});
	}, [navigation]);

	const cancel = () => {
		console.log('cancelling...');
		navigation.navigate('ProjectList');
	};

	const onSubmit = async (project: Project) => {
		const resultAction = await dispatch(addNewProject({ dataSource, project }));
		//console.log('111111111111111111', resultAction);
		if (addNewProject.fulfilled.match(resultAction)) {
			const newProject = resultAction.payload;
			navigation.navigate('ProjectHome', {
				projectId: newProject.projectId,
			});
		} else if (addNewProject.rejected.match(resultAction)) {
			//console.error('Failed to add the project:', resultAction.error);
			const error = resultAction.payload as {
				code?: string;
				message?: string;
			};
			if (error.code) {
				Toast.show({
					type: 'error',
					text1: error.message,
					visibilityTime: 2500,
				});
			} else {
				Toast.show({
					type: 'error',
					text1: 'An unexpected error occurred while creating the project.',
					visibilityTime: 2500,
				});
			}
		}
	};

	const resetForm = () => {
		reset({
			projectName: '',
			customer: '',
			site: '',
			building: '',
			primaryContact: '',
		});
	};

	const AddProjectButtons = [
		{
			type: 'textButton',
			text: 'CLEAR ALL',
			onPress: resetForm,
		},
	];

	const handleBackButtonPress = () => {
		navigation.goBack();
	};
	return (
		<View style={styles.mainContainer}>
			<SafeAreaView edges={['top']} style={styles.safeHeader}>
				<View
					style={[
						styles.headerSection,
						{
							backgroundColor: '#000',
							alignItems: 'center',
						},
					]}>
					<View
						style={{
							flexDirection: 'row',
							alignItems: 'center',
							paddingHorizontal: 10,
							height: '100%',
						}}>
						<TouchableOpacity
							onPress={() => handleBackButtonPress()}
							style={{
								height: '100%',
								padding: 0,
								margin: 0,
								justifyContent: 'center',
							}}>
							<LeftArrowWhite height={30} width={30} />
						</TouchableOpacity>
						<View style={[{ flex: 2 }]}>
							<Text
								style={{
									color: '#fff',
									fontSize: 18,
									fontWeight: 'bold',
									textAlign: 'center',
								}}>
								New Project
							</Text>
						</View>
					</View>
				</View>
			</SafeAreaView>
			<View style={styles.contentSection}>
				<ScrollView contentContainerStyle={styles.scrollContainer}>
					<TextInputField
						name='projectName'
						control={control}
						placeholder={t('enterProjectName')}
						title={t('projectName')}
						isRequired={true}
						errorMessage={errors.projectName?.message}
						maxChar={maxLength}
					/>
					{/*<TextInputField
                    name="customer"
                    control={control}
                    placeholder="Enter Customer"
                    title="Customer"
                    errorMessage={errors.customer?.message}
                    maxChar={maxLength}
                />*/}
					<TextInputField
						name='site'
						control={control}
						placeholder={t('Entersitelocation')}
						title={t('SiteLocation')}
						errorMessage={errors.site?.message}
						maxChar={maxLength}
					/>
					<TextInputField
						name='building'
						control={control}
						placeholder={t('EnterBuildingName')}
						title={t('buildingname')}
						errorMessage={errors.building?.message}
						maxChar={maxLength}
					/>
					{/*<TextInputField
                    name="primaryContact"
                    control={control}
                    placeholder="Enter Primary Contact"
                    title="Primary Contact"
                    errorMessage={errors.primaryContact?.message}
                    maxChar={maxLength}
                />*/}
				</ScrollView>
				<View
					style={{
						borderTopColor: commonColors.lineColor,
						borderTopWidth: commonSizes.lineThicknessS,
						backgroundColor: commonColors.backgroundColor_White,
					}}>
					<View style={{ marginHorizontal: '2%' }}>
						<DoubleButtonFooter
							leftButtonText={t('cancel')}
							rightButtonText={t('save')}
							onLeftButtonPress={() => cancel()}
							onRightButtonPress={handleSubmit(onSubmit)}
						/>
					</View>
				</View>
			</View>
		</View>
	);
}

const styles = StyleSheet.create({
	mainContainer: {
		flex: 1,
		backgroundColor: '#f5f5f5',
	},
	safeHeader: {
		backgroundColor: '#000',
	},
	headerSection: {
		backgroundColor: '#000',
		height: 56,
		width: '100%',
	},
	contentSection: {
		flex: 1,
		width: '100%',
	},
	container: {
		flex: 1,
		justifyContent: 'space-evenly',
		backgroundColor: commonColors.backgroundColor_White,
	},
	scrollContainer: {
		// flexGrow: 1,
		paddingHorizontal: commonSizes.paddingXL_Percent,
		paddingTop: commonSizes.paddingXL_Percent,
		// gap: '50%',
	},
});
