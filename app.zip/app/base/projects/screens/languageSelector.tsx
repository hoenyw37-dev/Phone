import {
	SafeAreaView,
	StyleSheet,
	Text,
	TouchableOpacity,
	View,
} from 'react-native';
//import { Text } from 'react-native-elements';
import React, { useEffect, useState } from 'react';
//import { Picker } from '@react-native-picker/picker';
import { useTranslation } from 'react-i18next';
import { commonSizes } from '@styles/base';
import RNPickerSelect from 'react-native-picker-select';
import AsyncStorage from '@react-native-async-storage/async-storage';
import EncryptedStorage from 'react-native-encrypted-storage';
import LeftArrowWhite from '@assets/images/LeftArrowWhite.svg';

export default function LanguageSelector({ navigation }: any) {
	const [selectedLanguage, setSelectedLanguage] = useState('en');
	const { t, i18n } = useTranslation();

	useEffect(() => {
		const loadLanguage = async () => {
			try {
				const savedLanguage = await EncryptedStorage.getItem('deviceLanguage');
				if (savedLanguage) {
					setSelectedLanguage(savedLanguage);
					i18n.changeLanguage(savedLanguage);
				}
			} catch (error) {
				console.error('Failed to load language:', error);
			}
		};
		loadLanguage();
	}, []);
	const handleLanguageChange = async (itemValue: string) => {
		setSelectedLanguage(itemValue);
		i18n.changeLanguage(itemValue);
		try {
			await EncryptedStorage.setItem('deviceLanguage', itemValue);
		} catch (error) {
			console.error('Failed to save language:', error);
		}
		console.log(`Language changed to: ${itemValue}`);
	};

	const BackButtonCommand = () => {
		navigation.goBack();
	};
	const renderHeader = () => {
		return (
			<SafeAreaView>
				<View
					style={[
						styles.headerSection,
						{
							height: 56,
							backgroundColor: '#000',
							alignItems: 'center',
						},
					]}>
					<View
						style={{
							flexDirection: 'row',
							alignItems: 'center',
							paddingHorizontal: 10,
							height: '100%',
							backgroundColor: '#000',
						}}>
						<TouchableOpacity
							onPress={() => BackButtonCommand()}
							style={{
								height: '100%',
								padding: 0,
								margin: 0,
								justifyContent: 'center',
							}}>
							<LeftArrowWhite height={30} width={30} />
						</TouchableOpacity>

						<View style={[{ flex: 2 }]}>
							<Text
								style={{
									color: '#fff',
									fontSize: 18,
									fontWeight: 'bold',
									textAlign: 'center',
								}}>
								{t('lang')}
							</Text>
						</View>
					</View>
				</View>
			</SafeAreaView>
		);
	};

	return (
		<SafeAreaView style={styles.safeArea}>
			{renderHeader()}
			<View style={styles.content}>
				{/*<Text style={{ marginHorizontal: 18, marginBottom: 10, color:'#373737' }}>{t('lblLanguage')}</Text>*/}
				<View style={styles.box}>
					<Text
						style={{
							color: '#000',
							fontSize: 18,
							fontWeight: 'bold',
							textAlign: 'left',
						}}>
						{t('selectlang')}
					</Text>
					<RNPickerSelect
						placeholder={{}}
						onValueChange={itemValue => handleLanguageChange(itemValue)}
						items={[
							{ label: 'English', value: 'en' },
							{ label: 'Español - Spanish', value: 'es' },
							{ label: 'Français - French', value: 'fr' },
							{ label: 'Deutsch - German', value: 'de' },
							{ label: 'Polski - Polish', value: 'pl' },
							{ label: 'Italiano - Italian', value: 'it' },
							{ label: 'Korean (Simplified)', value: 'ko' },
							{ label: 'Chinese (Simplified)', value: 'zh' },
						]}
						style={{
							inputIOS: {
								height: 65,
								width: '100%',
								color: '#373737',
								borderWidth: 1,
								borderColor: '#373737',
								borderRadius: 8,
								paddingHorizontal: 10,
							},
							inputAndroid: {
								height: 65,
								width: '100%',
								color: '#373737',
								borderWidth: 1,
								borderColor: '#000',
								borderRadius: 8,
								paddingHorizontal: 10,
							},
						}}
						value={selectedLanguage}
					/>
				</View>
			</View>
		</SafeAreaView>
	);
}

const styles = StyleSheet.create({
	container: {
		flex: 1,
		padding: 8,
	},
	content: {
		flex: 1,
		justifyContent: 'flex-start',
	},
	box: {
		backgroundColor: '#FFFFFF',
		padding: 2,
		marginHorizontal: 16,
		borderRadius: commonSizes.cornerRadius,
		marginTop: 10,
	},
	headerSection: {
		height: '5%',
		width: '100%',
	},
	safeArea: {
		flex: 1,
		backgroundColor: '#fff',
	},
});
