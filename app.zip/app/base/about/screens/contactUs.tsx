import React from 'react';
import {
	View,
	Text,
	StyleSheet,
	Linking,
	TouchableOpacity,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import LeftArrowWhite from '@assets/images/LeftArrowWhite.svg';

export default function ContactUs({ navigation }: any) {
	return (
		<View style={styles.mainContainer}>
			<SafeAreaView edges={['top']} style={styles.safeHeader}>
				<View
					style={[
						styles.headerSection,
						{
							backgroundColor: '#000',
							alignItems: 'center',
						},
					]}>
					<View
						style={{
							flexDirection: 'row',
							alignItems: 'center',
							paddingHorizontal: 10,
							height: '100%',
						}}>
						<TouchableOpacity
							onPress={() => navigation.goBack()}
							style={{
								height: '100%',
								padding: 0,
								margin: 0,
								justifyContent: 'center',
							}}>
							<LeftArrowWhite height={30} width={30} />
						</TouchableOpacity>
						<View style={[{ flex: 2 }]}>
							<Text
								style={{
									color: '#fff',
									fontSize: 18,
									fontWeight: 'bold',
									textAlign: 'center',
								}}>
								Contact Us
							</Text>
						</View>
					</View>
				</View>
			</SafeAreaView>
			<View style={styles.contentSection}>
				<View style={styles.contentContainer}>
					<Text style={styles.contentText}>
						Please complete the form from the below link so we can respond to
						your enquiry effectively. For additional information around this
						product or any Honeywell product please contact your authorised
						Honeywell.
					</Text>
				</View>
				<View style={styles.linkContainer}>
					<Text
						style={[{ color: 'blue', textDecorationLine: 'underline' }]}
						onPress={() =>
							Linking.openURL(
								'https://www.honeywell.com/us/en/contact/support#webform',
							)
						}>
						https://www.honeywell.com/us/en/contact/support#webform
					</Text>
				</View>
			</View>
		</View>
	);
}

const styles = StyleSheet.create({
	mainContainer: {
		flex: 1,
		backgroundColor: '#f5f5f5',
	},
	safeHeader: {
		backgroundColor: '#000',
	},
	headerSection: {
		backgroundColor: '#000',
		height: 56,
		width: '100%',
	},
	contentSection: {
		flex: 1,
		width: '100%',
	},
	container: {
		flex: 1,
		backgroundColor: '#FFFFFF',
	},
	contentContainer: {
		backgroundColor: '#F4F4F4',
		padding: 30,
	},
	contentText: {
		color: '#000000',
		fontSize: 16,
	},
	linkContainer: {
		padding: 30,
	},
});
