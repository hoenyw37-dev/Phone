import React from 'react';
import {
	View,
	Text,
	StyleSheet,
	Linking,
	TouchableOpacity,
} from 'react-native';
import packageJson from '../../../../../package.json';
import AppIcon from '@assets/images/AppIcon.svg';
import { commonColors, commonSizes } from '@styles/base';
import DeviceInfo from 'react-native-device-info';
import { useTranslation } from 'react-i18next';
import { SafeAreaView } from 'react-native-safe-area-context';
import LeftArrowWhite from '@assets/images/LeftArrowWhite.svg';

export default function AboutUs({ navigation }: any) {
	const { t } = useTranslation();
	const versionName = DeviceInfo.getVersion(); // Gets the versionName
	const bundleVersion = DeviceInfo.getBuildNumber(); // Gets the bundle version
	return (
		<View style={styles.mainContainer}>
			<SafeAreaView edges={['top']} style={styles.safeHeader}>
				<View
					style={[
						styles.headerSection,
						{
							backgroundColor: '#000',
							alignItems: 'center',
						},
					]}>
					<View
						style={{
							flexDirection: 'row',
							alignItems: 'center',
							paddingHorizontal: 10,
							height: '100%',
						}}>
						<TouchableOpacity
							onPress={() => navigation.goBack()}
							style={{
								height: '100%',
								padding: 0,
								margin: 0,
								justifyContent: 'center',
							}}>
							<LeftArrowWhite height={30} width={30} />
						</TouchableOpacity>
						<View style={[{ flex: 2 }]}>
							<Text
								style={{
									color: '#fff',
									fontSize: 18,
									fontWeight: 'bold',
									textAlign: 'center',
								}}>
								About Us
							</Text>
						</View>
					</View>
				</View>
			</SafeAreaView>
			<View style={styles.contentSection}>
				<View style={styles.versionContianer}>
					<AppIcon width={65} height={80} />
					<Text style={styles.version}>
						{t('lblVersion')}: {versionName} ({bundleVersion})
					</Text>
				</View>
				<View style={styles.contentContainer}>
					<Text style={styles.contentText}>{t('aboutusMsg')}</Text>
					<Text style={styles.contentBullet}>{'\u2022 Powerstrike'}</Text>
					<Text style={styles.contentBullet}>{`\u2022 ${t(
						'aboutusSubMsg2',
					)}`}</Text>
					<Text style={styles.contentText}>
						{t('aboutuslblFeaturesInclude')}
					</Text>
					<Text style={styles.contentBullet}>
						{`\u2022 ${t('aboutusMsgFeaturesInclude1')}`}
					</Text>
					<Text style={styles.contentBullet}>
						{`\u2022 ${t('aboutusMsgFeaturesInclude2')}`}
					</Text>
					<Text style={styles.contentBullet}>
						{`\u2022 ${t('aboutusMsgFeaturesInclude3')}`}
					</Text>
					<Text style={[styles.contentText, { marginTop: 40 }]}>
						{t('aboutusMsgHoneywellUrl')}
					</Text>
					<Text
						style={[
							styles.contentBullet,
							{ color: 'blue', textDecorationLine: 'underline' },
						]}
						onPress={() => Linking.openURL('https://www.honeywell.com/')}>
						www.honeywell.com
					</Text>
				</View>
			</View>
		</View>
	);
}

const styles = StyleSheet.create({
	mainContainer: {
		flex: 1,
		backgroundColor: '#f5f5f5',
	},
	safeHeader: {
		backgroundColor: '#000',
	},
	headerSection: {
		backgroundColor: '#000',
		height: 56,
		width: '100%',
	},
	contentSection: {
		flex: 1,
		width: '100%',
	},
	container: {
		flex: 1,
		//justifyContent: 'center',
		padding: commonSizes.paddingM_Percent,
	},
	versionContianer: {
		marginLeft: commonSizes.widthM_Pixel,
		flexDirection: 'row',
		justifyContent: 'flex-start',
		alignItems: 'center',
	},
	version: {
		color: commonColors.textColor_Black,
		fontSize: commonSizes.textSizeM,
		marginLeft: commonSizes.widthM_Pixel,
	},
	contentContainer: {
		padding: commonSizes.paddingS_Percent,
		flex: 1,
	},
	contentText: {
		color: commonColors.textColor_Black,
		fontSize: commonSizes.textSizeS,
		marginVertical: commonSizes.heightM_Pixel,
	},
	contentBullet: {
		color: commonColors.textColor_Black,
		fontSize: commonSizes.textSizeS,
		marginLeft: commonSizes.widthM_Pixel,
	},
});
