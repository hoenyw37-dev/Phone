import { authorize, refresh } from 'react-native-app-auth';
import * as Keychain from 'react-native-keychain';

type OAuthResponse = {
	accessToken?: string;
	accessTokenExpirationDate?: string;
	refreshToken?: string;
	refreshTokenExpirationDate?: string;
	idToken?: string;
	userId?: string;
};

enum KeychainService {
	ACCESS_TOKEN = 'access_token',
	ACCESS_TOKEN_EXPIRY = 'access_token_expiry',
	REFRESH_TOKEN = 'refresh_token',
	RERESH_TOKEN_EXPIRY = 'refresh_token_expiry',
	ID_TOKEN = 'id_token',
}

const DEFAULT_REFRESH_TOKEN_LIFESPAN = 90 * 24 * 60 * 60 * 1000; // 90 days in milliseconds (confirm this with the actual lifespan in Azure)

export default class AuthManager {
	private static config = {
		issuer: 'https://login.microsoftonline.com/honidentitydev.onmicrosoft.com',
		clientId: 'de374aa2-8f8b-4f5d-a9af-9abc7613c70d',
		tenantId: 'honidentitydev.onmicrosoft.com',
		redirectUrl: 'evance-im-qa://Honeywell.beta.GLSS.IMTF',
		scopes: ['openid', 'profile', 'email', 'offline_access', 'User.Read'],
		//scopes: [
		//    'https://honidentitydev.onmicrosoft.com/def9341b-3773-474a-81a2-3bccbcab37a5/.default',
		//],
		additionalParameters: {
			prompt: 'select_account', //'login',
			resource:
				'https://honidentitydev.onmicrosoft.com/def9341b-3773-474a-81a2-3bccbcab37a5',
		},
		serviceConfiguration: {
			authorizationEndpoint:
				'https://login.microsoftonline.com/honidentitydev.onmicrosoft.com/oauth2/authorize',
			tokenEndpoint:
				'https://login.microsoftonline.com/honidentitydev.onmicrosoft.com/oauth2/token',
		},
	};

	static async checkAuthState(): Promise<boolean> {
		const refreshToken = await this.getRefreshToken();
		if (!refreshToken) {
			return false;
		}

		const hasValidRefreshToken = await this.isRefreshTokenValid();
		if (hasValidRefreshToken) {
			return hasValidRefreshToken;
		}

		await this.clearTokens();
		return false;
	}

	static async login(): Promise<void> {
		try {
			const authState = await authorize(this.config);
			await this.clearTokens();

			if (!authState.accessToken || !authState.accessTokenExpirationDate) {
				throw new Error('Invalid authentication response');
			}

			const now = new Date();
			const setRefreshTokenExpiry = new Date(
				now.getTime() + DEFAULT_REFRESH_TOKEN_LIFESPAN,
			);

			await this.storeTokens({
				accessToken: authState.accessToken,
				accessTokenExpirationDate: authState.accessTokenExpirationDate,
				refreshToken: authState.refreshToken,
				refreshTokenExpirationDate: setRefreshTokenExpiry.toISOString(),
				idToken: authState.idToken,
			});
		} catch (error) {
			await this.clearTokens();
			if (error.message.includes('User cancelled flow')) {
				throw new Error('USER_CANCELLED');
			}
			throw error;
		}
	}

	static async logout(): Promise<void> {
		try {
			//const accessToken = await this.getAccessToken();
			//const refreshToken = await this.getRefreshToken();
			await this.clearTokens();
			/*if(accessToken){  // need to get the revoke endpoints if required
        await revoke(this.config, {
          tokenToRevoke: accessToken,
          //sendClientId: true,
        });
      }
      if(refreshToken){
        await revoke(this.config, {
          tokenToRevoke: refreshToken,
          //sendClientId: true,
        });
      }*/
		} catch (error) {
			console.error('Logout failed:', error);
		}
	}

	static async refresh(): Promise<void> {
		try {
			const refreshToken = await this.getRefreshToken();
			if (!refreshToken) {
				throw new Error('No refresh token found');
			}
			const newTokens = await refresh(this.config, { refreshToken });

			const now = new Date();
			const setRefreshTokenExpiry = new Date(
				now.getTime() + DEFAULT_REFRESH_TOKEN_LIFESPAN,
			);

			await this.storeTokens({
				accessToken: newTokens.accessToken,
				accessTokenExpirationDate: newTokens.accessTokenExpirationDate,
				refreshToken: newTokens.refreshToken,
				refreshTokenExpirationDate: setRefreshTokenExpiry.toISOString(),
				idToken: newTokens.idToken,
			});
			console.log('Tokens refreshed!!!!!!!!!!!', newTokens);
		} catch (error) {
			await this.clearTokens();
		}
	}

	static async getAccessToken(): Promise<string | null> {
		try {
			const credentials = await Keychain.getGenericPassword({
				service: KeychainService.ACCESS_TOKEN,
			});
			if (!credentials) {
				return null;
			}
			return credentials?.password || null;
		} catch (error) {
			console.error('Access token retrieval failed:', error);
			return null;
		}
	}

	static async getRefreshToken(): Promise<string | null> {
		try {
			const credentials = await Keychain.getGenericPassword({
				service: KeychainService.REFRESH_TOKEN,
			});
			if (!credentials) {
				return null;
			}
			return credentials?.password || null;
		} catch (error) {
			console.error('Refresh token retrieval failed:', error);
			return null;
		}
	}

	static async isAccessTokenValid(): Promise<boolean> {
		try {
			const expiry = await Keychain.getGenericPassword({
				service: KeychainService.ACCESS_TOKEN_EXPIRY,
			});
			if (!expiry) {
				return false;
			}
			return new Date(expiry?.password) > new Date();
		} catch (error) {
			console.error('Expiry check failed:', error);
			return false;
		}
	}

	static async isRefreshTokenValid(): Promise<boolean> {
		try {
			const expiry = await Keychain.getGenericPassword({
				service: KeychainService.RERESH_TOKEN_EXPIRY,
			});
			if (!expiry) {
				return false;
			}
			return new Date(expiry?.password) > new Date();
		} catch (error) {
			console.error('Expiry check failed:', error);
			return false;
		}
	}

	private static async storeTokens(
		tokens: Partial<OAuthResponse>,
	): Promise<void> {
		if (tokens.accessToken) {
			await Keychain.setGenericPassword(
				KeychainService.ACCESS_TOKEN,
				tokens.accessToken,
				{ service: KeychainService.ACCESS_TOKEN },
			);
			console.log('Access token stored', tokens.accessToken);
		}
		if (tokens.refreshToken) {
			await Keychain.setGenericPassword(
				KeychainService.REFRESH_TOKEN,
				tokens.refreshToken,
				{ service: KeychainService.REFRESH_TOKEN },
			);
			console.log('Refresh token stored', tokens.refreshToken);
		}
		if (tokens.idToken) {
			await Keychain.setGenericPassword(
				KeychainService.ID_TOKEN,
				tokens.idToken,
				{ service: KeychainService.ID_TOKEN },
			);
			console.log('ID token stored', tokens.idToken);
		}
		if (tokens.accessTokenExpirationDate) {
			await Keychain.setGenericPassword(
				KeychainService.ACCESS_TOKEN_EXPIRY,
				tokens.accessTokenExpirationDate,
				{ service: KeychainService.ACCESS_TOKEN_EXPIRY },
			);
			console.log(
				'Access token expiry stored',
				tokens.accessTokenExpirationDate,
			);
		}
		if (tokens.refreshTokenExpirationDate) {
			await Keychain.setGenericPassword(
				KeychainService.RERESH_TOKEN_EXPIRY,
				tokens.refreshTokenExpirationDate,
				{ service: KeychainService.RERESH_TOKEN_EXPIRY },
			);
			console.log(
				'Refresh token expiry stored',
				tokens.refreshTokenExpirationDate,
			);
		}
	}

	private static async clearTokens(): Promise<void> {
		await Promise.all([
			Keychain.resetGenericPassword({
				service: KeychainService.ACCESS_TOKEN,
			}),
			Keychain.resetGenericPassword({
				service: KeychainService.REFRESH_TOKEN,
			}),
			Keychain.resetGenericPassword({
				service: KeychainService.ID_TOKEN,
			}),
			Keychain.resetGenericPassword({
				service: KeychainService.ACCESS_TOKEN_EXPIRY,
			}),
			Keychain.resetGenericPassword({
				service: KeychainService.RERESH_TOKEN_EXPIRY,
			}),
		]);
	}
}
