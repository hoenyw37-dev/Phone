import React from 'react';
import { View, StyleSheet, Button, ImageBackground } from 'react-native';
import { useAuth } from './authContext';
import { useEffect } from 'react';

const LoginScreen = ({ navigation }: any) => {
	const { isAuthenticated, login } = useAuth();

	useEffect(() => {
		if (isAuthenticated) {
			navigation.replace('ProjectList');
		}
	}, [isAuthenticated, navigation]);

	const handleLogin = async () => {
		try {
			navigation.replace('ProjectList');
		} catch (error) {
			// Handle error (show error message to user)
			console.error('Login failed:', error);
		}
	};

	return (
		<ImageBackground
			style={styles.backgroudImageContainer}
			source={require('@assets/images/WelcomeScreenImage.png')}>
			<View style={styles.container}>
				<Button title='Log In' onPress={handleLogin} />
			</View>
		</ImageBackground>
	);
};

const styles = StyleSheet.create({
	container: {
		flex: 1,
		justifyContent: 'center',
		alignItems: 'center',
		padding: 20,
	},
	button: {
		backgroundColor: '#0078d4',
		paddingHorizontal: 30,
		paddingVertical: 10,
	},
	backgroudImageContainer: {
		flex: 1,
		resizeMode: 'cover',
	},
});

export default LoginScreen;
