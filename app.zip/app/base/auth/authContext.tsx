// src/contexts/AuthContext.tsx
import React, {
	createContext,
	useContext,
	useEffect,
	useState,
	useCallback,
} from 'react';
import AuthManager from './authManager';

type AuthContextType = {
	isAuthenticated: boolean;
	isLoading: boolean;
	login: () => Promise<void>;
	logout: () => Promise<void>;
};

const AuthContext = createContext<AuthContextType>({} as AuthContextType);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({
	children,
}) => {
	const [authState, setAuthState] = useState<{
		isAuthenticated: boolean;
		isLoading: boolean;
	}>({
		isAuthenticated: false,
		isLoading: true,
	});

	const checkAuth = useCallback(async () => {
		try {
			const isSignedIn = await AuthManager.checkAuthState();

			if (isSignedIn) {
				//await AuthManager.refreshToken();
				setAuthState({ isAuthenticated: isSignedIn, isLoading: false });
			} else {
				setAuthState({ isAuthenticated: false, isLoading: false });
			}
		} catch (error) {
			console.error('Auth check failed:', error);
			setAuthState({ isAuthenticated: false, isLoading: false });
		}
	}, []);

	useEffect(() => {
		checkAuth();
	}, [checkAuth]);

	const login = async () => {
		try {
			setAuthState({ ...authState, isLoading: true });
			await AuthManager.login();
			//await AuthManager.refresh();
			await checkAuth();
		} catch (error) {
			setAuthState({ ...authState, isLoading: false });
			if (error instanceof Error && error.message === 'USER_CANCELLED') {
				// Handle cancellation specifically if needed
				return;
			}
			throw error;
		}
	};

	const logout = async () => {
		try {
			await AuthManager.logout();
			setAuthState({ isAuthenticated: false, isLoading: false });
		} catch (error) {
			console.error('Logout failed:', error);
			throw error;
		}
	};

	return (
		<AuthContext.Provider
			value={{
				isAuthenticated: authState.isAuthenticated,
				isLoading: authState.isLoading,
				login,
				logout,
			}}>
			{children}
		</AuthContext.Provider>
	);
};

export const useAuth = () => useContext(AuthContext);
