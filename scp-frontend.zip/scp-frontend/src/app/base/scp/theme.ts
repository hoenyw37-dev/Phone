/**
 * Design tokens for the new "Smart Configuration Plus" first-flow screens.
 *
 * Every colour below comes from the palette supplied with the Figma frames
 * (FFFFFF, 1A1C1E, 007BFF, 000000, 000000@20%, 878C93, DE1E34, DEE1E5,
 * and the white "Linear" 12% overlay). The only derived value is
 * `screenBg` (a very light grey for the area behind white cards), which the
 * frames show but the palette does not list.
 *
 * These tokens are intentionally separate from `@styles/base` so the legacy
 * screens keep working untouched.
 */
export const scpColors = {
	white: '#FFFFFF',
	ink: '#1A1C1E', // dark surface / primary text
	blue: '#007BFF', // primary action
	black: '#000000', // header + side menu
	shadow: 'rgba(0,0,0,0.2)', // 000000 @ 20%
	grey: '#878C93', // secondary text, placeholders
	red: '#DE1E34', // Honeywell red, step labels, progress line
	border: '#DEE1E5', // input borders, dividers, disabled button
	glass: 'rgba(255,255,255,0.12)', // "Linear 12%" – back/menu button fill
	screenBg: '#F2F3F5', // derived: grey behind white cards
	green: '#43A047', // success tick (from the success frame)
	scrim: 'rgba(0,0,0,0.5)', // dimmer behind sheets / drawer
};

export const scpRadius = { card: 14, input: 10, button: 12, sheet: 24 };
