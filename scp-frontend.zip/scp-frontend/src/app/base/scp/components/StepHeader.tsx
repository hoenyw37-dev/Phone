import React from 'react';
import { View, Text, Pressable, StyleSheet } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { scpColors } from '../theme';
import { BackIcon } from './icons';

/**
 * Solid black header used by Add Panel (steps 1/2) and Panel details.
 * `progress` (0-1) draws the red line under the header seen in the frames.
 */
export default function StepHeader({
	title,
	progress,
	onBack,
	right,
}: {
	title: string;
	progress?: number;
	onBack?: () => void;
	right?: React.ReactNode;
}) {
	const insets = useSafeAreaInsets();
	return (
		<View style={{ backgroundColor: scpColors.black, paddingTop: insets.top }}>
			<View style={styles.row}>
				<View style={styles.side}>
					{onBack && (
						<Pressable style={styles.iconBtn} onPress={onBack} hitSlop={8}>
							<BackIcon />
						</Pressable>
					)}
				</View>
				<Text style={styles.title} numberOfLines={1}>{title}</Text>
				<View style={[styles.side, { alignItems: 'flex-end' }]}>{right}</View>
			</View>
			{progress !== undefined && (
				<View style={styles.track}>
					<View style={[styles.fill, { width: `${Math.round(progress * 100)}%` }]} />
				</View>
			)}
		</View>
	);
}

export const headerIconBtn = {
	width: 36,
	height: 36,
	borderRadius: 10,
	backgroundColor: scpColors.glass,
	alignItems: 'center' as const,
	justifyContent: 'center' as const,
};

const styles = StyleSheet.create({
	row: { height: 56, flexDirection: 'row', alignItems: 'center', paddingHorizontal: 16 },
	side: { width: 44 },
	iconBtn: headerIconBtn,
	title: { flex: 1, textAlign: 'center', color: scpColors.white, fontSize: 16, fontWeight: '600' },
	track: { height: 3, backgroundColor: 'transparent' },
	fill: { height: 3, backgroundColor: scpColors.red },
});
