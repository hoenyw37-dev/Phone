import React, { useEffect, useMemo, useState } from 'react';
import { View, Text, ScrollView, Pressable, StyleSheet } from 'react-native';
import { Switch } from '@powerstrike/features/panels/types/panel';
import { formData } from '@powerstrike/questionnaire_data';
import BottomSheet from './BottomSheet';
import PrimaryButton from './PrimaryButton';
import { scpColors, scpRadius } from '../theme';

/**
 * Bottom-sheet version of the legacy "Output DIP switch" questionnaire
 * (`formData[1]` + `Question`/`Form`). Same data, same bit-code maths, new UI:
 *
 *   page 1  -> "S3 - Output 3 Dip Switch": choose the output function
 *   page 2+ -> function-specific questions (e.g. Wiring Supervision Type)
 *
 * Each page shows an option-card list, a progress bar, and Back / Next
 * (last page: Save). Nothing is persisted here – `onSave` hands the updated
 * Switch back to the caller, which decides whether to store it in local
 * state (Add Panel) or in the database (Panel details).
 */
const ROOT: any = formData[1]; // 'Output Switch Data'
const ROOT_ID = '32';

/** Same bit-merge rule as legacy FormIndex.handleResponseChange. */
const applyCode = (current: string, code?: string) => {
	if (!code) return current;
	let bits = '';
	for (let i = 0; i < code.length; i++) {
		if (code[i] === '1' || code[i] === '2') bits += code[i];
		else if (code[i] === '0') bits += current[i];
		else bits += '0'; // '3' (Unused) clears the bit
	}
	return bits;
};

/** Collect the question nodes that must be shown on `page` (mirrors legacy Question recursion). */
const collect = (node: any, resp: Record<string, string>, page: number, out: any[]) => {
	if (node.childDisplay && node.options && node.page === page) out.push(node);
	// descend into the chosen option when options carry sub-questions rather than bit codes
	if (node.options && (!node.options[0].code || node.id === ROOT_ID)) {
		node.options.forEach((o: any) => {
			if (resp[node.id] === o.id) collect(o, resp, page, out);
		});
	}
	node.questions?.forEach((q: any) => collect(q, resp, page, out));
};

type Props = {
	visible: boolean;
	sw: Switch | null;
	onClose: () => void;
	onSave: (updated: Switch) => void;
};

export default function OutputConfigSheet({ visible, sw, onClose, onSave }: Props) {
	const [draft, setDraft] = useState<Switch | null>(sw);
	const [page, setPage] = useState(1);

	// Start from the stored value every time the sheet opens.
	useEffect(() => {
		if (visible && sw) {
			setDraft({ ...sw, response: { ...sw.response } });
			setPage(1);
		}
	}, [visible, sw]);

	const chosenRoot = ROOT.options.find((o: any) => o.id === draft?.response?.[ROOT_ID]);
	const numPages: number = chosenRoot?.numPages ?? 1;

	const questions = useMemo(() => {
		const out: any[] = [];
		if (draft) collect(ROOT, draft.response, page, out);
		return out;
	}, [draft, page]);

	if (!draft) return null;

	const select = (node: any, option: any) => {
		setDraft(prev => {
			if (!prev) return prev;
			// Changing the main function invalidates every dependent answer, so start clean.
			const base = node.id === ROOT_ID ? { ...prev, response: {}, switchSetting: '00000000' } : prev;
			return {
				...base,
				response: { ...base.response, [node.id]: option.id },
				switchSetting: applyCode(base.switchSetting, option.code),
			};
		});
	};

	const allAnswered = questions.length > 0 && questions.every(q => !!draft.response[q.id]);
	const isLast = page >= numPages;
	const title =
		page === 1 ? `${draft.switchName} - ${draft.switchDescription} Dip Switch` : `${draft.switchName} - ${chosenRoot?.text ?? ''}`;

	const next = () => {
		if (isLast) {
			onSave(draft);
			onClose();
		} else setPage(p => p + 1);
	};

	return (
		<BottomSheet visible={visible} onClose={onClose}>
			<Text style={styles.title}>{title}</Text>
			<View style={styles.track}>
				<View style={[styles.fill, { width: `${(page / numPages) * 100}%` }]} />
			</View>

			<ScrollView style={{ marginTop: 16 }} showsVerticalScrollIndicator={false}>
				{questions.map(q => (
					<View key={q.id} style={{ marginBottom: 12 }}>
						{/* Page 1 has no sub-heading; deeper pages show the question text */}
						{q.id !== ROOT_ID && !!q.text && <Text style={styles.question}>{q.text}</Text>}
						{q.options.map((o: any) => {
							const selected = draft.response[q.id] === o.id;
							return (
								<Pressable key={o.id} onPress={() => select(q, o)} style={[styles.option, selected && styles.optionOn]}>
									<Text style={styles.optionText}>{o.text}</Text>
								</Pressable>
							);
						})}
					</View>
				))}
			</ScrollView>

			<View style={styles.footer}>
				{page > 1 && <PrimaryButton variant='secondary' label='Back' onPress={() => setPage(p => p - 1)} style={{ marginRight: 12 }} />}
				<PrimaryButton label={isLast ? 'Save' : 'Next'} onPress={next} disabled={!allAnswered} style={page === 1 ? { flex: 0, minWidth: 140 } : undefined} />
			</View>
		</BottomSheet>
	);
}

const styles = StyleSheet.create({
	title: { fontSize: 16, fontWeight: '600', color: scpColors.ink },
	track: { height: 4, backgroundColor: scpColors.border, borderRadius: 2, marginTop: 12 },
	fill: { height: 4, backgroundColor: scpColors.red, borderRadius: 2 },
	question: { fontSize: 14, fontWeight: '600', color: scpColors.ink, marginBottom: 10 },
	option: {
		borderWidth: 1,
		borderColor: scpColors.border,
		borderRadius: scpRadius.card,
		paddingVertical: 14,
		paddingHorizontal: 14,
		marginBottom: 10,
	},
	optionOn: { borderColor: scpColors.blue, borderWidth: 1.5 },
	optionText: { fontSize: 14, color: scpColors.ink },
	footer: { flexDirection: 'row', justifyContent: 'flex-end', marginTop: 12 },
});
