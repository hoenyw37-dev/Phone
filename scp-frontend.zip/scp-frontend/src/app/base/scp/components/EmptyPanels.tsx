import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { scpColors } from '../theme';

/**
 * "No panels yet" illustration – stacked server cards with a floating "+"
 * (drawn with plain Views so no image asset is needed).
 */
export default function EmptyPanels({ onAdd }: { onAdd: () => void }) {
	return (
		<View style={styles.wrap}>
			<View style={styles.art}>
				<View style={styles.plus}><Text style={styles.plusText}>+</Text></View>
				{[0, 1, 2].map(i => (
					<View key={i} style={styles.unit}>
						<View style={styles.bar} />
						<View style={styles.dot} />
					</View>
				))}
				<View style={styles.floor} />
			</View>
			<Text style={styles.msg}>There are no panels created so far</Text>
			<Text style={styles.link} onPress={onAdd}>Add Panel</Text>
		</View>
	);
}

const styles = StyleSheet.create({
	wrap: { flex: 1, alignItems: 'center', justifyContent: 'center' },
	art: { width: 190, height: 150, alignItems: 'center', justifyContent: 'flex-end' },
	plus: {
		position: 'absolute',
		top: 0,
		right: 6,
		width: 44,
		height: 44,
		borderRadius: 22,
		borderWidth: 1,
		borderColor: scpColors.border,
		alignItems: 'center',
		justifyContent: 'center',
		backgroundColor: scpColors.white,
	},
	plusText: { fontSize: 24, color: scpColors.border, marginTop: -2 },
	unit: {
		width: 120,
		height: 34,
		borderRadius: 8,
		borderWidth: 1,
		borderColor: scpColors.border,
		backgroundColor: scpColors.white,
		marginBottom: 6,
		flexDirection: 'row',
		alignItems: 'center',
		justifyContent: 'space-between',
		paddingHorizontal: 12,
	},
	bar: { width: 54, height: 8, borderRadius: 4, backgroundColor: scpColors.border },
	dot: { width: 6, height: 6, borderRadius: 3, backgroundColor: scpColors.red },
	floor: { position: 'absolute', bottom: 0, width: 190, height: 1, backgroundColor: scpColors.border },
	msg: { marginTop: 22, fontSize: 13, color: scpColors.grey },
	link: { marginTop: 10, fontSize: 15, fontWeight: '600', color: scpColors.blue },
});
