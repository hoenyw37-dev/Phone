import React from 'react';
import { Pressable, Text, StyleSheet, ViewStyle } from 'react-native';
import { scpColors, scpRadius } from '../theme';

type Props = {
	label: string;
	onPress: () => void;
	/** 'primary' = solid blue, 'secondary' = light grey (Cancel / Back). */
	variant?: 'primary' | 'secondary';
	disabled?: boolean;
	style?: ViewStyle;
};

/**
 * One button for the whole flow. Disabled state follows the frames:
 * primary turns light grey (DEE1E5) with grey text.
 */
export default function PrimaryButton({ label, onPress, variant = 'primary', disabled, style }: Props) {
	const isPrimary = variant === 'primary';
	const bg = disabled ? scpColors.border : isPrimary ? scpColors.blue : scpColors.screenBg;
	const fg = disabled ? scpColors.grey : isPrimary ? scpColors.white : scpColors.blue;
	return (
		<Pressable
			onPress={onPress}
			disabled={disabled}
			style={({ pressed }) => [styles.btn, { backgroundColor: bg, opacity: pressed ? 0.85 : 1 }, style]}>
			<Text style={[styles.text, { color: fg }]}>{label}</Text>
		</Pressable>
	);
}

const styles = StyleSheet.create({
	btn: { height: 50, borderRadius: scpRadius.button, alignItems: 'center', justifyContent: 'center', flex: 1 },
	text: { fontSize: 16, fontWeight: '600' },
});
