import React from 'react';
import { Modal, Pressable, View, StyleSheet } from 'react-native';
import { scpColors, scpRadius } from '../theme';

/**
 * Minimal bottom sheet built on RN's Modal (no extra dependency).
 * Used for the template picker and the per-output configuration questionnaire.
 */
export default function BottomSheet({
	visible,
	onClose,
	children,
	maxHeight = '80%',
}: {
	visible: boolean;
	onClose: () => void;
	children: React.ReactNode;
	maxHeight?: number | `${number}%`;
}) {
	return (
		<Modal visible={visible} transparent animationType='slide' onRequestClose={onClose} statusBarTranslucent>
			<View style={styles.root}>
				<Pressable style={StyleSheet.absoluteFill} onPress={onClose} />
				<View style={[styles.sheet, { maxHeight }]}>{children}</View>
			</View>
		</Modal>
	);
}

const styles = StyleSheet.create({
	root: { flex: 1, justifyContent: 'flex-end', backgroundColor: scpColors.scrim },
	sheet: {
		backgroundColor: scpColors.white,
		borderTopLeftRadius: scpRadius.sheet,
		borderTopRightRadius: scpRadius.sheet,
		paddingHorizontal: 20,
		paddingTop: 22,
		paddingBottom: 24,
	},
});
