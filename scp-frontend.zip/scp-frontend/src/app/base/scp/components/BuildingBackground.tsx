import React from 'react';
import { ImageBackground, StatusBar, StyleSheet, View, ViewStyle } from 'react-native';
import { scpColors } from '../theme';

/**
 * The dark tiled-building photo from the frames, with a dark scrim so white
 * text stays readable. `align` lets header strips show a different slice of
 * the (tall) photo – 'top' for the splash/terms, 'bottom' for site headers.
 */
export default function BuildingBackground({
	children,
	style,
	dim = 0.35,
	align = 'center',
}: {
	children?: React.ReactNode;
	style?: ViewStyle;
	dim?: number;
	align?: 'top' | 'center' | 'bottom';
}) {
	const pos = align === 'top' ? { top: 0 } : align === 'bottom' ? { bottom: 0 } : {};
	return (
		<View style={[{ flex: 1, backgroundColor: scpColors.ink }, style]}>
			<StatusBar translucent backgroundColor='transparent' barStyle='light-content' />
			<ImageBackground
				source={require('@assets/images/HoneywellBuilding.jpg')}
				resizeMode='cover'
				style={StyleSheet.absoluteFill}
				imageStyle={pos as any}
			/>
			<View style={[StyleSheet.absoluteFill, { backgroundColor: `rgba(0,0,0,${dim})` }]} />
			{children}
		</View>
	);
}
