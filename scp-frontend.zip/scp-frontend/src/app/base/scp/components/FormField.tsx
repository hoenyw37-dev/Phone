import React from 'react';
import { View, Text, TextInput, Pressable, StyleSheet } from 'react-native';
import { scpColors, scpRadius } from '../theme';
import { ChevronDown } from './icons';

type Props = {
	label: string;
	required?: boolean;
	value: string;
	placeholder?: string;
	onChangeText?: (v: string) => void;
	maxLength?: number;
	error?: string;
	/** When set the field behaves as a dropdown trigger instead of a text box. */
	onPressDropdown?: () => void;
};

/** Label + rounded input (or dropdown trigger) used on every form in the flow. */
export default function FormField({ label, required, value, placeholder, onChangeText, maxLength, error, onPressDropdown }: Props) {
	return (
		<View style={styles.wrap}>
			<Text style={styles.label}>
				{label}
				{required ? <Text style={{ color: scpColors.red }}> *</Text> : null}
			</Text>
			{onPressDropdown ? (
				<Pressable style={[styles.box, styles.row]} onPress={onPressDropdown}>
					<Text style={[styles.value, !value && { color: scpColors.grey }]} numberOfLines={1}>
						{value || placeholder}
					</Text>
					<ChevronDown />
				</Pressable>
			) : (
				<TextInput
					style={[styles.box, styles.value, error ? { borderColor: scpColors.red } : null]}
					value={value}
					onChangeText={onChangeText}
					placeholder={placeholder}
					placeholderTextColor={scpColors.grey}
					maxLength={maxLength}
				/>
			)}
			{!!error && <Text style={styles.error}>{error}</Text>}
		</View>
	);
}

const styles = StyleSheet.create({
	wrap: { marginBottom: 18 },
	label: { fontSize: 13, color: scpColors.grey, marginBottom: 8 },
	box: {
		height: 50,
		borderRadius: scpRadius.input,
		borderWidth: 1,
		borderColor: scpColors.border,
		backgroundColor: scpColors.white,
		paddingHorizontal: 14,
	},
	row: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
	value: { fontSize: 15, color: scpColors.ink },
	error: { color: scpColors.red, fontSize: 12, marginTop: 6 },
});
