/**
 * Small inline SVG icon set (react-native-svg is already a dependency).
 * Drawn here so colours are controllable per-use and no new asset files
 * (or SVG transformer quirks) are involved.
 */
import React from 'react';
import Svg, { Path, Rect, Circle } from 'react-native-svg';

type P = { size?: number; color?: string };

export const BackIcon = ({ size = 20, color = '#fff' }: P) => (
	<Svg width={size} height={size} viewBox='0 0 24 24' fill='none'>
		<Path d='M15 5l-7 7 7 7' stroke={color} strokeWidth={2.2} strokeLinecap='round' strokeLinejoin='round' />
	</Svg>
);

export const ChevronRight = ({ size = 18, color = '#007BFF' }: P) => (
	<Svg width={size} height={size} viewBox='0 0 24 24' fill='none'>
		<Path d='M9 5l7 7-7 7' stroke={color} strokeWidth={2.2} strokeLinecap='round' strokeLinejoin='round' />
	</Svg>
);

export const ChevronDown = ({ size = 18, color = '#878C93' }: P) => (
	<Svg width={size} height={size} viewBox='0 0 24 24' fill='none'>
		<Path d='M5 9l7 7 7-7' stroke={color} strokeWidth={2} strokeLinecap='round' strokeLinejoin='round' />
	</Svg>
);

export const MenuIcon = ({ size = 20, color = '#fff' }: P) => (
	<Svg width={size} height={size} viewBox='0 0 24 24' fill='none'>
		<Path d='M4 7h16M4 12h16M4 17h16' stroke={color} strokeWidth={2} strokeLinecap='round' />
	</Svg>
);

export const CloseIcon = ({ size = 18, color = '#fff' }: P) => (
	<Svg width={size} height={size} viewBox='0 0 24 24' fill='none'>
		<Path d='M6 6l12 12M18 6L6 18' stroke={color} strokeWidth={2.2} strokeLinecap='round' />
	</Svg>
);

export const CheckIcon = ({ size = 14, color = '#fff' }: P) => (
	<Svg width={size} height={size} viewBox='0 0 24 24' fill='none'>
		<Path d='M5 12.5l4.5 4.5L19 7.5' stroke={color} strokeWidth={3} strokeLinecap='round' strokeLinejoin='round' />
	</Svg>
);

export const BuildingIcon = ({ size = 14, color = '#878C93' }: P) => (
	<Svg width={size} height={size} viewBox='0 0 24 24' fill='none'>
		<Path d='M4 21V8l8-5 8 5v13M4 21h16M9 21v-5h6v5M9 11h.01M15 11h.01' stroke={color} strokeWidth={1.8} strokeLinecap='round' strokeLinejoin='round' />
	</Svg>
);

export const EditIcon = ({ size = 16, color = '#DE1E34' }: P) => (
	<Svg width={size} height={size} viewBox='0 0 24 24' fill='none'>
		<Path d='M4 20h4L19 9a2.8 2.8 0 00-4-4L4 16v4z' stroke={color} strokeWidth={1.9} strokeLinejoin='round' />
	</Svg>
);

export const ResetIcon = ({ size = 16, color = '#DE1E34' }: P) => (
	<Svg width={size} height={size} viewBox='0 0 24 24' fill='none'>
		<Path d='M4 12a8 8 0 108-8H8M8 4L5 7l3 3' stroke={color} strokeWidth={1.9} strokeLinecap='round' strokeLinejoin='round' />
	</Svg>
);

export const ExportIcon = ({ size = 18, color = '#fff' }: P) => (
	<Svg width={size} height={size} viewBox='0 0 24 24' fill='none'>
		<Path d='M12 3v12M7 10l5 5 5-5M5 20h14' stroke={color} strokeWidth={2} strokeLinecap='round' strokeLinejoin='round' />
	</Svg>
);

/** Generic line icons for the side menu. `name` selects the glyph. */
export const MenuGlyph = ({ name, size = 18, color = '#fff' }: P & { name: string }) => {
	const common = { stroke: color, strokeWidth: 1.8, strokeLinecap: 'round' as const, strokeLinejoin: 'round' as const };
	return (
		<Svg width={size} height={size} viewBox='0 0 24 24' fill='none'>
			{name === 'language' && (<><Circle cx='12' cy='12' r='9' {...common} /><Path d='M3 12h18M12 3c3 3 3 15 0 18M12 3c-3 3-3 15 0 18' {...common} /></>)}
			{name === 'rate' && <Path d='M12 3l2.7 5.6 6.1.9-4.4 4.3 1 6.1L12 17l-5.4 2.9 1-6.1L3.2 9.5l6.1-.9L12 3z' {...common} />}
			{name === 'about' && (<><Circle cx='12' cy='12' r='9' {...common} /><Path d='M12 11v6M12 7.5h.01' {...common} /></>)}
			{name === 'contact' && <Path d='M5 4h4l2 5-2.5 1.5a11 11 0 005 5L15 13l5 2v4a2 2 0 01-2 2A16 16 0 013 6a2 2 0 012-2z' {...common} />}
			{name === 'doc' && (<><Path d='M7 3h7l5 5v13H7V3z' {...common} /><Path d='M14 3v5h5M10 13h6M10 17h6' {...common} /></>)}
			{name === 'shield' && <Path d='M12 3l8 3v6c0 5-3.5 8-8 9-4.5-1-8-4-8-9V6l8-3z' {...common} />}
			{name === 'lock' && (<><Rect x='5' y='11' width='14' height='9' rx='2' {...common} /><Path d='M8 11V8a4 4 0 018 0v3' {...common} /></>)}
		</Svg>
	);
};
