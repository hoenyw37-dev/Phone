import React from 'react';
import { Modal, View, Text, Pressable, StyleSheet } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { scpColors } from '../theme';
import { CloseIcon, MenuGlyph } from './icons';

export type SideMenuItem = { key: string; label: string; glyph: string; onPress: () => void };

/** Black right-hand drawer from the "Your Sites" menu frame. */
export default function SideMenu({ visible, onClose, items }: { visible: boolean; onClose: () => void; items: SideMenuItem[] }) {
	const insets = useSafeAreaInsets();
	return (
		<Modal visible={visible} transparent animationType='fade' onRequestClose={onClose} statusBarTranslucent>
			<View style={styles.root}>
				{/* tapping the dimmed area closes the drawer */}
				<Pressable style={StyleSheet.absoluteFill} onPress={onClose} />
				<View style={[styles.drawer, { paddingTop: insets.top + 8 }]}>
					<Pressable style={styles.close} onPress={onClose} hitSlop={8}>
						<CloseIcon />
					</Pressable>
					{items.map(it => (
						<Pressable
							key={it.key}
							style={styles.item}
							onPress={() => {
								onClose();
								it.onPress();
							}}>
							<MenuGlyph name={it.glyph} />
							<Text style={styles.label}>{it.label}</Text>
						</Pressable>
					))}
				</View>
			</View>
		</Modal>
	);
}

const styles = StyleSheet.create({
	root: { flex: 1, flexDirection: 'row', justifyContent: 'flex-end', backgroundColor: scpColors.scrim },
	drawer: { width: '72%', backgroundColor: scpColors.black },
	close: {
		alignSelf: 'flex-end',
		marginRight: 16,
		marginBottom: 12,
		width: 36,
		height: 36,
		borderRadius: 10,
		backgroundColor: scpColors.glass,
		alignItems: 'center',
		justifyContent: 'center',
	},
	item: {
		flexDirection: 'row',
		alignItems: 'center',
		paddingVertical: 18,
		paddingHorizontal: 20,
		borderTopWidth: StyleSheet.hairlineWidth,
		borderTopColor: 'rgba(255,255,255,0.18)',
	},
	label: { color: scpColors.white, fontSize: 14, marginLeft: 14 },
});
