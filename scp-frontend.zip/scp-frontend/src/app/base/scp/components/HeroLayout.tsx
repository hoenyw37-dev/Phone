import React from 'react';
import { View, StyleSheet } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import BuildingBackground from './BuildingBackground';
import { scpColors, scpRadius } from '../theme';

/**
 * Shared layout of the site screens: building photo + header content on top,
 * rounded white/grey sheet below. `hero` is the content drawn over the photo.
 */
export default function HeroLayout({
	hero,
	heroHeight = 170,
	children,
	bodyColor = scpColors.white,
	align = 'bottom',
}: {
	hero: React.ReactNode;
	heroHeight?: number;
	children: React.ReactNode;
	bodyColor?: string;
	align?: 'top' | 'center' | 'bottom';
}) {
	const insets = useSafeAreaInsets();
	return (
		<BuildingBackground align={align} dim={0.4}>
			<View style={{ height: heroHeight + insets.top, paddingTop: insets.top }}>{hero}</View>
			<View style={[styles.sheet, { backgroundColor: bodyColor, paddingBottom: insets.bottom }]}>{children}</View>
		</BuildingBackground>
	);
}

const styles = StyleSheet.create({
	sheet: {
		flex: 1,
		borderTopLeftRadius: scpRadius.sheet,
		borderTopRightRadius: scpRadius.sheet,
		overflow: 'hidden',
	},
});
