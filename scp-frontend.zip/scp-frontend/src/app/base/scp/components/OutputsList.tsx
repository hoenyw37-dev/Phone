import React from 'react';
import { View, Text, Image, Pressable, ScrollView, StyleSheet } from 'react-native';
import { Switch } from '@powerstrike/features/panels/types/panel';
import Image_switch_off from '@powerstrike/features/switches/images/switch_off.png';
import Image_switch_on from '@powerstrike/features/switches/images/switch_on.png';
import Image_switch_disabled from '@powerstrike/features/switches/images/switch_disabled.png';
import { getOutputRows } from '../panelDefaults';
import { scpColors, scpRadius } from '../theme';
import { EditIcon, ResetIcon } from './icons';

/**
 * Output cards used on "Configure panel" (step 2) and on "Panel details".
 *  - configured output  : label, function name, 8 DIP bits, edit + reset buttons
 *  - untouched output   : "Not Available" + blue "Configure" link
 * The bit artwork (switch_on/off/disabled.png) is the existing asset set.
 */
export default function OutputsList({
	settings,
	onEdit,
	onReset,
	bottomPadding = 24,
}: {
	settings: Switch[];
	onEdit: (index: number) => void;
	onReset: (index: number) => void;
	bottomPadding?: number;
}) {
	const rows = getOutputRows(settings);
	return (
		<ScrollView contentContainerStyle={{ padding: 16, paddingBottom: bottomPadding }} showsVerticalScrollIndicator={false}>
			{rows.map(({ index, sw, outputNumber, functionName }) => {
				const configured = !!functionName;
				return (
					<View key={sw.switchName} style={styles.card}>
						<View style={styles.top}>
							<View style={{ flex: 1 }}>
								<Text style={styles.label}>{`${sw.switchName} - Output ${outputNumber}`}</Text>
								<Text style={[styles.name, !configured && { color: scpColors.grey }]}>
									{configured ? functionName : 'Not Available'}
								</Text>
							</View>
							{configured ? (
								<View style={{ flexDirection: 'row' }}>
									<Pressable style={styles.roundBtn} onPress={() => onEdit(index)} hitSlop={6}><EditIcon /></Pressable>
									<Pressable style={[styles.roundBtn, { marginLeft: 8 }]} onPress={() => onReset(index)} hitSlop={6}><ResetIcon /></Pressable>
								</View>
							) : (
								<Text style={styles.link} onPress={() => onEdit(index)}>Configure</Text>
							)}
						</View>

						{configured && (
							<View style={styles.bits}>
								{sw.switchSetting.split('').map((bit, i) => (
									<View key={i} style={{ alignItems: 'center' }}>
										<Image
											source={bit === '1' ? Image_switch_off : bit === '2' ? Image_switch_on : Image_switch_disabled}
											style={styles.bitImg}
											resizeMode='contain'
										/>
										<Text style={styles.bitNo}>{i + 1}</Text>
									</View>
								))}
							</View>
						)}
					</View>
				);
			})}
		</ScrollView>
	);
}

const styles = StyleSheet.create({
	card: {
		backgroundColor: scpColors.white,
		borderRadius: scpRadius.card,
		padding: 14,
		marginBottom: 12,
		shadowColor: scpColors.black,
		shadowOpacity: 0.06,
		shadowRadius: 6,
		shadowOffset: { width: 0, height: 2 },
		elevation: 2,
	},
	top: { flexDirection: 'row', alignItems: 'center' },
	label: { fontSize: 12, color: scpColors.grey },
	name: { fontSize: 15, fontWeight: '600', color: scpColors.ink, marginTop: 3 },
	roundBtn: {
		width: 34,
		height: 34,
		borderRadius: 17,
		backgroundColor: scpColors.screenBg,
		alignItems: 'center',
		justifyContent: 'center',
	},
	link: { color: scpColors.blue, fontSize: 14, fontWeight: '600' },
	bits: {
		flexDirection: 'row',
		justifyContent: 'space-between',
		backgroundColor: scpColors.screenBg,
		borderRadius: 10,
		paddingVertical: 10,
		paddingHorizontal: 10,
		marginTop: 12,
	},
	bitImg: { width: 22, height: 34 },
	bitNo: { fontSize: 11, color: scpColors.grey, marginTop: 2 },
});
