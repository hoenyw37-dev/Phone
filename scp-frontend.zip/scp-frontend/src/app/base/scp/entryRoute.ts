/**
 * Decides where the app goes after the splash / after accepting the terms:
 *   - no site saved yet  -> "Let's begin adding your first site"
 *   - at least one site  -> "Your Sites"
 * Uses the existing fetchProjects thunk – no data-layer changes.
 */
import { fetchProjects } from '@base/projects/redux/projectsThunk';

export const resolveEntryRoute = async (dispatch: any, dataSource: any) => {
	try {
		const projects: any[] = await dispatch(fetchProjects(dataSource)).unwrap();
		return projects && projects.length > 0 ? 'ScpSites' : 'ScpFirstSite';
	} catch (e) {
		console.error('resolveEntryRoute failed, defaulting to first-site screen', e);
		return 'ScpFirstSite';
	}
};
