/**
 * Helpers shared by the Add-Panel flow and the Panel-details screen.
 * Pure functions only – nothing here touches the database or redux.
 */
import { Switch } from '@powerstrike/features/panels/types/panel';
import { formData } from '@powerstrike/questionnaire_data';

/** Blank DIP-switch settings – same values the legacy PanelsList used. */
export const createDefaultSettings = (panelType: string): Switch[] => {
	const outputs = panelType === 'HPF-PS10' ? 7 : 5; // PS10 => S2..S8, PS6 => S2..S6
	const list: Switch[] = [
		{ switchName: 'S1', switchDescription: 'Global Options', switchSetting: '0000000000', response: {} },
	];
	// Legacy order is descending (S8 … S2); kept so persisted data is identical.
	for (let n = outputs + 1; n >= 2; n--) {
		list.push({
			switchName: `S${n}`,
			switchDescription: `Output ${n - 1}`,
			switchSetting: '00000000',
			response: {},
		});
	}
	return list;
};

export type OutputRow = {
	/** index inside panel.panelSetting – needed to write changes back */
	index: number;
	sw: Switch;
	outputNumber: number;
	/** label of the chosen function, e.g. "Door Holder Power" (undefined = never configured) */
	functionName?: string;
};

/** Output switches (everything except S1) sorted Output 1 → N, as in the frames. */
export const getOutputRows = (settings: Switch[]): OutputRow[] => {
	const outputRoot: any = formData[1];
	return settings
		.map((sw, index) => ({ sw, index }))
		.filter(({ index }) => index > 0)
		.map(({ sw, index }) => {
			const n = parseInt((sw.switchDescription.match(/(\d+)/) || [])[1] || '0', 10);
			const chosen = outputRoot.options.find((o: any) => o.id === sw.response?.['32']);
			return { index, sw, outputNumber: n, functionName: chosen?.text as string | undefined };
		})
		.sort((a, b) => a.outputNumber - b.outputNumber);
};

/** True when any bit of any switch has been set (used to enable "Save"). */
export const hasAnyConfiguration = (settings: Switch[]) =>
	settings.some(s => /[12]/.test(s.switchSetting));

export const resetSwitch = (sw: Switch): Switch => ({
	...sw,
	switchSetting: sw.switchName === 'S1' ? '0000000000' : '00000000',
	response: {},
});
