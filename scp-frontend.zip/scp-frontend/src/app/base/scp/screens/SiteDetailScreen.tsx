import React, { useEffect } from 'react';
import { View, Text, Pressable, StyleSheet } from 'react-native';
import { useSelector } from 'react-redux';
import HeroLayout from '../components/HeroLayout';
import { BackIcon, BuildingIcon, ChevronRight } from '../components/icons';
import { headerIconBtn } from '../components/StepHeader';
import { useDatabase } from '@global/DatabaseContext';
import { useAppDispatch, useAppSelector } from '@global/hooks';
import { AppStore } from '@global/store';
import { selectProjectById } from '@base/projects/redux/projectsSlice';
import { fetchPanelsByProject } from '@powerstrike/features/panels/redux/panelsThunk';
import { selectLatestUpdatedAtByProject } from '@powerstrike/features/panels/redux/panelsSlice';
import { fetchDevicesByProjectId } from '@ff_redux/deviceRedux/devicesThunk';
import { AppConstants } from '@global/GlobalConstants/globalConstants';
import { scpColors, scpRadius } from '../theme';

const fmt = (d?: Date | null) => (d && d.getTime() > 0 ? d.toLocaleDateString() : 'Not configured yet');

/**
 * Frame "Site Name": building header, then one card per product.
 *  - Powerstrike | Power supply -> new panel list screens (this flow)
 *  - Faastflex Detectors        -> existing legacy flow, logic copied from ProjectHome
 */
export default function SiteDetailScreen({ route, navigation }: any) {
	const { projectId } = route.params;
	const dispatch = useAppDispatch();
	const { dataSource } = useDatabase();
	const site = useSelector((s: AppStore) => selectProjectById(s, projectId));
	const latest = useAppSelector(s => selectLatestUpdatedAtByProject(s, projectId));

	useEffect(() => {
		if (dataSource) dispatch(fetchPanelsByProject({ dataSource, projectId }));
	}, [dataSource, projectId, dispatch]);

	const openFaastflex = async () => {
		const devices = await dispatch(fetchDevicesByProjectId({ dataSource, projectId })).unwrap();
		if (devices && devices.length > 0) navigation.navigate(AppConstants.DeviceListScreen, { projectId });
		else navigation.navigate(AppConstants.CreateOrEditDeviceScreen, { projectId, isNewDevice: true, isFromProjectHome: true });
	};

	if (!site) return null;

	const hero = (
		<View style={styles.hero}>
			<Pressable style={headerIconBtn} onPress={() => navigation.navigate('ScpSites')} hitSlop={8}>
				<BackIcon />
			</Pressable>
			<View style={{ flex: 1 }} />
			<Text style={styles.name} numberOfLines={1}>{site.projectName}</Text>
			<View style={styles.sub}>
				<BuildingIcon color={scpColors.white} />
				<Text style={styles.subText} numberOfLines={1}>
					{[site.site, site.building].filter(Boolean).join(', ')}
				</Text>
			</View>
		</View>
	);

	const Card = ({ title, subtitle, onPress }: { title: string; subtitle: string; onPress: () => void }) => (
		<Pressable style={styles.card} onPress={onPress}>
			{/* grey tile = icon placeholder, exactly as in the frame */}
			<View style={styles.tile} />
			<View style={{ flex: 1 }}>
				<Text style={styles.cardTitle}>{title}</Text>
				<Text style={styles.cardSub}>{subtitle}</Text>
			</View>
			<ChevronRight />
		</Pressable>
	);

	return (
		<HeroLayout hero={hero} heroHeight={190} bodyColor={scpColors.screenBg} align='bottom'>
			<View style={{ padding: 16 }}>
				<Card title='Powerstrike | Power supply' subtitle={`Last configured: ${fmt(latest)}`} onPress={() => navigation.navigate('ScpPanelList', { projectId })} />
				<Card title='Faastflex Detectors' subtitle={`Last configured: ${fmt(latest)}`} onPress={openFaastflex} />
			</View>
		</HeroLayout>
	);
}

const styles = StyleSheet.create({
	hero: { flex: 1, paddingHorizontal: 20, paddingBottom: 20 },
	name: { color: scpColors.white, fontSize: 24, fontWeight: '700' },
	sub: { flexDirection: 'row', alignItems: 'center', marginTop: 6 },
	subText: { color: scpColors.white, fontSize: 12, marginLeft: 6, flex: 1 },
	card: {
		flexDirection: 'row',
		alignItems: 'center',
		backgroundColor: scpColors.white,
		borderRadius: scpRadius.card,
		padding: 14,
		marginBottom: 12,
	},
	tile: { width: 44, height: 44, borderRadius: 10, backgroundColor: scpColors.screenBg, marginRight: 14 },
	cardTitle: { fontSize: 15, fontWeight: '600', color: scpColors.ink },
	cardSub: { fontSize: 12, color: scpColors.grey, marginTop: 4 },
});
