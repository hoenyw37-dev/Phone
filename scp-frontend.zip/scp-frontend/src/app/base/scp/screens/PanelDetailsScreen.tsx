import React, { useState } from 'react';
import { View, Pressable, StyleSheet } from 'react-native';
import { useSelector } from 'react-redux';
import StepHeader, { headerIconBtn } from '../components/StepHeader';
import OutputsList from '../components/OutputsList';
import OutputConfigSheet from '../components/OutputConfigSheet';
import { ExportIcon } from '../components/icons';
import { resetSwitch } from '../panelDefaults';
import { useDatabase } from '@global/DatabaseContext';
import { useAppDispatch } from '@global/hooks';
import { AppStore } from '@global/store';
import { selectPanelById } from '@powerstrike/features/panels/redux/panelsSlice';
import { updateExistingPanel } from '@powerstrike/features/panels/redux/panelsThunk';
import { Panel, Switch } from '@powerstrike/features/panels/types/panel';
import { selectProjectById } from '@base/projects/redux/projectsSlice';
import { generatePDF } from '@powerstrike/features/pdf/components/generatePDF';
import { PdfSavedMessageModal } from '@powerstrike/features/pdf/components/PdfSavedMessageModal';
import { CustomActivityIndicator } from '@components/CustomActivityIndicator';
import { scpColors } from '../theme';

/**
 * Last frame – "Panel Name" with every output. Edit/reset write straight to
 * the saved panel through the existing updateExistingPanel thunk (same
 * payload shape the legacy SwitchesList used). The top-right icon exports
 * the PDF with the existing generatePDF helper.
 */
export default function PanelDetailsScreen({ route, navigation }: any) {
	const { panelId } = route.params;
	const dispatch = useAppDispatch();
	const { dataSource } = useDatabase();
	const panel: Panel = useSelector((s: AppStore) => selectPanelById(s, panelId));
	const project = useSelector((s: AppStore) => selectProjectById(s, panel?.projectId));

	const [editing, setEditing] = useState<number | null>(null);
	const [busy, setBusy] = useState(false);
	const [pdfPath, setPdfPath] = useState('');
	const [pdfModal, setPdfModal] = useState(false);

	if (!panel) return null;

	const persist = (index: number, sw: Switch) => {
		const panelSetting = panel.panelSetting.map((s, i) => (i === index ? sw : s));
		dispatch(updateExistingPanel({ dataSource, panelId, updates: { panelSetting, updatedAt: new Date().toISOString() } }));
	};

	const exportPdf = async () => {
		setBusy(true);
		await generatePDF({
			panelData: panel,
			projectData: project,
			getData: (path: string, flag: boolean) => {
				setPdfPath(path);
				setPdfModal(flag);
			},
		});
		setBusy(false);
	};

	return (
		<View style={styles.root}>
			<StepHeader
				title={panel.panelName}
				onBack={() => navigation.navigate('ScpPanelList', { projectId: panel.projectId })}
				right={
					<Pressable style={headerIconBtn} onPress={exportPdf} hitSlop={8}>
						<ExportIcon />
					</Pressable>
				}
			/>
			<OutputsList
				settings={panel.panelSetting}
				onEdit={setEditing}
				onReset={i => persist(i, resetSwitch(panel.panelSetting[i]))}
			/>
			<OutputConfigSheet
				visible={editing !== null}
				sw={editing !== null ? panel.panelSetting[editing] : null}
				onClose={() => setEditing(null)}
				onSave={sw => editing !== null && persist(editing, sw)}
			/>
			{pdfModal && <PdfSavedMessageModal path={pdfPath} modalVisible={pdfModal} closeModal={() => setPdfModal(false)} navigation={navigation} />}
			{busy && <CustomActivityIndicator />}
		</View>
	);
}

const styles = StyleSheet.create({
	root: { flex: 1, backgroundColor: scpColors.screenBg },
});
