import React, { useState } from 'react';
import { View, Text, Image, Pressable, StyleSheet, Dimensions } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import EncryptedStorage from 'react-native-encrypted-storage';
import BuildingBackground from '../components/BuildingBackground';
import PrimaryButton from '../components/PrimaryButton';
import { CheckIcon } from '../components/icons';
import { useDatabase } from '@global/DatabaseContext';
import { useAppDispatch } from '@global/hooks';
import { resolveEntryRoute } from '../entryRoute';
import { scpColors, scpRadius } from '../theme';

const { width } = Dimensions.get('window');

const Box = ({ checked, onPress }: { checked: boolean; onPress: () => void }) => (
	<Pressable onPress={onPress} hitSlop={8} style={[styles.box, checked && styles.boxOn]}>
		{checked && <CheckIcon />}
	</Pressable>
);

/**
 * Frames 2 & 3 – "Terms and Policies": two checkboxes, Accept disabled
 * (grey) until both are ticked, then blue. Links open the existing
 * TermsAndConditions screen (EULA / Privacy policy text files).
 */
export default function TermsPoliciesScreen({ navigation }: any) {
	const insets = useSafeAreaInsets();
	const dispatch = useAppDispatch();
	const { dataSource } = useDatabase();
	const [eula, setEula] = useState(false);
	const [privacy, setPrivacy] = useState(false);

	const accept = async () => {
		try {
			// Same keys as the legacy LicenseAgreementModal
			await EncryptedStorage.setItem('licenseAccepted', 'true');
			await EncryptedStorage.setItem('PrivacyPolicy', 'true');
		} catch (e) {
			console.error('Failed to save acceptance', e);
		}
		navigation.replace(await resolveEntryRoute(dispatch, dataSource));
	};

	const open = (fileName: 'EULA' | 'PrivacyPolicy') => navigation.navigate('TermsAndConditions', { fileName });

	return (
		<BuildingBackground align='top' dim={0.3}>
			<View style={[styles.brand, { paddingTop: insets.top + 70 }]}>
				<Image source={require('@assets/images/HoneywellLogo.png')} style={styles.logo} resizeMode='contain' />
				<Text style={styles.caption}>SMART CONFIGURATION PLUS</Text>
			</View>

			<View style={[styles.sheet, { paddingBottom: insets.bottom + 16 }]}>
				<Text style={styles.welcome}>Welcome to Smart Configuration Plus</Text>
				<Text style={styles.title}>Terms and Policies</Text>

				<View style={styles.row}>
					<Box checked={eula} onPress={() => setEula(v => !v)} />
					<Text style={styles.text}>
						I confirm that I have read and accept the{' '}
						<Text style={styles.link} onPress={() => open('EULA')}>Latest EULA Agreement</Text>
					</Text>
				</View>
				<View style={styles.row}>
					<Box checked={privacy} onPress={() => setPrivacy(v => !v)} />
					<Text style={styles.text}>
						Your personal information will be processed in accordance with{' '}
						<Text style={styles.link} onPress={() => open('PrivacyPolicy')}>Honeywell Privacy Statement</Text>
					</Text>
				</View>

				<View style={{ flex: 1 }} />
				<View style={{ flexDirection: 'row' }}>
					<PrimaryButton label='Accept' onPress={accept} disabled={!(eula && privacy)} />
				</View>
			</View>
		</BuildingBackground>
	);
}

const styles = StyleSheet.create({
	brand: { alignItems: 'center' },
	logo: { width: width * 0.5, height: (width * 0.5 * 94) / 534 },
	caption: { marginTop: 8, color: scpColors.white, fontSize: 10, letterSpacing: 2 },
	sheet: {
		position: 'absolute',
		left: 0,
		right: 0,
		bottom: 0,
		top: '40%',
		backgroundColor: scpColors.white,
		borderTopLeftRadius: scpRadius.sheet,
		borderTopRightRadius: scpRadius.sheet,
		paddingHorizontal: 20,
		paddingTop: 24,
	},
	welcome: { color: scpColors.red, fontSize: 12, fontWeight: '600' },
	title: { color: scpColors.ink, fontSize: 22, fontWeight: '700', marginTop: 6, marginBottom: 22 },
	row: { flexDirection: 'row', alignItems: 'flex-start', marginBottom: 16 },
	box: {
		width: 20,
		height: 20,
		borderRadius: 5,
		borderWidth: 1.5,
		borderColor: scpColors.grey,
		alignItems: 'center',
		justifyContent: 'center',
		marginRight: 12,
		marginTop: 1,
	},
	boxOn: { backgroundColor: scpColors.blue, borderColor: scpColors.blue },
	text: { flex: 1, fontSize: 13, lineHeight: 19, color: scpColors.ink },
	link: { color: scpColors.blue, textDecorationLine: 'underline' },
});
