import React, { useState } from 'react';
import { View, Text, ScrollView, KeyboardAvoidingView, Platform, Pressable, StyleSheet } from 'react-native';
import Toast from 'react-native-toast-message';
import HeroLayout from '../components/HeroLayout';
import FormField from '../components/FormField';
import PrimaryButton from '../components/PrimaryButton';
import { BackIcon } from '../components/icons';
import { headerIconBtn } from '../components/StepHeader';
import { useDatabase } from '@global/DatabaseContext';
import { useAppDispatch } from '@global/hooks';
import { addNewProject } from '@base/projects/redux/projectsThunk';
import { Project } from '@base/projects/types/project';
import { scpColors } from '../theme';

const MAX = 50;

/**
 * One form, two frames:
 *   - ScpFirstSite  -> "Let's begin adding your first site…" (no back button)
 *   - ScpAddSite    -> "Please provide following details"     (back button)
 * A "site" is the existing `Project` model:
 *   Site name -> projectName, Site location -> site, Building name -> building.
 * Saving uses the existing addNewProject thunk, then opens the site.
 */
export default function SiteFormScreen({ navigation, route }: any) {
	const isFirst = route.name === 'ScpFirstSite';
	const dispatch = useAppDispatch();
	const { dataSource } = useDatabase();
	const [name, setName] = useState('');
	const [location, setLocation] = useState('');
	const [building, setBuilding] = useState('');
	const [error, setError] = useState('');
	const [saving, setSaving] = useState(false);

	const save = async () => {
		if (!name.trim()) return setError('Site name is required');
		setError('');
		setSaving(true);
		const project = { projectName: name.trim(), site: location.trim(), building: building.trim() } as Project;
		const result = await dispatch(addNewProject({ dataSource, project }));
		setSaving(false);
		if (addNewProject.fulfilled.match(result)) {
			navigation.replace('ScpSiteDetail', { projectId: result.payload.projectId });
		} else {
			const payload = (result as any).payload as { message?: string } | undefined;
			Toast.show({ type: 'error', text1: payload?.message || 'Could not create the site.', visibilityTime: 2500 });
		}
	};

	const hero = (
		<View style={styles.hero}>
			{!isFirst && (
				<Pressable style={[headerIconBtn, { marginBottom: 14 }]} onPress={() => navigation.goBack()} hitSlop={8}>
					<BackIcon />
				</Pressable>
			)}
			<View style={{ flex: 1 }} />
			<Text style={styles.kicker}>Site Setup</Text>
			<Text style={styles.title}>{isFirst ? "Let's begin adding your first site…" : 'Please provide following details'}</Text>
		</View>
	);

	return (
		<HeroLayout hero={hero} heroHeight={isFirst ? 150 : 170} align='top'>
			<KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
				<ScrollView contentContainerStyle={styles.body} keyboardShouldPersistTaps='handled'>
					{isFirst && <Text style={styles.sub}>Enter following details</Text>}
					<FormField label='Site name' required value={name} onChangeText={setName} placeholder='Enter site name' maxLength={MAX} error={error} />
					<FormField label='Site location' value={location} onChangeText={setLocation} placeholder='Enter site location' maxLength={MAX} />
					<FormField label='Building name' value={building} onChangeText={setBuilding} placeholder='Enter building name' maxLength={MAX} />
				</ScrollView>
				<View style={styles.footer}>
					<PrimaryButton label='Save' onPress={save} disabled={saving} />
				</View>
			</KeyboardAvoidingView>
		</HeroLayout>
	);
}

const styles = StyleSheet.create({
	hero: { flex: 1, paddingHorizontal: 20, paddingBottom: 18 },
	kicker: { color: scpColors.red, fontSize: 12, fontWeight: '600' },
	title: { color: scpColors.white, fontSize: 24, fontWeight: '700', marginTop: 4 },
	body: { padding: 20 },
	sub: { fontSize: 13, fontWeight: '600', color: scpColors.ink, marginBottom: 18 },
	footer: { flexDirection: 'row', paddingHorizontal: 20, paddingVertical: 12 },
});
