import React, { useEffect } from 'react';
import { View, Text, Pressable, StyleSheet } from 'react-native';
import { CheckIcon } from '../components/icons';
import { scpColors } from '../theme';

/**
 * Frame "Panel Configured Successfully". Auto-continues to Panel details
 * after ~2 s (tap also continues). The stack is rebuilt so that Back from the
 * details screen returns to the panel list instead of re-opening this page.
 */
export default function PanelSuccessScreen({ route, navigation }: any) {
	const { projectId, panelId, panelName, panelType, templateName } = route.params;

	useEffect(() => {
		const go = () =>
			navigation.reset({
				index: 3,
				routes: [
					{ name: 'ScpSites' },
					{ name: 'ScpSiteDetail', params: { projectId } },
					{ name: 'ScpPanelList', params: { projectId } },
					{ name: 'ScpPanelDetails', params: { panelId } },
				],
			});
		const t = setTimeout(go, 2000);
		return () => clearTimeout(t);
	}, [navigation, projectId, panelId]);

	return (
		<Pressable style={styles.root} onPress={() => navigation.navigate('ScpPanelDetails', { panelId })}>
			<View style={styles.circle}><CheckIcon size={44} /></View>
			<Text style={styles.title}>Panel Configured Successfully</Text>
			<View style={styles.line} />
			<Text style={styles.name}>{panelName}</Text>
			<Text style={styles.sub}>{panelType} | {templateName}</Text>
		</Pressable>
	);
}

const styles = StyleSheet.create({
	root: { flex: 1, backgroundColor: scpColors.white, alignItems: 'center', justifyContent: 'center', paddingHorizontal: 32 },
	circle: { width: 110, height: 110, borderRadius: 55, backgroundColor: scpColors.green, alignItems: 'center', justifyContent: 'center' },
	title: { marginTop: 28, fontSize: 18, fontWeight: '600', color: scpColors.ink, textAlign: 'center' },
	line: { alignSelf: 'stretch', height: 1, backgroundColor: scpColors.border, marginVertical: 28 },
	name: { fontSize: 15, fontWeight: '600', color: scpColors.ink },
	sub: { fontSize: 12, color: scpColors.grey, marginTop: 4 },
});
