import React, { useEffect } from 'react';
import { View, Image, Text, StyleSheet, Dimensions } from 'react-native';
import EncryptedStorage from 'react-native-encrypted-storage';
import BuildingBackground from '../components/BuildingBackground';
import { useDatabase } from '@global/DatabaseContext';
import { useAppDispatch } from '@global/hooks';
import { resolveEntryRoute } from '../entryRoute';
import { scpColors } from '../theme';

const { width } = Dimensions.get('window');

/**
 * Frame 1 – Honeywell logo + "SMART CONFIGURATION PLUS" over the building photo.
 * After a short pause it routes to Terms (first launch) or to the sites flow.
 * Acceptance is read from the same EncryptedStorage keys the legacy
 * LicenseAgreementModal wrote, so existing installs are not asked again.
 */
export default function SplashScreen({ navigation }: any) {
	const dispatch = useAppDispatch();
	const { dataSource } = useDatabase();

	useEffect(() => {
		let cancelled = false;
		const run = async () => {
			const minDelay = new Promise(r => setTimeout(r, 1500)); // keep the splash visible
			let accepted = false;
			try {
				const eula = await EncryptedStorage.getItem('licenseAccepted');
				const privacy = await EncryptedStorage.getItem('PrivacyPolicy');
				accepted = !!eula && !!privacy;
			} catch (e) {
				console.error('Failed reading terms acceptance', e);
			}
			const next = accepted ? await resolveEntryRoute(dispatch, dataSource) : 'ScpTerms';
			await minDelay;
			if (!cancelled) navigation.replace(next);
		};
		if (dataSource) run();
		return () => {
			cancelled = true;
		};
	}, [dataSource, dispatch, navigation]);

	return (
		<BuildingBackground dim={0.25}>
			<View style={styles.center}>
				<Image source={require('@assets/images/HoneywellLogo.png')} style={styles.logo} resizeMode='contain' />
				<Text style={styles.caption}>SMART CONFIGURATION PLUS</Text>
			</View>
		</BuildingBackground>
	);
}

const styles = StyleSheet.create({
	center: { flex: 1, alignItems: 'center', justifyContent: 'center' },
	logo: { width: width * 0.66, height: (width * 0.66 * 94) / 534 },
	caption: { marginTop: 10, color: scpColors.white, fontSize: 11, letterSpacing: 2.2 },
});
