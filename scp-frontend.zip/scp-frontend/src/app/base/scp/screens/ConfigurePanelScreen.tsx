import React, { useState } from 'react';
import { View, Text, StyleSheet } from 'react-native';
import Toast from 'react-native-toast-message';
import StepHeader from '../components/StepHeader';
import PrimaryButton from '../components/PrimaryButton';
import OutputsList from '../components/OutputsList';
import OutputConfigSheet from '../components/OutputConfigSheet';
import { createDefaultSettings, hasAnyConfiguration, resetSwitch } from '../panelDefaults';
import { useDatabase } from '@global/DatabaseContext';
import { useAppDispatch } from '@global/hooks';
import { addNewPanel } from '@powerstrike/features/panels/redux/panelsThunk';
import { Panel, Switch } from '@powerstrike/features/panels/types/panel';
import { scpColors } from '../theme';

/**
 * Frames "Add Panel – Step 2 of 2 / Configure panel" (+ the option sheets).
 * Edits live in local state; the panel is written once, on Save, through the
 * existing addNewPanel thunk – so backing out leaves no half-created panel.
 */
export default function ConfigurePanelScreen({ route, navigation }: any) {
	const { projectId, panelName, panelType, templateName, templateSetting } = route.params;
	const dispatch = useAppDispatch();
	const { dataSource } = useDatabase();

	// deep copy so edits never mutate the template object held in redux
	const [settings, setSettings] = useState<Switch[]>(() =>
		templateSetting ? JSON.parse(JSON.stringify(templateSetting)) : createDefaultSettings(panelType),
	);
	const [editing, setEditing] = useState<number | null>(null);
	const [saving, setSaving] = useState(false);

	const patch = (index: number, sw: Switch) => setSettings(prev => prev.map((s, i) => (i === index ? sw : s)));

	const save = async () => {
		setSaving(true);
		const panel: Panel = { projectId, panelId: 0, panelName, panelType, panelSetting: settings, updatedAt: new Date().toISOString() };
		const res = await dispatch(addNewPanel({ dataSource, panel }));
		setSaving(false);
		if (addNewPanel.fulfilled.match(res)) {
			navigation.navigate('ScpPanelSuccess', { projectId, panelId: res.payload.panelId, panelName, panelType, templateName });
		} else {
			Toast.show({ type: 'error', text1: 'Failed to add the panel', visibilityTime: 2500 });
		}
	};

	return (
		<View style={styles.root}>
			<StepHeader title='Add Panel' progress={1} />
			<View style={styles.head}>
				<Text style={styles.step}>Step 2 of 2</Text>
				<Text style={styles.title}>Configure panel</Text>
			</View>

			<View style={{ flex: 1, backgroundColor: scpColors.screenBg }}>
				<OutputsList settings={settings} onEdit={setEditing} onReset={i => patch(i, resetSwitch(settings[i]))} />
			</View>

			<View style={styles.footer}>
				<PrimaryButton variant='secondary' label='Back' onPress={() => navigation.goBack()} style={{ marginRight: 12 }} />
				<PrimaryButton label='Save' onPress={save} disabled={saving || !hasAnyConfiguration(settings)} />
			</View>

			<OutputConfigSheet
				visible={editing !== null}
				sw={editing !== null ? settings[editing] : null}
				onClose={() => setEditing(null)}
				onSave={sw => editing !== null && patch(editing, sw)}
			/>
		</View>
	);
}

const styles = StyleSheet.create({
	root: { flex: 1, backgroundColor: scpColors.white },
	head: { paddingHorizontal: 20, paddingTop: 20, backgroundColor: scpColors.white },
	step: { color: scpColors.red, fontSize: 12, fontWeight: '600' },
	title: { color: scpColors.ink, fontSize: 22, fontWeight: '700', marginTop: 6 },
	footer: { flexDirection: 'row', padding: 16, paddingBottom: 24, backgroundColor: scpColors.white },
});
