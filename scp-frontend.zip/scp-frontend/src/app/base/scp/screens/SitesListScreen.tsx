import React, { useCallback, useState } from 'react';
import { View, Text, Pressable, FlatList, Linking, StyleSheet } from 'react-native';
import { useFocusEffect } from '@react-navigation/native';
import HeroLayout from '../components/HeroLayout';
import PrimaryButton from '../components/PrimaryButton';
import SideMenu, { SideMenuItem } from '../components/SideMenu';
import { BuildingIcon, ChevronRight, MenuIcon } from '../components/icons';
import { headerIconBtn } from '../components/StepHeader';
import { useDatabase } from '@global/DatabaseContext';
import { useAppDispatch, useAppSelector } from '@global/hooks';
import { fetchProjects } from '@base/projects/redux/projectsThunk';
import { selectAllProjects } from '@base/projects/redux/projectsSlice';
import { scpColors, scpRadius } from '../theme';

/** Frames "Your Sites" + side menu. Cards come from the existing projects slice. */
export default function SitesListScreen({ navigation }: any) {
	const dispatch = useAppDispatch();
	const { dataSource } = useDatabase();
	const sites = useAppSelector(selectAllProjects);
	const [menu, setMenu] = useState(false);

	// refresh whenever the screen regains focus (e.g. after adding a site)
	useFocusEffect(
		useCallback(() => {
			if (dataSource) dispatch(fetchProjects(dataSource));
		}, [dataSource, dispatch]),
	);

	const items: SideMenuItem[] = [
		{ key: 'lang', label: 'Languages', glyph: 'language', onPress: () => navigation.navigate('LanguageSelector') },
		// TODO: the 2nd entry of the frame is not legible at export size – confirm its label/target.
		{ key: 'rate', label: 'Rate us', glyph: 'rate', onPress: () => {} },
		{ key: 'about', label: 'About us', glyph: 'about', onPress: () => navigation.navigate('AboutUs') },
		{ key: 'contact', label: 'Contact us', glyph: 'contact', onPress: () => navigation.navigate('ContactUs') },
		{ key: 'eula', label: 'EULA', glyph: 'doc', onPress: () => navigation.navigate('TermsAndConditions', { fileName: 'EULA' }) },
		{ key: 'privacy', label: 'Privacy statement', glyph: 'shield', onPress: () => navigation.navigate('TermsAndConditions', { fileName: 'PrivacyPolicy' }) },
		{ key: 'perm', label: 'App permissions', glyph: 'lock', onPress: () => Linking.openSettings() },
	];

	const hero = (
		<View style={styles.hero}>
			<View style={{ flex: 1 }} />
			<Text style={styles.title}>Your Sites</Text>
			<Pressable style={[headerIconBtn, styles.menuBtn]} onPress={() => setMenu(true)} hitSlop={8}>
				<MenuIcon />
			</Pressable>
		</View>
	);

	return (
		<HeroLayout hero={hero} heroHeight={110} bodyColor={scpColors.screenBg} align='center'>
			<FlatList
				data={sites}
				keyExtractor={s => String(s.projectId)}
				contentContainerStyle={{ padding: 16 }}
				renderItem={({ item }) => (
					<Pressable style={styles.card} onPress={() => navigation.navigate('ScpSiteDetail', { projectId: item.projectId })}>
						<View style={{ flex: 1 }}>
							<Text style={styles.name} numberOfLines={1}>{item.projectName}</Text>
							<View style={styles.sub}>
								<BuildingIcon />
								<Text style={styles.subText} numberOfLines={1}>
									{[item.site, item.building].filter(Boolean).join(', ') || '—'}
								</Text>
							</View>
						</View>
						<ChevronRight />
					</Pressable>
				)}
			/>
			<View style={styles.footer}>
				<PrimaryButton label='+ Site' onPress={() => navigation.navigate('ScpAddSite')} />
			</View>
			<SideMenu visible={menu} onClose={() => setMenu(false)} items={items} />
		</HeroLayout>
	);
}

const styles = StyleSheet.create({
	hero: { flex: 1, paddingHorizontal: 20, paddingBottom: 18, justifyContent: 'flex-end' },
	title: { color: scpColors.white, fontSize: 26, fontWeight: '700' },
	menuBtn: { position: 'absolute', right: 20, top: 8 },
	card: {
		flexDirection: 'row',
		alignItems: 'center',
		backgroundColor: scpColors.white,
		borderRadius: scpRadius.card,
		padding: 16,
		marginBottom: 12,
	},
	name: { fontSize: 15, fontWeight: '700', color: scpColors.ink },
	sub: { flexDirection: 'row', alignItems: 'center', marginTop: 6 },
	subText: { marginLeft: 6, fontSize: 12, color: scpColors.grey, flex: 1 },
	footer: { flexDirection: 'row', paddingHorizontal: 16, paddingVertical: 12 },
});
