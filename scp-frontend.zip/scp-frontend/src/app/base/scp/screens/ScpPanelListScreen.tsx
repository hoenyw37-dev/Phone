import React from 'react';
import { View, Text, Pressable, FlatList, StyleSheet } from 'react-native';
import HeroLayout from '../components/HeroLayout';
import EmptyPanels from '../components/EmptyPanels';
import PrimaryButton from '../components/PrimaryButton';
import { BackIcon, ChevronRight } from '../components/icons';
import { headerIconBtn } from '../components/StepHeader';
import { useAppSelector } from '@global/hooks';
import { selectPanelsByProject } from '@powerstrike/features/panels/redux/panelsSlice';
import { scpColors, scpRadius } from '../theme';

/**
 * Frames "Power strike | Power supply": empty state (illustration + "Add Panel")
 * and the "List of available panels" state. Data = existing panels slice
 * (already fetched by SiteDetailScreen).
 */
export default function ScpPanelListScreen({ route, navigation }: any) {
	const { projectId } = route.params;
	const panels = useAppSelector(s => selectPanelsByProject(s, projectId));
	const addPanel = () => navigation.navigate('ScpAddPanel', { projectId });
	const empty = !panels || panels.length === 0;

	const hero = (
		<View style={styles.hero}>
			<Pressable style={headerIconBtn} onPress={() => navigation.goBack()} hitSlop={8}>
				<BackIcon />
			</Pressable>
			<Text style={styles.title}>Power strike | Power supply</Text>
			<View style={{ width: 36 }} />
		</View>
	);

	return (
		<HeroLayout hero={hero} heroHeight={72} align='bottom' bodyColor={empty ? scpColors.white : scpColors.screenBg}>
			{empty ? (
				<EmptyPanels onAdd={addPanel} />
			) : (
				<>
					<Text style={styles.listLabel}>List of available panels</Text>
					<FlatList
						data={panels}
						keyExtractor={p => String(p.panelId)}
						contentContainerStyle={{ paddingHorizontal: 16 }}
						renderItem={({ item }) => (
							<Pressable style={styles.card} onPress={() => navigation.navigate('ScpPanelDetails', { panelId: item.panelId })}>
								<View style={{ flex: 1 }}>
									<Text style={styles.name} numberOfLines={1}>{item.panelName}</Text>
									<Text style={styles.sub}>
										{item.panelType}
										{item.updatedAt ? ` | Last configured ${new Date(item.updatedAt).toLocaleDateString()}` : ''}
									</Text>
								</View>
								<ChevronRight />
							</Pressable>
						)}
					/>
					<View style={styles.footer}>
						<PrimaryButton label='Add Panel' onPress={addPanel} />
					</View>
				</>
			)}
		</HeroLayout>
	);
}

const styles = StyleSheet.create({
	hero: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: 16, paddingTop: 8 },
	title: { color: scpColors.white, fontSize: 14, fontWeight: '600' },
	listLabel: { fontSize: 12, color: scpColors.grey, padding: 16, paddingBottom: 10 },
	card: { flexDirection: 'row', alignItems: 'center', backgroundColor: scpColors.white, borderRadius: scpRadius.card, padding: 16, marginBottom: 12 },
	name: { fontSize: 15, fontWeight: '600', color: scpColors.ink },
	sub: { fontSize: 12, color: scpColors.grey, marginTop: 4 },
	footer: { flexDirection: 'row', padding: 16 },
});
