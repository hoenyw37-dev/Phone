import React, { useCallback, useEffect, useState } from 'react';
import { View, Text, ScrollView, Pressable, StyleSheet } from 'react-native';
import Toast from 'react-native-toast-message';
import StepHeader from '../components/StepHeader';
import FormField from '../components/FormField';
import PrimaryButton from '../components/PrimaryButton';
import BottomSheet from '../components/BottomSheet';
import { ChevronRight } from '../components/icons';
import { createDefaultSettings } from '../panelDefaults';
import { useDatabase } from '@global/DatabaseContext';
import { useAppDispatch, useAppSelector } from '@global/hooks';
import { validateNewPanel } from '@powerstrike/features/panels/redux/panelsThunk';
import { Panel, Switch } from '@powerstrike/features/panels/types/panel';
import { fetchTemplates } from '@powerstrike/features/switches/redux/templatesThunk';
import { selectTemplatesByTypeAndPanelType } from '@powerstrike/features/switches/redux/templatesSlice';
import initializeTemplates from '@powerstrike/features/switches/dataAccess/initializeTemplates';
import { scpColors, scpRadius } from '../theme';

type Choice = { key: string; name: string; description: string; setting: Switch[] | null };

const MANUAL: Choice = { key: 'manual', name: 'Manual configuration', description: 'Configure each output yourself', setting: null };
const NAME_RE = /^[a-zA-Z0-9-_ ]*$/;

/**
 * Frames "Add Panel – Step 1 of 2": panel name, panel type (HPF-PS6 / HPF-PS10)
 * and configuration template (bottom sheet). Next validates through the
 * existing validateNewPanel thunk (duplicate names etc.), then opens step 2.
 * Nothing is written to the database until step 2 is saved.
 */
export default function AddPanelScreen({ route, navigation }: any) {
	const { projectId } = route.params;
	const dispatch = useAppDispatch();
	const { dataSource } = useDatabase();

	const [name, setName] = useState('');
	const [type, setType] = useState<'HPF-PS6' | 'HPF-PS10'>('HPF-PS6');
	const [choice, setChoice] = useState<Choice | null>(null);
	const [sheet, setSheet] = useState(false);
	const [nameError, setNameError] = useState('');

	const standard = useAppSelector(s => selectTemplatesByTypeAndPanelType(s, 'standard', type));
	const custom = useAppSelector(s => selectTemplatesByTypeAndPanelType(s, 'custom', type));

	// Load (and, on first use, seed) templates – same calls as legacy TemplatesList.
	const loadTemplates = useCallback(async () => {
		try {
			if (standard?.length === 0) await initializeTemplates(dataSource);
			await dispatch(fetchTemplates(dataSource));
		} catch (e) {
			console.error('Failed to load templates', e);
		}
	}, [dataSource, dispatch, standard?.length]);
	useEffect(() => {
		if (dataSource) loadTemplates();
	}, [dataSource]); // eslint-disable-line react-hooks/exhaustive-deps

	// a template belongs to one panel type, so switching type clears the choice
	const pickType = (t: 'HPF-PS6' | 'HPF-PS10') => {
		if (t !== type) {
			setType(t);
			setChoice(null);
		}
	};

	const choices: Choice[] = [
		MANUAL,
		...[...(standard || []), ...(custom || [])].map((t: any) => ({
			key: `t${t.templateId}`,
			name: t.templateName,
			description: t.templateDescription || '',
			setting: t.templateSetting as Switch[],
		})),
	];

	const canNext = name.trim().length > 0 && !!choice;

	const next = async () => {
		if (!NAME_RE.test(name)) return setNameError('Panel name cannot have special characters');
		setNameError('');
		const settings = choice!.setting ?? createDefaultSettings(type);
		const panel: Panel = { projectId, panelId: 0, panelName: name.trim(), panelType: type, panelSetting: settings, updatedAt: new Date().toISOString() };
		const res = await dispatch(validateNewPanel({ dataSource, panel }));
		if (validateNewPanel.rejected.match(res)) {
			const p = res.payload as { message?: string } | undefined;
			return Toast.show({ type: 'error', text1: p?.message || 'An unexpected error occurred while validating the panel.', visibilityTime: 2500 });
		}
		navigation.navigate('ScpConfigurePanel', {
			projectId,
			panelName: panel.panelName,
			panelType: type,
			templateName: choice!.name,
			templateSetting: choice!.setting, // null => manual configuration
		});
	};

	return (
		<View style={styles.root}>
			<StepHeader title='Add Panel' progress={0.5} />
			<ScrollView contentContainerStyle={styles.body} keyboardShouldPersistTaps='handled'>
				<Text style={styles.step}>Step 1 of 2</Text>
				<Text style={styles.title}>Provide following details</Text>

				<FormField label='Panel name' required value={name} onChangeText={setName} placeholder='Enter full name' maxLength={50} error={nameError} />

				<Text style={styles.label}>Panel type</Text>
				<View style={styles.segment}>
					{(['HPF-PS6', 'HPF-PS10'] as const).map(t => (
						<Pressable key={t} style={[styles.seg, type === t && styles.segOn]} onPress={() => pickType(t)}>
							<Text style={[styles.segText, type === t && { color: scpColors.blue, fontWeight: '600' }]}>{t}</Text>
						</Pressable>
					))}
				</View>

				<FormField label='Configuration template' value={choice?.name ?? ''} placeholder='Select configuration template' onPressDropdown={() => setSheet(true)} />
			</ScrollView>

			<View style={styles.footer}>
				<PrimaryButton variant='secondary' label='Cancel' onPress={() => navigation.goBack()} style={{ marginRight: 12 }} />
				<PrimaryButton label='Next' onPress={next} disabled={!canNext} />
			</View>

			<BottomSheet visible={sheet} onClose={() => setSheet(false)}>
				<Text style={styles.sheetTitle}>Select configuration template</Text>
				<ScrollView>
					{choices.map(c => (
						<Pressable
							key={c.key}
							style={styles.sheetRow}
							onPress={() => {
								setChoice(c);
								setSheet(false);
							}}>
							<View style={{ flex: 1 }}>
								<Text style={styles.sheetName}>{c.name}</Text>
								{!!c.description && <Text style={styles.sheetDesc}>{c.description}</Text>}
							</View>
							<ChevronRight />
						</Pressable>
					))}
				</ScrollView>
			</BottomSheet>
		</View>
	);
}

const styles = StyleSheet.create({
	root: { flex: 1, backgroundColor: scpColors.white },
	body: { padding: 20 },
	step: { color: scpColors.red, fontSize: 12, fontWeight: '600' },
	title: { color: scpColors.ink, fontSize: 22, fontWeight: '700', marginTop: 6, marginBottom: 24 },
	label: { fontSize: 13, color: scpColors.grey, marginBottom: 8 },
	segment: {
		flexDirection: 'row',
		borderWidth: 1,
		borderColor: scpColors.border,
		borderRadius: scpRadius.input,
		padding: 4,
		marginBottom: 18,
	},
	seg: { flex: 1, height: 40, alignItems: 'center', justifyContent: 'center', borderRadius: 8, borderWidth: 1, borderColor: 'transparent' },
	segOn: { borderColor: scpColors.blue },
	segText: { fontSize: 14, color: scpColors.grey },
	footer: { flexDirection: 'row', padding: 16, paddingBottom: 24 },
	sheetTitle: { fontSize: 16, fontWeight: '600', color: scpColors.ink, marginBottom: 8 },
	sheetRow: { flexDirection: 'row', alignItems: 'center', paddingVertical: 14, borderBottomWidth: StyleSheet.hairlineWidth, borderBottomColor: scpColors.border },
	sheetName: { fontSize: 14, fontWeight: '600', color: scpColors.ink },
	sheetDesc: { fontSize: 12, color: scpColors.grey, marginTop: 3 },
});
