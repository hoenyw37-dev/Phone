# Smart Configuration Plus – new first flow (frontend only)

Drop-in files for `hoenyw37-dev/Phone`. Paths are relative to `src/` of the unzipped
repo code (the repo stores `src/*.zip`; unzip `app.zip`, `assets.zip`, `global.zip`
first, then copy these files over them and re-zip if you keep that layout).

## What is inside
| Path | Status |
|---|---|
| `global/navigation/appNavigator.tsx` | **edited** – 10 imports, `initialRouteName='ScpSplash'`, one new `Stack.Group` (diff is additive only) |
| `app/base/scp/**` | **new** – theme, components, 10 screens |
| `assets/images/HoneywellBuilding.jpg`, `HoneywellLogo.png` | **new** – your supplied images |

No new npm dependencies. No changes to redux, TypeORM entities, data access or BLE code –
every screen uses the existing thunks (`fetchProjects`, `addNewProject`, `fetchPanelsByProject`,
`validateNewPanel`, `addNewPanel`, `updateExistingPanel`, `fetchTemplates`).

## Flow
Splash -> Terms and Policies -> (no sites) Add first site | (sites exist) Your Sites (+ side menu)
-> Site detail -> Power strike panel list (empty / list) -> Add Panel step 1 (name, type, template sheet)
-> Step 2 Configure panel (per-output option sheets) -> Success -> Panel details.

Legacy screens/routes are still registered, so nothing else breaks.

## Assumptions to confirm
1. Side-menu item #2 is not legible in the exported frame – I used "Rate us" with an empty handler (TODO in `SitesListScreen.tsx`).
2. Step-2 primary button label is unreadable too – I used **Save**.
3. Master switch S1 ("Global Options") has no UI in the frames, so it is kept in the data (templates carry it) but not shown.
4. Panel card sub-line shows `HPF-PSx | Last configured <date>` because the config type is not stored in the existing Panel model.
5. Font = system font; page grey `#F2F3F5` is derived (not in your palette).
