/** Local hybrid vector + FTS retrieval; does not call a hosted service. */
export { search } from '../runtime/rag/RetrievalService';
export type { Hit } from '../runtime/rag/RetrievalService';
