/** Public facade for the local-only answer pipeline. */
export { askQuestion, createLocalDataProvider } from '../runtime/engine/ChatbotEngine';
export type {
  AskQuestionOptions,
  AskQuestionResult,
  EntityDetails,
  LocalDataProvider,
  LocalDataResult,
  SourceReference,
} from '../runtime/engine/types';
