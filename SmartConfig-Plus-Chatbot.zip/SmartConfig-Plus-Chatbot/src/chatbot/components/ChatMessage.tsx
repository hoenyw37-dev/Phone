import React from 'react';
import { Text, View } from 'react-native';
import type { AskQuestionResult } from '../runtime/engine/types';

export type ChatLine = {
  id: string;
  role: 'user' | 'assistant';
  text: string;
  sources?: AskQuestionResult['sources'];
  pending?: boolean;
};

export function ChatMessage({ message }: { message: ChatLine }) {
  const user = message.role === 'user';
  return (
    <View style={{ alignSelf: user ? 'flex-end' : 'flex-start', maxWidth: '88%', marginVertical: 6 }}>
      <View style={{ borderRadius: 16, padding: 12, backgroundColor: user ? '#DCEBFF' : '#F1F2F4' }}>
        <Text accessibilityRole="text">{message.pending && !message.text ? 'Thinking…' : message.text}</Text>
      </View>
      {!!message.sources?.length && (
        <View style={{ paddingHorizontal: 8, paddingTop: 5 }}>
          {message.sources.map((source, index) => (
            <Text key={`${source.path}-${index}`} style={{ color: '#52657A', fontSize: 12, marginTop: 3 }}>
              Source: {source.path}{source.heading ? ` · ${source.heading}` : ''}
            </Text>
          ))}
        </View>
      )}
    </View>
  );
}
