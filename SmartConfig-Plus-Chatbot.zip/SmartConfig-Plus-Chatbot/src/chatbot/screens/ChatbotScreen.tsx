import React, { useState } from 'react';
import { Button, KeyboardAvoidingView, Platform, ScrollView, TextInput, View } from 'react-native';
import { ChatMessage } from '../components/ChatMessage';
import { useChatbot } from '../hooks/useChatbot';
import type { AskQuestionOptions } from '../services/LLMService';

/** Minimal drop-in screen. Pass an optional approved read-only local data provider. */
export default function ChatbotScreen({ localDataProvider }: { localDataProvider?: AskQuestionOptions['localDataProvider'] }) {
  const [question, setQuestion] = useState('');
  const { messages, busy, send, stop } = useChatbot(localDataProvider);
  const submit = () => { const value = question; setQuestion(''); void send(value); };
  return (
    <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
      <ScrollView style={{ flex: 1 }} contentContainerStyle={{ padding: 16 }} keyboardShouldPersistTaps="handled">
        {messages.map((message) => <ChatMessage key={message.id} message={message} />)}
      </ScrollView>
      <View style={{ flexDirection: 'row', alignItems: 'center', padding: 10, gap: 8 }}>
        <TextInput
          value={question}
          onChangeText={setQuestion}
          placeholder="Ask about this app…"
          multiline
          editable={!busy}
          accessibilityLabel="Question"
          style={{ flex: 1, minHeight: 44, maxHeight: 110, borderWidth: 1, borderColor: '#B8BEC7', borderRadius: 12, paddingHorizontal: 12, paddingVertical: 8 }}
        />
        <Button title={busy ? 'Stop' : 'Send'} onPress={busy ? stop : submit} />
      </View>
    </KeyboardAvoidingView>
  );
}
