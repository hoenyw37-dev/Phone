import { AgentRun } from '@chatbot/agent/AgentOrchestrator';
import type { Citation } from '@chatbot/types';
import type { AskQuestionOptions, AskQuestionResult, LocalDataProvider, SourceReference } from './types';

/**
 * Reusable question interface. It delegates to the existing on-device RAG and
 * llama.rn orchestration, without depending on a screen, router, or chat store.
 */
export async function askQuestion(
  question: string,
  options: AskQuestionOptions = {}
): Promise<AskQuestionResult> {
  const prompt = question.trim();
  if (!prompt) return { answer: 'Please enter a question.', sources: [] };
  if (options.signal?.aborted) throw new Error('Question cancelled');

  const citations: Citation[] = [];
  let answer = '';
  const run = new AgentRun();
  const abort = () => void run.stop();
  options.signal?.addEventListener('abort', abort, { once: true });
  try {
    await run.run({
      history: [], userText: prompt, documentsOnly: true, answerLength: 'normal',
      onEvent: (event) => {
        if (event.type === 'content') { answer = event.text; options.onToken?.(answer); }
        if (event.type === 'final') { answer = event.content; citations.splice(0, citations.length, ...event.citations); }
      },
    });
  } finally {
    options.signal?.removeEventListener('abort', abort);
  }

  let localDataStatus: AskQuestionResult['localDataStatus'];
  let entities: AskQuestionResult['entities'];
  if (options.localDataProvider && !options.signal?.aborted) {
    try {
      const local = await options.localDataProvider.lookup(prompt, options.signal);
      localDataStatus = local.status;
      if (local.status === 'available' && local.entities.length) entities = local.entities;
    } catch {
      localDataStatus = 'unavailable';
    }
  }
  return {
    answer,
    sources: citations.map(citationToSource),
    entities,
    localDataStatus,
    needsClarification: (entities?.length ?? 0) > 1,
  };
}

function citationToSource(citation: Citation): SourceReference {
  return { path: citation.sourcePath ?? citation.title, title: citation.title, excerpt: citation.snippet };
}

/** Optional adapter factory for host-owned, allowlisted local data access. */
export function createLocalDataProvider(
  lookup: LocalDataProvider['lookup']
): LocalDataProvider {
  return { lookup };
}

