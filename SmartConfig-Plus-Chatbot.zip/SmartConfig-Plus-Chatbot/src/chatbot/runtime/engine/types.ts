/** Public, screen-independent contracts for the offline assistant. */
export interface SourceReference {
  path: string;
  title?: string;
  heading?: string;
  excerpt?: string;
  score?: number;
}

export interface EntityDetails {
  type: string;
  id: string;
  name?: string;
  fields: Record<string, string | number | boolean | null>;
  navigation?: { route: string; params?: Record<string, string> };
}

export type LocalDataResult =
  | { status: 'available'; entities: EntityDetails[] }
  | { status: 'unavailable'; reason?: string };

/** Host apps implement approved, read-only lookups; never provide raw SQL. */
export interface LocalDataProvider {
  lookup(question: string, signal?: AbortSignal): Promise<LocalDataResult>;
}

export interface AskQuestionOptions {
  signal?: AbortSignal;
  localDataProvider?: LocalDataProvider;
  onToken?: (text: string) => void;
}

export interface AskQuestionResult {
  answer: string;
  sources: SourceReference[];
  entities?: EntityDetails[];
  localDataStatus?: 'available' | 'unavailable';
  needsClarification?: boolean;
}

