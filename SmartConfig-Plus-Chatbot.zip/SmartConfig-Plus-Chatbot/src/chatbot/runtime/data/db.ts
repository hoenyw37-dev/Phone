import { open, type DB, type Scalar } from '@op-engineering/op-sqlite';

import { log } from '@chatbot/utils/logger';
import { MIGRATIONS } from './schema';

const L = log('db');
let instance: DB | null = null;

export function getDb(): DB {
  if (instance) return instance;
  const db = open({ name: 'docassist.db' });
  db.executeSync('PRAGMA journal_mode = WAL');
  db.executeSync('PRAGMA foreign_keys = ON');
  migrate(db);
  instance = db;
  return db;
}

function migrate(db: DB) {
  const current = Number(db.executeSync('PRAGMA user_version').rows[0]?.user_version ?? 0);
  for (let v = current; v < MIGRATIONS.length; v++) {
    db.executeSync('BEGIN');
    try {
      for (const stmt of MIGRATIONS[v]) db.executeSync(stmt);
      db.executeSync(`PRAGMA user_version = ${v + 1}`);
      db.executeSync('COMMIT');
      L.info('migrated', { to: v + 1 });
    } catch (e) {
      db.executeSync('ROLLBACK');
      throw e;
    }
  }
}

export async function query<T = Record<string, Scalar>>(sql: string, params: Scalar[] = []): Promise<T[]> {
  const res = await getDb().execute(sql, params);
  return res.rows as T[];
}

export function querySync<T = Record<string, Scalar>>(sql: string, params: Scalar[] = []): T[] {
  return getDb().executeSync(sql, params).rows as T[];
}

export async function run(sql: string, params: Scalar[] = []) {
  return getDb().execute(sql, params);
}

export function closeAndDeleteDb() {
  getDb().delete();
  instance = null;
}
