import type { Scalar } from '@op-engineering/op-sqlite';

import type { ChunkRecord } from '@chatbot/types';
import { getDb, query } from '../db';

type Row = Record<string, any>;

export const mapChunk = (r: Row): ChunkRecord => ({
  id: r.id,
  documentId: r.document_id,
  ord: r.ord,
  pageStart: r.page_start ?? null,
  pageEnd: r.page_end ?? null,
  sectionPath: r.section_path ?? null,
  text: r.text,
  tokenCount: r.token_count,
});

export interface NewChunk {
  ord: number;
  pageStart: number | null;
  pageEnd: number | null;
  sectionPath: string | null;
  text: string;
  tokenCount: number;
}

export const chunksRepo = {
  async insertMany(documentId: string, chunks: NewChunk[]) {
    await getDb().transaction(async (tx) => {
      await tx.execute('DELETE FROM vec_chunks WHERE chunk_id IN (SELECT id FROM chunks WHERE document_id=?)', [documentId]);
      await tx.execute('DELETE FROM chunks WHERE document_id=?', [documentId]);
      for (const c of chunks) {
        await tx.execute(
          'INSERT INTO chunks (document_id,ord,page_start,page_end,section_path,text,token_count) VALUES (?,?,?,?,?,?,?)',
          [documentId, c.ord, c.pageStart, c.pageEnd, c.sectionPath, c.text, c.tokenCount]
        );
      }
    });
  },
  async byDocumentFrom(documentId: string, fromOrd: number, limit: number): Promise<ChunkRecord[]> {
    return (await query<Row>(
      'SELECT * FROM chunks WHERE document_id=? AND ord>=? ORDER BY ord LIMIT ?',
      [documentId, fromOrd, limit]
    )).map(mapChunk);
  },
  async allForDocument(documentId: string): Promise<ChunkRecord[]> {
    return (await query<Row>('SELECT * FROM chunks WHERE document_id=? ORDER BY ord', [documentId])).map(mapChunk);
  },
  async byIds(ids: number[]): Promise<(ChunkRecord & { title: string })[]> {
    if (!ids.length) return [];
    const rows = await query<Row>(
      `SELECT c.*, d.title, d.local_path AS source_path FROM chunks c JOIN documents d ON d.id=c.document_id
       WHERE c.id IN (${ids.map(() => '?').join(',')}) AND d.status='ready'`,
      ids
    );
    return rows.map((r) => ({ ...mapChunk(r), title: r.title, sourcePath: String(r.source_path ?? '').startsWith('kb://') ? String(r.source_path).slice(5) : undefined }));
  },
  async neighbours(chunk: ChunkRecord, expand: number): Promise<ChunkRecord[]> {
    return (await query<Row>(
      'SELECT * FROM chunks WHERE document_id=? AND ord BETWEEN ? AND ? ORDER BY ord',
      [chunk.documentId, chunk.ord - expand, chunk.ord + expand]
    )).map(mapChunk);
  },
  async insertVectors(items: { chunkId: number; vector: Float32Array }[]) {
    await getDb().transaction(async (tx) => {
      for (const it of items) {
        // vec0 has no upsert; delete first so a resumed batch is idempotent.
        await tx.execute('DELETE FROM vec_chunks WHERE chunk_id=?', [it.chunkId]);
        await tx.execute('INSERT INTO vec_chunks(chunk_id, embedding) VALUES (?, ?)', [
          it.chunkId,
          it.vector.buffer as ArrayBuffer,
        ]);
      }
    });
  },
  async vectors(ids: number[]): Promise<Map<number, Float32Array>> {
    const out = new Map<number, Float32Array>();
    if (!ids.length) return out;
    const rows = await query<Row>(
      `SELECT chunk_id, embedding FROM vec_chunks WHERE chunk_id IN (${ids.map(() => '?').join(',')})`,
      ids as Scalar[]
    );
    for (const r of rows) out.set(r.chunk_id, new Float32Array(r.embedding as ArrayBuffer));
    return out;
  },
};
