import type { DocStatus, DocumentRecord } from '@chatbot/types';
import { getDb, query, run } from '../db';

type Row = Record<string, any>;

const map = (r: Row): DocumentRecord => ({
  id: r.id,
  title: r.title,
  fileName: r.file_name,
  mime: r.mime,
  sizeBytes: r.size_bytes,
  sha256: r.sha256,
  localPath: r.local_path,
  pageCount: r.page_count ?? null,
  chunkCount: r.chunk_count ?? 0,
  status: r.status,
  progress: r.progress ?? 0,
  error: r.error ?? null,
  summary: r.summary ?? null,
  description: r.description ?? null,
  createdAt: r.created_at,
  updatedAt: r.updated_at,
});

export const documentsRepo = {
  async list(): Promise<DocumentRecord[]> {
    return (await query<Row>('SELECT * FROM documents ORDER BY created_at DESC')).map(map);
  },
  async listReady(): Promise<DocumentRecord[]> {
    return (await query<Row>("SELECT * FROM documents WHERE status='ready' ORDER BY title")).map(map);
  },
  async get(id: string): Promise<DocumentRecord | null> {
    const rows = await query<Row>('SELECT * FROM documents WHERE id=?', [id]);
    return rows[0] ? map(rows[0]) : null;
  },
  async findBySha(sha: string): Promise<DocumentRecord | null> {
    const rows = await query<Row>('SELECT * FROM documents WHERE sha256=?', [sha]);
    return rows[0] ? map(rows[0]) : null;
  },
  async insert(d: Omit<DocumentRecord, 'chunkCount' | 'progress' | 'error' | 'summary' | 'description' | 'pageCount'>) {
    await run(
      `INSERT INTO documents (id,title,file_name,mime,size_bytes,sha256,local_path,status,created_at,updated_at)
       VALUES (?,?,?,?,?,?,?,?,?,?)`,
      [d.id, d.title, d.fileName, d.mime, d.sizeBytes, d.sha256, d.localPath, d.status, d.createdAt, d.updatedAt]
    );
  },
  async update(id: string, patch: Partial<{ status: DocStatus; progress: number; error: string | null; pageCount: number; chunkCount: number; summary: string; description: string }>) {
    const cols: Record<string, string> = {
      status: 'status', progress: 'progress', error: 'error', pageCount: 'page_count',
      chunkCount: 'chunk_count', summary: 'summary', description: 'description',
    };
    const keys = Object.keys(patch) as (keyof typeof patch)[];
    if (!keys.length) return;
    const sets = keys.map((k) => `${cols[k]}=?`).join(',');
    await run(`UPDATE documents SET ${sets}, updated_at=? WHERE id=?`, [
      ...keys.map((k) => (patch[k] ?? null) as any), Date.now(), id,
    ]);
  },
  /** Removes vectors explicitly (vec0 does not cascade), then the document (chunks + FTS cascade). */
  async remove(id: string) {
    await getDb().transaction(async (tx) => {
      await tx.execute('DELETE FROM vec_chunks WHERE chunk_id IN (SELECT id FROM chunks WHERE document_id=?)', [id]);
      await tx.execute('DELETE FROM documents WHERE id=?', [id]);
    });
  },
  async stats(): Promise<{ docs: number; ready: number; chunks: number }> {
    const r = (await query<Row>(
      "SELECT COUNT(*) AS docs, SUM(status='ready') AS ready, (SELECT COUNT(*) FROM chunks) AS chunks FROM documents"
    ))[0];
    return { docs: r?.docs ?? 0, ready: r?.ready ?? 0, chunks: r?.chunks ?? 0 };
  },
};
