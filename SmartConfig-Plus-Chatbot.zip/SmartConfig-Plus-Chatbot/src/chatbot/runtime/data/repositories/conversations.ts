import type { AgentStepView, ChatMessage, Citation, Conversation, MessageStatus, TurnMetrics } from '@chatbot/types';
import { query, run } from '../db';

type Row = Record<string, any>;

const mapMsg = (r: Row): ChatMessage => ({
  id: r.id,
  conversationId: r.conversation_id,
  role: r.role,
  content: r.content,
  citations: r.citations_json ? (JSON.parse(r.citations_json) as Citation[]) : [],
  steps: r.steps_json ? (JSON.parse(r.steps_json) as AgentStepView[]) : [],
  status: r.status,
  metrics: r.metrics_json ? (JSON.parse(r.metrics_json) as TurnMetrics) : undefined,
  createdAt: r.created_at,
});

export const conversationsRepo = {
  async list(): Promise<Conversation[]> {
    return (await query<Row>('SELECT * FROM conversations ORDER BY updated_at DESC')).map((r) => ({
      id: r.id, title: r.title ?? null, createdAt: r.created_at, updatedAt: r.updated_at,
    }));
  },
  async create(id: string, title: string | null = null) {
    const now = Date.now();
    await run('INSERT INTO conversations (id,title,created_at,updated_at) VALUES (?,?,?,?)', [id, title, now, now]);
  },
  async rename(id: string, title: string) {
    await run('UPDATE conversations SET title=?, updated_at=? WHERE id=?', [title, Date.now(), id]);
  },
  async touch(id: string) {
    await run('UPDATE conversations SET updated_at=? WHERE id=?', [Date.now(), id]);
  },
  async remove(id: string) {
    await run('DELETE FROM conversations WHERE id=?', [id]);
  },
  async messages(conversationId: string): Promise<ChatMessage[]> {
    return (await query<Row>('SELECT * FROM messages WHERE conversation_id=? ORDER BY created_at', [conversationId])).map(mapMsg);
  },
  async upsertMessage(m: ChatMessage) {
    await run(
      `INSERT INTO messages (id,conversation_id,role,content,citations_json,steps_json,status,metrics_json,created_at)
       VALUES (?,?,?,?,?,?,?,?,?)
       ON CONFLICT(id) DO UPDATE SET content=excluded.content, citations_json=excluded.citations_json,
         steps_json=excluded.steps_json, status=excluded.status, metrics_json=excluded.metrics_json`,
      [
        m.id, m.conversationId, m.role, m.content,
        m.citations.length ? JSON.stringify(m.citations) : null,
        m.steps.length ? JSON.stringify(m.steps) : null,
        m.status, m.metrics ? JSON.stringify(m.metrics) : null, m.createdAt,
      ]
    );
  },
  async setStatus(id: string, status: MessageStatus) {
    await run('UPDATE messages SET status=? WHERE id=?', [status, id]);
  },
  async deleteMessage(id: string) {
    await run('DELETE FROM messages WHERE id=?', [id]);
  },
  /** Any message left 'streaming' after a crash/kill is marked stopped. */
  async recoverStreaming() {
    await run("UPDATE messages SET status='stopped' WHERE status='streaming'");
  },
};
