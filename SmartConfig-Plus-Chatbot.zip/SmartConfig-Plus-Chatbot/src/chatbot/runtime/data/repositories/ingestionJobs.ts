import { query, run } from '../db';

export interface IngestionJob { documentId: string; stage: 'queued' | 'chunked'; nextOrd: number; attempts: number }

export const jobsRepo = {
  async upsert(j: IngestionJob) {
    await run(
      `INSERT INTO ingestion_jobs (document_id,stage,next_ord,attempts) VALUES (?,?,?,?)
       ON CONFLICT(document_id) DO UPDATE SET stage=excluded.stage, next_ord=excluded.next_ord, attempts=excluded.attempts`,
      [j.documentId, j.stage, j.nextOrd, j.attempts]
    );
  },
  async pending(): Promise<IngestionJob[]> {
    const rows = await query<any>('SELECT * FROM ingestion_jobs ORDER BY rowid');
    return rows.map((r) => ({ documentId: r.document_id, stage: r.stage, nextOrd: r.next_ord, attempts: r.attempts }));
  },
  async remove(documentId: string) {
    await run('DELETE FROM ingestion_jobs WHERE document_id=?', [documentId]);
  },
};
