// Migrations (LLD §3). Each entry runs once, tracked via PRAGMA user_version.
export const MIGRATIONS: string[][] = [
  [
    `CREATE TABLE IF NOT EXISTS documents (
      id TEXT PRIMARY KEY,
      title TEXT NOT NULL,
      file_name TEXT NOT NULL,
      mime TEXT NOT NULL,
      size_bytes INTEGER NOT NULL,
      sha256 TEXT NOT NULL UNIQUE,
      local_path TEXT NOT NULL,
      page_count INTEGER,
      chunk_count INTEGER DEFAULT 0,
      status TEXT NOT NULL CHECK (status IN ('queued','parsing','embedding','ready','failed')),
      progress REAL DEFAULT 0,
      error TEXT,
      summary TEXT,
      description TEXT,
      created_at INTEGER NOT NULL,
      updated_at INTEGER NOT NULL
    )`,
    `CREATE TABLE IF NOT EXISTS chunks (
      id INTEGER PRIMARY KEY,
      document_id TEXT NOT NULL REFERENCES documents(id) ON DELETE CASCADE,
      ord INTEGER NOT NULL,
      page_start INTEGER,
      page_end INTEGER,
      section_path TEXT,
      text TEXT NOT NULL,
      token_count INTEGER NOT NULL,
      UNIQUE(document_id, ord)
    )`,
    `CREATE INDEX IF NOT EXISTS idx_chunks_doc ON chunks(document_id, ord)`,
    `CREATE VIRTUAL TABLE IF NOT EXISTS vec_chunks USING vec0(
      chunk_id INTEGER PRIMARY KEY,
      embedding float[384] distance_metric=cosine
    )`,
    `CREATE VIRTUAL TABLE IF NOT EXISTS fts_chunks USING fts5(
      text, section_path,
      content='chunks', content_rowid='id',
      tokenize='unicode61 remove_diacritics 2'
    )`,
    `CREATE TRIGGER IF NOT EXISTS chunks_ai AFTER INSERT ON chunks BEGIN
      INSERT INTO fts_chunks(rowid, text, section_path) VALUES (new.id, new.text, new.section_path);
    END`,
    `CREATE TRIGGER IF NOT EXISTS chunks_ad AFTER DELETE ON chunks BEGIN
      INSERT INTO fts_chunks(fts_chunks, rowid, text, section_path) VALUES ('delete', old.id, old.text, old.section_path);
    END`,
    `CREATE TABLE IF NOT EXISTS conversations (
      id TEXT PRIMARY KEY, title TEXT, created_at INTEGER NOT NULL, updated_at INTEGER NOT NULL
    )`,
    `CREATE TABLE IF NOT EXISTS messages (
      id TEXT PRIMARY KEY,
      conversation_id TEXT NOT NULL REFERENCES conversations(id) ON DELETE CASCADE,
      role TEXT NOT NULL CHECK (role IN ('user','assistant','system','tool')),
      content TEXT NOT NULL,
      citations_json TEXT,
      steps_json TEXT,
      status TEXT NOT NULL DEFAULT 'complete' CHECK (status IN ('streaming','complete','stopped','error')),
      metrics_json TEXT,
      created_at INTEGER NOT NULL
    )`,
    `CREATE INDEX IF NOT EXISTS idx_messages_conv ON messages(conversation_id, created_at)`,
    `CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value TEXT NOT NULL)`,
    `CREATE TABLE IF NOT EXISTS ingestion_jobs (
      document_id TEXT PRIMARY KEY REFERENCES documents(id) ON DELETE CASCADE,
      stage TEXT NOT NULL,
      next_ord INTEGER NOT NULL DEFAULT 0,
      attempts INTEGER NOT NULL DEFAULT 0
    )`,
  ],
];
