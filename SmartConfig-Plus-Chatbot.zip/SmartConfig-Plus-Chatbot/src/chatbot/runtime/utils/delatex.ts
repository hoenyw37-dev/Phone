/** Small models sometimes emit LaTeX; render the common bits as plain text. */
export function delatex(s: string): string {
  return s
    .replace(/\\(?:times|cdot)/g, '×')
    .replace(/\\div/g, '÷')
    .replace(/\\(?:approx)/g, '≈')
    .replace(/\\(?:leq|le)\b/g, '≤')
    .replace(/\\(?:geq|ge)\b/g, '≥')
    .replace(/\\text\{([^}]*)\}/g, '$1')
    .replace(/\\frac\{([^}]*)\}\{([^}]*)\}/g, '$1/$2')
    .replace(/\\[()[\]]/g, '')
    .replace(/\$([^$\n]{1,80})\$/g, (m, inner: string) => (/[a-z]{3,}\s[a-z]{3,}/i.test(inner) ? m : inner))
    .replace(/\\%/g, '%');
}
