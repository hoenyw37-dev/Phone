import { randomUUID } from 'expo-crypto';

/** Time-sortable id: base36 millis + random suffix. */
export function newId(): string {
  return Date.now().toString(36).padStart(9, '0') + '-' + randomUUID().slice(0, 8);
}
