/** Cheap token estimate for budgeting (LLD §7.3). Exact counts come from the model's tokenizer. */
export const estimateTokens = (text: string): number => Math.ceil(text.length / 3.6);

export function truncateToTokens(text: string, maxTokens: number): string {
  const maxChars = Math.floor(maxTokens * 3.6);
  return text.length <= maxChars ? text : text.slice(0, maxChars).trimEnd() + '…';
}
