// Local-only logger (LLD §14). Never logs document text or prompts in release builds.
import { File, Paths } from 'expo-file-system';

type Level = 'debug' | 'info' | 'warn' | 'error';
const MAX_BYTES = 1_000_000;
const buffer: string[] = [];
let flushTimer: ReturnType<typeof setTimeout> | null = null;

function logFile() {
  return new File(Paths.document, 'app.log');
}

function flush() {
  flushTimer = null;
  if (!buffer.length) return;
  try {
    const f = logFile();
    if (f.exists && (f.size ?? 0) > MAX_BYTES) {
      const old = new File(Paths.document, 'app.1.log');
      if (old.exists) old.delete();
      f.moveSync(old);
    }
    const target = logFile();
    if (!target.exists) target.create();
    target.write(buffer.join('\n') + '\n', { append: true });
  } catch {
    // logging must never crash the app
  }
  buffer.length = 0;
}

function write(level: Level, scope: string, msg: string, meta?: Record<string, unknown>) {
  const line = `${new Date().toISOString()} ${level.toUpperCase()} [${scope}] ${msg}${meta ? ' ' + JSON.stringify(meta) : ''}`;
  if (__DEV__) console[level === 'debug' ? 'log' : level](line);
  buffer.push(line);
  if (!flushTimer) flushTimer = setTimeout(flush, 2000);
}

export const log = (scope: string) => ({
  debug: (m: string, meta?: Record<string, unknown>) => __DEV__ && write('debug', scope, m, meta),
  info: (m: string, meta?: Record<string, unknown>) => write('info', scope, m, meta),
  warn: (m: string, meta?: Record<string, unknown>) => write('warn', scope, m, meta),
  error: (m: string, meta?: Record<string, unknown>) => write('error', scope, m, meta),
});

export function logFileUri(): string {
  flush();
  return logFile().uri;
}
