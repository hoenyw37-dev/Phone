export type AppErrorCode =
  | 'MODEL_LOAD_FAILED'
  | 'MODEL_FILE_CORRUPT'
  | 'INSUFFICIENT_MEMORY'
  | 'NO_DOCUMENTS'
  | 'SCANNED_PDF_UNSUPPORTED'
  | 'FILE_TOO_LARGE'
  | 'UNSUPPORTED_TYPE'
  | 'DUPLICATE_DOCUMENT'
  | 'GENERATION_ABORTED'
  | 'ENGINE_NOT_READY'
  | 'PARSE_FAILED';

const MESSAGES: Record<AppErrorCode, string> = {
  MODEL_LOAD_FAILED: "The assistant couldn't start. Close other apps and try again.",
  MODEL_FILE_CORRUPT: 'Preparing the assistant failed. Please reinstall the app.',
  INSUFFICIENT_MEMORY: 'Your device ran low on memory, so the answer was shortened.',
  NO_DOCUMENTS: 'No documents yet. Ask an admin to add some.',
  SCANNED_PDF_UNSUPPORTED: 'This PDF looks scanned. Only PDFs with selectable text are supported for now.',
  FILE_TOO_LARGE: 'This file is too large.',
  UNSUPPORTED_TYPE: "This file type isn't supported.",
  DUPLICATE_DOCUMENT: 'This document is already added.',
  GENERATION_ABORTED: 'Stopped.',
  ENGINE_NOT_READY: 'The assistant is still getting ready.',
  PARSE_FAILED: "This document couldn't be read.",
};

export class AppError extends Error {
  constructor(public code: AppErrorCode, message?: string) {
    super(message ?? MESSAGES[code]);
  }
}

/** User-facing text: AppErrors carry curated copy; anything else gets a generic fallback (raw detail is logged). */
export const userMessage = (e: unknown, fallback = 'Something went wrong. Please try again.'): string =>
  e instanceof AppError ? e.message : fallback;
