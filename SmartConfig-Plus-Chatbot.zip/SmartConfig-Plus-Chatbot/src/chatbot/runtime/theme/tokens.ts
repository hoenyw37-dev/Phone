// Semantic design tokens (ADR-007, LLD §9). All pairs are contrast-checked in __tests__/contrast.test.ts.
export type ThemeMode = 'light' | 'dark' | 'system';
export type Scheme = 'light' | 'dark';

export const palette = {
  light: {
    bg: '#F7F7FA',
    surface: '#FFFFFF',
    surfaceElevated: '#FFFFFF',
    surfaceMuted: '#EEEFF4',
    textPrimary: '#14151A',
    textSecondary: '#5B5F6B',
    border: '#E4E5EA',
    accent: '#4F46E5',
    accentSoft: '#EEF0FF',
    accentOn: '#FFFFFF',
    bubbleUser: '#4F46E5',
    bubbleUserText: '#FFFFFF',
    bubbleAssistant: '#FFFFFF',
    success: '#15803D',
    warning: '#B45309',
    danger: '#B91C1C',
    focus: '#6366F1',
    scrim: 'rgba(0,0,0,0.35)',
    shadow: 'rgba(20,21,26,0.08)',
  },
  dark: {
    bg: '#0E0F13',
    surface: '#17181D',
    surfaceElevated: '#1F2128',
    surfaceMuted: '#24262E',
    textPrimary: '#F2F3F5',
    textSecondary: '#A3A7B3',
    border: '#2A2C34',
    accent: '#818CF8',
    accentSoft: '#23244A',
    accentOn: '#0E0F13',
    bubbleUser: '#4F46E5',
    bubbleUserText: '#FFFFFF',
    bubbleAssistant: '#1F2128',
    success: '#4ADE80',
    warning: '#FBBF24',
    danger: '#F87171',
    focus: '#A5B4FC',
    scrim: 'rgba(0,0,0,0.6)',
    shadow: 'rgba(0,0,0,0.4)',
  },
} as const;

export type Colors = { [K in keyof (typeof palette)['light']]: string };

export const space = { xs: 4, sm: 8, md: 12, lg: 16, xl: 20, xxl: 24, xxxl: 32 };
export const radius = { sm: 8, md: 12, lg: 18, xl: 24, pill: 999 };
export const type = {
  title: { fontSize: 22, lineHeight: 28, fontWeight: '600' as const },
  heading: { fontSize: 17, lineHeight: 22, fontWeight: '600' as const },
  body: { fontSize: 16, lineHeight: 22, fontWeight: '400' as const },
  callout: { fontSize: 15, lineHeight: 20, fontWeight: '400' as const },
  caption: { fontSize: 13, lineHeight: 18, fontWeight: '500' as const },
  micro: { fontSize: 11, lineHeight: 14, fontWeight: '600' as const },
};
export const motion = { fast: 150, base: 220, slow: 300 };
