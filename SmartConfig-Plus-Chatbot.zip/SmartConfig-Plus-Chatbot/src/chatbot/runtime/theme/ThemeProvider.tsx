import { setBackgroundColorAsync } from 'expo-system-ui';
import { StatusBar } from 'expo-status-bar';
import React, { createContext, useContext, useEffect, useMemo } from 'react';
import { useColorScheme } from 'react-native';
import Animated, { useReducedMotion, useSharedValue, withTiming, useAnimatedStyle } from 'react-native-reanimated';

import { useSettingsStore } from '@chatbot/state/settingsStore';
import { palette, type Colors, type Scheme } from './tokens';

interface ThemeCtx {
  scheme: Scheme;
  colors: Colors;
}

const Ctx = createContext<ThemeCtx>({ scheme: 'light', colors: palette.light });

export function ThemeProvider({ children }: { children: React.ReactNode }) {
  const system = useColorScheme();
  const mode = useSettingsStore((s) => s.themeMode);
  const scheme: Scheme = mode === 'system' ? (system === 'dark' ? 'dark' : 'light') : mode;
  const value = useMemo(() => ({ scheme, colors: palette[scheme] as Colors }), [scheme]);
  const reduceMotion = useReducedMotion();

  // Theme cross-fade (ADR-007): briefly dip opacity of a scrim in the new bg colour.
  const fade = useSharedValue(0);
  useEffect(() => {
    setBackgroundColorAsync(value.colors.bg).catch(() => {});
    if (reduceMotion) return;
    fade.value = 0.6;
    fade.value = withTiming(0, { duration: 250 });
  }, [scheme]); // eslint-disable-line react-hooks/exhaustive-deps

  const scrimStyle = useAnimatedStyle(() => ({ opacity: fade.value }));

  return (
    <Ctx.Provider value={value}>
      <StatusBar style={scheme === 'dark' ? 'light' : 'dark'} />
      {children}
      <Animated.View
        pointerEvents="none"
        style={[{ position: 'absolute', top: 0, left: 0, right: 0, bottom: 0, backgroundColor: value.colors.bg }, scrimStyle]}
      />
    </Ctx.Provider>
  );
}

export const useTheme = () => useContext(Ctx);
