// Keep in sync with scripts/fetch-models.sh (ADR-006).
export type ModelSpec = { file: string; sizeBytes: number; sha256: string; label: string; quant: string };

export const MODELS = {
  llm: {
    file: 'qwen3-1.7b-q4_k_m.gguf',
    sizeBytes: 1107409472,
    sha256: 'b139949c5bd74937ad8ed8c8cf3d9ffb1e99c866c823204dc42c0d91fa181897',
    label: 'Qwen3-1.7B',
    quant: 'Q4_K_M',
  },
  embedding: {
    file: 'bge-small-en-v1.5-q8_0.gguf',
    sizeBytes: 36806944,
    sha256: 'ec38e8da142596baa913124ae50550de284b6916bf59577ef2f0cb9660c2f514',
    label: 'bge-small-en-v1.5',
    quant: 'Q8_0',
  },
} satisfies Record<string, ModelSpec>;

export const EMBEDDING_DIM = 384;
export const BGE_QUERY_PREFIX = 'Represent this sentence for searching relevant passages: ';
