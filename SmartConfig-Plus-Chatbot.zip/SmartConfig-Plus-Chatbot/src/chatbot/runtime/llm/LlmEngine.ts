import { initLlama, type LlamaContext } from 'llama.rn';
import { Platform } from 'react-native';

import { AppError } from '@chatbot/utils/errors';
import { log } from '@chatbot/utils/logger';
import type { DeviceCaps } from '@chatbot/native/nativeUtils';
import type { ChatMsg, CompletionOpts, CompletionResult, EngineState, Sampling, ToolCall } from './types';

const L = log('llm');

// Qwen3 recommended sampling (LLD §4.3).
const SAMPLING = {
  nonThinking: { temperature: 0.7, top_p: 0.8, top_k: 20, min_p: 0, penalty_present: 0.5 },
  thinking: { temperature: 0.6, top_p: 0.95, top_k: 20, min_p: 0, penalty_present: 0.5 },
} satisfies Record<string, Sampling>;

export interface LlmLoadConfig {
  path: string;
  caps: DeviceCaps;
  nCtx?: number;
}

/** Converts our messages to the OpenAI-compatible shape llama.rn's Jinja formatter expects. */
function toOai(messages: ChatMsg[]) {
  return messages.map((m) => {
    if (m.role === 'assistant' && m.tool_calls?.length) {
      return {
        role: 'assistant',
        content: m.content || '',
        tool_calls: m.tool_calls.map((c) => ({
          type: 'function',
          id: c.id,
          function: { name: c.name, arguments: JSON.stringify(c.arguments) },
        })),
      };
    }
    if (m.role === 'tool') return { role: 'tool', content: m.content, tool_call_id: m.tool_call_id, name: m.name };
    return { role: m.role, content: m.content };
  });
}

function parseArgs(raw: string): Record<string, unknown> {
  try {
    const v = JSON.parse(raw || '{}');
    return v && typeof v === 'object' ? v : {};
  } catch {
    return {};
  }
}

export class LlmEngine {
  state: EngineState = 'idle';
  nCtx = 4096;
  gpu = false;
  private ctx: LlamaContext | null = null;
  private listeners = new Set<(s: EngineState) => void>();

  onState(cb: (s: EngineState) => void) {
    this.listeners.add(cb);
    return () => this.listeners.delete(cb);
  }

  private setState(s: EngineState) {
    this.state = s;
    this.listeners.forEach((l) => l(s));
  }

  get info() {
    return { gpu: this.gpu, nCtx: this.nCtx, desc: this.ctx?.model?.desc ?? '' };
  }

  async load({ path, caps, nCtx }: LlmLoadConfig, onProgress?: (p: number) => void) {
    if (this.state === 'ready' || this.state === 'loading') return;
    this.setState('loading');
    this.nCtx = nCtx ?? (caps.tier === 'A' ? 8192 : caps.tier === 'B' ? 4096 : 2048);
    const base = {
      model: path,
      n_ctx: this.nCtx,
      n_batch: 512,
      n_ubatch: 512,
      n_parallel: 1,
      n_threads: caps.performanceCores,
      n_gpu_layers: Platform.OS === 'ios' ? 99 : 0,
      use_mmap: true,
      use_mlock: false,
      ctx_shift: false,
    };
    try {
      try {
        // q8_0 KV cache halves memory; requires flash attention.
        this.ctx = await initLlama(
          { ...base, flash_attn_type: 'on', cache_type_k: 'q8_0', cache_type_v: 'q8_0' },
          (p) => onProgress?.(p / 100)
        );
      } catch (e) {
        L.warn('init with quantised KV failed, retrying with f16', { e: String(e) });
        this.ctx = await initLlama({ ...base, flash_attn_type: 'auto' }, (p) => onProgress?.(p / 100));
      }
      this.gpu = this.ctx.gpu;
      L.info('loaded', { nCtx: this.nCtx, gpu: this.gpu, desc: this.ctx.model.desc });
      this.setState('ready');
    } catch (e) {
      L.error('load failed', { e: String(e) });
      this.ctx = null;
      this.setState('error');
      throw new AppError('MODEL_LOAD_FAILED');
    }
  }

  async complete(o: CompletionOpts): Promise<CompletionResult> {
    if (!this.ctx || this.state !== 'ready') throw new AppError('ENGINE_NOT_READY');
    this.setState('generating');
    const sampling = { ...(o.thinking ? SAMPLING.thinking : SAMPLING.nonThinking), ...o.sampling };
    const started = Date.now();
    let ttft = 0;
    let sawTool = false;
    let lastContent = '';
    try {
      const res = await this.ctx.completion(
        {
          messages: toOai(o.messages) as any,
          jinja: true,
          tools: o.tools?.length ? o.tools : undefined,
          tool_choice: o.tools?.length ? (o.toolChoice ?? 'auto') : undefined,
          enable_thinking: !!o.thinking,
          reasoning_format: 'auto',
          grammar: o.grammar,
          n_predict: o.maxTokens ?? 700,
          ...sampling,
        },
        (data) => {
          if (!ttft) ttft = Date.now() - started;
          if (data.tool_calls?.length && !sawTool) {
            sawTool = true;
            o.onToolCallDetected?.();
          }
          if (sawTool || !o.onContent) return;
          if (typeof data.content === 'string' && data.content !== lastContent) {
            // content is the accumulated parsed answer; guard against delta-style payloads.
            lastContent = data.content.startsWith(lastContent) || !lastContent ? data.content : lastContent + data.content;
            o.onContent(lastContent);
          }
        }
      );
      const toolCalls: ToolCall[] = (res.tool_calls ?? []).map((c, i) => ({
        id: c.id || `call_${Date.now().toString(36)}_${i}`,
        name: c.function.name,
        arguments: parseArgs(c.function.arguments),
      }));
      const t = res.timings;
      return {
        text: res.text,
        content: (res.content ?? res.text ?? '').trim(),
        reasoning: res.reasoning_content || undefined,
        toolCalls,
        stoppedBy: res.interrupted ? 'abort' : res.stopped_eos ? 'eos' : res.stopped_limit ? 'limit' : 'stop_word',
        timings: {
          promptMs: t?.prompt_ms ?? 0,
          predictedMs: t?.predicted_ms ?? 0,
          promptTokens: t?.prompt_n ?? 0,
          predictedTokens: t?.predicted_n ?? 0,
          tokPerSec: t?.predicted_per_second ?? 0,
          ttftMs: ttft,
        },
      };
    } finally {
      if ((this.state as EngineState) === 'generating') this.setState('ready');
    }
  }

  async stop() {
    await this.ctx?.stopCompletion().catch(() => {});
  }

  /** Waits for in-flight generation to stop before freeing native memory (LLD §4.2). */
  async release() {
    if (!this.ctx) return;
    if (this.state === 'generating') await this.stop();
    this.setState('releasing');
    try {
      await this.ctx.release();
    } finally {
      this.ctx = null;
      this.setState('idle');
    }
  }
}

export const llm = new LlmEngine();
