// Serialises access to native contexts; chat work jumps ahead of ingestion (HLA §4).
type Task<T> = { run: () => Promise<T>; resolve: (v: T) => void; reject: (e: unknown) => void; priority: number };

class Queue {
  private tasks: Task<any>[] = [];
  private busy = false;
  activeChatTurns = 0;

  enqueue<T>(run: () => Promise<T>, priority: 'chat' | 'ingest' = 'chat'): Promise<T> {
    return new Promise<T>((resolve, reject) => {
      const p = priority === 'chat' ? 1 : 0;
      const t: Task<T> = { run, resolve, reject, priority: p };
      const idx = this.tasks.findIndex((x) => x.priority < p);
      if (idx === -1) this.tasks.push(t);
      else this.tasks.splice(idx, 0, t);
      void this.pump();
    });
  }

  private async pump() {
    if (this.busy) return;
    const t = this.tasks.shift();
    if (!t) return;
    this.busy = true;
    try {
      t.resolve(await t.run());
    } catch (e) {
      t.reject(e);
    } finally {
      this.busy = false;
      void this.pump();
    }
  }
}

export const inferenceQueue = new Queue();
