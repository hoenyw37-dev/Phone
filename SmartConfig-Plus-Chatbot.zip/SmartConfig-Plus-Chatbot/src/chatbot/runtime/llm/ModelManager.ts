import { AppState } from 'react-native';

import { getDeviceCaps, getThermalState, onInstallProgress, onMemoryWarning, resolveModelPath } from '@chatbot/native/nativeUtils';
import { useModelStore } from '@chatbot/state/modelStore';
import { userMessage } from '@chatbot/utils/errors';
import { log } from '@chatbot/utils/logger';
import { embedder } from './EmbeddingEngine';
import { llm } from './LlmEngine';
import { MODELS } from './modelManifest';

const L = log('model');
let warmPromise: Promise<void> | null = null;
let reducedCtx = false;

/** Install (Android first launch) → load LLM. Idempotent; safe to call from anywhere. */
export function warmUp(): Promise<void> {
  if (llm.state === 'ready') return Promise.resolve();
  if (warmPromise) return warmPromise;
  const store = useModelStore.getState();
  warmPromise = (async () => {
    const caps = getDeviceCaps();
    L.info('warmUp', { tier: caps.tier, ram: caps.totalRamMB, soc: caps.socModel });
    const sub = onInstallProgress((e) => {
      if (e.name === MODELS.llm.file) useModelStore.getState().set({ phase: 'installing', progress: e.progress });
    });
    try {
      store.set({ phase: 'installing', progress: 0, error: null });
      const embedPath = await resolveModelPath(MODELS.embedding.file, MODELS.embedding.sizeBytes, MODELS.embedding.sha256);
      embedder.setPath(embedPath);
      const llmPath = await resolveModelPath(MODELS.llm.file, MODELS.llm.sizeBytes, MODELS.llm.sha256);
      useModelStore.getState().set({ phase: 'loading', progress: 0 });
      await llm.load({ path: llmPath, caps, nCtx: reducedCtx ? 2048 : undefined }, (p) =>
        useModelStore.getState().set({ progress: p })
      );
      useModelStore.getState().set({ phase: 'ready', progress: 1 });
    } catch (e) {
      L.error('warmUp failed', { e: String(e) });
      useModelStore.getState().set({ phase: 'error', error: userMessage(e) });
      throw e;
    } finally {
      sub.remove();
      warmPromise = null;
    }
  })();
  return warmPromise;
}

export async function retryWarmUp() {
  // Second failure → retry with a smaller context (LLD §12).
  if (useModelStore.getState().phase === 'error') reducedCtx = true;
  await llm.release().catch(() => {});
  return warmUp();
}

/** Memory ladder (HLA §5): embedder first, then shrink LLM context, then unload. */
let warnings = 0;
async function handleMemoryWarning() {
  warnings++;
  L.warn('memory warning', { n: warnings });
  if (embedder.loaded) return embedder.release();
  if (!reducedCtx && llm.state === 'ready') {
    reducedCtx = true;
    await llm.release();
    useModelStore.getState().set({ phase: 'idle' });
    return;
  }
  if (llm.state !== 'generating') {
    await llm.release();
    useModelStore.getState().set({ phase: 'idle' });
  }
}

export function installLifecycleHooks() {
  const memSub = onMemoryWarning(() => void handleMemoryWarning());
  const thermalTimer = setInterval(() => {
    const t = getThermalState();
    useModelStore.getState().set({ warm: t === 'serious' || t === 'critical' });
  }, 15_000);
  const appSub = AppState.addEventListener('change', (s) => {
    if (s === 'background') void llm.stop();
  });
  return () => {
    memSub.remove();
    appSub.remove();
    clearInterval(thermalTimer);
  };
}

/** Ensures the LLM is loaded before use (it may have been unloaded under memory pressure). */
export async function ensureLlm() {
  if (llm.state === 'ready') return;
  await warmUp();
}
