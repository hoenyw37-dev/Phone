import { initLlama, type LlamaContext } from 'llama.rn';

import { log } from '@chatbot/utils/logger';
import { BGE_QUERY_PREFIX, EMBEDDING_DIM } from './modelManifest';

const L = log('embed');

function l2normalise(v: number[]): Float32Array {
  let s = 0;
  for (const x of v) s += x * x;
  const n = Math.sqrt(s) || 1;
  const out = new Float32Array(v.length);
  for (let i = 0; i < v.length; i++) out[i] = v[i] / n;
  return out;
}

export class EmbeddingEngine {
  private ctx: LlamaContext | null = null;
  private loading: Promise<void> | null = null;
  path: string | null = null;

  setPath(p: string) {
    this.path = p;
  }

  get loaded() {
    return !!this.ctx;
  }

  /** Lazily loaded; released first under memory pressure (HLA §5). */
  private async ensure() {
    if (this.ctx) return;
    if (!this.path) throw new Error('Embedding model path not set');
    if (!this.loading) {
      this.loading = (async () => {
        this.ctx = await initLlama({
          model: this.path!,
          embedding: true,
          n_ctx: 512,
          n_batch: 512,
          n_ubatch: 512,
          n_threads: 2,
          n_gpu_layers: 0,
          pooling_type: 'cls',
          use_mmap: true,
        });
        L.info('loaded');
      })().finally(() => {
        this.loading = null;
      });
    }
    await this.loading;
  }

  async embed(text: string, kind: 'query' | 'passage'): Promise<Float32Array> {
    await this.ensure();
    const input = (kind === 'query' ? BGE_QUERY_PREFIX : '') + text;
    // bge-small has a 512-token window; ~1800 chars keeps us safely inside it.
    const res = await this.ctx!.embedding(input.slice(0, 1800));
    if (res.embedding.length !== EMBEDDING_DIM) throw new Error(`Unexpected embedding dim ${res.embedding.length}`);
    return l2normalise(res.embedding);
  }

  async embedBatch(texts: string[]): Promise<Float32Array[]> {
    const out: Float32Array[] = [];
    for (const t of texts) out.push(await this.embed(t, 'passage'));
    return out;
  }

  async release() {
    const c = this.ctx;
    this.ctx = null;
    await c?.release().catch(() => {});
  }
}

export const embedder = new EmbeddingEngine();
