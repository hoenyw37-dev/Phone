export interface ToolCall {
  id: string;
  name: string;
  arguments: Record<string, unknown>;
}

export interface ChatMsg {
  role: 'system' | 'user' | 'assistant' | 'tool';
  content: string;
  tool_calls?: ToolCall[];
  tool_call_id?: string;
  name?: string;
}

export interface ToolSchema {
  type: 'function';
  function: { name: string; description: string; parameters: Record<string, unknown> };
}

export interface Sampling {
  temperature: number;
  top_p: number;
  top_k: number;
  min_p: number;
  penalty_present: number;
}

export interface CompletionOpts {
  messages: ChatMsg[];
  tools?: ToolSchema[];
  toolChoice?: 'auto' | 'none';
  thinking?: boolean;
  grammar?: string;
  maxTokens?: number;
  sampling?: Partial<Sampling>;
  /** Called with the accumulated, parsed answer content (no <think>, no tool-call markup). */
  onContent?: (accumulated: string) => void;
  /** Called once the stream is known to contain tool calls. */
  onToolCallDetected?: () => void;
}

export interface CompletionResult {
  text: string;
  content: string;
  reasoning?: string;
  toolCalls: ToolCall[];
  stoppedBy: 'eos' | 'limit' | 'abort' | 'stop_word';
  timings: { promptMs: number; predictedMs: number; promptTokens: number; predictedTokens: number; tokPerSec: number; ttftMs: number };
}

export type EngineState = 'idle' | 'installing' | 'loading' | 'ready' | 'generating' | 'releasing' | 'error';
