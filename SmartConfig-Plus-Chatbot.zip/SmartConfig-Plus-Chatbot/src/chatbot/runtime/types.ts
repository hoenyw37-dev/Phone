export type DocStatus = 'queued' | 'parsing' | 'embedding' | 'ready' | 'failed';

export interface DocumentRecord {
  id: string;
  title: string;
  fileName: string;
  mime: string;
  sizeBytes: number;
  sha256: string;
  localPath: string;
  pageCount: number | null;
  chunkCount: number;
  status: DocStatus;
  progress: number;
  error: string | null;
  summary: string | null;
  description: string | null;
  createdAt: number;
  updatedAt: number;
}

export interface ChunkRecord {
  id: number;
  documentId: string;
  ord: number;
  pageStart: number | null;
  pageEnd: number | null;
  sectionPath: string | null;
  text: string;
  tokenCount: number;
  sourcePath?: string;
}

export interface Citation {
  n: number;
  chunkId: number;
  documentId: string;
  title: string;
  page: number | null;
  snippet: string;
  sourcePath?: string;
}

export interface AgentStepView {
  step: number;
  tool: string;
  label: string;
  status: 'running' | 'done' | 'failed';
  durationMs?: number;
}

export interface TurnMetrics {
  ttftMs?: number;
  tokPerSec?: number;
  llmCalls: number;
  promptTokens: number;
  genTokens: number;
  totalMs: number;
}

export type MessageStatus = 'streaming' | 'complete' | 'stopped' | 'error';

export interface ChatMessage {
  id: string;
  conversationId: string;
  role: 'user' | 'assistant';
  content: string;
  citations: Citation[];
  steps: AgentStepView[];
  status: MessageStatus;
  metrics?: TurnMetrics;
  createdAt: number;
}

export interface Conversation {
  id: string;
  title: string | null;
  createdAt: number;
  updatedAt: number;
}
