// Safe arithmetic evaluator (no eval) — shunting-yard. Unit tested.
type Tok = { t: 'num'; v: number } | { t: 'op'; v: string } | { t: 'fn'; v: string } | { t: '('; } | { t: ')' } | { t: ',' };

const FNS: Record<string, (...a: number[]) => number> = {
  round: (x, d = 0) => Math.round(x * 10 ** d) / 10 ** d,
  min: Math.min,
  max: Math.max,
  sum: (...a) => a.reduce((s, x) => s + x, 0),
  avg: (...a) => (a.length ? a.reduce((s, x) => s + x, 0) / a.length : NaN),
  sqrt: Math.sqrt,
  abs: Math.abs,
};
const PREC: Record<string, number> = { '+': 1, '-': 1, '*': 2, '/': 2, '%': 2, '^': 3, 'u-': 4 };
const RIGHT = new Set(['^', 'u-']);

function tokenize(src: string): Tok[] {
  const s = src.replace(/,(?=\d{3}\b)/g, '').replace(/[$€£₹]/g, '').replace(/×/g, '*').replace(/÷/g, '/');
  const out: Tok[] = [];
  let i = 0;
  while (i < s.length) {
    const c = s[i];
    if (/\s/.test(c)) { i++; continue; }
    const num = /^(\d+(\.\d+)?|\.\d+)(e[+-]?\d+)?%?/i.exec(s.slice(i));
    if (num) {
      let v = parseFloat(num[0]);
      if (num[0].endsWith('%')) v /= 100;
      out.push({ t: 'num', v });
      i += num[0].length;
      continue;
    }
    const id = /^[a-z]+/i.exec(s.slice(i));
    if (id) {
      const name = id[0].toLowerCase();
      if (name === 'pi') out.push({ t: 'num', v: Math.PI });
      else if (FNS[name]) out.push({ t: 'fn', v: name });
      else throw new Error(`Unknown identifier "${id[0]}"`);
      i += id[0].length;
      continue;
    }
    if ('+-*/%^'.includes(c)) {
      const prev = out[out.length - 1];
      const unary = c === '-' && (!prev || prev.t === 'op' || prev.t === '(' || prev.t === ',');
      if (unary) out.push({ t: 'op', v: 'u-' });
      else if (c === '+' && (!prev || prev.t === 'op' || prev.t === '(')) { /* unary plus */ }
      else out.push({ t: 'op', v: c });
      i++;
      continue;
    }
    if (c === '(') out.push({ t: '(' });
    else if (c === ')') out.push({ t: ')' });
    else if (c === ',') out.push({ t: ',' });
    else throw new Error(`Unexpected character "${c}"`);
    i++;
  }
  return out;
}

export function evaluate(expr: string): number {
  if (expr.length > 200) throw new Error('Expression too long');
  const output: (number | { op: string } | { fn: string; argc: number })[] = [];
  const ops: (Tok & { argc?: number })[] = [];
  const argc: number[] = [];
  for (const tok of tokenize(expr)) {
    if (tok.t === 'num') output.push(tok.v);
    else if (tok.t === 'fn') ops.push(tok);
    else if (tok.t === ',') {
      while (ops.length && ops[ops.length - 1].t !== '(') output.push({ op: (ops.pop() as any).v });
      argc[argc.length - 1]++;
    } else if (tok.t === 'op') {
      while (ops.length) {
        const top = ops[ops.length - 1];
        if (top.t !== 'op') break;
        const p1 = PREC[tok.v], p2 = PREC[top.v];
        if (p2 > p1 || (p2 === p1 && !RIGHT.has(tok.v))) output.push({ op: (ops.pop() as any).v });
        else break;
      }
      ops.push(tok);
    } else if (tok.t === '(') {
      ops.push(tok);
      argc.push(1);
    } else {
      while (ops.length && ops[ops.length - 1].t !== '(') output.push({ op: (ops.pop() as any).v });
      if (!ops.length) throw new Error('Mismatched parentheses');
      ops.pop();
      const n = argc.pop() ?? 1;
      if (ops.length && ops[ops.length - 1].t === 'fn') output.push({ fn: (ops.pop() as any).v, argc: n });
    }
  }
  while (ops.length) {
    const o = ops.pop()!;
    if (o.t === '(') throw new Error('Mismatched parentheses');
    output.push({ op: (o as any).v });
  }
  const st: number[] = [];
  for (const x of output) {
    if (typeof x === 'number') st.push(x);
    else if ('fn' in x) st.push(FNS[x.fn](...st.splice(st.length - x.argc, x.argc)));
    else if (x.op === 'u-') st.push(-(st.pop() as number));
    else {
      const b = st.pop(), a = st.pop();
      if (a === undefined || b === undefined) throw new Error('Malformed expression');
      st.push(x.op === '+' ? a + b : x.op === '-' ? a - b : x.op === '*' ? a * b : x.op === '/' ? a / b : x.op === '%' ? a % b : a ** b);
    }
  }
  if (st.length !== 1 || !Number.isFinite(st[0])) throw new Error('Could not evaluate');
  return st[0];
}
