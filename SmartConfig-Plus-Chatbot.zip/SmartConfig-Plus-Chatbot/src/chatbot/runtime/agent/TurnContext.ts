import type { Citation } from '@chatbot/types';

export interface SourceRef {
  chunkId: number;
  documentId: string;
  title: string;
  page: number | null;
  snippet: string;
  sourcePath?: string;
}

/** Per-turn state: numbered sources, call de-duplication, metrics. */
export class TurnContext {
  private sources = new Map<number, { n: number; ref: SourceRef }>();
  private seenCalls = new Set<string>();
  parseFailures = 0;
  llmCalls = 0;
  promptTokens = 0;
  genTokens = 0;
  ttftMs?: number;
  tokPerSec?: number;
  readonly startedAt = Date.now();

  /** Registers a source and returns its stable per-turn number. */
  register(ref: SourceRef): number {
    const ex = this.sources.get(ref.chunkId);
    if (ex) return ex.n;
    const n = this.sources.size + 1;
    this.sources.set(ref.chunkId, { n, ref });
    return n;
  }

  sourceByN(n: number): SourceRef | undefined {
    for (const s of this.sources.values()) if (s.n === n) return s.ref;
    return undefined;
  }

  get sourceCount() {
    return this.sources.size;
  }

  allSources(): Citation[] {
    return [...this.sources.values()].map(({ n, ref }) => ({ n, ...ref }));
  }

  /** Returns true if the same tool+args was already executed this turn. */
  seen(name: string, args: unknown): boolean {
    const key = name + ':' + JSON.stringify(args);
    if (this.seenCalls.has(key)) return true;
    this.seenCalls.add(key);
    return false;
  }
}
