// Citation validation (LLD §5.6) — unit tested.
import type { Citation } from '@chatbot/types';
import { REFUSAL } from './prompts';

export interface SourceLookup {
  sourceByN(n: number): Omit<Citation, 'n'> | undefined;
  allSources(): Citation[];
}

export interface Validated {
  content: string;
  citations: Citation[];
  refused: boolean;
}

const MARKER = /\[(\d+(?:\s*,\s*\d+)*)\]/g;

export function validateCitations(text: string, ctx: SourceLookup, documentsOnly: boolean): Validated {
  const renumber = new Map<number, number>();
  const citations: Citation[] = [];
  let content = text.replace(MARKER, (_, group: string) => {
    const nums = group
      .split(',')
      .map((s) => Number(s.trim()))
      .filter((n) => {
        const src = ctx.sourceByN(n);
        if (!src) return false;
        if (!renumber.has(n)) {
          renumber.set(n, renumber.size + 1);
          citations.push({ ...src, n: renumber.size });
        }
        return true;
      })
      .map((n) => renumber.get(n)!);
    const uniq = [...new Set(nums)];
    return uniq.length ? `[${uniq.join(', ')}]` : '';
  });
  // Internal identifiers must never reach users (prompt rule 7 is not always followed by small models).
  content = content
    .replace(/,?\s*\b(?:chunk_id|document_id|doc_id)\s*[=:]\s*[\w-]+/gi, '')
    .replace(/\(\s*\)/g, '');
  content = content.replace(/[ \t]+([.,;:])/g, '$1').replace(/[ \t]{2,}/g, ' ').trim();

  const isRefusal = /couldn['’]t find|could not find|not (mentioned|found|available) in/i.test(content);
  const sentences = content.split(/[.!?]\s/).filter((s) => s.trim().length > 3).length;
  const sources = ctx.allSources();
  if (documentsOnly && !isRefusal && sentences > 1 && !sources.length) {
    // Factual-looking answer with no retrieved evidence at all → refuse rather than risk a hallucination.
    return { content: REFUSAL, citations: [], refused: true };
  }
  if (!citations.length && !isRefusal && sources.length) {
    // Small models sometimes omit [n] markers; surface the sources the answer actually overlaps with.
    const ranked = sources
      .map((s) => ({ s, score: overlap(content, s.snippet) }))
      .filter((x) => x.score >= 2)
      .sort((a, b) => b.score - a.score);
    // Keep only sources comparable to the best match (passing mentions of other docs don't count).
    const top = ranked[0]?.score ?? 0;
    const picked = ranked
      .filter((x) => x.score >= top * 0.5)
      .slice(0, 3)
      .map((x) => x.s);
    const chosen = picked.length ? picked : sources.slice(0, 1);
    return { content, citations: chosen.map((c, i) => ({ ...c, n: i + 1 })), refused: false };
  }
  return { content, citations, refused: isRefusal };
}

const STOP = new Set('the and for are with that this from have has not you your can may per of to in on a an is be or by it as at'.split(' '));
const terms = (t: string) =>
  new Set(t.toLowerCase().split(/[^\p{L}\p{N}]+/u).filter((w) => (w.length > 3 || /\d/.test(w)) && !STOP.has(w)));

/** Count of distinctive words (and numbers) shared by the answer and a source snippet. */
function overlap(answer: string, snippet: string): number {
  const a = terms(answer);
  let n = 0;
  for (const w of terms(snippet)) if (a.has(w)) n += /\d/.test(w) ? 2 : 1;
  return n;
}
