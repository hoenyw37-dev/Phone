// Heuristic router (no LLM call) — LLD §5.2. Unit tested.
export type Route = 'smalltalk' | 'docs' | 'general';

const SMALLTALK = /^(hi|hello|hey|hiya|yo|thanks|thank you|thx|ty|ok|okay|cool|great|nice|bye|goodbye|good (morning|afternoon|evening|night)|how are you|who are you|what can you do)\b[\s!.?]*$/i;
const DOC_CUES = /\b(document|doc|docs|file|policy|policies|manual|report|according to|in the|section|page|clause|contract|guide|handbook|summar|procedure|faq)\b/i;
const COMPLEX = /\b(compare|comparison|difference|differ|versus|vs\.?|calculate|total|sum|how many|how much|step[- ]by[- ]step|pros and cons|across|between|trade-?offs?|explain why)\b/i;

export function classify(text: string, hasDocuments: boolean): Route {
  const t = text.trim();
  const words = t.split(/\s+/).length;
  if (words <= 5 && SMALLTALK.test(t)) return 'smalltalk';
  if (DOC_CUES.test(t)) return 'docs';
  if (hasDocuments) return 'docs';
  return 'general';
}

export function isComplex(text: string): boolean {
  return COMPLEX.test(text) || (text.match(/\?/g)?.length ?? 0) > 1;
}
