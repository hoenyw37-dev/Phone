// Bounded ReAct loop with native tool calling (ADR-005, LLD §5.2).
import { AGENT, BUDGET } from '@chatbot/config';
import { documentsRepo } from '@chatbot/data/repositories/documents';
import { inferenceQueue } from '@chatbot/llm/InferenceQueue';
import { llm } from '@chatbot/llm/LlmEngine';
import { ensureLlm } from '@chatbot/llm/ModelManager';
import type { ChatMsg, CompletionOpts, CompletionResult, ToolCall } from '@chatbot/llm/types';
import type { AnswerLength } from '@chatbot/state/settingsStore';
import type { Citation, TurnMetrics } from '@chatbot/types';
import { AppError } from '@chatbot/utils/errors';
import { log } from '@chatbot/utils/logger';
import { estimateTokens } from '@chatbot/utils/tokens';
import { validateCitations } from './citations';
import { GRAMMAR_INSTRUCTIONS, SMALLTALK_PROMPT, TOOLCALL_GBNF, systemPrompt, type PromptCtx } from './prompts';
import { classify, isComplex } from './router';
import { executeTool, TOOL_NAMES, TOOL_SCHEMAS } from './tools';
import { TurnContext } from './TurnContext';

const L = log('agent');

export type AgentEvent =
  | { type: 'step_started'; step: number; tool: string; label: string }
  | { type: 'step_finished'; step: number; ok: boolean; label: string; durationMs: number }
  | { type: 'content'; text: string } // accumulated final-answer text
  | { type: 'content_reset' }
  | { type: 'final'; content: string; citations: Citation[]; metrics: TurnMetrics };

export interface RunInput {
  history: { role: 'user' | 'assistant'; content: string }[];
  userText: string;
  documentsOnly: boolean;
  answerLength: AnswerLength;
  onEvent: (e: AgentEvent) => void;
}

export class AgentRun {
  private aborted = false;

  async stop() {
    this.aborted = true;
    await llm.stop();
  }

  private async call(ctx: TurnContext, o: CompletionOpts): Promise<CompletionResult> {
    await ensureLlm();
    const r = await inferenceQueue.enqueue(() => llm.complete(o), 'chat');
    ctx.llmCalls++;
    ctx.promptTokens += r.timings.promptTokens;
    ctx.genTokens += r.timings.predictedTokens;
    if (ctx.ttftMs === undefined) ctx.ttftMs = Date.now() - ctx.startedAt;
    if (r.timings.tokPerSec) ctx.tokPerSec = r.timings.tokPerSec;
    return r;
  }

  private metrics(ctx: TurnContext): TurnMetrics {
    return {
      ttftMs: ctx.ttftMs,
      tokPerSec: ctx.tokPerSec,
      llmCalls: ctx.llmCalls,
      promptTokens: ctx.promptTokens,
      genTokens: ctx.genTokens,
      totalMs: Date.now() - ctx.startedAt,
    };
  }

  async run(input: RunInput): Promise<void> {
    const { onEvent } = input;
    const ctx = new TurnContext();
    const ready = await documentsRepo.listReady();
    const pctx: PromptCtx = {
      date: new Date().toDateString(),
      documentsOnly: input.documentsOnly,
      answerLength: input.answerLength,
      docCount: ready.length,
      topTitles: ready.slice(0, 8).map((d) => d.title),
    };
    const route = classify(input.userText, ready.length > 0);
    L.info('turn', { route, docs: ready.length });

    const finish = (raw: string) => {
      if (!raw.trim()) {
        raw = this.aborted ? '' : "Sorry, I couldn't put together an answer. Please try rephrasing your question.";
      }
      const v = validateCitations(raw, ctx, input.documentsOnly);
      onEvent({ type: 'final', content: v.content, citations: v.citations, metrics: this.metrics(ctx) });
    };

    // Smalltalk fast path: no tools, short reply.
    if (route === 'smalltalk') {
      const r = await this.call(ctx, {
        messages: [{ role: 'system', content: SMALLTALK_PROMPT(pctx) }, ...input.history.slice(-4), { role: 'user', content: input.userText }],
        maxTokens: 150,
        onContent: (t) => onEvent({ type: 'content', text: t }),
      });
      onEvent({ type: 'final', content: r.content, citations: [], metrics: this.metrics(ctx) });
      return;
    }

    if (input.documentsOnly && ready.length === 0) {
      onEvent({ type: 'final', content: new AppError('NO_DOCUMENTS').message, citations: [], metrics: this.metrics(ctx) });
      return;
    }

    const budget = (f: number) => Math.floor(llm.nCtx * f);
    const msgs: ChatMsg[] = [
      { role: 'system', content: systemPrompt(pctx) },
      ...trimHistory(input.history, budget(BUDGET.history)),
      { role: 'user', content: input.userText },
    ];

    // Prefetch evidence for document questions — saves one LLM round-trip (ADR-005 §4).
    let step = 0;
    if (route === 'docs' && ready.length) {
      step++;
      const args = { query: input.userText.slice(0, 300), top_k: AGENT.PREFETCH_TOP_K };
      ctx.seen('search_documents', args);
      await this.runTool(ctx, msgs, { id: 'prefetch_0', name: 'search_documents', arguments: args }, step, onEvent);
    }

    const thinking = isComplex(input.userText);
    let grammarMode = false;

    while (!this.aborted) {
      step++;
      const last = step >= AGENT.MAX_STEPS;
      trimObservations(msgs, budget(BUDGET.observations));
      let streamed = false;

      if (grammarMode && !last) {
        const r = await this.call(ctx, {
          messages: [...msgs.slice(0, 1), { role: 'system', content: GRAMMAR_INSTRUCTIONS }, ...msgs.slice(1)],
          grammar: TOOLCALL_GBNF,
          maxTokens: AGENT.MAX_GEN_TOKENS,
          sampling: { temperature: 0.2, top_p: 0.9, penalty_present: 0 },
        });
        const parsed = safeJson(r.content || r.text);
        if (parsed?.final_answer) return finish(String(parsed.final_answer));
        if (parsed?.tool && TOOL_NAMES.includes(parsed.tool)) {
          const call: ToolCall = { id: `g_${step}`, name: parsed.tool, arguments: parsed.arguments ?? {} };
          msgs.push({ role: 'assistant', content: '', tool_calls: [call] });
          await this.runTool(ctx, msgs, call, step, onEvent);
          continue;
        }
        grammarMode = false; // unusable output; fall through to a forced final answer
      }

      const r = await this.call(ctx, {
        messages: msgs,
        tools: last ? undefined : TOOL_SCHEMAS,
        toolChoice: last ? 'none' : 'auto',
        thinking: thinking && step <= 2,
        maxTokens: AGENT.MAX_GEN_TOKENS,
        onContent: (t) => {
          streamed = true;
          onEvent({ type: 'content', text: t });
        },
        onToolCallDetected: () => streamed && onEvent({ type: 'content_reset' }),
      });
      if (this.aborted || r.stoppedBy === 'abort') return finish(r.content);

      const calls = r.toolCalls.filter((c) => TOOL_NAMES.includes(c.name)).slice(0, AGENT.MAX_PARALLEL_CALLS);
      if (!calls.length) {
        if (looksLikeBrokenToolCall(r.text) && !last) {
          if (streamed) onEvent({ type: 'content_reset' });
          if (++ctx.parseFailures >= 2) grammarMode = true;
          else msgs.push({ role: 'system', content: 'Your last tool call was malformed. Emit a valid tool call or answer the user directly.' });
          continue;
        }
        return finish(r.content);
      }

      msgs.push({ role: 'assistant', content: r.content, tool_calls: calls });
      for (const c of calls) {
        if (ctx.seen(c.name, c.arguments)) {
          msgs.push({ role: 'tool', tool_call_id: c.id, name: c.name, content: 'You already ran this exact call; its results are above. Answer the user now.' });
          continue;
        }
        await this.runTool(ctx, msgs, c, step, onEvent);
      }
    }
  }

  private async runTool(ctx: TurnContext, msgs: ChatMsg[], call: ToolCall, step: number, onEvent: RunInput['onEvent']) {
    const t0 = Date.now();
    onEvent({ type: 'step_started', step, tool: call.name, label: labelFor(call) });
    const { obs } = await executeTool(call.name, call.arguments, ctx);
    onEvent({ type: 'step_finished', step, ok: obs.ok, label: obs.summary || labelFor(call), durationMs: Date.now() - t0 });
    if (call.id === 'prefetch_0') {
      // Present prefetched evidence as a native tool exchange so the template formats it consistently.
      msgs.push({ role: 'assistant', content: '', tool_calls: [call] });
    }
    msgs.push({ role: 'tool', tool_call_id: call.id, name: call.name, content: obs.content });
  }
}

function labelFor(c: ToolCall): string {
  const q = typeof c.arguments.query === 'string' ? c.arguments.query : '';
  switch (c.name) {
    case 'search_documents':
      return `Searching documents${q ? ` for “${q.length > 32 ? q.slice(0, 31) + '…' : q}”` : ''}`;
    case 'read_chunk':
      return 'Reading a passage';
    case 'list_documents':
      return 'Checking available documents';
    case 'summarize_document':
      return 'Summarising a document';
    case 'calculator':
      return 'Calculating';
    case 'get_datetime':
      return 'Checking today’s date';
    default:
      return c.name;
  }
}

function looksLikeBrokenToolCall(text: string): boolean {
  return /<tool_call>|"name"\s*:\s*"(search_documents|read_chunk|list_documents|summarize_document|calculator|get_datetime)"/.test(text);
}

function safeJson(s: string): any {
  try {
    return JSON.parse(s.trim());
  } catch {
    const m = /\{[\s\S]*\}/.exec(s);
    try {
      return m ? JSON.parse(m[0]) : null;
    } catch {
      return null;
    }
  }
}

/** Keeps the most recent turns within budget (LLD §4.4). */
function trimHistory(history: RunInput['history'], maxTokens: number): ChatMsg[] {
  const out: ChatMsg[] = [];
  let used = 0;
  for (let i = history.length - 1; i >= 0; i--) {
    const h = history[i];
    const content = h.content.replace(/\[\d+(?:,\s*\d+)*\]/g, ''); // stale citation markers confuse numbering
    const t = estimateTokens(content);
    if (used + t > maxTokens) break;
    out.unshift({ role: h.role, content });
    used += t;
  }
  // Never start with an assistant message.
  while (out.length && out[0].role === 'assistant') out.shift();
  return out;
}

/** Shrinks the oldest tool observations when total observation tokens exceed budget. */
function trimObservations(msgs: ChatMsg[], maxTokens: number) {
  const tools = msgs.filter((m) => m.role === 'tool');
  let total = tools.reduce((n, m) => n + estimateTokens(m.content), 0);
  for (const m of tools) {
    if (total <= maxTokens) break;
    const before = estimateTokens(m.content);
    const keep = Math.max(60, before - (total - maxTokens));
    m.content = m.content.slice(0, Math.floor(keep * 3.6)) + '…';
    total -= before - estimateTokens(m.content);
  }
}
