// Tool registry (ADR-005, LLD §5.3).
import { z } from 'zod';

import { chunksRepo } from '@chatbot/data/repositories/chunks';
import { documentsRepo } from '@chatbot/data/repositories/documents';
import { inferenceQueue } from '@chatbot/llm/InferenceQueue';
import { llm } from '@chatbot/llm/LlmEngine';
import type { ToolSchema } from '@chatbot/llm/types';
import { search } from '@chatbot/rag/RetrievalService';
import { estimateTokens, truncateToTokens } from '@chatbot/utils/tokens';
import { evaluate } from './calculator';
import type { TurnContext } from './TurnContext';

export interface Observation {
  ok: boolean;
  content: string; // what the model sees
  summary: string; // short UI label
}

interface Tool<A> {
  name: string;
  description: string;
  parameters: Record<string, unknown>;
  schema: z.ZodType<A>;
  label: (a: A) => string;
  execute: (a: A, ctx: TurnContext) => Promise<Observation>;
}

const short = (s: string, n = 32) => (s.length > n ? s.slice(0, n - 1) + '…' : s);
const pageLabel = (p: number | null) => (p ? ` p.${p}` : '');

const searchDocuments: Tool<{ query: string; top_k?: number; document_ids?: string[] }> = {
  name: 'search_documents',
  description:
    "Search the user's documents for passages relevant to a query. Returns numbered sources [n] to cite. Reformulate the query with key terms when a first search is not enough.",
  parameters: {
    type: 'object',
    properties: {
      query: { type: 'string', description: 'Search query with the key terms' },
      top_k: { type: 'integer', minimum: 1, maximum: 8, description: 'Number of passages (default 5)' },
      document_ids: { type: 'array', items: { type: 'string' }, description: 'Optional: restrict to these document ids' },
    },
    required: ['query'],
  },
  schema: z.object({
    query: z.string().min(2).max(300),
    top_k: z.number().int().min(1).max(8).optional(),
    document_ids: z.array(z.string()).optional(),
  }),
  label: (a) => `Searching documents for “${short(a.query)}”`,
  async execute(a, ctx) {
    const hits = await search(a.query, a.top_k ?? 5, a.document_ids);
    if (!hits.length) return { ok: true, content: 'No relevant passages found.', summary: 'No relevant passages' };
    const lines = hits.map((h) => {
      const n = ctx.register({ chunkId: h.id, documentId: h.documentId, title: h.title, page: h.pageStart, snippet: h.text.slice(0, 280), sourcePath: h.sourcePath });
      const loc = [h.title + pageLabel(h.pageStart), h.sectionPath].filter(Boolean).join(' › ');
      return `[${n}] (${loc}) chunk_id=${h.id}\n${truncateToTokens(h.text, 170)}`;
    });
    const docs = new Set(hits.map((h) => h.documentId)).size;
    return { ok: true, content: lines.join('\n\n'), summary: `Found ${hits.length} passages in ${docs} document${docs > 1 ? 's' : ''}` };
  },
};

const readChunk: Tool<{ chunk_id: number; expand?: number }> = {
  name: 'read_chunk',
  description: 'Read the full text of a passage (by chunk_id from search results), optionally with neighbouring passages for more context.',
  parameters: {
    type: 'object',
    properties: {
      chunk_id: { type: 'integer', description: 'chunk_id from search_documents results' },
      expand: { type: 'integer', minimum: 0, maximum: 2, description: 'Neighbouring passages to include on each side' },
    },
    required: ['chunk_id'],
  },
  schema: z.object({ chunk_id: z.coerce.number().int(), expand: z.coerce.number().int().min(0).max(2).optional() }),
  label: () => 'Reading a passage',
  async execute(a, ctx) {
    const [c] = await chunksRepo.byIds([a.chunk_id]);
    if (!c) return { ok: false, content: `No passage with chunk_id=${a.chunk_id}.`, summary: 'Passage not found' };
    const parts = a.expand ? await chunksRepo.neighbours(c, a.expand) : [c];
    const n = ctx.register({ chunkId: c.id, documentId: c.documentId, title: c.title, page: c.pageStart, snippet: c.text.slice(0, 280), sourcePath: c.sourcePath });
    const text = truncateToTokens(parts.map((p) => p.text).join('\n'), 900);
    return { ok: true, content: `[${n}] (${c.title}${pageLabel(c.pageStart)})\n${text}`, summary: `Read ${short(c.title, 28)}${pageLabel(c.pageStart)}` };
  },
};

const listDocuments: Tool<Record<string, never>> = {
  name: 'list_documents',
  description: 'List the available documents with their ids, titles, page counts and short descriptions.',
  parameters: { type: 'object', properties: {} },
  schema: z.object({}).passthrough() as any,
  label: () => 'Checking available documents',
  async execute() {
    const docs = await documentsRepo.listReady();
    if (!docs.length) return { ok: true, content: 'No documents are available.', summary: 'No documents' };
    const rows = docs.slice(0, 50).map((d) => `id=${d.id} · ${d.title}${d.pageCount ? ` · ${d.pageCount} pages` : ''}${d.description ? ` · ${d.description.slice(0, 120)}` : ''}`);
    return { ok: true, content: rows.join('\n'), summary: `${docs.length} documents available` };
  },
};

async function llmSummarise(text: string, instruction: string, maxTokens: number): Promise<string> {
  const r = await inferenceQueue.enqueue(() =>
    llm.complete({
      messages: [
        { role: 'system', content: 'You write faithful, concise summaries. Use only the given text.' },
        { role: 'user', content: `${instruction}\n\nTEXT:\n${text}` },
      ],
      maxTokens,
      sampling: { temperature: 0.3 },
    })
  );
  return r.content.trim();
}

const summarizeDocument: Tool<{ document_id: string; focus?: string }> = {
  name: 'summarize_document',
  description: 'Summarise a whole document (by id from list_documents), optionally focusing on a topic.',
  parameters: {
    type: 'object',
    properties: {
      document_id: { type: 'string', description: 'Document id from list_documents' },
      focus: { type: 'string', description: 'Optional topic to focus on' },
    },
    required: ['document_id'],
  },
  schema: z.object({ document_id: z.string(), focus: z.string().max(200).optional() }),
  label: () => 'Summarising a document',
  async execute(a, ctx) {
    let doc = await documentsRepo.get(a.document_id);
    if (!doc) {
      // Small models sometimes pass the title instead of the id.
      const all = await documentsRepo.listReady();
      doc = all.find((d) => d.title.toLowerCase().includes(a.document_id.toLowerCase())) ?? null;
    }
    if (!doc || doc.status !== 'ready') return { ok: false, content: 'Document not found. Call list_documents for valid ids.', summary: 'Document not found' };
    const chunks = await chunksRepo.allForDocument(doc.id);
    const n = ctx.register({ chunkId: chunks[0].id, documentId: doc.id, title: doc.title, page: chunks[0].pageStart, snippet: chunks[0].text.slice(0, 280) });
    if (!a.focus && doc.summary) return { ok: true, content: `[${n}] Summary of ${doc.title}:\n${doc.summary}`, summary: `Summarised ${short(doc.title, 28)}` };

    // Map-reduce over up to 4 evenly spaced groups of ~1,200 tokens (bounded latency on-device).
    const groups: string[] = [];
    let cur = '';
    for (const c of chunks) {
      if (estimateTokens(cur + c.text) > 1200 && cur) {
        groups.push(cur);
        cur = '';
      }
      cur += c.text + '\n';
    }
    if (cur) groups.push(cur);
    const step = Math.max(1, Math.ceil(groups.length / 4));
    const picked = groups.filter((_, i) => i % step === 0).slice(0, 4);
    const focus = a.focus ? ` Focus on: ${a.focus}.` : '';
    const partials: string[] = [];
    for (const g of picked) partials.push(await llmSummarise(g, `Summarise this part of "${doc.title}" in at most 80 words.${focus}`, 160));
    const summary = picked.length === 1 ? partials[0] : await llmSummarise(partials.join('\n\n'), `Combine these partial summaries of "${doc.title}" into one summary of at most 150 words.${focus}`, 260);
    if (!a.focus) await documentsRepo.update(doc.id, { summary });
    return { ok: true, content: `[${n}] Summary of ${doc.title}:\n${summary}`, summary: `Summarised ${short(doc.title, 28)}` };
  },
};

const calculator: Tool<{ expression: string }> = {
  name: 'calculator',
  description: 'Evaluate an arithmetic expression exactly. Supports + - * / % ^ ( ) and round, min, max, sum, avg, sqrt, abs.',
  parameters: { type: 'object', properties: { expression: { type: 'string', description: 'e.g. (12 * 1500) / 4' } }, required: ['expression'] },
  schema: z.object({ expression: z.string().min(1).max(200) }),
  label: () => 'Calculating',
  async execute(a) {
    try {
      const v = evaluate(a.expression);
      const out = Number.isInteger(v) ? String(v) : String(Math.round(v * 1e6) / 1e6);
      return { ok: true, content: `${a.expression} = ${out}`, summary: `Calculated ${out}` };
    } catch (e) {
      return { ok: false, content: `Error: ${(e as Error).message}`, summary: 'Calculation failed' };
    }
  },
};

const getDatetime: Tool<Record<string, never>> = {
  name: 'get_datetime',
  description: "Get the device's current date, time, weekday and timezone.",
  parameters: { type: 'object', properties: {} },
  schema: z.object({}).passthrough() as any,
  label: () => 'Checking today’s date',
  async execute() {
    const d = new Date();
    const tz = Intl.DateTimeFormat().resolvedOptions().timeZone;
    const s = `${d.toISOString()} · ${d.toLocaleDateString(undefined, { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })} · ${d.toLocaleTimeString()} · ${tz}`;
    return { ok: true, content: s, summary: 'Checked the date' };
  },
};

const ALL: Tool<any>[] = [searchDocuments, readChunk, listDocuments, summarizeDocument, calculator, getDatetime];
export const TOOL_NAMES = ALL.map((t) => t.name);

export const TOOL_SCHEMAS: ToolSchema[] = ALL.map((t) => ({
  type: 'function',
  function: { name: t.name, description: t.description, parameters: t.parameters },
}));

export function getTool(name: string): Tool<any> | undefined {
  return ALL.find((t) => t.name === name);
}

/** Validates args and executes; unknown tools / invalid args become error observations. */
export async function executeTool(name: string, args: unknown, ctx: TurnContext): Promise<{ label: string; obs: Observation }> {
  const tool = getTool(name);
  if (!tool) return { label: 'Unknown tool', obs: { ok: false, content: `Unknown tool "${name}". Available: ${TOOL_NAMES.join(', ')}`, summary: 'Unknown tool' } };
  const parsed = tool.schema.safeParse(args ?? {});
  if (!parsed.success) {
    return { label: tool.name, obs: { ok: false, content: `Invalid arguments for ${name}: ${parsed.error.issues.map((i) => i.message).join('; ')}`, summary: 'Invalid arguments' } };
  }
  const label = tool.label(parsed.data);
  try {
    return { label, obs: await tool.execute(parsed.data, ctx) };
  } catch (e) {
    return { label, obs: { ok: false, content: `Tool error: ${(e as Error).message}`, summary: 'Tool failed' } };
  }
}
