// Pure ranking helpers (LLD §6) — unit tested.
export interface Ranked {
  chunkId: number;
}

/** Reciprocal Rank Fusion: score = Σ 1/(k + rank). */
export function rrf(lists: Ranked[][], k = 60): { chunkId: number; score: number }[] {
  const scores = new Map<number, number>();
  for (const list of lists) {
    list.forEach((item, rank) => scores.set(item.chunkId, (scores.get(item.chunkId) ?? 0) + 1 / (k + rank + 1)));
  }
  return [...scores.entries()].map(([chunkId, score]) => ({ chunkId, score })).sort((a, b) => b.score - a.score);
}

export function cosine(a: Float32Array, b: Float32Array): number {
  let dot = 0, na = 0, nb = 0;
  for (let i = 0; i < a.length; i++) {
    dot += a[i] * b[i];
    na += a[i] * a[i];
    nb += b[i] * b[i];
  }
  return dot / (Math.sqrt(na) * Math.sqrt(nb) || 1);
}

/** Maximal Marginal Relevance selection for diverse top-k. */
export function mmr<T extends { chunkId: number }>(
  candidates: T[],
  query: Float32Array,
  vectors: Map<number, Float32Array>,
  k: number,
  lambda = 0.7
): T[] {
  const pool = candidates.filter((c) => vectors.has(c.chunkId));
  const missing = candidates.filter((c) => !vectors.has(c.chunkId));
  const selected: T[] = [];
  const rel = new Map(pool.map((c) => [c.chunkId, cosine(query, vectors.get(c.chunkId)!)]));
  while (selected.length < k && pool.length) {
    let bestIdx = 0;
    let best = -Infinity;
    pool.forEach((c, i) => {
      const v = vectors.get(c.chunkId)!;
      const maxSim = selected.length ? Math.max(...selected.map((s) => cosine(v, vectors.get(s.chunkId)!))) : 0;
      const score = lambda * rel.get(c.chunkId)! - (1 - lambda) * maxSim;
      if (score > best) {
        best = score;
        bestIdx = i;
      }
    });
    selected.push(pool.splice(bestIdx, 1)[0]);
  }
  return [...selected, ...missing].slice(0, k);
}

const STOP = new Set(
  'a an and are as at be by can do does for from has have how i in is it of on or our that the their there this to was we what when where which who why will with you your'.split(' ')
);

/** Lowercase, drop stop words, quote tokens, OR-join, prefix-match longer terms. */
export function toFtsQuery(q: string): string | null {
  const terms = q
    .toLowerCase()
    .replace(/[^\p{L}\p{N}\s]/gu, ' ')
    .split(/\s+/)
    .filter((t) => t.length > 1 && !STOP.has(t));
  if (!terms.length) return null;
  return [...new Set(terms)].map((t) => (t.length >= 4 ? `"${t}"*` : `"${t}"`)).join(' OR ');
}
