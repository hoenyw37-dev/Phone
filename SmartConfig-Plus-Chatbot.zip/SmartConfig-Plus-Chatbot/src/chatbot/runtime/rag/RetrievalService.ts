import { RAG } from '@chatbot/config';
import { chunksRepo } from '@chatbot/data/repositories/chunks';
import { query } from '@chatbot/data/db';
import { embedder } from '@chatbot/llm/EmbeddingEngine';
import { inferenceQueue } from '@chatbot/llm/InferenceQueue';
import type { ChunkRecord } from '@chatbot/types';
import { cosine, mmr, rrf, toFtsQuery } from './fusion';

export interface Hit extends ChunkRecord {
  chunkId: number;
  title: string;
  score: number;
  similarity: number;
}

export async function search(q: string, k: number = RAG.FINAL_K, documentIds?: string[]): Promise<Hit[]> {
  const qv = await inferenceQueue.enqueue(() => embedder.embed(q, 'query'), 'chat');
  const fts = toFtsQuery(q);
  const [vecRows, ftsRows] = await Promise.all([
    query<{ chunk_id: number; distance: number }>(
      'SELECT chunk_id, distance FROM vec_chunks WHERE embedding MATCH ? AND k = ? ORDER BY distance',
      [qv.buffer as ArrayBuffer, RAG.VEC_K]
    ),
    fts
      ? query<{ chunk_id: number }>(
          'SELECT rowid AS chunk_id FROM fts_chunks WHERE fts_chunks MATCH ? ORDER BY bm25(fts_chunks) LIMIT ?',
          [fts, RAG.FTS_K]
        ).catch(() => [])
      : Promise.resolve([]),
  ]);

  const vec = vecRows.map((r) => ({ chunkId: r.chunk_id }));
  const bm = ftsRows.map((r) => ({ chunkId: r.chunk_id }));
  const fused = rrf([vec, bm], RAG.RRF_K).slice(0, 20);
  if (!fused.length) return [];

  const ids = fused.map((f) => f.chunkId);
  const [chunks, vectors] = await Promise.all([chunksRepo.byIds(ids), chunksRepo.vectors(ids)]);
  const byId = new Map(chunks.map((c) => [c.id, c]));
  let candidates: Hit[] = fused
    .filter((f) => byId.has(f.chunkId))
    .map((f) => {
      const c = byId.get(f.chunkId)!;
      const v = vectors.get(f.chunkId);
      return { ...c, chunkId: c.id, score: f.score, similarity: v ? cosine(qv, v) : 0 };
    });
  if (documentIds?.length) candidates = candidates.filter((c) => documentIds.includes(c.documentId));

  // Score floor: nothing semantically close and no lexical match → no evidence.
  const bestSim = Math.max(0, ...candidates.map((c) => c.similarity));
  if (bestSim < RAG.MIN_COSINE && bm.length === 0) return [];

  return mmr(candidates, qv, vectors, k, RAG.MMR_LAMBDA);
}
