import { Platform } from 'react-native';

import NativeUtils, { type DeviceCapsRaw, type ThermalState } from '../../../../modules/native-utils';

export type Tier = 'A' | 'B' | 'C';
export interface DeviceCaps extends DeviceCapsRaw {
  tier: Tier;
  performanceCores: number;
}

let cached: DeviceCaps | null = null;

/** LLD §15 tier resolution. */
export function getDeviceCaps(): DeviceCaps {
  if (cached) return cached;
  const raw = NativeUtils.getDeviceCaps();
  const gb = raw.totalRamMB / 1024;
  // Reported totals are slightly below marketing sizes (e.g. 8 GB → ~7.4 GB).
  const tier: Tier =
    Platform.OS === 'ios' ? (gb >= 5.5 ? 'A' : gb >= 3.5 ? 'B' : 'C') : gb >= 7.2 ? 'A' : gb >= 5.4 ? 'B' : 'C';
  cached = { ...raw, tier, performanceCores: Math.max(2, Math.min(4, Math.floor(raw.cpuCores / 2))) };
  return cached;
}

export const getThermalState = (): ThermalState => {
  try {
    return NativeUtils.getThermalState();
  } catch {
    return 'nominal';
  }
};

export const extractPdf = (path: string) => NativeUtils.extractPdf(path);

export async function resolveModelPath(file: string, sizeBytes: number, sha256: string): Promise<string> {
  if (Platform.OS === 'ios') {
    const p = NativeUtils.getBundledModelPath(file);
    if (p) return p;
  }
  return NativeUtils.installBundledModel(file, sizeBytes, sha256);
}

export const onMemoryWarning = (cb: () => void) => NativeUtils.addListener('onMemoryWarning', cb);
export const onInstallProgress = (cb: (e: { name: string; progress: number }) => void) =>
  NativeUtils.addListener('onInstallProgress', cb);
