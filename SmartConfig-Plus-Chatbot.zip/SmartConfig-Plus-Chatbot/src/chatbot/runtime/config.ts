// Tunables from specs/03-lld.md §13.
export const APP_NAME = 'Smart Config Plus Assistant';

export const AGENT = {
  MAX_STEPS: 5,
  MAX_PARALLEL_CALLS: 2,
  PREFETCH_TOP_K: 5,
  MAX_GEN_TOKENS: 700,
  MAX_TOOL_TOKENS: 256,
};

export const RAG = { VEC_K: 20, FTS_K: 20, RRF_K: 60, MMR_LAMBDA: 0.7, FINAL_K: 5, MIN_COSINE: 0.35 };

export const CHUNK = { TARGET: 350, MIN: 80, MAX: 480, OVERLAP: 50 };

export const INGEST = { EMBED_BATCH: 16, MAX_FILE_MB: 50, MAX_PAGES: 2000, MAX_ATTEMPTS: 3 };

export const ADMIN = { PIN_MIN: 4, PIN_MAX: 6, PBKDF2_ITERS: 20_000, LOCK_AFTER: 5, SESSION_MS: 300_000 };

export const BRANDING = { MAX_LOGO_MB: 5, MAX_LOGO_PX: 512 };

/** Token budgets per turn as a fraction of n_ctx (LLD §4.4). */
export const BUDGET = { system: 0.25, history: 0.2, observations: 0.37 };
