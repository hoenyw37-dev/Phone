import { create } from 'zustand';

import { ADMIN } from '@chatbot/config';

interface AdminSession {
  unlockedAt: number | null;
  /** >0 while a system picker (files/photos) we launched is in front of the app. */
  externalActivity: number;
  lastActivity: number;
  unlock: () => void;
  lock: () => void;
  touch: () => void;
  isUnlocked: () => boolean;
}

export const useAdminSession = create<AdminSession>((set, get) => ({
  unlockedAt: null,
  externalActivity: 0,
  lastActivity: 0,
  unlock: () => set({ unlockedAt: Date.now(), lastActivity: Date.now() }),
  lock: () => set({ unlockedAt: null }),
  touch: () => get().unlockedAt && set({ lastActivity: Date.now() }),
  isUnlocked: () => {
    const { unlockedAt, lastActivity } = get();
    return !!unlockedAt && Date.now() - lastActivity < ADMIN.SESSION_MS;
  },
}));

/** Runs a system picker without the background transition locking the admin session. */
export async function withExternalActivity<T>(fn: () => Promise<T>): Promise<T> {
  useAdminSession.setState((s) => ({ externalActivity: s.externalActivity + 1 }));
  try {
    return await fn();
  } finally {
    // Delay the decrement so the 'active' transition after the picker closes is also ignored.
    setTimeout(() => useAdminSession.setState((s) => ({ externalActivity: Math.max(0, s.externalActivity - 1), lastActivity: Date.now() })), 1000);
  }
}
