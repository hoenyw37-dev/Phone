import { create } from 'zustand';

import { kvJson } from './kv';

export interface LogoAsset {
  uri: string;
  kind: 'png' | 'svg';
  luminance: number; // alpha-weighted mean relative luminance, 0..1
  opaque: boolean; // mostly opaque (e.g. JPG with its own background)
  aspect: number; // width / height
  /** Share of visible pixels below 3:1 against each theme background (drives the plate). */
  lowContrast?: { light: number; dark: number };
}

export interface BrandingState {
  light?: LogoAsset;
  dark?: LogoAsset;
  updatedAt: number;
  set: (p: Partial<Pick<BrandingState, 'light' | 'dark'>>) => void;
  clear: (variant: 'light' | 'dark') => void;
}

const KEY = 'branding.v1';
type Persisted = Pick<BrandingState, 'light' | 'dark' | 'updatedAt'>;

export const useBrandingStore = create<BrandingState>((set, get) => {
  const save = () => {
    const { light, dark, updatedAt } = get();
    kvJson.set(KEY, { light, dark, updatedAt });
  };
  return {
    updatedAt: 0,
    ...kvJson.get<Partial<Persisted>>(KEY, {}),
    set: (p) => (set({ ...p, updatedAt: Date.now() }), save()),
    clear: (variant) => (set({ [variant]: undefined, updatedAt: Date.now() } as Partial<BrandingState>), save()),
  };
});
