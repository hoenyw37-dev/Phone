import { create } from 'zustand';

import type { ThemeMode } from '@chatbot/theme/tokens';
import { kvJson } from './kv';

export type AnswerLength = 'short' | 'normal' | 'detailed';

interface SettingsState {
  themeMode: ThemeMode;
  documentsOnly: boolean;
  answerLength: AnswerLength;
  onboardingComplete: boolean;
  setThemeMode: (m: ThemeMode) => void;
  setDocumentsOnly: (v: boolean) => void;
  setAnswerLength: (v: AnswerLength) => void;
  completeOnboarding: () => void;
}

type Persisted = Pick<SettingsState, 'themeMode' | 'documentsOnly' | 'answerLength' | 'onboardingComplete'>;
const KEY = 'settings.v1';
const defaults: Persisted = { themeMode: 'system', documentsOnly: true, answerLength: 'normal', onboardingComplete: false };

export const useSettingsStore = create<SettingsState>((set, get) => {
  const save = () => {
    const { themeMode, documentsOnly, answerLength, onboardingComplete } = get();
    kvJson.set(KEY, { themeMode, documentsOnly, answerLength, onboardingComplete });
  };
  return {
    ...defaults,
    ...kvJson.get<Partial<Persisted>>(KEY, {}),
    setThemeMode: (themeMode) => (set({ themeMode }), save()),
    setDocumentsOnly: (documentsOnly) => (set({ documentsOnly }), save()),
    setAnswerLength: (answerLength) => (set({ answerLength }), save()),
    completeOnboarding: () => (set({ onboardingComplete: true }), save()),
  };
});
