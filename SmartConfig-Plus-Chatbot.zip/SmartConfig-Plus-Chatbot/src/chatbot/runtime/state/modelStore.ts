import { create } from 'zustand';

export type ModelPhase = 'idle' | 'installing' | 'loading' | 'ready' | 'error';

interface ModelState {
  phase: ModelPhase;
  progress: number; // 0..1 for the current phase
  error: string | null;
  lastTokPerSec: number | null;
  lastTtftMs: number | null;
  warm: boolean; // device is thermally throttled
  set: (p: Partial<Omit<ModelState, 'set'>>) => void;
}

export const useModelStore = create<ModelState>((set) => ({
  phase: 'idle',
  progress: 0,
  error: null,
  lastTokPerSec: null,
  lastTtftMs: null,
  warm: false,
  set: (p) => set(p),
}));
