import { create } from 'zustand';

import { documentsRepo } from '@chatbot/data/repositories/documents';
import type { DocumentRecord } from '@chatbot/types';

interface DocState {
  docs: DocumentRecord[];
  loaded: boolean;
  refresh: () => Promise<void>;
  patch: (id: string, p: Partial<DocumentRecord>) => void;
}

export const useDocStore = create<DocState>((set) => ({
  docs: [],
  loaded: false,
  refresh: async () => set({ docs: await documentsRepo.list(), loaded: true }),
  patch: (id, p) => set((s) => ({ docs: s.docs.map((d) => (d.id === id ? { ...d, ...p } : d)) })),
}));

export const selectReadyCount = (s: DocState) => s.docs.filter((d) => d.status === 'ready').length;
