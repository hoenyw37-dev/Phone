import { create } from 'zustand';

import { AgentRun } from '@chatbot/agent/AgentOrchestrator';
import { conversationsRepo } from '@chatbot/data/repositories/conversations';
import { useModelStore } from '@chatbot/state/modelStore';
import { useSettingsStore } from '@chatbot/state/settingsStore';
import type { AgentStepView, ChatMessage, Conversation } from '@chatbot/types';
import { userMessage } from '@chatbot/utils/errors';
import { newId } from '@chatbot/utils/ids';
import { log } from '@chatbot/utils/logger';

const L = log('chat');

interface ChatState {
  conversations: Conversation[];
  currentId: string | null;
  messages: ChatMessage[];
  generating: boolean;
  loadConversations: () => Promise<void>;
  open: (id: string) => Promise<void>;
  newChat: () => void;
  send: (text: string) => Promise<void>;
  stop: () => Promise<void>;
  regenerate: () => Promise<void>;
  rename: (id: string, title: string) => Promise<void>;
  remove: (id: string) => Promise<void>;
}

let activeRun: AgentRun | null = null;

const titleFrom = (text: string) => {
  const t = text.replace(/\s+/g, ' ').trim();
  return t.length > 48 ? t.slice(0, 47) + '…' : t;
};

export const useChatStore = create<ChatState>((set, get) => {
  const patchMessage = (id: string, p: Partial<ChatMessage> | ((m: ChatMessage) => Partial<ChatMessage>)) =>
    set((s) => ({
      messages: s.messages.map((m) => (m.id === id ? { ...m, ...(typeof p === 'function' ? p(m) : p) } : m)),
    }));

  const runTurn = async (conversationId: string, userText: string, history: ChatMessage[]) => {
    const assistant: ChatMessage = {
      id: newId(), conversationId, role: 'assistant', content: '', citations: [], steps: [], status: 'streaming', createdAt: Date.now(),
    };
    set((s) => ({ messages: [...s.messages, assistant], generating: true }));
    await conversationsRepo.upsertMessage(assistant);

    const run = new AgentRun();
    activeRun = run;
    const settings = useSettingsStore.getState();

    // Throttle streaming updates to ~20fps to keep the JS thread free.
    let pending: string | null = null;
    let timer: ReturnType<typeof setTimeout> | null = null;
    const flushContent = () => {
      timer = null;
      if (pending !== null) patchMessage(assistant.id, { content: pending });
      pending = null;
    };

    try {
      await run.run({
        history: history.filter((m) => m.status !== 'error' && m.content).map((m) => ({ role: m.role, content: m.content })),
        userText,
        documentsOnly: settings.documentsOnly,
        answerLength: settings.answerLength,
        onEvent: (e) => {
          switch (e.type) {
            case 'step_started':
              patchMessage(assistant.id, (m) => ({
                steps: [...m.steps, { step: e.step, tool: e.tool, label: e.label, status: 'running' } as AgentStepView],
              }));
              break;
            case 'step_finished':
              patchMessage(assistant.id, (m) => ({
                steps: m.steps.map((s, i) =>
                  i === m.steps.length - 1 && s.status === 'running'
                    ? { ...s, label: e.label, status: e.ok ? 'done' : 'failed', durationMs: e.durationMs }
                    : s
                ),
              }));
              break;
            case 'content':
              pending = e.text;
              if (!timer) timer = setTimeout(flushContent, 50);
              break;
            case 'content_reset':
              pending = null;
              patchMessage(assistant.id, { content: '' });
              break;
            case 'final':
              if (timer) clearTimeout(timer);
              pending = null;
              patchMessage(assistant.id, {
                content: e.content,
                citations: e.citations,
                metrics: e.metrics,
                status: 'complete',
              });
              useModelStore.getState().set({ lastTokPerSec: e.metrics.tokPerSec ?? null, lastTtftMs: e.metrics.ttftMs ?? null });
              break;
          }
        },
      });
    } catch (e) {
      L.error('turn failed', { e: String(e) });
      patchMessage(assistant.id, (m) => ({ status: 'error', content: m.content || userMessage(e) }));
    } finally {
      if (timer) clearTimeout(timer);
      flushContent();
      const final = get().messages.find((m) => m.id === assistant.id);
      if (final && final.status === 'streaming') {
        patchMessage(assistant.id, { status: 'stopped' });
      }
      const persisted = get().messages.find((m) => m.id === assistant.id);
      if (persisted) await conversationsRepo.upsertMessage(persisted);
      await conversationsRepo.touch(conversationId);
      activeRun = null;
      set({ generating: false });
      void get().loadConversations();
    }
  };

  return {
    conversations: [],
    currentId: null,
    messages: [],
    generating: false,

    loadConversations: async () => set({ conversations: await conversationsRepo.list() }),

    open: async (id) => {
      if (get().generating) await get().stop();
      set({ currentId: id, messages: await conversationsRepo.messages(id) });
    },

    newChat: () => {
      if (get().generating) void get().stop();
      set({ currentId: null, messages: [] });
    },

    send: async (text) => {
      const t = text.trim();
      if (!t || get().generating) return;
      let id = get().currentId;
      if (!id) {
        id = newId();
        await conversationsRepo.create(id, titleFrom(t));
        set({ currentId: id });
      }
      const history = get().messages;
      const user: ChatMessage = {
        id: newId(), conversationId: id, role: 'user', content: t, citations: [], steps: [], status: 'complete', createdAt: Date.now(),
      };
      set((s) => ({ messages: [...s.messages, user] }));
      await conversationsRepo.upsertMessage(user);
      await runTurn(id, t, history);
    },

    stop: async () => {
      await activeRun?.stop();
    },

    regenerate: async () => {
      const { messages, currentId, generating } = get();
      if (!currentId || generating) return;
      const lastUserIdx = messages.map((m) => m.role).lastIndexOf('user');
      if (lastUserIdx < 0) return;
      const removed = messages.slice(lastUserIdx + 1);
      for (const m of removed) await conversationsRepo.deleteMessage(m.id);
      set({ messages: messages.slice(0, lastUserIdx + 1) });
      await runTurn(currentId, messages[lastUserIdx].content, messages.slice(0, lastUserIdx));
    },

    rename: async (id, title) => {
      await conversationsRepo.rename(id, title);
      await get().loadConversations();
    },

    remove: async (id) => {
      await conversationsRepo.remove(id);
      if (get().currentId === id) set({ currentId: null, messages: [] });
      await get().loadConversations();
    },
  };
});
