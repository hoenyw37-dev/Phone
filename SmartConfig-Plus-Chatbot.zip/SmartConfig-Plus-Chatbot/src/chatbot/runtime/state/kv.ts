import { createMMKV } from 'react-native-mmkv';

export const kv = createMMKV({ id: 'docassist' });

export const kvJson = {
  get<T>(key: string, fallback: T): T {
    const raw = kv.getString(key);
    if (raw == null) return fallback;
    try {
      return JSON.parse(raw) as T;
    } catch {
      return fallback;
    }
  },
  set(key: string, value: unknown) {
    kv.set(key, JSON.stringify(value));
  },
};
