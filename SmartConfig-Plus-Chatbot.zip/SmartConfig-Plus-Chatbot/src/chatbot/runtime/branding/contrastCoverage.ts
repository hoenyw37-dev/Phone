// Logo legibility per theme (ADR-007) — pure, unit tested.
// Averaging a logo's luminance hides dark text next to a bright mark, so measure instead what
// share of the logo's visible pixels individually fall below 3:1 against the theme background.
import { contrastRatio, hexToRgb, relativeLuminance } from '@/theme/contrast';
import { palette } from '@/theme/tokens';

export const PLATE_THRESHOLD = 0.15; // >15% of visible pixels illegible → use a plate
const MIN_CONTRAST = 3;

export interface LowContrast {
  light: number;
  dark: number;
}

const bgLum = (scheme: 'light' | 'dark') => relativeLuminance(hexToRgb(palette[scheme].bg));

/** Fraction of visible (alpha > 0.5) pixels with < 3:1 contrast against each theme background. */
export function lowContrastCoverage(rgba: Uint8Array): LowContrast {
  const bl = bgLum('light'), bd = bgLum('dark');
  let visible = 0, lowL = 0, lowD = 0;
  for (let i = 0; i < rgba.length; i += 4) {
    if (rgba[i + 3] < 128) continue;
    visible++;
    const l = relativeLuminance([rgba[i], rgba[i + 1], rgba[i + 2]]);
    if (contrastRatio(l, bl) < MIN_CONTRAST) lowL++;
    if (contrastRatio(l, bd) < MIN_CONTRAST) lowD++;
  }
  return visible ? { light: lowL / visible, dark: lowD / visible } : { light: 0, dark: 0 };
}

/** Same measure for vector logos, weighting each fill/stroke colour equally. */
export function lowContrastFromColours(hexes: string[]): LowContrast {
  if (!hexes.length) return { light: 0, dark: 1 }; // unknown fills default to black in SVG
  const bl = bgLum('light'), bd = bgLum('dark');
  const lums = hexes.map((h) => relativeLuminance(hexToRgb(h)));
  return {
    light: lums.filter((l) => contrastRatio(l, bl) < MIN_CONTRAST).length / lums.length,
    dark: lums.filter((l) => contrastRatio(l, bd) < MIN_CONTRAST).length / lums.length,
  };
}
