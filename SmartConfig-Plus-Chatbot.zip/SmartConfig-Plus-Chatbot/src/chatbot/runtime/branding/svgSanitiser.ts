// Allowlist SVG sanitiser (ADR-007) — unit tested.
const ALLOWED_TAGS = new Set([
  'svg', 'g', 'path', 'rect', 'circle', 'ellipse', 'line', 'polyline', 'polygon', 'text', 'tspan', 'defs',
  'lineargradient', 'radialgradient', 'stop', 'clippath', 'mask', 'use', 'title', 'desc', 'symbol',
]);
const ALLOWED_ATTRS = new Set([
  'id', 'class', 'd', 'x', 'y', 'x1', 'x2', 'y1', 'y2', 'cx', 'cy', 'r', 'rx', 'ry', 'width', 'height', 'points',
  'fill', 'fill-opacity', 'fill-rule', 'stroke', 'stroke-width', 'stroke-opacity', 'stroke-linecap', 'stroke-linejoin',
  'stroke-miterlimit', 'stroke-dasharray', 'opacity', 'transform', 'viewbox', 'xmlns', 'version', 'preserveaspectratio',
  'offset', 'stop-color', 'stop-opacity', 'gradientunits', 'gradienttransform', 'clip-path', 'clip-rule', 'mask',
  'font-family', 'font-size', 'font-weight', 'text-anchor', 'dominant-baseline', 'letter-spacing', 'style', 'href',
  'xlink:href', 'xmlns:xlink', 'fx', 'fy', 'spreadmethod', 'maskunits', 'clippathunits',
]);

export function sanitiseSvg(src: string): string {
  let s = src
    .replace(/<\?xml[\s\S]*?\?>/g, '')
    .replace(/<!DOCTYPE[\s\S]*?>/gi, '')
    .replace(/<!--[\s\S]*?-->/g, '')
    .replace(/<(script|foreignObject|style|iframe|image|a)\b[\s\S]*?<\/\1\s*>/gi, '')
    .replace(/<(script|foreignObject|style|iframe|image|a)\b[^>]*\/?>/gi, '');

  s = s.replace(/<(\/?)([a-zA-Z][\w:-]*)([^>]*?)(\/?)>/g, (_m, close: string, tag: string, attrs: string, selfClose: string) => {
    if (!ALLOWED_TAGS.has(tag.toLowerCase())) return '';
    if (close) return `</${tag}>`;
    const kept: string[] = [];
    attrs.replace(/([\w:-]+)\s*=\s*("([^"]*)"|'([^']*)')/g, (_a, name: string, _q, dq?: string, sq?: string) => {
      const n = name.toLowerCase();
      const v = (dq ?? sq ?? '').trim();
      if (!ALLOWED_ATTRS.has(n) || n.startsWith('on')) return '';
      if ((n === 'href' || n === 'xlink:href') && !v.startsWith('#')) return '';
      if (/url\s*\(\s*['"]?(?!#)/i.test(v) || /javascript:|expression\(/i.test(v)) return '';
      kept.push(`${name}="${v.replace(/"/g, '&quot;')}"`);
      return '';
    });
    return `<${tag}${kept.length ? ' ' + kept.join(' ') : ''}${selfClose}>`;
  });
  if (!/^\s*<svg[\s>]/i.test(s)) throw new Error('Not a valid SVG');
  return s.trim();
}

/** Average luminance of the fills/strokes used in an SVG (0..1). */
export function svgColours(svg: string): string[] {
  return [...svg.matchAll(/(?:fill|stroke|stop-color)\s*[:=]\s*"?\s*(#[0-9a-fA-F]{3,6})\b/g)].map((m) => m[1]);
}
