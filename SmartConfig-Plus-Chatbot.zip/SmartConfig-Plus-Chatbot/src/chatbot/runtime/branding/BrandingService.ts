import { Directory, File, Paths } from 'expo-file-system';
import { ImageManipulator, SaveFormat } from 'expo-image-manipulator';

import { BRANDING } from '@/config';
import { useBrandingStore, type LogoAsset } from '@/state/brandingStore';
import { hexToRgb, relativeLuminance } from '@/theme/contrast';
import { AppError } from '@/utils/errors';
import { lowContrastCoverage, lowContrastFromColours, PLATE_THRESHOLD, type LowContrast } from './contrastCoverage';
import { decodePng } from './png';
import { sanitiseSvg, svgColours } from './svgSanitiser';

export interface PickedImage {
  uri: string;
  mimeType?: string | null;
  fileName?: string | null;
  fileSize?: number | null;
  width?: number;
  height?: number;
}

const dir = () => {
  const d = new Directory(Paths.document, 'branding');
  if (!d.exists) d.create({ intermediates: true });
  return d;
};

function base64ToBytes(b64: string): Uint8Array {
  const bin = globalThis.atob(b64);
  const out = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
  return out;
}

/** Samples a 32×32 downscale for opacity and per-theme legibility (drives the contrast plate). */
async function analyseRaster(uri: string): Promise<{ luminance: number; opaque: boolean; lowContrast?: LowContrast }> {
  try {
    const ref = await ImageManipulator.manipulate(uri).resize({ width: 32, height: 32 }).renderAsync();
    const res = await ref.saveAsync({ format: SaveFormat.PNG, base64: true });
    const { rgba } = decodePng(base64ToBytes(res.base64!));
    let lum = 0, weight = 0, opaquePx = 0;
    for (let i = 0; i < rgba.length; i += 4) {
      const a = rgba[i + 3] / 255;
      if (a > 0.9) opaquePx++;
      lum += relativeLuminance([rgba[i], rgba[i + 1], rgba[i + 2]]) * a;
      weight += a;
    }
    return { luminance: weight ? lum / weight : 0.5, opaque: opaquePx / (rgba.length / 4) > 0.9, lowContrast: lowContrastCoverage(rgba) };
  } catch {
    return { luminance: 0.5, opaque: false };
  }
}

function isSvg(img: PickedImage) {
  return img.mimeType === 'image/svg+xml' || /\.svg$/i.test(img.fileName ?? img.uri);
}

export async function setLogo(variant: 'light' | 'dark', img: PickedImage): Promise<LogoAsset> {
  const size = img.fileSize ?? new File(img.uri).size ?? 0;
  if (size > BRANDING.MAX_LOGO_MB * 1024 * 1024) throw new AppError('FILE_TOO_LARGE', 'Logo must be 5 MB or smaller.');
  const stamp = Date.now().toString(36);
  let asset: LogoAsset;

  if (isSvg(img)) {
    const clean = sanitiseSvg(await new File(img.uri).text());
    const out = new File(dir(), `logo-${variant}-${stamp}.svg`);
    out.create();
    out.write(clean);
    const cols = svgColours(clean);
    const luminance = cols.length ? cols.reduce((s, c) => s + relativeLuminance(hexToRgb(c)), 0) / cols.length : 0.1;
    const vb = /viewBox="[\d.\-]+\s+[\d.\-]+\s+([\d.]+)\s+([\d.]+)"/i.exec(clean);
    asset = { uri: out.uri, kind: 'svg', luminance, opaque: false, aspect: vb ? Number(vb[1]) / Number(vb[2]) : 3, lowContrast: lowContrastFromColours(cols) };
  } else {
    if (img.mimeType && !/^image\/(png|jpe?g|webp|heic|heif)$/.test(img.mimeType)) throw new AppError('UNSUPPORTED_TYPE');
    const w = img.width ?? 0, h = img.height ?? 0;
    const ctx = ImageManipulator.manipulate(img.uri);
    if (Math.max(w, h) > BRANDING.MAX_LOGO_PX || !w) {
      ctx.resize(w >= h ? { width: BRANDING.MAX_LOGO_PX } : { height: BRANDING.MAX_LOGO_PX });
    }
    const ref = await ctx.renderAsync();
    const saved = await ref.saveAsync({ format: SaveFormat.PNG, compress: 1 });
    const out = new File(dir(), `logo-${variant}-${stamp}.png`);
    await new File(saved.uri).move(out);
    const { luminance, opaque, lowContrast } = await analyseRaster(out.uri);
    asset = { uri: out.uri, kind: 'png', luminance, opaque, lowContrast, aspect: saved.width / Math.max(1, saved.height) };
  }

  const prev = useBrandingStore.getState()[variant];
  useBrandingStore.getState().set({ [variant]: asset });
  if (prev) deleteQuietly(prev.uri);
  return asset;
}

export function removeLogo(variant: 'light' | 'dark') {
  const prev = useBrandingStore.getState()[variant];
  useBrandingStore.getState().clear(variant);
  if (prev) deleteQuietly(prev.uri);
}

function deleteQuietly(uri: string) {
  try {
    const f = new File(uri);
    if (f.exists) f.delete();
  } catch {}
}

/** Picks the logo for a scheme and whether it needs a contrast plate (< 3:1 vs background). */
export function logoFor(
  s: Pick<ReturnType<typeof useBrandingStore.getState>, 'light' | 'dark'>,
  scheme: 'light' | 'dark',
  bgLuminance: number
): { asset?: LogoAsset; plate: boolean } {
  const asset = (scheme === 'dark' ? s.dark ?? s.light : s.light ?? s.dark) ?? undefined;
  if (!asset || asset.opaque) return { asset, plate: false };
  if (asset.lowContrast) return { asset, plate: asset.lowContrast[scheme] > PLATE_THRESHOLD };
  // Assets stored before per-pixel analysis: fall back to mean luminance.
  const [a, b] = asset.luminance > bgLuminance ? [asset.luminance, bgLuminance] : [bgLuminance, asset.luminance];
  return { asset, plate: (a + 0.05) / (b + 0.05) < 3 };
}
