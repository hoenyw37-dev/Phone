import { useCallback, useRef, useState } from 'react';
import { askQuestion, type AskQuestionOptions, type AskQuestionResult } from '../services/LLMService';
import type { ChatLine } from '../components/ChatMessage';

export function useChatbot(provider?: AskQuestionOptions['localDataProvider']) {
  const [messages, setMessages] = useState<ChatLine[]>([]);
  const [busy, setBusy] = useState(false);
  const controller = useRef<AbortController | null>(null);

  const send = useCallback(async (question: string) => {
    const text = question.trim();
    if (!text || busy) return;
    const user: ChatLine = { id: `${Date.now()}-u`, role: 'user', text };
    const assistant: ChatLine = { id: `${Date.now()}-a`, role: 'assistant', text: '', pending: true };
    setMessages((current) => [...current, user, assistant]);
    const abort = new AbortController();
    controller.current = abort;
    setBusy(true);
    const update = (result: Partial<ChatLine>) => setMessages((current) => current.map((m) => m.id === assistant.id ? { ...m, ...result } : m));
    try {
      const result: AskQuestionResult = await askQuestion(text, {
        signal: abort.signal,
        localDataProvider: provider,
        onToken: (partial) => update({ text: partial }),
      });
      update({ text: result.answer, sources: result.sources, pending: false });
    } catch (error) {
      update({ text: abort.signal.aborted ? 'Response stopped.' : `Could not answer: ${String(error)}`, pending: false });
    } finally {
      controller.current = null;
      setBusy(false);
    }
  }, [busy, provider]);

  const stop = useCallback(() => controller.current?.abort(), []);
  return { messages, busy, send, stop };
}
