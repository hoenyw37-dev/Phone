import ExpoModulesCore
import PDFKit
import UIKit

public class NativeUtilsModule: Module {
  private var memoryObserver: NSObjectProtocol?

  public func definition() -> ModuleDefinition {
    Name("NativeUtils")

    Events("onMemoryWarning", "onInstallProgress")

    OnCreate {
      self.memoryObserver = NotificationCenter.default.addObserver(
        forName: UIApplication.didReceiveMemoryWarningNotification, object: nil, queue: .main
      ) { [weak self] _ in
        self?.sendEvent("onMemoryWarning", ["level": 80])
      }
    }

    OnDestroy {
      if let o = self.memoryObserver { NotificationCenter.default.removeObserver(o) }
    }

    Function("getDeviceCaps") { () -> [String: Any] in
      var sys = utsname()
      uname(&sys)
      let machine = withUnsafePointer(to: &sys.machine) {
        $0.withMemoryRebound(to: CChar.self, capacity: 1) { String(cString: $0) }
      }
      let total = Double(ProcessInfo.processInfo.physicalMemory) / 1_048_576
      let avail = Double(os_proc_available_memory()) / 1_048_576
      return [
        "totalRamMB": total,
        "availRamMB": avail,
        "cpuCores": ProcessInfo.processInfo.activeProcessorCount,
        "socModel": machine,
        "deviceModel": machine,
        "osVersion": UIDevice.current.systemVersion,
        "abis": ["arm64"]
      ]
    }

    Function("getThermalState") { () -> String in
      switch ProcessInfo.processInfo.thermalState {
      case .nominal: return "nominal"
      case .fair: return "fair"
      case .serious: return "serious"
      case .critical: return "critical"
      @unknown default: return "nominal"
      }
    }

    // iOS: models are bundle resources; mmap straight from the read-only bundle.
    Function("getBundledModelPath") { (name: String) -> String? in
      let url = URL(fileURLWithPath: name)
      return Bundle.main.path(forResource: url.deletingPathExtension().lastPathComponent,
                              ofType: url.pathExtension, inDirectory: "models")
        ?? Bundle.main.path(forResource: url.deletingPathExtension().lastPathComponent, ofType: url.pathExtension)
    }

    AsyncFunction("installBundledModel") { (name: String, _: Double, _: String?) -> String in
      let url = URL(fileURLWithPath: name)
      guard let p = Bundle.main.path(forResource: url.deletingPathExtension().lastPathComponent,
                                     ofType: url.pathExtension, inDirectory: "models")
        ?? Bundle.main.path(forResource: url.deletingPathExtension().lastPathComponent, ofType: url.pathExtension) else {
        throw Exception(name: "MODEL_NOT_BUNDLED", description: "\(name) is missing from the app bundle")
      }
      return p
    }

    AsyncFunction("extractPdf") { (path: String) -> [String: Any] in
      let url = path.hasPrefix("file://") ? URL(string: path)! : URL(fileURLWithPath: path)
      guard let doc = PDFDocument(url: url) else {
        throw Exception(name: "PDF_OPEN_FAILED", description: "Could not open PDF")
      }
      var pages: [[String: Any]] = []
      for i in 0..<doc.pageCount {
        pages.append(["page": i + 1, "text": doc.page(at: i)?.string ?? ""])
      }
      return ["pageCount": doc.pageCount, "pages": pages]
    }
  }
}
