package expo.modules.nativeutils

import android.app.ActivityManager
import android.content.ComponentCallbacks2
import android.content.Context
import android.content.res.Configuration
import android.os.Build
import android.os.PowerManager
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.text.PDFTextStripper
import expo.modules.kotlin.exception.CodedException
import expo.modules.kotlin.modules.Module
import expo.modules.kotlin.modules.ModuleDefinition
import java.io.File
import java.io.FileOutputStream
import java.security.MessageDigest

class NativeUtilsModule : Module() {
  private val context: Context
    get() = appContext.reactContext ?: throw CodedException("ERR_NO_CONTEXT", "React context unavailable", null)

  private var pdfBoxReady = false

  private val memoryCallbacks = object : ComponentCallbacks2 {
    override fun onTrimMemory(level: Int) {
      @Suppress("DEPRECATION")
      if (level >= ComponentCallbacks2.TRIM_MEMORY_RUNNING_LOW) {
        sendEvent("onMemoryWarning", mapOf("level" to level))
      }
    }
    override fun onConfigurationChanged(newConfig: Configuration) {}
    @Deprecated("Deprecated in Java")
    override fun onLowMemory() {
      sendEvent("onMemoryWarning", mapOf("level" to 80))
    }
  }

  override fun definition() = ModuleDefinition {
    Name("NativeUtils")

    Events("onMemoryWarning", "onInstallProgress")

    OnCreate {
      appContext.reactContext?.applicationContext?.registerComponentCallbacks(memoryCallbacks)
    }

    OnDestroy {
      appContext.reactContext?.applicationContext?.unregisterComponentCallbacks(memoryCallbacks)
    }

    Function("getDeviceCaps") {
      val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
      val mi = ActivityManager.MemoryInfo()
      am.getMemoryInfo(mi)
      mapOf(
        "totalRamMB" to (mi.totalMem / (1024 * 1024)).toDouble(),
        "availRamMB" to (mi.availMem / (1024 * 1024)).toDouble(),
        "cpuCores" to Runtime.getRuntime().availableProcessors(),
        "socModel" to (if (Build.VERSION.SDK_INT >= 31) "${Build.SOC_MANUFACTURER} ${Build.SOC_MODEL}" else Build.HARDWARE),
        "deviceModel" to "${Build.MANUFACTURER} ${Build.MODEL}",
        "osVersion" to Build.VERSION.RELEASE,
        "abis" to Build.SUPPORTED_ABIS.toList()
      )
    }

    Function("getThermalState") {
      val pm = context.getSystemService(Context.POWER_SERVICE) as PowerManager
      when (pm.currentThermalStatus) {
        PowerManager.THERMAL_STATUS_NONE, PowerManager.THERMAL_STATUS_LIGHT -> "nominal"
        PowerManager.THERMAL_STATUS_MODERATE -> "fair"
        PowerManager.THERMAL_STATUS_SEVERE -> "serious"
        else -> "critical"
      }
    }

    // Android: model files ship inside the APK (assets/models). llama.cpp needs a real path,
    // so stream the asset into noBackupFilesDir once, verifying size (+ optional SHA-256).
    AsyncFunction("installBundledModel") { assetName: String, expectedSize: Double, expectedSha256: String? ->
      val dir = File(context.noBackupFilesDir, "models").apply { mkdirs() }
      val dest = File(dir, assetName)
      val marker = File(dir, "$assetName.ok")
      if (dest.exists() && marker.exists() && dest.length().toDouble() == expectedSize) {
        return@AsyncFunction dest.absolutePath
      }
      marker.delete()
      val tmp = File(dir, "$assetName.part")
      val digest = MessageDigest.getInstance("SHA-256")
      context.assets.open("models/$assetName").use { input ->
        FileOutputStream(tmp).use { out ->
          val buf = ByteArray(4 * 1024 * 1024)
          var copied = 0L
          var lastPct = -1
          while (true) {
            val n = input.read(buf)
            if (n < 0) break
            out.write(buf, 0, n)
            if (expectedSha256 != null) digest.update(buf, 0, n)
            copied += n
            val pct = if (expectedSize > 0) ((copied * 100) / expectedSize.toLong()).toInt() else 0
            if (pct != lastPct) {
              lastPct = pct
              sendEvent("onInstallProgress", mapOf("name" to assetName, "progress" to pct / 100.0))
            }
          }
        }
      }
      if (expectedSha256 != null) {
        val hex = digest.digest().joinToString("") { "%02x".format(it) }
        if (!hex.equals(expectedSha256, ignoreCase = true)) {
          tmp.delete()
          throw CodedException("MODEL_FILE_CORRUPT", "Checksum mismatch for $assetName", null)
        }
      }
      if (dest.exists()) dest.delete()
      if (!tmp.renameTo(dest)) throw CodedException("MODEL_INSTALL_FAILED", "Could not finalise $assetName", null)
      marker.writeText("ok")
      dest.absolutePath
    }

    // iOS resolves models from the app bundle; Android has no equivalent path.
    Function("getBundledModelPath") { _: String -> null as String? }

    AsyncFunction("extractPdf") { path: String ->
      if (!pdfBoxReady) {
        PDFBoxResourceLoader.init(context.applicationContext)
        pdfBoxReady = true
      }
      val file = File(path.removePrefix("file://"))
      PDDocument.load(file).use { doc ->
        val stripper = PDFTextStripper().apply { sortByPosition = true }
        val pages = ArrayList<Map<String, Any>>()
        for (i in 1..doc.numberOfPages) {
          stripper.startPage = i
          stripper.endPage = i
          pages.add(mapOf("page" to i, "text" to stripper.getText(doc)))
        }
        mapOf("pageCount" to doc.numberOfPages, "pages" to pages)
      }
    }
  }
}
