export type DeviceCapsRaw = {
  totalRamMB: number;
  availRamMB: number;
  cpuCores: number;
  socModel: string;
  deviceModel: string;
  osVersion: string;
  abis: string[];
};

export type ThermalState = 'nominal' | 'fair' | 'serious' | 'critical';

export type PdfExtraction = { pageCount: number; pages: { page: number; text: string }[] };

export type NativeUtilsEvents = {
  onMemoryWarning: (e: { level: number }) => void;
  onInstallProgress: (e: { name: string; progress: number }) => void;
};
