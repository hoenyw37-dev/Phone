import { NativeModule, requireNativeModule } from 'expo';

import type { DeviceCapsRaw, NativeUtilsEvents, PdfExtraction, ThermalState } from './NativeUtils.types';

declare class NativeUtilsModule extends NativeModule<NativeUtilsEvents> {
  getDeviceCaps(): DeviceCapsRaw;
  getThermalState(): ThermalState;
  getBundledModelPath(name: string): string | null;
  installBundledModel(name: string, expectedSize: number, expectedSha256: string | null): Promise<string>;
  extractPdf(path: string): Promise<PdfExtraction>;
}

export default requireNativeModule<NativeUtilsModule>('NativeUtils');
