#!/usr/bin/env bash
# Build-time only: fetches the bundled GGUF models (ADR-006). The app itself never touches the network.
set -euo pipefail
mkdir -p "$(dirname "$0")/../../assets/models"
cd "$(dirname "$0")/../../assets/models"

fetch() { # url file sha256
  if [[ -f "$2" ]] && echo "$3  $2" | shasum -a 256 -c --status; then echo "✓ $2"; return; fi
  echo "↓ $2"; curl -fL --retry 3 -o "$2.part" "$1" && mv "$2.part" "$2"
  echo "$3  $2" | shasum -a 256 -c
}

fetch https://huggingface.co/unsloth/Qwen3-1.7B-GGUF/resolve/main/Qwen3-1.7B-Q4_K_M.gguf \
  qwen3-1.7b-q4_k_m.gguf b139949c5bd74937ad8ed8c8cf3d9ffb1e99c866c823204dc42c0d91fa181897
fetch https://huggingface.co/CompendiumLabs/bge-small-en-v1.5-gguf/resolve/main/bge-small-en-v1.5-q8_0.gguf \
  bge-small-en-v1.5-q8_0.gguf ec38e8da142596baa913124ae50550de284b6916bf59577ef2f0cb9660c2f514
