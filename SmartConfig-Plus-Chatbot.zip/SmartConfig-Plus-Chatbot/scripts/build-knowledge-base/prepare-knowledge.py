#!/usr/bin/env python3
"""Build a deterministic, offline SQLite knowledge base from approved source files.

Embeddings are produced by a locally installed llama.cpp `llama-embedding`
binary and the configured bge GGUF. No model or source data is downloaded.
"""
import argparse, hashlib, json, os, re, sqlite3, subprocess, sys
from pathlib import Path

EXTENSIONS = {'.md', '.mdx', '.txt', '.ts', '.tsx', '.js', '.jsx', '.json', '.yaml', '.yml', '.html', '.css', '.scss', '.xml'}
SKIP_DIRS = {'.git', '.expo', 'node_modules', 'vendor', 'dist', 'build', 'coverage', '.next', 'Pods', 'DerivedData', '.gradle'}
SECRET = re.compile(r'(?i)(api[_-]?key|secret|password|token|private[_-]?key)\s*[:=]\s*["\'][^"\']{6,}')
MAX_BYTES = 2_000_000
CHUNK_CHARS = 1400

def files_under(root):
    for base, dirs, names in os.walk(root):
        dirs[:] = sorted(d for d in dirs if d not in SKIP_DIRS and not d.startswith('.'))
        for name in sorted(names):
            p = Path(base) / name
            lower = name.lower()
            if lower.startswith(('.env', 'secret', 'credential')) or lower.endswith(('.min.js', '.generated.ts', '.generated.tsx')):
                continue
            if p.suffix.lower() in EXTENSIONS and p.stat().st_size <= MAX_BYTES:
                yield p

def clean_text(path):
    raw = path.read_bytes()
    if b'\0' in raw: return ''
    text = raw.decode('utf-8-sig', errors='replace').replace('\r\n', '\n').replace('\r', '\n')
    if SECRET.search(text):
        text = '\n'.join(line for line in text.splitlines() if not SECRET.search(line))
    return re.sub(r'\n{3,}', '\n\n', text).strip()

def chunks(text):
    heading = ''
    blocks = []
    for para in re.split(r'\n\s*\n', text):
        para = para.strip()
        if not para: continue
        if para.startswith('#'):
            heading = para.lstrip('#').strip()[:160]
        while len(para) > CHUNK_CHARS:
            cut = para.rfind('\n', 0, CHUNK_CHARS)
            if cut < CHUNK_CHARS // 2: cut = para.rfind(' ', 0, CHUNK_CHARS)
            if cut < CHUNK_CHARS // 2: cut = CHUNK_CHARS
            blocks.append((heading, para[:cut].strip()))
            para = para[cut:].strip()
        if para: blocks.append((heading, para))
    return blocks

def embedding(text, model, executable):
    cmd = [executable, '-m', str(model), '--embd-output-format', 'json', '-p', text]
    proc = subprocess.run(cmd, check=True, text=True, capture_output=True)
    # llama.cpp versions wrap JSON differently; select the last JSON object/array.
    output = proc.stdout.strip()
    try: parsed = json.loads(output)
    except json.JSONDecodeError:
        start = min([i for i in (output.find('{'), output.find('[')) if i >= 0], default=-1)
        if start < 0: raise RuntimeError('llama-embedding returned no JSON vector')
        parsed = json.loads(output[start:])
    def find_vector(value):
        if isinstance(value, list) and value and all(isinstance(x, (int, float)) for x in value): return value
        if isinstance(value, dict):
            for child in value.values():
                found = find_vector(child)
                if found is not None: return found
        if isinstance(value, list):
            for child in value:
                found = find_vector(child)
                if found is not None: return found
        return None
    vector = find_vector(parsed)
    if not vector or len(vector) != 384: raise RuntimeError(f'Expected a 384-value bge vector; got {len(vector) if vector else 0}')
    return vector

def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--source', required=True, type=Path, help='Approved source/documentation directory')
    ap.add_argument('--output', type=Path, default=Path('assets/knowledge/knowledge.db'))
    ap.add_argument('--embedding-model', type=Path, default=Path('assets/models/bge-small-en-v1.5-q8_0.gguf'))
    ap.add_argument('--embedding-cli', default=os.environ.get('LLAMA_EMBEDDING', 'llama-embedding'))
    args = ap.parse_args()
    if not args.source.is_dir(): ap.error(f'Source directory does not exist: {args.source}')
    if not args.embedding_model.is_file(): ap.error(f'Local embedding model not found: {args.embedding_model}')
    args.output.parent.mkdir(parents=True, exist_ok=True)
    temp = args.output.with_suffix('.tmp.db')
    if temp.exists(): temp.unlink()
    previous = sqlite3.connect(args.output) if args.output.is_file() else None
    db = sqlite3.connect(temp)
    db.executescript('''
      PRAGMA journal_mode=DELETE; PRAGMA user_version=1;
      CREATE TABLE documents(id TEXT PRIMARY KEY,title TEXT NOT NULL,file_name TEXT NOT NULL,mime TEXT NOT NULL,size_bytes INTEGER NOT NULL,sha256 TEXT NOT NULL UNIQUE,local_path TEXT NOT NULL,page_count INTEGER,chunk_count INTEGER NOT NULL,status TEXT NOT NULL,progress REAL NOT NULL,error TEXT,summary TEXT,description TEXT,created_at INTEGER NOT NULL,updated_at INTEGER NOT NULL);
      CREATE TABLE chunks(id INTEGER PRIMARY KEY,document_id TEXT NOT NULL REFERENCES documents(id),ord INTEGER NOT NULL,page_start INTEGER,page_end INTEGER,section_path TEXT,text TEXT NOT NULL,token_count INTEGER NOT NULL,UNIQUE(document_id,ord));
      CREATE INDEX idx_chunks_doc ON chunks(document_id,ord);
      CREATE TABLE vec_chunks(chunk_id INTEGER PRIMARY KEY,embedding BLOB NOT NULL);
      CREATE VIRTUAL TABLE fts_chunks USING fts5(text,section_path,content='chunks',content_rowid='id',tokenize='unicode61 remove_diacritics 2');
      CREATE TRIGGER chunks_ai AFTER INSERT ON chunks BEGIN INSERT INTO fts_chunks(rowid,text,section_path) VALUES(new.id,new.text,new.section_path); END;
    ''')
    try:
        for path in files_under(args.source):
            text = clean_text(path)
            if not text: continue
            rel = path.relative_to(args.source).as_posix()
            digest = hashlib.sha256(text.encode()).hexdigest()
            doc_id = hashlib.sha256(rel.encode()).hexdigest()[:24]
            title = path.stem.replace('-', ' ').replace('_', ' ')
            parts = chunks(text)
            if not parts: continue
            db.execute('INSERT INTO documents VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)',
                (doc_id,title,path.name,'text/plain',path.stat().st_size,digest,'kb://' + rel,None,len(parts),'ready',1,None,None,None,0,0))
            cached = None
            if previous:
                try:
                    old = previous.execute('SELECT sha256 FROM documents WHERE id=?', (doc_id,)).fetchone()
                    if old and old[0] == digest:
                        cached = previous.execute('''SELECT c.ord,c.section_path,c.text,c.token_count,v.embedding
                          FROM chunks c JOIN vec_chunks v ON v.chunk_id=c.id WHERE c.document_id=? ORDER BY c.ord''', (doc_id,)).fetchall()
                        if len(cached) != len(parts): cached = None
                except sqlite3.Error:
                    cached = None
            for ordinal,(heading,body) in enumerate(parts):
                if cached:
                    _, section, body, token_count, vector_blob = cached[ordinal]
                    cur = db.execute('INSERT INTO chunks(document_id,ord,section_path,text,token_count) VALUES(?,?,?,?,?)',
                        (doc_id,ordinal,section,body,token_count))
                    db.execute('INSERT INTO vec_chunks VALUES(?,?)',(cur.lastrowid,vector_blob))
                    continue
                cur = db.execute('INSERT INTO chunks(document_id,ord,section_path,text,token_count) VALUES(?,?,?,?,?)',
                    (doc_id,ordinal,heading or None,body,max(1,len(body.split()))))
                chunk_id = cur.lastrowid
                vector = embedding(f'{title}{" › " + heading if heading else ""}\n{body}', args.embedding_model, args.embedding_cli)
                import array
                packed = array.array('f', vector)
                db.execute('INSERT INTO vec_chunks VALUES(?,?)',(chunk_id,packed.tobytes()))
            print(f'Indexed {rel}: {len(parts)} chunks')
        db.commit()
        count = db.execute('SELECT count(*) FROM chunks').fetchone()[0]
        if count != db.execute('SELECT count(*) FROM vec_chunks').fetchone()[0]: raise RuntimeError('Some chunks have no embedding')
        db.execute("INSERT INTO fts_chunks(fts_chunks) VALUES('integrity-check')")
        db.commit(); db.close()
        if previous: previous.close()
        temp.replace(args.output)
        print(f'Validated {count} chunks → {args.output}')
    except Exception:
        db.close()
        if previous: previous.close()
        temp.unlink(missing_ok=True)
        raise

if __name__ == '__main__':
    try: main()
    except Exception as exc:
        print(f'knowledge preparation failed: {exc}', file=sys.stderr); sys.exit(1)
