import importlib.util, tempfile, unittest
from pathlib import Path

SCRIPT = Path(__file__).with_name('prepare-knowledge.py')
spec = importlib.util.spec_from_file_location('prepare_knowledge', SCRIPT)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)

class KnowledgePreparationTests(unittest.TestCase):
    def test_chunks_retain_heading_and_split_long_sections(self):
        heading, first = module.chunks('# Setup\n\n' + ('word ' * 400))[0]
        self.assertEqual(heading, 'Setup')
        self.assertLessEqual(len(first), module.CHUNK_CHARS)
        self.assertTrue(all(section == 'Setup' for section, _ in module.chunks('# Setup\n\nshort text')))

    def test_secrets_are_removed_and_dependency_folders_are_skipped(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root / 'safe.md').write_text('Public\nAPI_KEY="abcdef123456"\nStill public', encoding='utf-8')
            (root / 'node_modules').mkdir()
            (root / 'node_modules' / 'hidden.ts').write_text('must not index')
            self.assertEqual([p.name for p in module.files_under(root)], ['safe.md'])
            self.assertNotIn('abcdef123456', module.clean_text(root / 'safe.md'))

    def test_binary_files_are_ignored(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / 'binary.md'
            path.write_bytes(b'hello\x00world')
            self.assertEqual(module.clean_text(path), '')

if __name__ == '__main__': unittest.main()
