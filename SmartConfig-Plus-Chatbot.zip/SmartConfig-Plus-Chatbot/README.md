# SmartConfig-Plus Chatbot Module

This ZIP contains the chatbot UI scaffold, local inference/retrieval engine, local native helper, and source-to-SQLite build script. It does not contain SmartConfig-Plus source code, model weights, or a generated `app_knowledge.db`; those must be supplied/generated in the host project.

## Layout

```text
src/chatbot/
  screens/ChatbotScreen.tsx
  components/ChatMessage.tsx
  hooks/useChatbot.ts
  services/LLMService.ts
  services/RetrievalService.ts
  services/SQLiteService.ts
  runtime/                  # copied inference, RAG, SQLite, prompts, and types
scripts/build-knowledge-base/
assets/models/               # place the two local GGUF files here
assets/knowledge/            # generated database goes here
modules/native-utils/        # Expo native PDF/model/device helper
plugins/withModelAssets.js   # packages GGUF and .db assets in native builds
```

`runtime/` keeps the existing phone project's engine modules intact as a private implementation detail. The screen and hook are new, minimal React Native integration points. No standalone `App.tsx`, navigation tree, or global app store is included.

## Add to an Expo React Native host

1. Copy `src/chatbot`, `modules/native-utils`, `plugins/withModelAssets.js`, and `scripts/build-knowledge-base` into the host repository.
2. Add this TypeScript path mapping so the copied runtime's internal imports remain namespaced:

   ```json
   { "compilerOptions": { "paths": { "@chatbot/*": ["src/chatbot/runtime/*"] } } }
   ```

3. Add the native dependencies compatible with the host Expo SDK: `llama.rn`, `@op-engineering/op-sqlite` (with sqlite-vec and FTS5 enabled), `expo-device`, and Expo Modules Core. The source project used React Native 0.86 / Expo SDK 57, `llama.rn` 0.12.9 and `@op-engineering/op-sqlite` 18.2.5. Check host compatibility before installing versions.
4. Register `./plugins/withModelAssets` in the host Expo config, and make the local Expo module under `modules/native-utils` discoverable by Expo autolinking. Regenerate native projects and build a development/native build; Expo Go is insufficient.
5. Register `ChatbotScreen` in the host's own navigation. It can receive an optional `LocalDataProvider`; its `lookup(question)` method must be allowlisted and read-only. It must not execute model-generated SQL.
6. Build the knowledge database as described below, then package it with the app. The host integration must copy/open/import that packaged database into its SQLite connection before `askQuestion` can retrieve from it. That packaged-database runtime loader is not included yet; the current engine retrieves from the chatbot's live database.

## Local models

The two pinned models are Qwen3-1.7B Q4_K_M (about 1.1 GB) and bge-small-en-v1.5 Q8_0 (about 35 MB). Model files are intentionally not in this source ZIP. Use `scripts/build-knowledge-base/fetch-models.sh` only on a trusted build machine to fetch/checksum them, or provide the exact filenames under `assets/models/`:

- `qwen3-1.7b-q4_k_m.gguf`
- `bge-small-en-v1.5-q8_0.gguf`

Package both in the native application so model initialization needs no network access after installation. Approximate model storage is 1.15 GB, in addition to the generated knowledge database. Minimum device guidance from the source app is iOS 16.4 / iPhone 12 (4 GB RAM) and Android 10 / arm64 / 6 GB RAM; 8 GB RAM is recommended for Android.

## Build the knowledge database

Select and review the approved app source and documentation first. Then, from the host repository root, run:

```bash
python3 scripts/build-knowledge-base/prepare-knowledge.py \
  --source /path/to/approved-SmartConfig-Plus-source \
  --embedding-model assets/models/bge-small-en-v1.5-q8_0.gguf \
  --output assets/knowledge/app_knowledge.db
```

A local `llama-embedding` executable is required; set `LLAMA_EMBEDDING` if it is not on `PATH`. The script does not use network services. It processes Markdown, TypeScript/TSX, JavaScript/JSX, JSON, YAML, text, HTML and CSS; skips common generated/dependency folders and likely credential files; retains relative file paths and headings; chunks content; embeds locally; and creates FTS5 and vector tables. Unchanged files reuse stored vectors. Review the selected source directory to ensure it contains no secrets before packaging.

## Important integration boundary

This module package is a source handoff, not a prebuilt, verified host app. The original engine uses `AgentRun` and its existing document-ready database records. The new build script creates a separate knowledge database and the config plugin packages it, but the code to open/import that bundled database into the live engine database remains to be implemented in the host integration. Do not treat the package as already answering from SmartConfig-Plus source until that loader is in place and verified.

The actual SmartConfig-Plus native build, airplane-mode run, and model inference were not verified from this ZIP. Unit test for the knowledge builder: `python3 scripts/build-knowledge-base/test-prepare-knowledge.py`.
