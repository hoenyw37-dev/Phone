// Bundles assets/models/*.gguf inside the native app (ADR-006).
// Android: copied to app/src/main/assets/models (uncompressed) and extracted on first launch.
// iOS: added as a "models" folder reference in the app bundle (mmap'd directly).
const fs = require('fs');
const path = require('path');
const { withDangerousMod, withAppBuildGradle, withXcodeProject, IOSConfig } = require('expo/config-plugins');

const MODELS_DIR = 'assets/models';
const KNOWLEDGE_DIR = 'assets/knowledge';

function modelFiles(projectRoot) {
  const dir = path.join(projectRoot, MODELS_DIR);
  if (!fs.existsSync(dir)) return [];
  return fs.readdirSync(dir).filter((f) => f.endsWith('.gguf') || f === 'models.manifest.json');
}

function knowledgeFiles(projectRoot) {
  const dir = path.join(projectRoot, KNOWLEDGE_DIR);
  return fs.existsSync(dir) ? fs.readdirSync(dir).filter((f) => f.endsWith('.db')) : [];
}

const withAndroidModels = (config) =>
  withDangerousMod(config, [
    'android',
    async (cfg) => {
      const root = cfg.modRequest.projectRoot;
      const dest = path.join(cfg.modRequest.platformProjectRoot, 'app/src/main/assets/models');
      fs.mkdirSync(dest, { recursive: true });
      for (const f of modelFiles(root)) {
        const src = path.join(root, MODELS_DIR, f);
        const out = path.join(dest, f);
        // Hard-link when possible to avoid duplicating a 1 GB file on the build machine.
        if (fs.existsSync(out)) fs.unlinkSync(out);
        try { fs.linkSync(src, out); } catch { fs.copyFileSync(src, out); }
      }
      const knowledgeDest = path.join(cfg.modRequest.platformProjectRoot, 'app/src/main/assets/knowledge');
      fs.mkdirSync(knowledgeDest, { recursive: true });
      for (const f of knowledgeFiles(root)) {
        fs.copyFileSync(path.join(root, KNOWLEDGE_DIR, f), path.join(knowledgeDest, f));
      }
      return cfg;
    },
  ]);

const withAndroidNoCompress = (config) =>
  withAppBuildGradle(config, (cfg) => {
    if (!cfg.modResults.contents.includes('noCompress "gguf"')) {
      cfg.modResults.contents = cfg.modResults.contents.replace(
        /android\s*\{/,
        `android {\n    androidResources {\n        noCompress "gguf"\n    }`
      );
    }
    return cfg;
  });

const withIosModels = (config) =>
  withXcodeProject(config, (cfg) => {
    const project = cfg.modResults;
    const root = cfg.modRequest.projectRoot;
    const rel = path.relative(cfg.modRequest.platformProjectRoot, path.join(root, MODELS_DIR));
    const groupName = cfg.modRequest.projectName;
    // Folder reference → copied as "models/" into the bundle.
    if (!project.hasFile(rel)) {
      IOSConfig.XcodeUtils.addResourceFileToGroup({
        filepath: rel,
        groupName,
        project,
        isBuildFile: true,
        verbose: false,
      });
      const ref = project.hasFile(rel);
      if (ref) ref.lastKnownFileType = 'folder';
    }
    const kbRel = path.relative(cfg.modRequest.platformProjectRoot, path.join(root, KNOWLEDGE_DIR));
    if (knowledgeFiles(root).length && !project.hasFile(kbRel)) {
      IOSConfig.XcodeUtils.addResourceFileToGroup({ filepath: kbRel, groupName, isBuildFile: true, verbose: false });
      const kbRef = project.hasFile(kbRel);
      if (kbRef) kbRef.lastKnownFileType = 'folder';
    }
    return cfg;
  });

module.exports = (config) => withIosModels(withAndroidNoCompress(withAndroidModels(config)));
