Generate app_knowledge.db here with scripts/build-knowledge-base/prepare-knowledge.py after selecting approved host source files. The generated database is not included in this source ZIP.
