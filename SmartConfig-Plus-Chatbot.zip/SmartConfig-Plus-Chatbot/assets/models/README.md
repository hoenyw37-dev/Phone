Place the pinned local GGUF model files here before native build. See the package README. Model weights are excluded from the source ZIP because they total about 1.15 GB.
