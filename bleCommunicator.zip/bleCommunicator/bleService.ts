import {
	NativeModules,
	DeviceEventEmitter,
	NativeEventEmitter,
	Platform,
	PermissionStatus,
	EmitterSubscription,
} from 'react-native';

const { BLECommunicator } = NativeModules;
export interface BluetoothDevice {
	address: string;
	name: string;
	rssi: number;
	status: string;
	connected: boolean;
}

interface DataChunkEvent {
	data: number[];
	length: number;
	timestamp: number;
}

class BLEService {
	private static instance: BLEService;
	private connectedDevice: BluetoothDevice | null = null;
	private nativeEventEmitter: NativeEventEmitter;

	private dataBuffer: number[] = [];
	private expectedLength: number = 0;
	private timeoutId: NodeJS.Timeout | null = null;
	private resolveCallback: ((data: Uint8Array) => void) | null = null;
	private rejectCallback: ((error: Error) => void) | null = null;
	private startTime: number = 0;
	private chunkCount: number = 0;
	private dataChunkListener: EmitterSubscription | null = null;
	private failedRequestsCount: number = 0;
	private isWriteInProgress: boolean = false;

	private constructor() {
		this.nativeEventEmitter = new NativeEventEmitter(BLECommunicator);
		this.setupDataChunkListener();
	}

	public static getInstance(): BLEService {
		if (!BLEService.instance) {
			BLEService.instance = new BLEService();
		}
		return BLEService.instance;
	}

	/**
	 * Check and request Bluetooth permissions for Android API 31+
	 * @returns Permission status
	 */
	public async requestBluetoothPermissions(): Promise<PermissionStatus> {
		if (Platform.OS === 'android') {
			try {
				// Check if the native module has the permission checking method
				const hasPermission =
					(await BLECommunicator.checkBluetoothPermissions()) as boolean;
				if (!hasPermission) {
					// Use the native implementation if available
					const status =
						await BLECommunicator.checkBluetoothPermissionsStatus();
					return status;
				}
			} catch (error) {
				console.error('Error requesting Bluetooth permissions:', error);
				return 'denied' as PermissionStatus;
			}
		}

		// Default return for older Android versions or when native implementation is not available
		return 'denied' as PermissionStatus;
	}

	/**
	 * Start scanning for Bluetooth devices
	 */
	public async startScan(
		timeout: number = 10,
		filter: string = 'BM',
	): Promise<void> {
		try {
			await BLECommunicator.startScan(timeout, filter);
			console.log('Scan started');
		} catch (error) {
			console.error('Error starting scan', error);
		}
	}

	/**
	 * Stop scanning for Bluetooth devices
	 */
	public async stopScan(): Promise<void> {
		try {
			await BLECommunicator.stopScan();
			console.log('Scan stopped');
		} catch (error) {
			console.error('Error stopping scan', error);
			throw error;
		}
	}

	public async connectToDevice(device: BluetoothDevice): Promise<void> {
		try {
			this.connectedDevice = device;
			await BLECommunicator.connectToDevice(device.address);
		} catch (error) {
			console.error('Failed to connect to device:', error);
			throw error;
		}
	}
	public async disconnectDevice(address: string): Promise<void> {
		try {
			this.connectedDevice = null;
			await BLECommunicator.disconnectBlePeripheral(address);
		} catch (error) {
			console.error('Failed to connect to device:', error);
			throw error;
		}
	}

	/**
	 * Setup listener for BLE data chunks from native
	 */
	private setupDataChunkListener(): void {
		this.dataChunkListener = this.nativeEventEmitter.addListener(
			'BLE_DATA_CHUNK',
			(event: DataChunkEvent) => {
				this.handleDataChunk(event);
			},
		);
	}

	/**
	 * Handle incoming data chunk
	 */
	private handleDataChunk(event: DataChunkEvent): void {
		// Only process if we're expecting data
		if (this.expectedLength === 0) {
			console.log('[BLEService] Received Empty data chunk, ignoring');
			return;
		}

		this.chunkCount++;
		const beforeLength = this.dataBuffer.length;

		// Add chunk to buffer
		this.dataBuffer.push(...event.data);

		const elapsed = Date.now() - this.startTime;
		console.log(
			`[BLEService] Chunk #${this.chunkCount}: ${event.data.length} bytes ` +
				`(Total: ${this.dataBuffer.length}/${this.expectedLength}) - ${elapsed}ms elapsed`,
		);

		// Check if we have all expected data
		if (this.dataBuffer.length >= this.expectedLength) {
			this.completeDataCollection();
		}
	}
	/**
	 * Complete data collection successfully
	 */
	private completeDataCollection(): void {
		if (this.timeoutId) {
			clearTimeout(this.timeoutId);
			this.timeoutId = null;
		}

		if (this.resolveCallback) {
			// Truncate to expected length if we received more
			const finalData = this.dataBuffer.slice(0, this.expectedLength);
			const elapsed = Date.now() - this.startTime;

			console.log(
				`[BLEService] Complete! ${finalData.length} bytes in ` +
					`${this.chunkCount} chunks, ${elapsed}ms total`,
			);

			// Check for all-zero response
			const hasAllZeros = finalData.every(b => b === 0);
			if (hasAllZeros && finalData.length > 0) {
				this.failedRequestsCount++;
				console.warn(
					`[BLEService] All-zero response (failed count: ${this.failedRequestsCount})`,
				);

				if (this.failedRequestsCount >= 7) {
					this.nativeEventEmitter.emit('BLEAdapterStatus', 'NotResponding');
					this.failedRequestsCount = 0;
				}
			} else {
				this.failedRequestsCount = 0;
			}

			this.resolveCallback(new Uint8Array(finalData));
			this.resetDataCollection();
		}
	}

	/**
	 * Handle timeout - return whatever data we have
	 */
	private handleTimeout(): void {
		const elapsed = Date.now() - this.startTime;
		console.warn(
			`[BLEService] Timeout! Expected ${this.expectedLength} bytes, ` +
				`got ${this.dataBuffer.length} in ${this.chunkCount} chunks (${elapsed}ms)`,
		);

		if (this.resolveCallback) {
			// Pad with zeros if needed
			while (this.dataBuffer.length < this.expectedLength) {
				this.dataBuffer.push(0);
			}

			const finalData = this.dataBuffer.slice(0, this.expectedLength);
			this.resolveCallback(new Uint8Array(finalData));
			this.resetDataCollection();
		}
	}

	/**
	 * Reset data collection state
	 */
	private resetDataCollection(): void {
		this.dataBuffer = [];
		this.expectedLength = 0;
		this.resolveCallback = null;
		this.rejectCallback = null;
		this.timeoutId = null;
		this.chunkCount = 0;
	}

	/**
	 * Cancel any pending data collection
	 */
	private cancelDataCollection(): void {
		if (this.timeoutId) {
			clearTimeout(this.timeoutId);
		}

		if (this.rejectCallback) {
			this.rejectCallback(new Error('Data collection cancelled'));
		}

		this.resetDataCollection();
	}

	/**
	 * Write characteristic and wait for response with accumulation
	 * @param data Data to write
	 * @param receivedPacketLength Expected response length in bytes
	 * @param timeout Timeout in milliseconds (default 4000)
	 * @returns Promise resolving to accumulated response data
	 */
	public async writeCharacteristic(
		data: Uint8Array,
		receivedPacketLength: number,
		timeout: number = 4000,
	): Promise<Uint8Array> {
		if (!this.connectedDevice) {
			throw new Error('No device connected');
		}

		// ADD: Prevent concurrent writes
		if (this.isWriteInProgress) {
			this.isWriteInProgress = false;
		}

		try {
			this.isWriteInProgress = true;
			const dataLength = data.length;
			const byteArray = this.toByteArray(data);

			console.log(
				`[BLEService] Writing ${dataLength} bytes, expecting ${receivedPacketLength} bytes back`,
			);
			// Setup data accumulation BEFORE writing
			const dataPromise = new Promise<Uint8Array>((resolve, reject) => {
				// Reset and setup for new data collection
				this.dataBuffer = [];
				this.expectedLength = receivedPacketLength;
				this.resolveCallback = resolve;
				this.rejectCallback = reject;
				this.startTime = Date.now();
				this.chunkCount = 0;

				// Set timeout
				this.timeoutId = setTimeout(() => {
					this.handleTimeout();
				}, timeout);
			});

			await BLECommunicator.sendPacketWithByteRecieved(byteArray, dataLength);
			console.log('[BLEService] Write completed, waiting for response...');

			// Wait for accumulated data
			const result = await dataPromise;

			console.log(
				`[BLEService] Received complete response: ${result.length} bytes`,
			);
			return result;
		} catch (error) {
			console.error('Failed to write characteristic:', error);
			this.cancelDataCollection();
			throw error;
		} finally {
			this.isWriteInProgress = false;
		}
	}
	/**
	 * Get current data accumulation state (for debugging)
	 */
	public getAccumulatorState() {
		return {
			received: this.dataBuffer.length,
			expected: this.expectedLength,
			chunks: this.chunkCount,
			elapsed: this.expectedLength > 0 ? Date.now() - this.startTime : 0,
		};
	}

	private toByteArray(data: Uint8Array): number[] {
		return Array.from(data);
	}

	public getConnectedDevice(): BluetoothDevice | null {
		return this.connectedDevice;
	}

	public setConnectedDevice(device: BluetoothDevice | null): void {
		this.connectedDevice = device;
	}

	public getEventEmitter(): NativeEventEmitter {
		return this.nativeEventEmitter;
	}

	public async isConnectionEstablished(
		deviceAddress: string,
	): Promise<boolean> {
		return await BLECommunicator.IsDeviceConnected(deviceAddress);
	}

	/**
	 * Cleanup when service is destroyed
	 */
	public destroy(): void {
		if (this.dataChunkListener) {
			this.dataChunkListener.remove();
			this.dataChunkListener = null;
		}
		this.cancelDataCollection();
	}
}

export default BLEService.getInstance();
