import { useEffect, useState } from 'react';
import { scanParam } from './communicator/scanParams';
import IConnectedDevice from './communicator/iConnectedDevice';
import {
	NativeModules,
	DeviceEventEmitter,
	NativeEventEmitter,
	Platform,
} from 'react-native';
const { BLECommunicator } = NativeModules;
const bleCommunicatorEmitter = new NativeEventEmitter(BLECommunicator);

const scanDevices = async () => {
	console.log('scanDevices Called First:');
	try {
		await BLECommunicator.startScan();
		console.log('Scanning started');
	} catch (error) {
		console.error('Error starting scan:', error);
	}
};

const getDevices = async (): Promise<IConnectedDevice[]> => {
	console.log('getDevices Called First:');
	try {
		const devices = await BLECommunicator.getDeviceList();
		console.log('SM: Devices found:', devices);
		const deviceList: IConnectedDevice[] = devices.map((device: any) => ({
			id: '1',
			Name: device.name,
			Address: device.address,
		}));
		return deviceList;
	} catch (error) {
		console.error('Error getting device list:', error);
		return [];
	}
};

const setupEventListener = () => {
	console.log('setupEventListener Called First:');
	let val = BLECommunicator.StartSubscription();
	bleCommunicatorEmitter.addListener('TEST_EVENT', async object => {
		if (typeof object === 'string') {
			console.log('Message is a string:', object);
		} else {
			console.log('Message is Object:', object);
		}
	});
};

export const ScanNearbyDevices = (
	params: scanParam,
): Promise<IConnectedDevice[]> => {
	return new Promise((resolve, reject) => {
		console.log('ScanNearbyDevices Called First:');
		scanDevices();
		setTimeout(async () => {
			const deviceList = await getDevices();
			console.log('Device List: ', deviceList);
			resolve(deviceList);
		}, params.ScanTime * 1000);
	});
};

// Call setupEventListener once when the module is loaded
setupEventListener();
