export const Constant_NeverAskAgain = 'never_ask_again';
export const Constant_Denied = 'denied';
export const Constant_Granted = 'granted';
export const BLE_MANUFACTURER_NAME = 'SmartConfig Inc.';
export const BLE_MODEL_NUMBER = 'SCP-001';
