import React, { createContext, useContext, useState, useEffect } from 'react';
import BLEService, { BluetoothDevice } from '../bleCommunicator/bleService';
import { BleErrorCode } from '@global/GlobalConstants/globalConstants';
import { PermissionStatus } from 'react-native';
import { eventHandler } from '@global/utils/EventBus';
import { use } from 'i18next';
import useSyncedState from '@global/Hooks/useSyncedState';

interface BLEContextType {
	scannedDevices: BluetoothDevice[];
	bleError?: BleErrorCode;
	scanDevices: () => Promise<void>;
	stopDeviceScan: () => Promise<void>;
	connectToDevice: (device: BluetoothDevice) => Promise<void>;
	SendPacketWithByteReceived: (
		data: Uint8Array,
		receivedPacketLength: number,
	) => Promise<Uint8Array>;
	disconnectDevice: (address: string) => Promise<void>;
	requestBluetoothPermissions: () => Promise<PermissionStatus>;
	getEventEmitter: () => Promise<any>;
	IsConnectionEstablished: (macAddress: string) => Promise<boolean>;
}

const BLEContext = createContext<BLEContextType | undefined>(undefined);
const Turned_Off = 'TurnedOff';
const Scan_Completed = 'ScanCompleted';
const Not_Responding = 'NotResponding';
const BLUETOOTH_TIMEOUT = 'BLUETOOTH_TIMEOUT';
const BLUETOOTH_NOT_ENABLED = 'BLUETOOTH_NOT_ENABLED';
const BLUETOOTH_NOT_SUPPORTED = 'BLUETOOTH_NOT_SUPPORTED';

export const BLEProvider: React.FC<{ children: React.ReactNode }> = ({
	children,
}) => {
	const [connectedDevice, setConnectedDevice, connectedDeviceRef] =
		useSyncedState<BluetoothDevice | null>(null);
	const [scannedDevices, setScannedDevices] = useState<BluetoothDevice[]>([]);
	const [bleError, setBleError] = useState<BleErrorCode>();
	const nativeEventEmitter = BLEService.getEventEmitter();

	useEffect(() => {
		setConnectedDevice(BLEService.getConnectedDevice());
		setupEventListeners();
		setBleError(BleErrorCode.UNKNOWN);
		setScannedDevices([]);
	}, []);

	const setupEventListeners = () => {
		cleanup();
		// Set up event listeners for the native module events
		nativeEventEmitter.addListener('DeviceDiscovered', handleDiscoverDevice);
		nativeEventEmitter.addListener('DeviceConnected', handleConnectDevice);
		nativeEventEmitter.addListener(
			'DeviceDisconnected',
			handleDisconnectDevice,
		);
		nativeEventEmitter.addListener(
			'DeviceDiscoverFailed',
			handleDiscoverDeviceFailed,
		);
		nativeEventEmitter.addListener('BLEAdapterStatus', handleBleAdapterStatus);
	};

	const getEventEmitter = async () => {
		return BLEService.getEventEmitter();
	};
	// Request Bluetooth permissions
	const requestBluetoothPermissions = async (): Promise<PermissionStatus> => {
		try {
			const permissionStatus = await BLEService.requestBluetoothPermissions();
			return permissionStatus;
		} catch (error) {
			console.error('Error requesting Bluetooth permissions:', error);
			return 'denied' as PermissionStatus;
		}
	};

	const scanDevices = async (): Promise<void> => {
		console.log('Scanning for devices...');
		setScannedDevices([]); // Clear previous devices
		await BLEService.startScan();
	};

	const stopDeviceScan = async (): Promise<void> => {
		console.log('Stopping device scan...');
		await BLEService.stopScan();
	};

	const connectToDevice = async (device: BluetoothDevice) => {
		if (device && device.address) {
			await BLEService.connectToDevice(device);
		}
	};
	const disconnectDevice = async (address: string) => {
		await BLEService.disconnectDevice(address);
		setConnectedDevice(null);
	};

	const SendPacketWithByteReceived = async (
		data: Uint8Array,
		receivedPacketLength: number,
	): Promise<Uint8Array> => {
		const response = await BLEService.writeCharacteristic(
			data,
			receivedPacketLength,
		);
		return response;
	};
	const IsConnectionEstablished = async (
		macAddress: string,
	): Promise<boolean> => {
		const isConnected = await BLEService.isConnectionEstablished(macAddress);
		return isConnected;
	};
	/**
	 * Handle device discovery events
	 */
	//TODO: Filters and duplicates
	const handleDiscoverDevice = (device: any) => {
		if (!device.name) {
			return;
		}
		console.log('Full device data:', JSON.stringify(device));
		const bluetoothDevice: BluetoothDevice = {
			address: device.address,
			name: device.name,
			rssi: device.rssi,
			status: device.status,
			connected: false,
		};
		let newDeviceArray: BluetoothDevice[] = [];
		newDeviceArray.push(bluetoothDevice);
		setScannedDevices(newDeviceArray);
	};
	/**
	 * Handle connect events
	 */
	const handleConnectDevice = (event: any) => {
		// if(connectedDevice?.address !== event.address) {
		//   return;
		// }
		const a = connectedDeviceRef.current;
		setConnectedDevice(BLEService.getConnectedDevice());
		if (event.isConnected) {
			setConnectedDevice({ connected: event.isConnected });
			const b = connectedDeviceRef.current;
			BLEService.setConnectedDevice(connectedDeviceRef.current);
			eventHandler.publish('deviceConnected', connectedDeviceRef.current);
		} else {
			handleDisconnectDevice(null);
		}
	};
	/**
	 * Handle disconnect events
	 */
	const handleDisconnectDevice = (event: any) => {
		BLEService.setConnectedDevice(null);
		setConnectedDevice(null);
		eventHandler.publish('deviceDisconnected');
	};

	const handleDiscoverDeviceFailed = (event: any) => {
		if (!event) {
			return;
		}
		if (typeof event === 'string') {
			switch (event) {
				case BLUETOOTH_TIMEOUT:
					setBleError(BleErrorCode.BLUETOOTH_TIMEOUT);
					break;
				case BLUETOOTH_NOT_ENABLED:
					setBleError(BleErrorCode.BLUETOOTH_NOT_ENABLED);
					break;
				case BLUETOOTH_NOT_SUPPORTED:
					setBleError(BleErrorCode.BLUETOOTH_NOT_SUPPORTED);
					break;
				default:
					return;
			}
		} else if (typeof event === 'number') {
			// Handle numeric error codes if any
		}
	};

	const handleBleAdapterStatus = (event: any) => {
		if (!event) {
			return;
		}
		if (typeof event === 'string') {
			switch (event) {
				case Turned_Off:
					eventHandler.publish('BLEAdapterStatus', Turned_Off);
					break;
				case Scan_Completed:
					eventHandler.publish('BLEAdapterStatus', Scan_Completed);
					break;
				case Not_Responding:
					eventHandler.publish('BLEAdapterStatus', Not_Responding);
					break;
				default:
					return;
			}
		}
	};
	/**
	 * Clean up event listeners
	 */
	const cleanup = () => {
		nativeEventEmitter.removeAllListeners('DeviceDiscovered');
		nativeEventEmitter.removeAllListeners('DeviceConnected');
		nativeEventEmitter.removeAllListeners('DeviceDisconnected');
		nativeEventEmitter.removeAllListeners('DeviceDiscoverFailed');
		nativeEventEmitter.removeAllListeners('BLEAdapterStatus');
	};

	return (
		<BLEContext.Provider
			value={{
				scannedDevices,
				bleError,
				getEventEmitter,
				scanDevices,
				stopDeviceScan,
				connectToDevice,
				disconnectDevice,
				SendPacketWithByteReceived,
				requestBluetoothPermissions,
				IsConnectionEstablished,
			}}>
			{children}
		</BLEContext.Provider>
	);
};

export const useBLE = (): BLEContextType => {
	const context = useContext(BLEContext);
	if (!context) {
		throw new Error('useBLE must be used within a BLEProvider');
	}
	return context;
};
