import { NativeModules, DeviceEventEmitter } from 'react-native';
import IConnectedDevice from './communicator/iConnectedDevice';

const { BLECommunicator } = NativeModules;
export const onConnect = async (item: IConnectedDevice) => {
	try {
		const a = await BLECommunicator.connectToDevice(item.Address);
	} catch (error) {
		// Failure code
		console.log('connection failed.........................');
		console.error('SM-Error ' + error);
	}
};

const setupEventListener = () => {
	console.log('setupEventListener Called First:');
	let val = BLECommunicator.StartSubscription();
	DeviceEventEmitter.addListener('TEST_EVENT', async object => {
		if (typeof object === 'string') {
			console.log('gducb is a string:', object);
		} else {
			console.log('mbfucb is Object:', object);
		}
	});
};

setupEventListener();
const getNotification = (
	characteristicUUID: any,
	serviceUUID: any,
	item: any,
) => {
	// if (item) {
	//     BleManager.startNotification(item.id, '0000fefb-0000-1000-8000-00805f9b34fb', "00000002-0000-1000-8000-008025000000")
	//         .then(() => {
	//             // Display confirmation message
	//             console.log(`Notification to...................... ${item.id} - ${serviceUUID} - ${characteristicUUID}`);
	//         })
	//         .catch((err) => {
	//             console.error('Error during BLE write:', err, characteristicUUID);
	//         });
	// }
};
