import {
	PermissionsAndroid,
	NativeModules,
	Platform,
	Linking,
} from 'react-native';
import {
	Constant_Denied,
	Constant_Granted,
	Constant_NeverAskAgain,
} from './bleConstants';

class BluetoothManager {
	async requestPermissionAndroid(): Promise<string> {
		let permissionStatus = '';
		try {
			const status = await PermissionsAndroid.requestMultiple([
				PermissionsAndroid.PERMISSIONS.BLUETOOTH_CONNECT,
				PermissionsAndroid.PERMISSIONS.BLUETOOTH_SCAN,
				PermissionsAndroid.PERMISSIONS.BLUETOOTH_ADVERTISE,
			]);
			//Android Permssions Logging
			console.log(
				'Android Permssions BLUETOOTH_CONNECT ',
				status[PermissionsAndroid.PERMISSIONS.BLUETOOTH_CONNECT],
			);
			console.log(
				'Android Permssions BLUETOOTH_SCAN ',
				status[PermissionsAndroid.PERMISSIONS.BLUETOOTH_SCAN],
			);
			console.log(
				'Android Permssions BLUETOOTH_ADVERTISE ',
				status[PermissionsAndroid.PERMISSIONS.BLUETOOTH_ADVERTISE],
			);
			if (
				status[PermissionsAndroid.PERMISSIONS.BLUETOOTH_CONNECT] ===
					Constant_Granted &&
				status[PermissionsAndroid.PERMISSIONS.BLUETOOTH_SCAN] ===
					Constant_Granted &&
				status[PermissionsAndroid.PERMISSIONS.BLUETOOTH_ADVERTISE] ===
					Constant_Granted
			) {
				permissionStatus = Constant_Granted;
			} else if (
				status[PermissionsAndroid.PERMISSIONS.BLUETOOTH_CONNECT] ===
					Constant_NeverAskAgain ||
				status[PermissionsAndroid.PERMISSIONS.BLUETOOTH_SCAN] ===
					Constant_NeverAskAgain ||
				status[PermissionsAndroid.PERMISSIONS.BLUETOOTH_ADVERTISE] ===
					Constant_NeverAskAgain
			) {
				permissionStatus = Constant_NeverAskAgain;
			} else {
				permissionStatus = Constant_Denied;
			}
			return permissionStatus;
		} catch (e) {
			console.log('Permssions Denied ', e);
			return permissionStatus;
		}
	}

	async EnableBluetoothAndroid(): Promise<void> {
		try {
			//  await BleManager.enableBluetooth();
		} catch (error) {
			console.log('Failed to enable Bluetooth: ', error);
		}
	}
	async enableBluetooth(): Promise<void> {
		//  const isEnabled = await BleManager.checkState();
		// if (Platform.OS === 'android')
		//   {
		//     console.log("Platform.OS === 'android'")
		//     const permissionStatus = await this.requestPermissionAndroid();
		//    if(permissionStatus != '' && permissionStatus === Constant_NeverAskAgain)
		//     {
		//       Linking.openSettings();
		//       return;
		//     }
		//     else
		//     {
		//       if(isEnabled!==BleState.On)
		//        {
		//         await this.EnableBluetoothAndroid();
		//       }
		//     }
		//   }
		//   else{
		//     if(isEnabled!==BleState.On)
		//      {
		//     const url = 'App-Prefs:root=Bluetooth';
		//     const supported = await Linking.canOpenURL(url);
		//     if (supported)
		//       {
		//         await Linking.openURL(url);
		//       }
		//     }
		//   }
	}
	// async checkState(): Promise<BleState> {
	//     try {
	//         return BleState.On;
	//         //await BleManager.checkState();
	//     } catch (error) {
	//         console.log("Failed to check state: ", error);
	//         return BleState.Unknown;
	//     }
	// }
}

export default BluetoothManager;
