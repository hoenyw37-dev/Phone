// Objective: Define the interface for a connected device
// 1. Define an interface IConnectedDevice with the following properties
//    a. id of type string
//    b. Name of type string
//    c. Address of type string
//    d. Status of type string
//    e. TimeoutMilliSeconds of type number
//    f. RSSI of type number
// 2. Export the IConnectedDevice interface
interface IConnectedDevice {
	id: string;
	Name: string;
	Address: string;
	Status: string;
	TimeoutMilliSeconds: number;
	RSSI: number;
}
export default IConnectedDevice;
