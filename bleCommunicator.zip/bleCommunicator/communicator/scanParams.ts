export type scanParam = {
	ServiceUUID: string[];
	Filters: string[];
	ScanTime: number;
	isDuplicatesAllowed: boolean;
};
