# SmartConfig app chatbot

A small, offline React Native chatbot for this Phone app. It answers common app/manual questions and reads the app's saved projects, unique site names, panels, and FAAST FLEX devices from its existing TypeORM database. Data access is read-only. It uses no AI service, internet connection, model, or new package.

## Add it to the app

1. Copy the `chatbot` folder into the app's `src` folder. Keep the folder name `chatbot` so its imports resolve.
2. In `src/global/navigation/appNavigator.tsx`, add this import:

   ```tsx
   import ChatbotScreen from '../../chatbot/ChatbotScreen';
   ```

3. Inside `<Stack.Navigator>`, register the screen:

   ```tsx
   <Stack.Screen
     name="Chatbot"
     component={ChatbotScreen}
     options={{ title: 'App Assistant' }}
   />
   ```

4. Add a button wherever you want the assistant entry point. From a screen that has `navigation`, call `navigation.navigate('Chatbot')` when the button is tapped.

The app already wraps navigation in `DatabaseProvider`, which the chatbot uses. It reads the same ProjectEntity, PanelEntity, and DeviceEntity records as the rest of the app. It does not create, edit, or delete any records.

## What it answers

- Greetings and what the assistant can help with.
- The basic project → panel/device → connect/pair → monitor/configure/test flow.
- Project, site, panel, and detector counts and names from the phone's current database.
- Project and detector setup, Bluetooth sound/manual pairing, device configuration, status, logs, tests, templates, passwords, and disconnecting.

Answers are short, rule-based and offline. If a question is not recognized, the chatbot suggests supported topics. Panel creation instructions come from the app flow because the attached FAAST FLEX guide does not document the Powerstrike panel form.

## Files

- `ChatbotScreen.tsx` - ready-to-register screen and live, read-only database lookup.
- `chatbotAnswers.ts` - offline answer rules and app-data question handling.
- `index.ts` - optional exports.
