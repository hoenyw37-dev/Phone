export type ChatbotData = {
  projects: Array<{ projectName?: string | null; site?: string | null; building?: string | null }>;
  panels: Array<{ panelName?: string | null; panelType?: string | null; projectId?: number | null }>;
  devices: Array<{ deviceName?: string | null; projectId?: number | null; firmwareVersion?: string | null }>;
};

const clean = (value: string) => value.toLowerCase().replace(/[^a-z0-9 ]/g, ' ').replace(/\s+/g, ' ').trim();
const has = (text: string, ...terms: string[]) => terms.some(term => text.includes(term));
const list = (values: string[]) => values.length ? values.join(', ') : 'None are currently saved.';

export function answerChatbotQuestion(question: string, data?: ChatbotData): string {
  const text = clean(question);
  if (!text) return 'Please type a question about the app, your projects, panels, devices, or Bluetooth.';

  if (/^(hi|hello|hey|good morning|good afternoon|good evening|hola)$/.test(text)) {
    return 'Hello! What can I do for you today? You can ask how to use the app or ask about your saved sites, projects, panels, and devices.';
  }
  if (has(text, 'what can you do', 'help', 'what can i ask', 'what do you know')) {
    return 'I can explain the app flow, creating projects, adding panels or FAAST FLEX devices, Bluetooth pairing, device status, logs, configuration, tests, and templates. I can also look up the site, project, panel, and device records saved on this phone.';
  }
  if (has(text, 'data', 'records') && has(text, 'detail', 'summary', 'show', 'what')) {
    if (!data) return 'I can show saved app details after the chatbot connects to the app database.';
    const sites = new Set(data.projects.map(project => project.site?.trim()).filter(Boolean));
    return `Saved app data: ${data.projects.length} projects, ${sites.size} named sites, ${data.panels.length} panels, and ${data.devices.length} FAAST FLEX devices.`;
  }

  if (has(text, 'site', 'location') && has(text, 'how many', 'how sites are there', 'number', 'count', 'list', 'show', 'which', 'what are', 'detail', 'name')) {
    if (!data) return 'I can show site details after the chatbot is connected to the app database.';
    const sites = [...new Set(data.projects.map(project => project.site?.trim()).filter((site): site is string => !!site))];
    if (has(text, 'how many', 'how sites are there', 'number', 'count')) return `There ${sites.length === 1 ? 'is' : 'are'} ${sites.length} saved ${sites.length === 1 ? 'site' : 'sites'} across ${data.projects.length} ${data.projects.length === 1 ? 'project' : 'projects'}.`;
    return `Saved sites (${sites.length}): ${list(sites)}${sites.length < data.projects.length ? '\nSome projects do not have a site name.' : ''}`;
  }
  if (has(text, 'project') && has(text, 'how many', 'how projects are there', 'number', 'count', 'list', 'show', 'which', 'what are', 'detail', 'name')) {
    if (!data) return 'I can show project details after the chatbot is connected to the app database.';
    const names = data.projects.map(project => project.projectName?.trim()).filter((name): name is string => !!name);
    if (has(text, 'how many', 'how projects are there', 'number', 'count')) return `There ${data.projects.length === 1 ? 'is' : 'are'} ${data.projects.length} saved ${data.projects.length === 1 ? 'project' : 'projects'}.`;
    return `Saved projects (${names.length}): ${list(names)}`;
  }
  if (has(text, 'panel') && has(text, 'how many', 'how panels are there', 'number', 'count', 'list', 'show', 'which', 'what are', 'detail', 'name')) {
    if (!data) return 'I can show panel details after the chatbot is connected to the app database.';
    if (has(text, 'how many', 'how panels are there', 'number', 'count')) return `There ${data.panels.length === 1 ? 'is' : 'are'} ${data.panels.length} saved ${data.panels.length === 1 ? 'panel' : 'panels'}.`;
    return `Saved panels (${data.panels.length}): ${list(data.panels.map(panel => panel.panelName).filter((name): name is string => !!name))}`;
  }
  if (has(text, 'device', 'detector', 'faast') && has(text, 'how many', 'how devices are there', 'number', 'count', 'list', 'show', 'which', 'what are', 'detail', 'name')) {
    if (!data) return 'I can show detector details after the chatbot is connected to the app database.';
    if (has(text, 'how many', 'how devices are there', 'number', 'count')) return `There ${data.devices.length === 1 ? 'is' : 'are'} ${data.devices.length} saved FAAST FLEX ${data.devices.length === 1 ? 'device' : 'devices'}.`;
    return `Saved devices (${data.devices.length}): ${list(data.devices.map(device => device.deviceName).filter((name): name is string => !!name))}`;
  }

  if (has(text, 'flow', 'start', 'workflow', 'how does the app work', 'where do i begin')) {
    return 'The usual flow is: create a project and enter its site details; add a panel or add a FAAST FLEX detector to the project; for a detector, assign it to the nearby Bluetooth device and pair it; then view status, logs, configure settings, or run a device test as needed.';
  }
  if (has(text, 'add site', 'new site', 'create site', 'add location')) {
    return 'In this app, a site is entered as part of a project. From the Projects page, tap the add icon, enter a project name and fill in the Site Name and other available details, then tap Save.';
  }
  if (has(text, 'create project', 'add project', 'new project', 'project')) {
    return 'From the Projects page, tap the add icon, enter the project name and available site/building details, then tap Save. Open a project to add its panels or FAAST FLEX detectors. You can edit a project from its three-dot menu. To delete one, first remove its detectors.';
  }
  if (has(text, 'add panel', 'new panel', 'create panel')) {
    return 'Open the project, choose the Powerstrike panel area, then tap Add New Panel and follow the panel setup form. The user manual covers FAAST FLEX detectors; it does not document the panel setup fields.';
  }
  if (has(text, 'add device', 'add detector', 'new device', 'new detector', 'faast')) {
    return 'Open the project and tap Add New. Enter a detector name, pipe configuration (I or U), and pipe length, then Save. Next select the detector, open its three-dot menu, and choose Assign Device to find a nearby unpaired detector.';
  }
  if (has(text, 'bluetooth', 'pair', 'assign device', 'connect')) {
    return 'For a FAAST FLEX detector: open the project, add its details, select it, then choose Assign Device from the three-dot menu. Enable Bluetooth and tap Pair. Keep the phone close. Firmware 4.0.1 or newer uses sound pairing by default; allow microphone access and tap Initiate. Older firmware uses manual pairing: open the detector cover, tap Next, enter the six-digit code on the detector, then tap Validate. After three failed sound-pairing attempts, use manual pairing. The app connects to one detector at a time, so disconnect before connecting another.';
  }
  if (has(text, 'configure', 'configuration', 'settings')) {
    return 'Open the connected detector, tap More, then Configure Device and enter the installer-provided password. Editing parameters requires Extended mode (DIP switch 1 ON). In Out of the Box mode, monitoring, password changes, time changes, and normalization are available, but parameter editing is not. Save changes with Save and Configure Device, then refresh status.';
  }
  if (has(text, 'status', 'reading', 'refresh', 'monitor')) {
    return 'Open a detector to view its status, including mode, aspirator RPM, airflow, temperature, smoke level, and channel obscuration. Tap Refresh for current readings. Auto Refresh updates the page every five seconds.';
  }
  if (has(text, 'log', 'event', 'report')) {
    return 'Open Logs on the detector to review alarms, faults, alerts, system activity, and user actions. Scroll down and tap Load More for older events. Use the three-dot menu to generate and share a text report (password required), or clear logs.';
  }
  if (has(text, 'test', 'self test')) {
    return 'Open the detector, tap More, then Perform Device Test and Begin Test. The app checks LED colors and status indicators: seven checks for single-channel detectors and ten for double-channel detectors. Tap Pass or Fail within 30 seconds based on the detector LEDs. Follow the product guide and site safety procedures.';
  }
  if (has(text, 'template')) {
    return 'From the detector list, open the three-dot menu and choose Create Template. Name it, select a channel, configure parameters, and export/share it. To import one, connect to the target detector, open Configure Device, then use the three-dot menu to import the template.';
  }
  if (has(text, 'password')) {
    return 'The installer provides the detector password. To change it, open the detector, choose More > Configure Device, enter the old password, select Tap to Change, enter and confirm the new password, then Save and Configure Device.';
  }
  if (has(text, 'disconnect')) {
    return 'Open the detector’s three-dot menu and tap Disconnect, then confirm. Disconnect the current detector before connecting to another; only one can be connected at a time.';
  }
  return 'I can help with app flow, projects, sites, panels, FAAST FLEX devices, Bluetooth pairing, detector status, logs, configuration, tests, and templates. Try asking one of those in a different way.';
}
