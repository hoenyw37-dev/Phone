import React, { useEffect, useRef, useState } from 'react';
import {
  ActivityIndicator,
  FlatList,
  KeyboardAvoidingView,
  Platform,
  SafeAreaView,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from 'react-native';
import { useDatabase } from '../global/DatabaseContext';
import { ProjectEntity } from '../app/base/projects/dataAccess/projectEntity';
import { PanelEntity } from '../app/powerstrike/features/panels/dataAccess/panelEntity';
import { DeviceEntity } from '../app/faastflex/dataAccess/deviceAccess/deviceEntity';
import { answerChatbotQuestion, ChatbotData } from './chatbotAnswers';

type Message = { id: string; text: string; from: 'bot' | 'user' };

export default function ChatbotScreen() {
  const { dataSource } = useDatabase();
  const [messages, setMessages] = useState<Message[]>([
    { id: 'welcome', from: 'bot', text: 'Hello! What can I do for you today? Ask about app steps or your saved sites, projects, panels, and devices.' },
  ]);
  const [question, setQuestion] = useState('');
  const [data, setData] = useState<ChatbotData>();
  const [loading, setLoading] = useState(true);
  const listRef = useRef<FlatList<Message>>(null);

  useEffect(() => {
    let active = true;
    const load = async () => {
      try {
        const [projects, panels, devices] = await Promise.all([
          dataSource.manager.find(ProjectEntity),
          dataSource.manager.find(PanelEntity),
          dataSource.manager.find(DeviceEntity),
        ]);
        if (active) setData({ projects, panels, devices });
      } catch (error) {
        console.warn('Chatbot could not load app records', error);
      } finally {
        if (active) setLoading(false);
      }
    };
    load();
    return () => { active = false; };
  }, [dataSource]);

  const send = () => {
    const text = question.trim();
    if (!text) return;
    const reply = answerChatbotQuestion(text, data);
    setMessages(current => [
      ...current,
      { id: `${Date.now()}-user`, from: 'user', text },
      { id: `${Date.now()}-bot`, from: 'bot', text: reply },
    ]);
    setQuestion('');
    setTimeout(() => listRef.current?.scrollToEnd({ animated: true }), 80);
  };

  return (
    <SafeAreaView style={styles.safe}>
      <KeyboardAvoidingView style={styles.container} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
        <View style={styles.header}>
          <Text style={styles.title}>App Assistant</Text>
          <Text style={styles.subtitle}>{loading ? 'Loading saved app details…' : 'Manual help and saved app details'}</Text>
        </View>
        <FlatList
          ref={listRef}
          style={styles.list}
          contentContainerStyle={styles.messages}
          data={messages}
          keyExtractor={item => item.id}
          renderItem={({ item }) => (
            <View style={[styles.bubble, item.from === 'user' ? styles.userBubble : styles.botBubble]}>
              <Text style={[styles.message, item.from === 'user' && styles.userMessage]}>{item.text}</Text>
            </View>
          )}
        />
        {loading ? <ActivityIndicator style={styles.loader} color="#1677c8" /> : null}
        <View style={styles.composer}>
          <TextInput
            value={question}
            onChangeText={setQuestion}
            onSubmitEditing={send}
            placeholder="Ask about the app…"
            placeholderTextColor="#7b8794"
            returnKeyType="send"
            style={styles.input}
          />
          <TouchableOpacity accessibilityRole="button" onPress={send} style={styles.sendButton}>
            <Text style={styles.sendText}>Send</Text>
          </TouchableOpacity>
        </View>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: '#f4f6f8' },
  container: { flex: 1 },
  header: { backgroundColor: '#101010', paddingHorizontal: 20, paddingVertical: 16 },
  title: { color: '#fff', fontSize: 20, fontWeight: '700' },
  subtitle: { color: '#d6dce2', fontSize: 13, marginTop: 4 },
  list: { flex: 1 },
  messages: { padding: 16, gap: 10 },
  bubble: { maxWidth: '88%', borderRadius: 14, paddingHorizontal: 13, paddingVertical: 10 },
  botBubble: { alignSelf: 'flex-start', backgroundColor: '#fff', borderWidth: 1, borderColor: '#e1e5e9' },
  userBubble: { alignSelf: 'flex-end', backgroundColor: '#1677c8' },
  message: { color: '#17212b', fontSize: 15, lineHeight: 21 },
  userMessage: { color: '#fff' },
  loader: { alignSelf: 'flex-start', marginHorizontal: 20, marginBottom: 8 },
  composer: { flexDirection: 'row', gap: 8, padding: 12, backgroundColor: '#fff', borderTopWidth: 1, borderTopColor: '#e1e5e9' },
  input: { flex: 1, minHeight: 44, maxHeight: 110, borderWidth: 1, borderColor: '#d5dce3', borderRadius: 10, paddingHorizontal: 12, color: '#17212b' },
  sendButton: { alignSelf: 'center', backgroundColor: '#1677c8', borderRadius: 10, paddingHorizontal: 16, paddingVertical: 12 },
  sendText: { color: '#fff', fontWeight: '700' },
});
